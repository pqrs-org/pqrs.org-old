/* KallistiOS 1.1.8

   sys/types.h
   (c)2002 Dan Potter

   $Id: types.h,v 1.1 2002/04/20 22:08:43 bardtx Exp $

*/

#ifndef __SYS_TYPES_H
#define __SYS_TYPES_H

#include <sys/cdefs.h>
__BEGIN_DECLS

#include <arch/types.h>

__END_DECLS

#endif	/* __SYS_TYPES_H */

