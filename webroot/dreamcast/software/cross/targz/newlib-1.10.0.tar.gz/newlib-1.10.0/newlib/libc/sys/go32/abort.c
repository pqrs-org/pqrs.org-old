
void
abort()
{
  
  exit(1);
  
}
