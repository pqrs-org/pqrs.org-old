
#include <sys/types.h>

getuid()
{
  
  return 10;
  
}
