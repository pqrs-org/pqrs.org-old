#include <_ansi.h>

char *
_DEFUN(_user_strerror, (errnum),
       int errnum)
{
  return 0;
}
