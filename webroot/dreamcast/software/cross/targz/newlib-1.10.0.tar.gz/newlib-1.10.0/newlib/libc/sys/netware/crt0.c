/* I have a copy of something that would serve as a NetWare crt0.o,
   but it is copyright by Novell.  */

int _dummy_crt0 = 1;
