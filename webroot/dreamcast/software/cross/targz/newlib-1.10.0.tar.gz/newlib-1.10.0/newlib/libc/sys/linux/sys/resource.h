/* libc/sys/linux/sys/resource.h - Resource usage */

/* Written 2000 by Werner Almesberger */


#ifndef _SYS_RESOURCE_H
#define _SYS_RESOURCE_H

#include <sys/types.h>
#include <linux/resource.h>

#endif
