#include "gnuboy.h"
#include <kos.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *strdup();

#include <stdarg.h>
#include <signal.h>

#include "input.h"
#include "rc.h"


#include "Version"
#include "sys/dc/dc_utils.h"
#include "sys/dc/dc_menu.h"

static uint16 startup_image[320 * 240];
static uint16 menu_image[320 * 240];
static uint16 credits_image[320 * 240];
static uint16 options_image[320 * 240];

static char *defaultconfig[] =
{
	"bind esc quit",
	"bind up +up",
	"bind down +down",
	"bind left +left",
	"bind right +right",
	"bind d +a",
	"bind s +b",
	"bind enter +start",
	"bind space +select",
	"bind tab +select",
	"bind joyup +up",
	"bind joydown +down",
	"bind joyleft +left",
	"bind joyright +right",
	"bind joy0 +b",
	"bind joy1 +a",
	"bind joy2 +select",
	"bind joy3 +start",
	"bind 1 \"set saveslot 1\"",
	"bind 2 \"set saveslot 2\"",
	"bind 3 \"set saveslot 3\"",
	"bind 4 \"set saveslot 4\"",
	"bind 5 \"set saveslot 5\"",
	"bind 6 \"set saveslot 6\"",
	"bind 7 \"set saveslot 7\"",
	"bind 8 \"set saveslot 8\"",
	"bind 9 \"set saveslot 9\"",
	"bind 0 \"set saveslot 0\"",
	"bind ins savestate",
	"bind del loadstate",
	"source gnuboy.rc",
	NULL
};


static void banner()
{
	printf("\ngnuboy " VERSION "\n");
}

static void copyright()
{
	banner();
	printf(
"Copyright (C) 2000-2001 Laguna and Gilgamesh\n"
"Portions contributed by other authors; see CREDITS for details.\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
"\n");
}

static void usage(char *name)
{
	copyright();
	printf("Type %s --help for detailed help.\n\n", name);
	exit(1);
}

static void copying()
{
	copyright();
	exit(0);
}

static void help(char *name)
{
	banner();
	printf("Usage: %s [options] romfile\n", name);
	printf("\n"
"      --source FILE             read rc commands from FILE\n"
"      --bind KEY COMMAND        bind KEY to perform COMMAND\n"
"      --VAR=VALUE               set rc variable VAR to VALUE\n"
"      --VAR                     set VAR to 1 (turn on boolean options)\n"
"      --no-VAR                  set VAR to 0 (turn off boolean options)\n"
"      --showvars                list all available rc variables\n"
"      --help                    display this help and exit\n"
"      --version                 output version information and exit\n"
"      --copying                 show copying permissions\n"
"");
	exit(0);
}


static void version(char *name)
{
	printf("%s-" VERSION "\n", name);
	exit(0);
}


void doevents()
{
	event_t ev;
	int st;

	ev_poll();
	while (ev_getevent(&ev))
	{
		if (ev.type != EV_PRESS && ev.type != EV_RELEASE)
			continue;
		st = (ev.type != EV_RELEASE);
		rc_dokey(ev.code, st);
	}
}




static int bad_signals[] =
{
	/* These are all standard, so no need to #ifdef them... */
	SIGINT, SIGSEGV, SIGTERM, SIGFPE, SIGABRT, SIGILL,
#ifdef SIGQUIT
	SIGQUIT,
#endif
#ifdef SIGPIPE
	SIGPIPE,
#endif
	0
};


static char *base(char *s)
{
	char *p;
	p = strrchr(s, '/');
	if (p) return p+1;
	return s;
}


static void
run_game(const char *filename)
{
  char *rom;
  
  dc_vid_empty ();
  
  exit_game_loop = 0;
  
  gb_vid_init();
  pcm_init();
  
  rom = strdup (filename);
  
  sys_sanitize(rom);
  loader_init(rom);
  
  emu_reset();
  emu_run ();
  
  loader_unload ();
  
  gb_vid_close();
  pcm_close();
}


static void
draw_main_menu ()
{
  display_rawimage (menu_image);
}


static char last_romfile[256];

static void
do_rom_menu_and_run () 
{
  fm_result_t result;
  char *p;
  char last_romfile_dir[256];
  fm_config_t fm_config;
  
  sprintf (last_romfile_dir, "%s", last_romfile);
  p = strrchr(last_romfile_dir, '/');
  *p = '\0';
  
  fm_config.vertical_wait = 80;
  fm_config.horizontal_wait = 80;
  fm_config.root_path = "/cd";
  if (do_file_menu (&result, last_romfile_dir, &fm_config))
  {
    run_game (result.path);
    sprintf (last_romfile, "%s", result.path);
  }
}



static void
load_main_menu ()
{
  cont_cond_t cont;

#if 0  
  draw_main_menu_vmu_icon ();
#endif
  
  for (;;) 
  {
    cont_get_cond (dc_controller_addr[0], &cont);
    
    if (cont.rtrig && cont.ltrig && 
	!(cont.buttons & CONT_Y) &&
	!(cont.buttons & CONT_START))
      break;
    
    if (!(cont.buttons & CONT_A)) 
    {
      do_rom_menu_and_run ();
#if 0
      draw_main_menu_vmu_icon ();
#endif
    }
    
#if 0
    if (!(cont.buttons & CONT_X)) 
      do_main_options ();
    
    if (!(cont.buttons & CONT_Y)) 
      do_credits ();
    
    if (!(cont.buttons & CONT_B)) 
    {
      do_vmu_menu (mvmu);
      draw_main_menu_vmu_icon ();
    }
#endif
    
    draw_main_menu ();
    dc_vid_flip (draw_type_fullscreen);
  }
}


static void
draw_startup_image (const char *string)
{
  display_rawimage (startup_image);
#ifdef __DC_PAL__
  draw_string(10, 200, _white, _black, "gnuboy/DC 1.0.3-0.2-PAL");
#else
  draw_string(10, 200, _white, _black, "gnuboy/DC 1.0.3-0.2");
#endif
  draw_string(10, 210, _white, _none, string);
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
}


int main()
{
	int i;
	
	kos_init_all(IRQ_ENABLE, NULL);
	dc_vid_init ();

	dc_maple_controller_init ();

        load_bmp (startup_image, "/cd/pics/startup.bmp");
        
        draw_startup_image ("startup");
        load_bmp (menu_image, "/cd/pics/menu.bmp");
        draw_startup_image ("startup.");
        load_bmp (credits_image, "/cd/pics/credits.bmp");
        draw_startup_image ("startup..");
        load_bmp (options_image, "/cd/pics/options.bmp");
        draw_startup_image ("startup...");
        init_menus ();
        
        sprintf (last_romfile, "/cd/gb/default.gb");
        
	rc_bindkey ("enter", "+start");
	rc_bindkey ("space", "+select");
	rc_bindkey ("ctrl", "+b");
	rc_bindkey ("alt", "+a");
	rc_bindkey ("up", "+up");
	rc_bindkey ("down", "+down");
	rc_bindkey ("left", "+left");
	rc_bindkey ("right", "+right");
	
	/* If we have special perms, drop them ASAP! */
	gb_vid_preinit();
	init_exports();
        
        load_main_menu ();
        
	kos_shutdown_all ();
	return 0;
}











