#ifndef __GNUBOY_H
#define __GNUBOY_H

extern int exit_game_loop;

void gb_vid_init();
void gb_vid_preinit();
void gb_vid_close();

void emu_init();
void emu_reset();
void emu_run();

void ev_poll();
void rc_dokey(int key, int st);

void pcm_init();
void pcm_close();
int pcm_submit();

void init_exports();

void loader_init(char *s);

void *sys_timer();
int sys_elapsed(void *p);
void sys_sleep(int us);
void sys_initpath();
void sys_sanitize(char *s);

#endif
