/* KallistiOS ##version##

   maple_globals.c
   (c)2002 Dan Potter
 */

#include <dc/maple.h>

CVSID("maple_globals.c,v 1.1 2002/02/22 07:34:20 bardtx Exp");

/* Global state info */
maple_state_t	maple_state;

