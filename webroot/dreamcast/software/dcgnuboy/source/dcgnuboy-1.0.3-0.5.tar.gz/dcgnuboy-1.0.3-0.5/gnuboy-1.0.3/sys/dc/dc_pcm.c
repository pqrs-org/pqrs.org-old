#include <stdlib.h>
#include "dc_sound.h"
#include <dc/g2bus.h>

#include "defs.h"
#include "pcm.h"
#include "rc.h"


/* SOUND_BUF_LEN = 2 * (rate * buffer_length_in_frames / 60.0) * (bit / 8) */
/* (format "%x" ((lambda (x) (* 2 (/ (* 44100 x) 60) (/ 16 8))) 3)) */
/* NOTE: AICA require 32-bit (or higher) alignment. */
#define SAMPLE_RATE 44100
#define SAMPLE_BITS 16
#define SOUND_BUF_LEN 0x4000

struct pcm pcm;

static uint8 buf[SOUND_BUF_LEN * 2] __attribute__ ((aligned (32)));

rcvar_t pcm_exports[] =
{
	RCV_END
};


static const uint32 base = 0xa0800000 + 0x11000;

uint32 pcm_rest;

void pcm_write ()
{
	static uint32 dst = base;
	uint8 *src = pcm.buf; 
	uint32 length = pcm.pos * 2;
	uint32 pos = base + dc_sound_get_position () * (SAMPLE_BITS / 8);
	uint32 available = 0;
	
	while (available < length)
	{
		pos = base + dc_sound_get_position () * (SAMPLE_BITS / 8);
		if (dst < pos) 
			available = pos - dst;
		else
			available = SOUND_BUF_LEN - (dst - pos);
	}
        
	if (length & 0x3)
	{
		pcm.buf[pcm.pos] = pcm.buf[pcm.pos - 1];
		length = (length >> 2) + 1;
	}
	else
	{
		length = length >> 2;
	}
	
	while (length > 8)
	{
		g2_write_block_32((uint32*)src, dst, 8);
		g2_fifo_wait();
		
		src += 8 * 4;
		dst += 8 * 4;
		
		if (base + SOUND_BUF_LEN <= dst)
			dst = base;
		length -= 8;
	}
	if (length > 0) 
	{
		g2_write_block_32((uint32*)src, dst, length);
		g2_fifo_wait();
		dst += length * 4;
		if (base + SOUND_BUF_LEN <= dst)
			dst = base;
	}
	
}


void pcm_clear_buffer()
{
	spu_memset (dc_sound_get_baseaddr (), 0, SOUND_BUF_LEN);
}

void pcm_init()
{
	pcm.hz = SAMPLE_RATE;
	pcm.stereo = 0;
        pcm.len = SOUND_BUF_LEN / 2 / sizeof(buf[0]);
	pcm.buf = buf;
	pcm.pos = 0;
	
	pcm_clear_buffer ();
	dc_sound_init (SAMPLE_RATE, SAMPLE_BITS, SOUND_BUF_LEN);
}

void pcm_close()
{
	dc_sound_shutdown ();
}


int pcm_submit()
{
	if (pcm.len < pcm.pos)
		return 0;
	
	pcm_write ();
	pcm.pos = 0;
	
	return 1;
}

