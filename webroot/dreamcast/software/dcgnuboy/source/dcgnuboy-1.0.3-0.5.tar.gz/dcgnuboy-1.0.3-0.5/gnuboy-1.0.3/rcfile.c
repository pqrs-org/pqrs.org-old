


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "defs.h"
#include "rc.h"
#include "hw.h"


rcvar_t rcfile_exports[] =
{
	RCV_END
};


