/* sys/nix/config.h.  Generated automatically by configure.  */


/* #undef WORDS_BIGENDIAN */
/* #undef SIZEOF_SHORT */
/* #undef SIZEOF_INT */
/* #undef SIZEOF_LONG */

#define HAVE_USLEEP 1
/* #undef HAVE_SELECT */

/* #undef HAVE_MMAP */

#define HAVE_LIBXEXT 1
/* #undef HAVE_X11_EXTENSIONS_XSHM_H */
#define HAVE_SYS_IPC_H 1
#define HAVE_SYS_SHM_H 1

/* #undef HAVE_SYS_SOUNDCARD_H */
/* #undef HAVE_SOUNDCARD_H */



