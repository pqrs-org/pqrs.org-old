/* KallistiOS ##version##

   errno.c
   (c)2002 Dan Potter

   errno.c,v 1.1 2002/03/04 06:09:18 bardtx Exp
*/

#include <sys/cdefs.h>

CVSID("errno.c,v 1.1 2002/03/04 06:09:18 bardtx Exp");

int errno = 0;
