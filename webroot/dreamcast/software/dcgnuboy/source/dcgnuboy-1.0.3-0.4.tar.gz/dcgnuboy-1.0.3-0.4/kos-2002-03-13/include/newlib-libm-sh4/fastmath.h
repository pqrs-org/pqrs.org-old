#ifndef _FASTMATH_H_
#ifdef __cplusplus
extern "C" {
#endif
#define _FASTMATH_H_

#include <newlib-libm-sh4/math.h>
#include <newlib-libm-sh4/machine/fastmath.h>

#ifdef __cplusplus
}
#endif
#endif /* _FASTMATH_H_ */
