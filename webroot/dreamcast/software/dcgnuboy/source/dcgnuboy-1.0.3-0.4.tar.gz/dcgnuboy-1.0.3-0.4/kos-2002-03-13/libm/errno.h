#ifndef __ERRNO_H
#define __ERRNO_H

#define EDOM -1
#define ERANGE -2
extern int errno;

#endif
