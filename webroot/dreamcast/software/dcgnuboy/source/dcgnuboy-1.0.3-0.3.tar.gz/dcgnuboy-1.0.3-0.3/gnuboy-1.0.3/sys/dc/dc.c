/*
 * dc.c
 * Dreamcast interfaces -- based on svga.c 
 *
 * Takayama Fumihiko <tekezo@catv296.ne.jp>
 *
 * Licensed under the GPLv2, or later.
 */

#include <stdlib.h>
#include <stdio.h>

#include "fb.h"
#include "input.h"
#include "rc.h"

#include "dc_utils.h"
#include "gnuboy.h"



struct fb fb;

static int vmode[3] = { 0, 0, 8 };
static int svga_mode;
static int svga_vsync = 1;

rcvar_t vid_exports[] =
{
	RCV_VECTOR("vmode", vmode, 3),
	RCV_INT("vsync", &svga_vsync),
	RCV_INT("svga_mode", &svga_mode),
	RCV_END
};


void *sys_timer()
{
}


int sys_elapsed(void *p)
{
}


void sys_sleep(int us)
{
}


void sys_checkdir(char *path, int wr)
{
}


void sys_initpath()
{
}


void sys_sanitize(char *s)
{
}


/* keymap - mappings of the form { scancode, localcode } - from pc/keymap.c */
extern int keymap[][2];

static int mapscancode(int scan)
{
	int i;
	for (i = 0; keymap[i][0]; i++)
		if (keymap[i][0] == scan)
			return keymap[i][1];
	return 0;
}

static void kbhandler(int scan, int state)
{
	event_t ev;
	ev.type = state ? EV_PRESS : EV_RELEASE;
	ev.code = mapscancode(scan);
	ev_postevent(&ev);
}

int *rc_getvec();


void gb_vid_preinit()
{
}

void gb_vid_init()
{
	fb.w = 160;
	fb.h = 144;
	fb.pelsize = 2;
	fb.pitch = 320 * 2;
	fb.ptr = dc_get_screen ();
	fb.enabled = 1;
	fb.dirty = 1;
	
	fb.indexed = 0;
	fb.cc[0].r = fb.cc[2].r = 3;
	fb.cc[1].r = 2;
	fb.cc[0].l = 11;
	fb.cc[1].l = 5;
	fb.cc[2].l = 0;
}


void gb_vid_close()
{
}

void vid_settitle(char *title)
{
}

void vid_setpal(int i, int r, int g, int b)
{
}

void vid_begin()
{
	fb.ptr = dc_get_screen ();
}

extern uint32 pcm_rest;
void vid_end()
{
	dc_vid_flip (draw_type_gb_fullscreen);
}

void kb_init()
{
}

void kb_close()
{
}

void kb_poll()
{
}


rcvar_t joy_exports[] =
{
	RCV_END
};

void joy_init()
{
}

void joy_close()
{
}

void joy_poll()
{
}


int is_statesave_available = 0;


void unlink_quickstate ()
{
	is_statesave_available = 0;
}


static void
draw_quick_menu ()
{
  dc_vid_clear ();
  
  draw_string (80,  30,   _white,  _black, "QUICK SAVE MENU");
  draw_string (100, 60,   _green,  _black, "Y: ");
  draw_string (10,  100,  _yellow, _black, "X: Quick save");
  draw_string (130, 100,  _blue,   _black, "B: Return to game");
  draw_string (100, 140,  _red,    _black, "A: Quick load");
}


static void 
do_quick_menu ()
{
  cont_cond_t cont;
  
  pcm_clear_buffer ();
  
  draw_quick_menu ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  wait_until_release_trigger (dc_controller_addr[0]);
  
  for (;;) 
  {
    cont_get_cond (dc_controller_addr[0], &cont);
    
    if (!(cont.buttons & CONT_B))
    {
      timer_sleep (100);
      break;
    }
    
    if (!(cont.buttons & CONT_X))
    {
      FILE *fp; 
      
      draw_quick_menu ();
      draw_string (100, 200, _white, _black, "save...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      fp = fopen ("/md/quick", "w");
      savestate (fp);
      fclose (fp);
      is_statesave_available = 1;
      
      draw_quick_menu ();
      draw_string (100, 200, _white, _black, "save...done");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    if (!(cont.buttons & CONT_A))
    {
      FILE *fp;
      
      draw_quick_menu ();
      draw_string (100, 200, _white, _black, "load...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      draw_quick_menu ();
      if (is_statesave_available)
      {
	fp = fopen ("/md/quick", "r");
	loadstate (fp);
	fclose (fp);
	
	draw_string (100, 200, _white, _black, "load...done");
      }
      else
      {
	draw_string (100, 200, _red, _black, "load...failed");
      }
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    draw_quick_menu ();
    dc_vid_flip (draw_type_fullscreen);
  }
  
  dc_vid_empty ();
}


static void
draw_save_menu ()
{
  dc_vid_clear ();
  
  draw_string (80,  30,   _white,  _black, "VMU MENU");
  draw_string (100, 60,   _green,  _black, "Y: ");
  draw_string (10,  100,  _yellow, _black, "X: State save");
  draw_string (130, 100,  _blue,   _black, "B: Return to game");
  draw_string (100, 140,  _red,    _black, "A: State load");
}


static void
do_save_menu ()
{
  cont_cond_t cont;
  
  pcm_clear_buffer ();
  
  draw_save_menu ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  wait_until_release_trigger (dc_controller_addr[0]);
  
  for (;;) 
  {
    cont_get_cond (dc_controller_addr[0], &cont);
    
    if (!(cont.buttons & CONT_B))
    {
      timer_sleep(100);
      break;
    }
    
    if (!(cont.buttons & CONT_X))
    {
      draw_save_menu ();
      draw_string (100, 200, _white, _black, "save...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      draw_save_menu ();
      if (statesave_to_vmu ())
      {
	is_statesave_available = 1;
	draw_string (100, 200, _white, _black, "save...done");
      }
      else
	draw_string (100, 200, _red, _black, "save...failed");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    if (!(cont.buttons & CONT_A))
    {
      draw_save_menu ();
      draw_string (100, 200, _white, _black, "load...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      draw_save_menu ();
      if (stateload_from_vmu ())
      {
	is_statesave_available = 1;
	draw_string (100, 200, _white, _black, "load...done");
      }
      else
	draw_string (100, 200, _red, _black, "load...failed");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    draw_save_menu ();
    dc_vid_flip (draw_type_fullscreen);
  }
  
  dc_vid_empty ();
}


void ev_poll()
{
  cont_cond_t cont;
  event_t ev;
  
  cont_get_cond (dc_controller_addr[0], &cont);
  
  if (cont.rtrig) 
  {
    if (cont.ltrig && !(cont.buttons & CONT_START))
    {
      exit_game_loop = 1;
      return;
    }
    else if (!(cont.buttons & CONT_B))
    {
      do_quick_menu();
      return;
    }
    else if (!(cont.buttons & CONT_Y))
    {
      do_save_menu ();
      return;
    }
  }
  
  /* start */
  ev.code = K_ENTER;
  if (cont.buttons & CONT_START) 
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
    
  /* select */
  ev.code = K_SPACE;
  if (cont.buttons & CONT_Y)
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
    
  /* b */
  ev.code = K_CTRL;
  if (cont.buttons & CONT_X)
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
    
  /* a */
  ev.code = K_ALT;
  if (cont.buttons & CONT_A)
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
    
  /* up */
  ev.code = K_UP;
  if (cont.buttons & CONT_DPAD_UP)
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
    
  /* down */
  ev.code = K_DOWN;
  if (cont.buttons & CONT_DPAD_DOWN)
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
    
  /* left */
  ev.code = K_LEFT;
  if (cont.buttons & CONT_DPAD_LEFT)
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
    
  /* right */
  ev.code = K_RIGHT;
  if (cont.buttons & CONT_DPAD_RIGHT)
    ev.type = EV_RELEASE;
  else
    ev.type = EV_PRESS;
  ev_postevent (&ev);
}  


