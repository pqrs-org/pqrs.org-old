/*
** thinlib (c) 2001 Matthew Conte (matt@conte.com)
**
**
** tl_prof.h
**
** Screen border color profiler.
**
** tl_prof.h,v 1.1.1.1 2002/04/09 14:41:22 tekezo Exp
*/

#ifndef _TL_PROF_H_
#define _TL_PROF_H_

extern void thin_prof_setborder(int pal_index);

#endif /* !_TL_PROF_H_ */

/*
** tl_prof.h,v
** Revision 1.1.1.1  2002/04/09 14:41:22  tekezo
**
**
*/
