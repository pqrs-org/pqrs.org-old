#ifndef __GNUBOY_H
#define __GNUBOY_H

#include <stdio.h>

extern int exit_game_loop;

/* sys/dc/dc.c */
void gb_vid_init();
void gb_vid_preinit();
void gb_vid_close();

void emu_init();
void emu_reset();
void emu_run();

void ev_poll();
void rc_dokey(int key, int st);

void pcm_init();
void pcm_clear_buffer();
void pcm_close();
int pcm_submit();

void unlink_quickstate ();

/* exports.c */
void init_exports();

/* loader.c */
void loader_init(char *s);
int stateload_from_vmu ();
int statesave_to_vmu ();

/* sys/ */
void *sys_timer();
int sys_elapsed(void *p);
void sys_sleep(int us);
void sys_initpath();
void sys_sanitize(char *s);
void unlink_quickstate ();

/* save.c */
void loadstate(FILE *f);
void savestate(FILE *f);
#if 0
int get_max_statefile_size ();
#else
extern const int max_statefile_size;
#endif

/* inflate.c */
int unzip (const unsigned char *data, long *p,
           void (* callback) (unsigned char d));


#endif
