/* 2001 Takayama Fumihiko <tekezo@catv296.ne.jp> */

/* This code is for nes/libsnss. */
/* I wish someone write real MFS for KOS. */

#ifndef _DC_MFS_H_
#define _DC_MFS_H_

#include "types.h"

#define _DC_MFS_STDIO_
#ifdef _DC_MFS_STDIO_
#define M_FILE FILE
#define m_open fopen
#define m_close fclose
#define m_read fread
#define m_write fwrite
#define m_seek fseek
#define m_tell ftell
#define m_getc fgetc
#define m_putc fputc
#define EOF (-1)
#endif

/* SEEK_SET, SEEK_CUR, SEEK_END are defined at kos/include/kos/fs.h. */

typedef enum {
  READ = 0x1,
  WRITE = 0x2
} M_OPEN_MODE;

typedef struct {
  void *quick_slot;
  uint32 mode;
} M_FILE;


#ifdef __cplusplus
extern "C" {
#endif

void m_init();
void m_clear();

M_FILE *m_open(const char *path, const char *mode);
int m_close(M_FILE *stream);
size_t m_read(void *ptr, size_t size, size_t nmemb, M_FILE *stream);
size_t m_write(void *ptr, size_t size, size_t nmemb, M_FILE *stream);
int m_seek(M_FILE *stream, int32 offset, int whence);
int m_tell(M_FILE *stream);
size_t m_size(M_FILE *stream);
int m_getc(M_FILE *stream);
int m_putc(int c, M_FILE *stream);


#ifdef __cplusplus
}
#endif

#endif


