#include "dc_menu.h"
#include "dc_utils.h"
#include "dc_mfs.h"
#include "vmu.h"

/* ============================================================ */
static int init_rom_menu ();
static int init_vmu_menu ();
static int init_vmu_select_menu ();

int
init_menus ()
{
  init_rom_menu ();
  init_vmu_menu ();
  init_vmu_select_menu ();
  
  return 1;
}


/* ============================================================ */
#define MAX_ROM_FILES 2048
struct {
  char name[256];
  char path[256];
  int filesize;
} rom_files[MAX_ROM_FILES];
static const int draw_rom_files_line_default = 20;

static uint8 rom_menu_bmp[240 * 320 * 3];
static uint8 rom_menu_no_games_bmp[240 * 320 * 3];
static int
init_rom_menu ()
{
  load_bmp (rom_menu_bmp, "/cd/pics/menu_selection.bmp");
  load_bmp (rom_menu_no_games_bmp, "/cd/pics/nogamecd.bmp");
  return 1;
}


static void
draw_rom_files (int base_pos, int cur_pos, int num_roms, int draw_lines) 
{
  int i;
  int y_pos = 10;
  int x_pos = 75;
  int line;
  int ndraw;
  
  if (num_roms < draw_lines)
    ndraw = num_roms;
  else
    ndraw = draw_lines;
  
  display_bmp(rom_menu_bmp);
  
  line = base_pos;
  for (i = 0; i < ndraw; ++i)
  {
    if (line >= num_roms)
      line = 0;
    
    uint16 fg_color = cur_pos == line ? _yellow : _white;
    draw_string (x_pos, y_pos, fg_color, _none, rom_files[line].name);
    ++line;
    y_pos += 10;
  }
  
  timer_sleep (50);
}


const char *
do_rom_menu() 
{
  int i;
  file_t d; 
  dirent_t *de;
  
  int base_pos = 0;
  int cur_pos = 0;
  int cur_row = 0;
  int num_roms = 0;
  int draw_lines = draw_rom_files_line_default;
  uint8 mcont1;
  cont_cond_t cont_out;
  
  mcont1 = maple_first_controller ();
  
  display_bmp(rom_menu_bmp);
  draw_string (75, 75, _white, _none, "Now loading");
  dc_flip ();
  
  /* call ioctl for Per-disc initialization */
  iso_ioctl(0, NULL, 0);
  timer_sleep(200);
  d = fs_open("/cd/games", O_RDONLY | O_DIR);
  while (!d) 
  {
    display_bmp (rom_menu_no_games_bmp);
    dc_flip ();
    
    for (;;)
    {
      cont_get_cond (mcont1, &cont_out);
      if ((cont_out.buttons & CONT_A) == 0)
	break;
      timer_sleep (50);
    }
    timer_sleep (50);
    
    /* call ioctl for Per-disc initialization */
    iso_ioctl(0, NULL, 0);
    timer_sleep(200);
    d = fs_open ("/cd/games", O_RDONLY | O_DIR);
  }
  
  memset(rom_files, 0, sizeof(rom_files));
  for (i = 0; i < MAX_ROM_FILES; ++i)
  {
    de = fs_readdir (d);
    if (!de) 
      break;
    
    strcpy (rom_files[i].name, de->name);
    sprintf (rom_files[i].path, "/cd/games/%s", de->name);
    rom_files[i].filesize = de->size;
    ++num_roms;
  }
  fs_close (d);
  
  if (num_roms == 0) 
  {
    dc_put_error ("There are no games in the GAMES directory");
    return NULL;
  }
  
  draw_lines = draw_rom_files_line_default;
  if (num_roms < draw_lines)
    draw_lines = num_roms;
  
  draw_rom_files (base_pos, cur_pos, num_roms, draw_lines);
  dc_flip ();
  for (;;) 
  {
    cont_get_cond (mcont1, &cont_out);
    
    if (!(cont_out.buttons & CONT_DPAD_UP))
    {
      if (cur_row > 0)
	--cur_row;
      else
      {
	if (base_pos == 0)
	  base_pos = num_roms - 1;
	else
	  --base_pos;
      }
      if (cur_pos == 0) 
	cur_pos = num_roms - 1;
      else
	--cur_pos;
    }
    else if (!(cont_out.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_row < draw_lines - 1)
	++cur_row;
      else
      {
	if (base_pos >= num_roms - 1)
	  base_pos = 0;
	else
	  ++base_pos;
      }
      if (cur_pos >= num_roms - 1)
	cur_pos = 0;
      else
	++cur_pos;
    }
    else if (!(cont_out.buttons & CONT_DPAD_LEFT)) 
    {
      for (i = 0; i < draw_lines; ++i)
      {
	if (base_pos == 0)
	  base_pos = num_roms - 1;
	else
	  --base_pos;
      	if (cur_pos == 0) 
	  cur_pos = num_roms - 1;
	else
	  --cur_pos;
      }
    } 
    else if (!(cont_out.buttons & CONT_DPAD_RIGHT)) 
    {
      for (i = 0; i < draw_lines; ++i)
      {
	if (base_pos == (num_roms - 1))
	  base_pos = 0;
	else
	  ++base_pos;
	if (cur_pos == (num_roms - 1))
	  cur_pos = 0;
	else
	  ++cur_pos;
      }
    } 
    else if (!(cont_out.buttons & CONT_START)) 
      return rom_files[cur_pos].path;
    else if (cont_out.rtrig  & cont_out.ltrig) 
      return NULL;
    
    draw_rom_files (base_pos, cur_pos, num_roms, draw_lines);
    dc_flip ();
    if (cont_out.buttons & CONT_X)
      timer_sleep (20);
    else
    {
      cont_cond_t cont_out_prev;
      for (;;)
      {
	cont_out_prev = cont_out;
	cont_get_cond (mcont1, &cont_out);
	if (cont_out_prev.buttons != cont_out.buttons)
	  break;
	timer_sleep (50);
      }
      timer_sleep (20);
    }
  }
  timer_sleep (50);
  
  dc_vid_clear ();
  dc_flip ();
}


/* ============================================================ */
typedef struct {
  char desc_long[64];
  char filename[32];
  uint8 filesize;
  uint8 filetype;
  boolean selected;
} vmu_item;

#define MAX_VMU_FILES 256
static vmu_item vmu_files[MAX_VMU_FILES];

const int draw_vmu_files_line = 15;

static int 
init_vmu_menu ()
{
  return 1;
}


static void
draw_vmu_menu_help ()
{
  dc_vid_clear ();
  draw_string (80, 10, _white, _black, "VMU menu help");
  draw_string (60, 40, _white, _black, "L: select file");
  draw_string (60, 50, _white, _black, "R+Y: remove selected files");
  draw_string (60, 60, _white, _black, "L+R: exit VMU menu");
  draw_string (80, 200, _white, _black, "start: exit help");
}

static void
draw_vmu_files (int base_pos, int cur_pos, int free_blocks, int ndc_use_blocks)
{
  int nline;
  char str[128];
  int i;
  int x_pos = 10;
  int y_pos = 50;
  
  dc_vid_clear ();
  
  if (MAX_VMU_FILES - base_pos > draw_vmu_files_line)
    nline = draw_vmu_files_line;
  else
    nline = MAX_VMU_FILES - base_pos;
  
  draw_string (80, 10, _white, _black, "VMU menu");
  draw_string (10, 20, _white, _black, "press L+R to exit/press start to help");
  sprintf (str, "%d free/%d ndc use", free_blocks, ndc_use_blocks);
  draw_string (80, 30, _white, 0, str);
  for (i = base_pos; i < base_pos + nline; ++i)
  {
    if (vmu_files[i].filetype != 0x00)
    {
      uint16 fg_color = cur_pos == i ? _yellow : _white;
      uint16 bg_color = vmu_files[i].selected ? _blue : _black;
      
      sprintf(str, "%s(%d)", vmu_files[i].desc_long, vmu_files[i].filesize);
      draw_string (x_pos, y_pos, fg_color, bg_color, str);
      y_pos += 10;
    }
  }
}

extern const char *progname;

void
do_vmu_menu (uint8 addr)
{
  dirent_vmu entries[MAX_VMU_FILES];
  int num_entries;
  int i;
  int num_vmu_files;
  int base_pos = 0;
  int cur_pos = 0;
  int free_blocks;
  int ndc_use_blocks;
  cont_cond_t cont_out;
  uint8 mcont1;
  boolean pulling_ltrig = 0;
  boolean select_mode = 0;
  
  mcont1 = maple_first_controller ();
  dc_print ("reading VMU");

  /* setup entries */
  num_entries = MAX_VMU_FILES;
  if (ndc_vmu_getall_dirent (entries, &num_entries, addr) < 0)
    return;
  
  memset (vmu_files, 0, sizeof(vmu_files));
  num_vmu_files = 0;
  ndc_use_blocks = 0;
  for (i = 0; i < num_entries; ++i)
  {
    if (entries[i].filetype != 0x00)
    {
      char *p;
      uint8 buf[512];
      file_hdr_vmu *hdr = (file_hdr_vmu *)buf;
      
      if (ndc_vmu_read (addr, entries[i].firstblk, buf) < 0)
        continue;
      
      if (strcmp(hdr->app_id, progname))
        continue;
      
      p = vmu_files[num_vmu_files].desc_long;
      strncpy (p, hdr->desc_long, 32);
      p[32] = '\0';
      
      p = vmu_files[num_vmu_files].filename;
      strncpy (p, entries[i].filename, 12);
      p[12] = '\0';
      
      vmu_files[num_vmu_files].filesize = entries[i].filesize;
      vmu_files[num_vmu_files].filetype = entries[i].filetype;
      vmu_files[num_vmu_files].selected = 0;
      
      ndc_use_blocks += entries[i].filesize;
      
      ++num_vmu_files;
    }
  }
  free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
  
  /* draw lines */
  draw_vmu_files (base_pos, cur_pos, free_blocks, ndc_use_blocks);
  dc_flip ();
  for (;;)
  {
    cont_get_cond (mcont1, &cont_out);
    
    if (!(cont_out.buttons & CONT_DPAD_UP))
    {
      if (cur_pos > 0)
      {
        if (cur_pos == base_pos)
          --base_pos;
        --cur_pos;
      }
      if (pulling_ltrig)
        vmu_files[cur_pos].selected = select_mode;
    }
    else if (!(cont_out.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_pos < num_vmu_files - 1)
      {
        if (cur_pos == base_pos + draw_vmu_files_line - 1)
          ++base_pos;
        ++cur_pos;
      }
      if (pulling_ltrig)
        vmu_files[cur_pos].selected = select_mode;
    }
    else if (!(cont_out.buttons & CONT_Y) && cont_out.rtrig)
    {
      for (i = 0; i < num_vmu_files; ++i)
      {
        if (vmu_files[i].selected)
        {
          char str[128];
          sprintf(str, "remove %s", vmu_files[i].desc_long);
          dc_print (str);
          ndc_vmu_remove_file (addr, vmu_files[i].filename);
        }
      }
      break;
    }
    else if (!(cont_out.buttons & CONT_START))
    {
      boolean start_pressed;
      
      draw_vmu_menu_help ();
      dc_flip ();
      
      timer_sleep (50);
      for (;;)
      {
        cont_get_cond (mcont1, &cont_out);
        if (cont_out.buttons & CONT_START)
          break;
        timer_sleep (50);
      }
      timer_sleep (50);
      
      start_pressed = 0;
      for (;;)
      {
        cont_get_cond (mcont1, &cont_out);
        if (!(cont_out.buttons & CONT_START))
          start_pressed = 1;
        else if (start_pressed)
          break;
        timer_sleep (50);
      }
      timer_sleep (50);
    }
    
    if (!(cont_out.ltrig))
      pulling_ltrig = 0;
    else
    {
      if (cont_out.rtrig)
        break;
      else
      {
        if (!pulling_ltrig)
        {
          pulling_ltrig = 1;
          vmu_files[cur_pos].selected = !(vmu_files[cur_pos].selected);
          select_mode = vmu_files[cur_pos].selected;
        }
      }
    }
    draw_vmu_files (base_pos, cur_pos, free_blocks, ndc_use_blocks);
    dc_flip ();
    timer_sleep (100);
  }
  timer_sleep (50);
  
  dc_vid_clear ();
  dc_flip ();
}


/* ============================================================ */
struct {
  char name[32];
  uint8 addr;
  uint8 free_blocks;
} vmu_slots[32];


static int
init_vmu_select_menu ()
{
  return 1;
}


static void
draw_vmu_select_slots (int cur_pos, int vmu_num)
{
  int i;
  int y_pos = 40;
  int x_pos = 75;
  char str[128];
  
  dc_vid_clear ();
  
  draw_string (100, 10, _white, _black, "VMU select");
  draw_string (100, 20, _white, _black, "press A to select");
  for (i = 0; i < vmu_num; ++i)
  {
    uint16 fg_color = cur_pos == i ? _yellow : _white;
    sprintf (str, "%s (%d free blocks)", vmu_slots[i].name, vmu_slots[i].free_blocks);
    draw_string (x_pos, y_pos, fg_color, _black, str);
    y_pos += 10;
  }
}


uint8 
do_vmu_select_menu ()
{
  int port, unit;
  int vmu_num;
  int cur_pos = 0;
  uint8 mcont1;

  mcont1 = maple_first_controller ();
  
  dc_vid_clear ();
  dc_flip ();
  
  vmu_num = 0;
  for (port=0; port<4; port++)
  {
    for (unit=0; unit<6; unit++) 
    {
      if (maple_device_func(port, unit) & MAPLE_FUNC_MEMCARD)
      {
        uint8 addr = maple_create_addr(port, unit);
        
        sprintf(vmu_slots[vmu_num].name, "p%d/u%d", port, unit);
        vmu_slots[vmu_num].addr = addr; 
        vmu_slots[vmu_num].free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
        ++vmu_num;
      }
    }
  }
  
  if (!vmu_num)
    return 0;
  
  draw_vmu_select_slots (cur_pos, vmu_num);
  dc_flip ();
  for (;;)
  {
    cont_cond_t cont_out;
    
    cont_get_cond (mcont1, &cont_out);
    if (!(cont_out.buttons & CONT_DPAD_UP))
    {
      if (cur_pos > 0)
	--cur_pos;
    }
    else if (!(cont_out.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_pos < vmu_num - 1)
	++cur_pos;
    }
    else if (!(cont_out.buttons & CONT_A))
      break;
    
    draw_vmu_select_slots (cur_pos, vmu_num);
    dc_flip ();
    
    timer_sleep (50);
  }
  timer_sleep (50);
  
  dc_vid_clear ();
  dc_flip ();
  
  return vmu_slots[cur_pos].addr;
}


