/*
** NesterDC - NES emulator for Dreamcast
** Copyright (C) 2001  Ken Friece
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/


#ifndef _DC_UTILS_H_
#define _DC_UTILS_H_

#ifdef __cplusplus
extern "C" {
#endif

#if 0
}
#endif

#include "types.h"

inline uint16* dc_get_base_vram_s ();
inline void dc_vid_clear ();
inline void dc_vid_empty ();
inline void dc_flip ();
inline void timer_sleep(int msec);

uint8 maple_find_device(uint8 port, int code);
void vmu_icon_draw(const char *vmu_icon, uint8 addr);

uint8 *load_misc(char *fn); 

#ifdef __WITH_TA__
void draw_nes_screen(uint32 textureaddr);
void draw_bmp(uint32 textureaddr);
#endif
void load_bmp (uint8 *pic_buffer, char * pic_name);
void display_bmp (uint8 *pic_buffer);

// define some common colors 
#define _yellow (((255 >> 3) << 11) | ((255 >> 2) << 5) | ((0 >> 3) << 0))
#define _red (((255 >> 3) << 11) | ((0 >> 2) << 5) | ((0 >> 3) << 0))
#define _green (((0 >> 3) << 11) | ((255 >> 2) << 5) | ((0 >> 3) << 0))
#define _blue (((20 >> 3) << 11) | ((20 >> 2) << 5) | ((255 >> 3) << 0))
#define _black (((0 >> 3) << 11) | ((0 >> 2) << 5) | ((0 >> 3) << 0))
#define _white (((255 >> 3) << 11) | ((255 >> 2) << 5) | ((255 >> 3) << 0))
#define _none (((254 >> 3) << 11) | ((254 >> 2) << 5) | ((254 >> 3) << 0))

void font_set(uint8 *fbm, int fh); 
#ifdef __WITH_TA__
void draw_char(int x1, int y1, uint16 fg_color, uint16 bg_color, int ch);
#else
inline void draw_char(int x1, int y1, uint16 fg_color, uint16 bg_color, int ch);
#endif
inline void draw_string(int x1, int y1, uint16 fg_color, uint16 bg_color, const char *str);
void dc_print(const char *string);
void dc_put_error(const char *string);

#ifdef __cplusplus
}
#endif

#endif

