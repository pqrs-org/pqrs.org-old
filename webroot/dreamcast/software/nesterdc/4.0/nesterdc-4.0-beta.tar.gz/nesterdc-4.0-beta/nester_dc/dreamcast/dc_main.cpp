/*
** NesterDC - NES emulator for Dreamcast
** Copyright (C) 2001  Ken Friece
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

#include <kos.h>
#include "vmu.h"
#include "nes.h"
#include "null_sound_mgr.h"
#include "dc_nes_screen_mgr.h"
#include "dc_sound_mgr.h"
#include "dc_settings.h"
#include "dc_utils.h"
#include "dc_menu.h"
#include "emulator.h"
#include "nes_pad.h"
#include "bzlib.h"


// this code is needed for all C++ dc programs 
// to compile
extern "C" {
  void *__builtin_new(int size)
  {
    return malloc(size);
  }
 
  void __builtin_delete(void *ptr)
  {
    free(ptr);
  }

  void *__builtin_vec_new (int size)
  {
    return __builtin_new (size);
  }
} // end extern "C"


/* for bzip2 */
extern "C" {
  void bz_internal_error (int errorcode) 
  {
    char str[128];
    sprintf(str, "bzip2 error (errorcode = 0x%x\n)", errorcode);
    dc_put_error (str);
  }
}

// vmu screen image
#include "vmu_icons/welcome.h"
#include "vmu_icons/available.h"
#include "vmu_icons/kos.h"
#include "vmu_icons/solid.h"

// device addresses
static uint8 mldc = 0;
uint8 mvmu = 0;
static uint8 mcont1 = 0;
static uint8 mcont2 = 0;

// global user settings data
DC_settings dc_settings;

// pointers to bmp images
static const int bmp_size = 240 * 320 * 3;
uint8 menu_bmp[bmp_size];
uint8 credits_bmp[bmp_size];
uint8 options_bmp[bmp_size];

// current controller button config data
short _CONT_A = CONT_A;
short _CONT_B = CONT_X;

// global flag to tell when to exit
// the game loop
boolean exit_game_loop = false;
boolean interrupt_game_loop = false;

// nes controllers
NES_pad pad1;
NES_pad pad2;

// a couple of local routines in main
static void do_options();
static void do_credits();
static void run_game(const char *filename);

static volatile int rest_frames = 0;
#ifdef __DRAW_FPS__
static volatile int frame_per_sec = 0;
static volatile int draw_frames = 0;
#endif


static void
draw_quick_menu (NES *emu)
{
  bool is_fds = emu->fds_id ();
  
  dc_vid_clear ();
  
  draw_string (100, 30, _white, _black, "Menu");
  draw_string (100, 60, _green, _black, "Y: Reset");
  draw_string (10, 100, _yellow, _black, "X: Quick save");
  draw_string (130, 100, _blue, _black, "B: Return to game");
  draw_string (100, 140, _red, _black, "A: Quick load");
  
  if (is_fds)
  {
    char diskside[128];
    draw_string (60, 160, _white, _black, "Up/Down/Left/Right:");
    draw_string (80, 170, _white, _black, "Set Disk 1A/1B/2A/2B");
    sprintf(diskside, "currnet disk side = 0x%x", emu->GetDiskSide ());
    draw_string (60, 190, _white, _black, diskside);
  }
}


static void 
do_quick_menu (NES* emu) 
{
  cont_cond_t cont_out;
  bool is_fds = emu->fds_id ();
  
  emu->freeze();
  
  mcont2 = maple_find_device(1, MAPLE_FUNC_CONTROLLER);
  
  draw_quick_menu (emu);
  dc_flip ();
  
  for (;;) 
  {
    cont_get_cond(mcont1, &cont_out);
    if (!(cont_out.rtrig)) 
    {
      if ((cont_out.buttons & CONT_B) == 0) 
      {
	timer_sleep(100);
	break;
      }
      if ((cont_out.buttons & CONT_X) == 0) 
      {
	bool save_success;
	
	draw_quick_menu (emu);
	draw_string (100, 200, _white, _black, "save...");
        dc_flip ();
	/* filename is dummy */
	save_success = emu->saveState("/md/quick");
	draw_quick_menu (emu);
	if (save_success)
	  draw_string (100, 200, _white, _black, "save...done");
	else 
	  draw_string (100, 200, _red, _black, "save...failed");
        dc_flip ();
	timer_sleep(1000);
	break;
      }
      if ((cont_out.buttons & CONT_A) == 0) 
      {
	bool load_success;
	
	draw_quick_menu (emu);
	draw_string (100, 200, _white, _black, "load...");
        dc_flip ();
	/* filename is dummy */	
	load_success = emu->loadState("/md/quick");
	draw_quick_menu (emu);
	if (load_success)
	  draw_string (100, 200, _white, _black, "load...done");
	else
	  draw_string (100, 200, _red, _black, "load...failed");
        dc_flip ();
	timer_sleep(1000);
	break;
      }
      if ((cont_out.buttons & CONT_Y) == 0) 
      {
        try 
        {
          emu->reset();
        }
        catch (...)
        {
          dc_put_error ("reset failed");
        }
	timer_sleep(100);
	break;
      }
      if (is_fds)
      {
        if ((cont_out.buttons & CONT_DPAD_UP) == 0)
        {
          emu->SetDiskSide (0x01);
	  draw_quick_menu (emu);
          draw_string (100, 200, _white, _black, "Set Disk 1A");
          dc_flip ();
        }
        else if ((cont_out.buttons & CONT_DPAD_DOWN) == 0)
        {
          emu->SetDiskSide (0x02);
	  draw_quick_menu (emu);
          draw_string (100, 200, _white, _black, "Set Disk 1B");
          dc_flip ();
        }          
        else if ((cont_out.buttons & CONT_DPAD_LEFT) == 0)
        {
          emu->SetDiskSide (0x03);
	  draw_quick_menu (emu);
          draw_string (100, 200, _white, _black, "Set Disk 2A");
          dc_flip ();
        }
        else if ((cont_out.buttons & CONT_DPAD_RIGHT) == 0)
        {
          emu->SetDiskSide (0x04);
	  draw_quick_menu (emu);
          draw_string (100, 200, _white, _black, "Set Disk 2B");
          dc_flip ();
        }
      }
    }
    timer_sleep (50);
  }
  timer_sleep (50);
  dc_vid_empty ();
  
  emu->thaw();
}


static bool
snap_save_to_vmu (NES *emu)
{
  M_FILE *fp;
  size_t size;
  bool success = false;
  if (!mvmu) 
    return success;
  
  if (!(emu->saveState("/md/quick")))
    return success;
  
  fp = m_open("/md/quick", "r");
  size = m_size(fp);
  if (size > 0) 
  {
    uint8 *buf; 
    uint32 buf_len;
    uint8 *compress_buf;
    uint32 compress_len;
    int bz_result;
    
    buf = (uint8 *)malloc(size); /* too large for stack */
    buf_len = m_read(buf, 1, size, fp);
    compress_buf = (uint8 *)malloc(size);
    compress_len = size;
    
    bz_result = BZ2_bzBuffToBuffCompress((char *)compress_buf, 
					 (unsigned int*)&compress_len,
					 (char *)buf, 
					 buf_len, 
					 9, 0, 0);
    if (bz_result == BZ_OK) 
    {
      char desc_long[512];
      char filename[512];

      sprintf(desc_long, "NesterDC snap %s", emu->getROMname());
      sprintf(filename, "%s_SS", emu->getROMcrc());
      if (ndc_vmu_save(compress_buf, compress_len, mvmu, 
                       filename, "NesterDC Snap", desc_long) == 0)
        success = true;
    }
    else 
      dc_put_error ("bzip2 failed. please report. ");

    free(buf);
    free(compress_buf);
  }
  m_close(fp);
  
  return success;
}


static bool
snap_load_from_vmu (NES *emu)
{
  uint8 *compressed_buf;
  uint32 compressed_len;
  uint8 *buf;
  size_t buf_len;
  char filename[512];
  bool success = false;
  
  if (!mvmu)
    return false;

   int max_buflen = sizeof(SNSS_FILE) * 2 + 0x8000 + 0x40000 * 2;
   compressed_buf = (uint8 *)malloc(max_buflen);
   compressed_len = max_buflen;
   buf = (uint8 *)malloc(max_buflen);
   buf_len = max_buflen;

   sprintf(filename, "%s_SS", emu->getROMcrc());

   if (ndc_vmu_load(compressed_buf, &compressed_len, mvmu, filename) == 0)
   {
     int bz_result;

     bz_result = BZ2_bzBuffToBuffDecompress((char *)buf, (unsigned int*)&buf_len, 
					    (char *)compressed_buf, compressed_len,
					    0, 0);
     if (bz_result == BZ_OK)
     {
       M_FILE *fp = m_open("/md/quick", "w");
       if (m_write(buf, 1, buf_len, fp) == buf_len) 
       {
	 emu->loadState("/md/quick");
	 success = true;
       }
       m_close(fp);
     }
   }

   free (compressed_buf);
   free (buf);

   return success;
 }


 static void
 draw_save_menu ()
 {
   dc_vid_clear ();

   draw_string (100, 30, _white, _black, "VMU Menu");
   draw_string (100, 60, _green, _black, "Y: ");
   draw_string (10, 100, _yellow, _black, "X: Snap save");
   draw_string (130, 100, _blue, _black, "B: Return to game");
   draw_string (100, 140, _red, _black, "A: Snap load");
 }


 static void
 do_save_menu (NES *emu)
 {
   cont_cond_t cont_out;

   emu->freeze();

   draw_save_menu ();
   dc_flip ();

   for (;;) 
   {
     cont_get_cond(mcont1, &cont_out);
     if (!(cont_out.rtrig)) {
       if ((cont_out.buttons & CONT_B) == 0) 
       {
	 timer_sleep(100);
	 break;
       }
       if ((cont_out.buttons & CONT_X) == 0) 
       {
	 bool save_success;

	 draw_save_menu ();
	 draw_string (100, 200, _white, _black, "save...");
	 dc_flip ();

	 save_success = snap_save_to_vmu (emu);
	 draw_save_menu ();
	 if (save_success) 
	   draw_string (100, 200, _white, _black, "save...done");
	 else
	   draw_string (100, 200, _red, _black, "save...failed");
	 dc_flip ();

	 timer_sleep(1000);
	 break;
       }
       if ((cont_out.buttons & CONT_A) == 0) 
       {
	 bool load_success;

	 draw_save_menu ();
	 draw_string (100, 200, _white, _black, "load...");
	 dc_flip ();

	 load_success = snap_load_from_vmu (emu);
	 draw_save_menu ();
	 if (load_success)
	   draw_string (100, 200, _white, _black, "load...done");
	 else
	   draw_string (100, 200, _red, _black, "load...failed");
	 dc_flip ();

	 timer_sleep(1000);
	 break;
       }
     }
     timer_sleep (50);
   }
   timer_sleep (50);
   dc_vid_empty ();

   emu->thaw();
 }


 inline static void 
 poll_input(NES* emu) 
 {
   cont_cond_t cont_out;

   cont_get_cond(mcont1, &cont_out);

   if (cont_out.rtrig) 
   {
     if (cont_out.ltrig) 
     {
       exit_game_loop = true;
       interrupt_game_loop = true;
     }
 #ifndef __WITH_TA__  
     if ((cont_out.buttons & CONT_B) == 0) 
     {
       do_quick_menu(emu);
       interrupt_game_loop = true;
       rest_frames = 0;
     }
     if ((cont_out.buttons & CONT_Y) == 0) 
     {
       do_save_menu (emu);
       interrupt_game_loop = true;
       rest_frames = 0;
     }
 #endif
   } 
   else 
   {
     if (cont_out.joyy < 5) 
     {
       /* analog UP */
       interrupt_game_loop = true;
       dc_settings.set_frameskip(DC_settings::two_per_three);
     } 
     else if (cont_out.joyy > 250) 
     {
       /* analog DOWN */
       interrupt_game_loop = true;
       dc_settings.set_frameskip(DC_settings::one_per_three);
     }
     else if (cont_out.joyx > 250) 
     {
       /* analog RIGHT */
       interrupt_game_loop = true;
       dc_settings.set_frameskip(DC_settings::auto_skip);
     }
     else if (cont_out.joyx < 5) 
     {
       /* analog LEFT */
       interrupt_game_loop = true;
       dc_settings.set_frameskip(DC_settings::dual_speed_skip);
     }

     pad1.set_button_state(NES_UP, !(cont_out.buttons & CONT_DPAD_UP));
     pad1.set_button_state(NES_DOWN, !(cont_out.buttons & CONT_DPAD_DOWN));
     pad1.set_button_state(NES_LEFT, !(cont_out.buttons & CONT_DPAD_LEFT));
     pad1.set_button_state(NES_RIGHT, !(cont_out.buttons & CONT_DPAD_RIGHT));
     pad1.set_button_state(NES_SELECT, !(cont_out.buttons & CONT_Y));
     pad1.set_button_state(NES_START, !(cont_out.buttons & CONT_START));
     pad1.set_button_state(NES_B, !(cont_out.buttons & _CONT_B));
     pad1.set_button_state(NES_A, !(cont_out.buttons & _CONT_A));
   }

   if (mcont2) 
   {
     cont_get_cond(mcont2, &cont_out);
     pad2.set_button_state(NES_UP, !(cont_out.buttons & CONT_DPAD_UP));
     pad2.set_button_state(NES_DOWN, !(cont_out.buttons & CONT_DPAD_DOWN));
     pad2.set_button_state(NES_LEFT, !(cont_out.buttons & CONT_DPAD_LEFT));
     pad2.set_button_state(NES_RIGHT, !(cont_out.buttons & CONT_DPAD_RIGHT));
     pad2.set_button_state(NES_SELECT, !(cont_out.buttons & CONT_Y));
     pad2.set_button_state(NES_START, !(cont_out.buttons & CONT_START));
     pad2.set_button_state(NES_B, !(cont_out.buttons & _CONT_B));
     pad2.set_button_state(NES_A, !(cont_out.buttons & _CONT_A));
   }
 }


 static void
 draw_main_menu ()
 {
   display_bmp(menu_bmp);
 }


 // the main menu code
 static void
 load_main_menu ()
 {
   cont_cond_t cont_out; 

   draw_main_menu ();
   dc_flip ();

   for (;;) 
   {
     cont_get_cond(mcont1, &cont_out);

     if (!(cont_out.buttons & CONT_A)) 
     {
       const char *rom_file = do_rom_menu ();
       if (rom_file)
	run_game (rom_file);
      draw_main_menu ();
      dc_flip ();
    } 
    else if (!(cont_out.buttons & CONT_X)) 
    {
      do_options ();
      draw_main_menu ();
      dc_flip ();
    }
    else if (!(cont_out.buttons & CONT_Y)) 
    {
      do_credits ();
      draw_main_menu ();
      dc_flip ();
    } 
    else if (!(cont_out.buttons & CONT_B)) 
    {
      if (cont_out.ltrig & cont_out.rtrig) 
	break;
      else
      {
        do_vmu_menu (mvmu);
        draw_main_menu ();
	dc_flip ();
      }
    }
    timer_sleep(50);
  }
  timer_sleep (50);
}


static void 
draw_option_menu ()
{
  display_bmp (options_bmp);
  
  draw_string (20, 30, _yellow, _none, "L+R: Return to Main Menu");
  draw_string (20, 50, _white, _none, "DOWN: Slower and Smoother");
  draw_string (20, 60, _white, _none, "  UP: Faster and Choppier");
  draw_string (60, 70, _white, _none, "Frame Skip:");
  draw_string (160, 70, _white, _none, dc_settings.get_frameskip_string());
  
  draw_string (20, 90, _white, _none, "Y: Adjust NES A and B Buttons");
  draw_string (60, 100, _white, _none, dc_settings.get_cont_scheme_string());
  
  draw_string (20, 120, _white, _none, "A: Toggle Sound");
  if (dc_settings.is_sound()) 
    draw_string (240, 120, _white, _none, "[ON]");
  else
    draw_string (240, 120, _white, _none, "[OFF]");
  
  draw_string (20, 140, _white, _none, "X: Toggle Save Support");
  if (dc_settings.is_save())
    draw_string (240, 140, _white, _none, "[ON]");
  else
    draw_string (240, 140, _white, _none, "[OFF]");
}


static void
do_options () 
{
  cont_cond_t cont_out, cont_out_prev;
  bool update = false;
  
  draw_option_menu();
  dc_flip ();

  cont_get_cond (mcont1, &cont_out_prev);
  for (;;) 
  {
    cont_get_cond(mcont1, &cont_out);
    if (cont_out.ltrig && cont_out.rtrig)
    {
      if (update) 
	dc_settings.save_to_vmu(mvmu);
      break;
    } 
    
    if (cont_out.buttons != cont_out_prev.buttons)
    {
      cont_out_prev = cont_out;
      
      if (!(cont_out.buttons & CONT_DPAD_UP)) 
      {
	dc_settings.inc_frameskip ();
	update = true;
      }
      else if (!(cont_out.buttons & CONT_DPAD_DOWN)) 
      {
	dc_settings.dec_frameskip ();
	update = true;
      }
      else if (!(cont_out.buttons & CONT_Y)) 
      {
	dc_settings.inc_cont_scheme ();
	_CONT_A = dc_settings.get_cont_a ();
	_CONT_B = dc_settings.get_cont_b ();
	update = true;
      }
      else if (!(cont_out.buttons & CONT_A)) 
      {
	dc_settings.toggle_sound ();
	update = true;
      } 
      else if (!(cont_out.buttons & CONT_X)) 
      {
	dc_settings.toggle_save ();
	update = true;
      }
      draw_option_menu ();
      dc_flip ();
    }
    timer_sleep (50);
  }
  timer_sleep (50);
}


static void 
do_credits() 
{
  display_bmp(credits_bmp);
  dc_flip ();
  timer_sleep (5000);
}


static void
timer_handler(irq_t source, irq_context_t *context)
{
#ifdef __DRAW_FPS__
  static int times = 0;
  ++times;
  if (times == 60)
  {
    times = 0;
    frame_per_sec = draw_frames;
    draw_frames = 0;
  }
#endif
  ++rest_frames;
}


static void
run_game(const char *filename)
{
  NES *emu;
  sound_mgr *snd_mgr = NULL;
  dc_NES_screen_mgr *scr_mgr = NULL;
  
  dc_vid_clear ();
  dc_flip ();
  dc_vid_clear ();
  
  try 
  {
    dc_print ("new sound_mgr");
    if (dc_settings.is_sound ())
      snd_mgr = new dc_sound_mgr();
    else
      snd_mgr = new null_sound_mgr();

    dc_print ("new screen_mgr");
    scr_mgr = new dc_NES_screen_mgr();

    dc_print ("new NES");
    emu = new NES (filename, scr_mgr, snd_mgr);
  }
  catch (...) 
  {
    free (snd_mgr);
    free (scr_mgr);
    dc_put_error ("something error...");
    return;
  }
  
  dc_print ("ready");
  
  emu->set_is_save (dc_settings.is_save ());
  
  scr_mgr->setParentNES((NES*)emu);
  emu->set_pad1(&pad1);
  emu->set_pad2(&pad2);
  
  emu->reset (); /* for parodius */
  
  dc_vid_empty ();
  m_clear();
  
#ifdef __WITH_TA__
  vid_set_mode (DM_640x480, PM_RGB565);
  vid_set_start (0);
#endif
  
  exit_game_loop = false;
  interrupt_game_loop = false;
  while (!exit_game_loop) 
  {
    vmu_icon_draw (dc_settings.get_vmu_icon(), mldc);
    switch (dc_settings.get_frameskip ()) 
    {
      case DC_settings::no_skip:
        while (!interrupt_game_loop) 
        {
          emu -> emulate_frame ();
	  dc_flip ();
          emu -> emulate_frame ();
	  dc_flip ();
          emu -> emulate_frame ();
	  dc_flip ();
          poll_input(emu);
        }
        break;
      case DC_settings::one_per_three:
        while (!interrupt_game_loop) 
        {
          emu -> emulate_frame ();
	  dc_flip ();
          emu -> emulate_frame ();
	  dc_flip ();
          emu -> emulate_frame_skip ();
          poll_input(emu);
        }
        break;
      case DC_settings::one_per_two:
        while (!interrupt_game_loop) 
        {
          emu -> emulate_frame ();
	  dc_flip ();
          emu -> emulate_frame_skip ();
          poll_input(emu);
        }
        break;
      case DC_settings::two_per_three: 
        while (!interrupt_game_loop) 
        {
          emu -> emulate_frame ();
	  dc_flip ();
          emu -> emulate_frame_skip();
          emu -> emulate_frame_skip();
          poll_input(emu);
        }
        break;
        
      case DC_settings::auto_skip:
      case DC_settings::dual_speed_skip:
      default:
        if (dc_settings.get_frameskip() == DC_settings::dual_speed_skip) 
          timer_prime(TMU2, 120, true);
        else
          timer_prime(TMU2, 60, true);
        
        irq_set_handler(EXC_TMU2_TUNI2, timer_handler);
        timer_start(TMU2);
        rest_frames = 0;
        
        while (!interrupt_game_loop) 
	{
	  emu->emulate_frame ();
#ifdef __DRAW_FPS__
	  ++draw_frames;
	  {
	    char str[128];
	    sprintf(str, "%d", frame_per_sec);
	    draw_string (30, 10, _white, _black, str);
	  }
#endif
	  dc_flip ();
          poll_input(emu);
	  if (rest_frames <= 0)
	  {
	    while (rest_frames <= 0)
	      ;
	    rest_frames = 0;
	  }
	  else
	  {
	    int i;
	    int skip_frame = rest_frames;
#if __PRECISION__EMULATE__
	    rest_frames = -skip_frame;
#else
	    rest_frames = -1;
#endif
	    for (i = 0; i < skip_frame; ++i)
	    {
	      emu->emulate_frame_skip ();
	      poll_input(emu);
	    }
	  }
        }
        timer_stop(TMU2);
        break;
    }
    interrupt_game_loop = false;
  }
  
#ifdef __WITH_TA__
  vid_set_mode (DM_320x240, PM_RGB565);
#endif
  
  dc_vid_clear ();
  dc_flip ();
  
  delete (emu);
  delete (scr_mgr);
  delete (snd_mgr);
}


static bool
default_game_exists () 
{
  file_t d;
  dirent_t *de;
  bool game_exist = false;
  
  d = fs_open ("/cd/games", O_RDONLY | O_DIR);
  if (!d) return game_exist;
  
  for (;;) 
  {
    de = fs_readdir (d);
    if (de)
    {
      if (stricmp (de->name, "game.nes") == 0) 
        game_exist = true;
    }
    else 
      break;
  }
  fs_close (d);
  
  return game_exist;
}


extern "C" int
main() 
{
  uint8 *fnt8x8;
  
#ifdef __WITH_TA__
  kos_init_all(IRQ_ENABLE | TA_ENABLE, ROMDISK_NONE);
#else
  kos_init_all(IRQ_ENABLE, ROMDISK_NONE);
#endif
  
  bfont_draw_str(vram_s, 640, 1, "startup");
  timer_sleep(1000);
  
  vid_set_mode(DM_320x240, PM_RGB565);
  dc_vid_clear ();
  dc_flip ();
  dc_vid_clear ();
  
  fnt8x8 = load_misc("/cd/gfx/8x8.fnt");
  font_set(fnt8x8 + 4, 8);
  
  /* allocate memory */
  m_init();
  
  /* device setting */ 
  mcont1 = maple_find_device(0, MAPLE_FUNC_CONTROLLER);
  mcont2 = maple_find_device(1, MAPLE_FUNC_CONTROLLER);
  
  mldc = maple_first_lcd ();
  
  if (mldc)
    vmu_icon_draw (vmu_kos_xpm, mldc);
  
  // display disclaimer
  load_bmp(credits_bmp, "/cd/pics/startup.bmp");
  display_bmp(credits_bmp);
  draw_string(10, 210, _white, _black, "NesterDC 4.0-beta");
  dc_flip ();
  
  // if vmu is present, draw to the screen
  if (mldc)
    vmu_icon_draw (vmu_welcome_xpm, mldc);
  
  load_bmp (menu_bmp, "/cd/pics/menu.bmp");
  load_bmp (credits_bmp, "/cd/pics/credits.bmp");
  load_bmp (options_bmp, "/cd/pics/options.bmp");
  
  init_menus ();
  
  mvmu = dc_settings.find_vmu ();
  if (!mvmu)
    mvmu = do_vmu_select_menu ();
  
  dc_settings.load_from_vmu (mvmu);
  NESTER_settings.nes.SetDefaults();
  NESTER_settings.Load();
  
  if (mldc)
    vmu_icon_draw (vmu_available_xpm, mldc);
  
  if (default_game_exists ()) 
    run_game ("game.nes");
  
#if 0
  run_game("/cd/games/metroid.fds");
#else
  load_main_menu();
#endif
  
  if (mldc)
    vmu_icon_draw(vmu_solid_xpm, mldc);
  kos_shutdown_all();
  return 0;
}


