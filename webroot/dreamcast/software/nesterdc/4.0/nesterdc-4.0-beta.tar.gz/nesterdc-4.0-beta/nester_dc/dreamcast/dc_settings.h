#ifndef _DC_SETTINGS_H_
#define _DC_SETTINGS_H_


#include "vmu_icons/frameskip0.h"
#include "vmu_icons/frameskip1.h"
#include "vmu_icons/frameskip2.h"
#include "vmu_icons/frameskip3.h"
#include "vmu_icons/frameskip_auto.h"
#include "vmu_icons/frameskip_dual.h"


class DC_settings
{
 public:
  enum cont_scheme_pattern {
    bx_aa, 
    ba_ab, 
    bx_ab, 
    cont_scheme_pattern_num
  };
  
  const char *get_cont_scheme_string () {
    static const char *strings[] = {
      "[NES_B = DC_X] [NES_A = DC_A]", 
      "[NES_B = DC_A] [NES_A = DC_B]",
      "[NES_B = DC_X] [NES_A = DC_B]"
    };
    return strings[cont_scheme];
  }
  
  void set_cont_scheme (uint8 pattern) { 
    if (pattern < cont_scheme_pattern_num)
      cont_scheme = pattern;
  }
  void inc_cont_scheme () { 
    if (cont_scheme < cont_scheme_pattern_num - 1) 
      ++cont_scheme; 
    else
      cont_scheme = 0;
  }
  void dec_cont_scheme () {
    if (cont_scheme > 0)
      --cont_scheme;
    else
      cont_scheme = cont_scheme_pattern_num - 1;
  }
  uint8 get_cont_scheme () {
    return cont_scheme;
  }
  uint16 get_cont_a () {
    switch (cont_scheme) {
      case bx_aa:
        return CONT_A;
      case ba_ab:
        return CONT_B;
      case bx_ab:
        return CONT_B;
    }
  }
  uint16 get_cont_b () {
    switch (cont_scheme) {
      case bx_aa:
        return CONT_X;
      case ba_ab:
        return CONT_A;
      case bx_ab:
        return CONT_X;
    }
  }
  
  /* */
  enum frameskip_rate {
    no_skip,
    one_per_three,
    one_per_two,
    two_per_three,
    auto_skip, 
    dual_speed_skip, 
    frameskip_rate_num
  };
  
  const char *get_frameskip_string () {
    static const char *strings[] = {
      "no frame skip", 
      "1 per 3 frames",
      "1 per 2 frames",
      "2 per 3 frames",
      "auto frame skip",
      "dual frame skip",
    };
    return strings[frameskip];
  }
  
  void set_frameskip (uint8 rate) { 
    if (rate < frameskip_rate_num)
      frameskip = rate;
  }
  void inc_frameskip () {
    if (frameskip < frameskip_rate_num - 1) ++frameskip; 
  }
  void dec_frameskip () { 
    if (frameskip > 0) --frameskip; 
  }
  uint8 get_frameskip () {
    return frameskip;
  }
  
  
  /* */
  void set_sound (bool which) {
    sound_on = which; 
  }
  void toggle_sound () {
    sound_on = !sound_on;
  }
  bool is_sound () { 
    return sound_on;
  }
  
  void set_player2 (bool which) {
    player2 = which;
  }

  void set_save (bool which) {
    save = which;
  }
  void toggle_save () {
    save = !save;
  }
  bool is_save () {
    return save;
  }
  
  
  /* */
  void set_defaults () {
    cont_scheme = bx_aa;
    frameskip = auto_skip;
    sound_on = true;
    player2 = true;
    save = false;
  }
  
  uint8 find_vmu ();
  void save_to_vmu (uint8 addr);
  void load_from_vmu (uint8 addr);
  
  const char *get_vmu_icon() {
    static const char *xpms[] = {
      vmu_frameskip0_xpm, 
      vmu_frameskip1_xpm, 
      vmu_frameskip2_xpm, 
      vmu_frameskip3_xpm, 
      vmu_frameskip_auto_xpm,
      vmu_frameskip_dual_xpm, 
    };
    return xpms[frameskip];
  }
  
 private:
  uint8 cont_scheme;
  uint8 frameskip;
  uint8	sound_on;
  uint8	player2;
  uint8	save;
};


#endif
