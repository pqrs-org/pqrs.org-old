/* Tryptonite

   precompiler.h
   (c)2000 Dan Potter

   precompiler.h,v 1.3 2001/10/19 04:52:58 tekezo Exp
*/


#ifndef __PRECOMPILER_H
#define __PRECOMPILER_H

/* Resets the precompiler for another scene/object */
void pc_reset(int size);

/* Appends a vertex to the scene buffer */
void pc_append(const void *data);

/* Transforms all verteces in the scene buffer */
void pc_transform_all();

/* Submits all verteces in the scene buffer to the TA */
void pc_submit_all();

/* Init */
void pc_init();

/* Shutdown */
void pc_shutdown();


#endif	/* __PRECOMPILER_H */
