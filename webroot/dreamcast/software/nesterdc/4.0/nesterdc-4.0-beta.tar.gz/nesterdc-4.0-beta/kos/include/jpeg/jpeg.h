/* KallistiOS 1.1.4

   jpeg.h
   (c)2001 Dan Potter

   jpeg.h,v 1.3 2001/10/19 04:52:58 tekezo Exp
*/

#ifndef __JPEG_JPEG_H
#define __JPEG_JPEG_H

/* Load a JPEG file into a texture; returns 0 for success, -1 for failure. */
int jpeg_to_texture(const char * filename, uint32 tex, int size, int scale);

#endif	/* __JPEG_JPEG_H */


