/* KallistiOS 1.1.4

   sys/iovec.h
   (c)2001 Dan Potter

   iovec.h,v 1.3 2001/10/19 04:52:59 tekezo Exp

*/

#ifndef __SYS_IOVEC_H
#define __SYS_IOVEC_H

#include <stddef.h>

typedef struct iovec {
	char	*iov_base;	/* Base address */
	size_t	iov_len;	/* Length */
} iovec_t;

#endif	/* __SYS_IOVEC_H */

