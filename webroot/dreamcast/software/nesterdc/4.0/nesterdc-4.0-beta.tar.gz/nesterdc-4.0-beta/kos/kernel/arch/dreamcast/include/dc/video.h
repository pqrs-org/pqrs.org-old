/* KallistiOS 1.1.4

   dc/video.h
   (c)2000-2001 Dan Potter

   video.h,v 1.3 2001/10/19 04:52:59 tekezo Exp

*/

#ifndef __DC_VIDEO_H
#define __DC_VIDEO_H

#include <arch/types.h>

/* Video profile information; one of these structures is selected based
   on the mode requested. This structure can be used for reference in other
   modules. */
typedef struct {
	int		dummy;
} video_profile_t;

extern uint32 *vram_l;
extern uint16 *vram_s;
extern int vram_config;
extern int vram_size;

extern int vid_resolution;
extern int vid_cable_type;

#define CT_VGA		0
#define CT_RGB		2
#define CT_COMPOSITE	3
int vid_check_cable();

#define PM_RGB555	0
#define PM_RGB565	1
#define PM_RGB888	3
#define DM_320x240	0
#define DM_640x480	1
#define DM_800x608	2	/* experimental */
void vid_set_mode_and_cable(int cable_type, int video_mode, int pixel_mode);
void vid_set_mode(int video_mode, int pixel_mode);

void vid_set_start(uint32 start);
void vid_border_color(int r, int g, int b);
void vid_clear(int r, int g, int b);
void vid_empty();
void vid_waitvbl();

void vid_init(int video_mode, int pixel_mode);
void vid_shutdown();

#endif	/* __DC_VIDEO_H */
