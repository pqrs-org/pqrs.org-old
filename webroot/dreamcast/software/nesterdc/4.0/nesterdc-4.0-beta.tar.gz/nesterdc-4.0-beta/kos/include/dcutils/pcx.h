/* E3 Demo CD

   pcx.h
   (c)2000-2001 Dan Potter

   pcx.h,v 1.3 2001/10/19 04:52:58 tekezo Exp

*/

#ifndef __PCX_H
#define __PCX_H

#include <arch/types.h>

typedef struct {
	int	width, height;
	uint16	*pixel_data;
} Image;

Image *pcx_load(const char *fn);
void pcx_free(Image *pcx);

/* Loads a PCX file into texture RAM, potentially twiddling it and/or
   converting it to an alpha mask. */
int pcx_load_texture(const char *fn, int twiddle, int alpha,
	uint32 *txr, int *w, int *h);
   

#endif	/* __PCX_H */

