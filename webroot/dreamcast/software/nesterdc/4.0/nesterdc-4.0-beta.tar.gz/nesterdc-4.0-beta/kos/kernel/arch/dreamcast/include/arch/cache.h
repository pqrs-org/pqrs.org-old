/* KallistiOS 1.1.4

   arch/dreamcast/include/cache.h
   (c)2001 Dan Potter
   
   cache.h,v 1.3 2001/10/19 04:52:59 tekezo Exp
*/

#ifndef __ARCH_CACHE_H
#define __ARCH_CACHE_H

#include <arch/types.h>

/* Flush a range of i-cache, given a physical address range */
void icache_flush_range(uint32 start, uint32 count);

/* Invalidate a range of o-cache/d-cache, given a physical address range */
void dcache_inval_range(uint32 start, uint32 count);

/* Flush a range of o-cache/d-cache, given a physical address range */
void dcache_flush_range(uint32 start, uint32 count);

#endif	/* __ARCH_CACHE_H */

