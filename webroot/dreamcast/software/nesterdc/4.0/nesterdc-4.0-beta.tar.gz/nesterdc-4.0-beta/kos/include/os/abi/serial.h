/* KallistiOS 0.80

   os/abi/serial.h
   (c)2001 Dan Potter

   serial.h,v 1.3 2001/10/19 04:52:58 tekezo Exp
*/

#ifndef __OS_ABI_SERIAL_H
#define __OS_ABI_SERIAL_H

#include <os/process.h>
#include <kos/dbgio.h>

typedef struct {
	service_abi_t	hdr;		/* Header info */

	void		(*write)(uint8 *data, int len);
	void		(*read)(uint8 *data, int len);
	void		(*flush)();
} abi_serial_t;

#endif	/* __OS_ABI_SERIAL_H */

