#ifndef _KOS_STDLIB_H_
#define _KOS_STDLIB_H_

#include "stdio.h"
#include "malloc.h"

#define _MAX_PATH 50

int abs(int j);

#endif


