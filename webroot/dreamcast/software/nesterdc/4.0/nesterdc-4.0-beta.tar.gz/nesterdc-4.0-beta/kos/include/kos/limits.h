/* KallistiOS 1.1.4

   kos/limits.h
   (c)2000-2001 Dan Potter

   limits.h,v 1.3 2001/10/19 04:52:58 tekezo Exp
  
*/

#ifndef __KOS_LIMITS_H
#define __KOS_LIMITS_H

#define MAX_FN_LEN	256		/* Max filename length */

#endif	/* __KOS_LIMITS_H */
