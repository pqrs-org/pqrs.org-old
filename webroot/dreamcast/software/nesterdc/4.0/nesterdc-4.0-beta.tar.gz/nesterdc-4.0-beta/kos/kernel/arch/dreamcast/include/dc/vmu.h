/* KallistiOS 1.1.4

   dc/vmu.h
   (C)2000-2001 Jordan DeLong

   vmu.h,v 1.3 2001/10/19 04:52:59 tekezo Exp

*/

#ifndef __DC_VMU_H
#define __DC_VMU_H

#include <arch/types.h>

int vmu_draw_lcd(uint8 addr, void *bitmap);
int vmu_block_read(uint8 addr, uint16 blocknum, uint8 *buffer);
int vmu_block_write(uint8 addr, uint16 blocknum, uint8 *buffer);

#endif	/* __DC_VMU_H */

