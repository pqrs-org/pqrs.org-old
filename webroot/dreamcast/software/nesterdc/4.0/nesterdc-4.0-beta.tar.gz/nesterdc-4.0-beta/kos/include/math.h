/* KallistiOS 1.1.4

   math.h
   (c)2001 Potter

   math.h,v 1.3 2001/10/19 04:52:58 tekezo Exp
*/

#ifndef __KOS_MATH_H
#define __KOS_MATH_H

/* Just pull in the Newlib math routines for the right platform */
#ifdef _arch_dreamcast
#include <newlib-libm-sh4/math.h>
#elif _arch_gba
#error No math.h support for GBA yet
#endif

#endif	/* __KOS_MATH_H */

