/* KallistiOS 1.1.4

   unistd.h
   (c)2000-2001 Dan Potter

   unistd.h,v 1.3 2001/10/19 04:52:58 tekezo Exp

*/

#ifndef __UNISTD_H
#define __UNISTD_H

#include <stddef.h>
#include <arch/types.h>

#define true (1)
#define false (0)

#endif	/* __UNISTD_H */

