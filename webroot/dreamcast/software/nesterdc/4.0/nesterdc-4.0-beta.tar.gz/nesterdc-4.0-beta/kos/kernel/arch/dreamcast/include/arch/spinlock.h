/* KallistiOS 1.1.4

   arch/dreamcast/include/spinlock.h
   (c)2001 Dan Potter
   
   spinlock.h,v 1.3 2001/10/19 04:52:59 tekezo Exp
*/

#ifndef __ARCH_SPINLOCK_H
#define __ARCH_SPINLOCK_H

/* Defines processor specific spinlocks */

/* DC implementation uses threads most of the time */
#include <kos/thread.h>

/* Spinlock data type */
typedef volatile int spinlock_t;

/* Value initializer */
#define SPINLOCK_INITIALIZER 0

/* Initialize a spinlock */
#define spinlock_init(A) *(A) = SPINLOCK_INITIALIZER

/* Spin on a lock */
#ifndef _userland
#define spinlock_lock(A) do { \
    if (thd_enabled) { \
	spinlock_t * __lock = A; \
	int __gotlock = 0; \
	while(1) { \
	    asm volatile ("tas.b @%1\n\t" \
			  "movt %0\n\t" \
			  : "=r" (__gotlock) : "r" (__lock) : "t", "memory"); \
	    if (!__gotlock) \
		thd_pass(); \
	    else break; \
	} \
    } \
} while (0)
#else	/* _userland */
#define spinlock_lock(A) do { \
    spinlock_t * __lock = A; \
    int __gotlock = 0; \
    while(1) { \
	asm volatile ("tas.b @%1\n\t" \
		      "movt %0\n\t" \
		      :"=r" (__gotlock) : "r" (__lock) : "t", "memory"); \
	if (!__gotlock) \
	    thd_pass(); \
	else break; \
    } \
} \
} while (0)
#endif	/* _userland */

/* Free a lock */
#ifndef _userland
#define spinlock_unlock(A) do { \
		if (thd_enabled) { \
			*(A) = 0; \
		} \
	} while (0)
#else	/* _userland */
#define spinlock_unlock(A) do { \
		*(A) = 0; \
	} while (0)
#endif	/* _userland */


#endif	/* __ARCH_SPINLOCK_H */

