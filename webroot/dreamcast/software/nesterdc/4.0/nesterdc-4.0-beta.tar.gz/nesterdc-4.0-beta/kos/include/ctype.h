/* KallistiOS 1.1.4

   ctype.h
   (c)2000 Jordan DeLong and Dan Potter

   ctype.h,v 1.3 2001/10/19 04:52:58 tekezo Exp
*/

#ifndef __CTYPE_H
#define __CTYPE_H

#define isprint(c) (((c) > ' ') && ((c) < '~'))
#define isascii(c) (((c) & ~0x7F) == 0)
#define tolower(c) (((c) >= 'A' && (c) <= 'Z') ? ((c) + ('a' - 'A')) : (c))

#endif
