/* KallistiOS 1.1.4
 *
 * ethernet.c
 *
 * (c)2001 Dan Potter
 */

static char id[] = "KOS ethernet.c,v 1.3 2001/10/19 04:52:59 tekezo Exp";

#include <stdio.h>
#include <string.h>
#include <dc/ethernet.h>
#include <dc/g2.h>
#include <arch/irq.h>

/*

Contains a low-level ethernet driver for the "Broadband Adapter", which
is principally a RealTek 8193C chip attached to the G2 external bus
using a PCI bridge chip called "GAPS PCI". GAPS PCI might ought to be
in its own module, but AFAIK this is the only peripheral to use this
chip, and quite possibly will be the only peripheral to ever use it.

Thanks to Andrew Kieschnick for finishing the driver info for the rtl8193c
(mainly the transmit code, and lots of help with the error correction).
Also thanks to the NetBSD sources for some info on register names.

This driver has basically been rewritten since KOS 1.0.x.

*/

/****************************************************************************/
/* GAPS PCI stuff probably ought to be moved to another file... */

/* Detect a GAPS PCI bridge */
static int gaps_detect() {
	const char *str = (char*)0xa1001400;
	if (!strncmp(str, "GAPSPCI_BRIDGE_2", 16))
		return 0;
	else
		return -1;
}

/* Initialize GAPS PCI bridge */
static int gaps_init() {
	vuint8 * const gaps8 = (vuint8 *)0xa1000000;
	vuint16 * const gaps16 = (vuint16 *)0xa1000000;
	vuint32 * const gaps32 = (vuint32 *)0xa1000000;
	int i;

	/* Make sure we have one */
	if (gaps_detect() < 0) {
		dbglog(DBG_KDEBUG, "eth: no ethernet card found\n");
		return -1;
	}

	/* Initialize the "GAPS" PCI glue controller.
	   It ain't pretty but it works. */
	gaps32[0x1418/4] = 0x5a14a501;		/* M */
	i = 10000;
	while (!(gaps32[0x1418/4] & 1) && i > 0)
		i--;
	if (!(gaps32[0x1418/4] & 1)) {
		dbglog(DBG_ERROR, "eth: GAPS PCI controller not responding; giving up!\n");
		return -1;
	}
	gaps32[0x1420/4] = 0x01000000;
	gaps32[0x1424/4] = 0x01000000;
	gaps32[0x1428/4] = 0x01840000;			/* DMA Base */
	gaps32[0x142c/4] = 0x01840000 + 32*1024;	/* DMA End */
	gaps32[0x1414/4] = 0x00000001;			/* Interrupt enable */
	gaps32[0x1434/4] = 0x00000001;

	/* Configure PCI bridge (very very hacky). If we wanted to be proper,
	   we ought to implement a full PCI subsystem. In this case that is
	   ridiculous for accessing a single card that will probably never
	   change. Considering that the DC is now out of production officially,
	   there is a VERY good chance it will never change. */
	gaps16[0x1606/2] = 0xf900;
	gaps32[0x1630/4] = 0x00000000;
	gaps8[0x163c] = 0x00;
	gaps8[0x160d] = 0xf0;
	(void)gaps16[0x04/2];
	gaps16[0x1604/2] = 0x0006;
	gaps32[0x1614/4] = 0x01000000;
	(void)gaps8[0x1650];

	return 0;
}

/****************************************************************************/
/* RTL8193C stuff */

/* Configuration definitions */
#define RX_BUFFER_LEN		16384

/* RTL8139C Config/Status info */
struct {
	uint16	cur_rx;		/* Current Rx read ptr */
	uint16	cur_tx;		/* Current available Tx slot */
	uint8	mac[6];		/* Mac address */
} rtl;

/* 8, 16, and 32 bit access to the PCI I/O space (configured by GAPS) */
#define NIC8(ADDR) (*(vuint8*)(0xa1001700 + (ADDR)))
#define NIC16(ADDR) (*(vuint16*)(0xa1001700 + (ADDR)))
#define NIC32(ADDR) (*(vuint32*)(0xa1001700 + (ADDR)))

/* 8 and 32 bit access to the PCI MEMMAP space (configured by GAPS) */
static vuint8 * const mem8 = (vuint8*)0xa1840000;
static vuint32 * const mem32 = (vuint32*)0xa1840000;

/* TX buffer pointers */
static vuint8 * const txdesc[4] = {	(vuint8*)0xa1846000,
					(vuint8*)0xa1846800,
					(vuint8*)0xa1847000,
					(vuint8*)0xa1847800 };

/* Receive descriptors: temporary space to copy out received data */
#define RX_BUFF_CNT 8
static uint8 rxbuffs[RX_BUFF_CNT][1600];
static uint32 rxbuffs_size[RX_BUFF_CNT];
static int rxbuffs_free_cnt, rxbuffs_head, rxbuffs_tail;

/* Is the link stabilized? */
static volatile int link_stable;

/* Receive callback */
eth_rx_callback_t eth_rx_callback;

/* Forward-declaration for IRQ handler */
static void eth_irq_hnd(irq_t src, irq_context_t *context);

/* Reads the MAC address of the BBA into the specified array */
void eth_get_mac(uint8 *arr) {
	memcpy(arr, rtl.mac, 6);
}

/* Set an ethernet packet receive callback */
void eth_set_rx_callback(eth_rx_callback_t cb) {
	eth_rx_callback = cb;
}

/*
  Initializes the BBA
  
  Returns 0 for success or -1 for failure.
 */
static int eth_hw_init() {
	int i;
	uint32 tmp;

	link_stable = 0;

	/* Initialize GAPS */
	if (gaps_init() < 0)
		return -1;

	/* Soft-reset the chip */
	NIC8(RT_CHIPCMD) = RT_CMD_RESET;
	
	/* Wait for it to come back */
	i = 1000;
	while ((NIC8(RT_CHIPCMD) & RT_CMD_RESET) && i > 0)
		i--;

	/* Reset CONFIG1 */
	NIC8(RT_CONFIG1) = 0;
	
	/* Enable auto-negotiation and restart that process */
	/* NIC16(RT_MII_BMCR) = 0x1200; */
	NIC16(RT_MII_BMCR) = 0x9200;
	
	/* Do another reset */
	NIC8(RT_CHIPCMD) = RT_CMD_RESET;
	
	/* Wait for it to come back */
	i = 1000;
	while ((NIC8(RT_CHIPCMD) & RT_CMD_RESET) && i > 0)
		i--;

	/* Enable writing to the config registers */
	NIC8(RT_CFG9346) = 0xc0;
	
	/* Read MAC address */
	tmp = NIC32(RT_IDR0);
	rtl.mac[0] = tmp & 0xff;
	rtl.mac[1] = (tmp >> 8) & 0xff;
	rtl.mac[2] = (tmp >> 16) & 0xff;
	rtl.mac[3] = (tmp >> 24) & 0xff;
	tmp = NIC32(RT_IDR0+4);
	rtl.mac[4] = tmp & 0xff;
	rtl.mac[5] = (tmp >> 8) & 0xff;
	dbglog(DBG_INFO, "eth: MAC Address is %02x:%02x:%02x:%02x:%02x:%02x\n",
		rtl.mac[0], rtl.mac[1], rtl.mac[2],
		rtl.mac[3], rtl.mac[4], rtl.mac[5]);

	/* Enable receive and transmit functions */
	NIC8(RT_CHIPCMD) = RT_CMD_RX_ENABLE | RT_CMD_TX_ENABLE;

	/* Set Rx FIFO threashold to 1K, Rx size to 16k+16, 1024 byte DMA burst */
	/* nic32[RT_RXCONFIG/4] = 0x0000c600; */

	/* Set Rx FIFO threashold to 1K, Rx size to 8k, 1024 byte DMA burst */
	NIC32(RT_RXCONFIG) = 0x00000e00;
	
	/* Set Tx 1024 byte DMA burst */
	NIC32(RT_TXCONFIG) = 00000600;

	/* Turn off lan-wake and set the driver-loaded bit */
	NIC8(RT_CONFIG1) = (NIC8(RT_CONFIG1) & ~0x30) | 0x20;
	
	/* Enable FIFO auto-clear */
	NIC8(RT_CONFIG4) |= 0x80;
	
	/* Switch back to normal operation mode */
	NIC8(RT_CFG9346) = 0;
	
	/* Setup RX/TX buffers */
	NIC32(RT_RXBUF) = 0x01840000;
	NIC32(RT_TXADDR0 + 0) = 0x01846000;
	NIC32(RT_TXADDR0 + 4) = 0x01846800;
	NIC32(RT_TXADDR0 + 8) = 0x01847000;
	NIC32(RT_TXADDR0 + 12) = 0x01847800;

	/* Reset RXMISSED counter */
	NIC32(RT_RXMISSED) = 0;
	
	/* Enable receiving broadcast and physical match packets */
	NIC32(RT_RXCONFIG) |= 0x0000000a;
	
	/* Filter out all multicast packets */
	NIC32(RT_MAR0 + 0) = 0;
	NIC32(RT_MAR0 + 4) = 0;
	
	/* Disable all multi-interrupts */
	NIC16(RT_MULTIINTR) = 0;

	/* Enable G2 interrupts; we unfortunately have to go behind g2evt's
	   back because this interrupt doesn't properly set the G2 event
	   bits in the mask registers. */
	irq_set_handler(EXC_IRQB, eth_irq_hnd);
	G2_IRQB_B = 1 << 3;

	/* Enable receive interrupts */
	/* XXX need to handle more! */
	NIC16(RT_INTRSTATUS) = 0xffff;
	NIC16(RT_INTRMASK) = RT_INT_PCIERR |
		RT_INT_TIMEOUT |
		RT_INT_RXFIFO_OVERFLOW |
		RT_INT_RXFIFO_UNDERRUN |
		RT_INT_RXBUF_OVERFLOW |
		RT_INT_TX_ERR |
		RT_INT_TX_OK |
		RT_INT_RX_ERR |
		RT_INT_RX_OK;

	/* Enable RX/TX once more */
	NIC8(RT_CHIPCMD) = RT_CMD_RX_ENABLE | RT_CMD_TX_ENABLE;

	/* Initialize status vars */
	rtl.cur_tx = 0;
	rtl.cur_rx = 0;

	return 0;
}

static void rx_reset() {
	rtl.cur_rx = NIC16(RT_RXBUFHEAD);
	NIC16(RT_RXBUFTAIL) = rtl.cur_rx - 16;

	rtl.cur_rx = 0;
	NIC8(RT_CHIPCMD) = RT_CMD_TX_ENABLE;

	NIC32(RT_RXCONFIG) = 0x00000e0a;

	while (!(NIC8(RT_CHIPCMD) & RT_CMD_RX_ENABLE))
		NIC8(RT_CHIPCMD) = RT_CMD_TX_ENABLE | RT_CMD_RX_ENABLE;

	NIC32(RT_RXCONFIG) = 0x00000e0a;
	NIC16(RT_INTRSTATUS) = 0xffff;
}

static void eth_hw_shutdown() {
	/* Disable receiver */
	NIC32(RT_RXCONFIG) = 0;

	/* Disable G2 interrupts */
	G2_IRQB_B &= ~(G2EVT_EXP_PCI & 0xff);
	irq_set_handler(EXC_IRQB, NULL);
}

/* Utility function to copy out a packet from the ring buffer into an SH-4
   buffer. This is done to make sure the buffers don't overflow. */
/* XXX Could probably use a memcpy8 here, even */
static void eth_copy_packet(uint8 *dst, uint32 src, int len) {
	vuint8	* pkt = mem8;

	if ( (src+len) < RX_BUFFER_LEN ) {
		/* Straight copy is ok */
		memcpy(dst, (void*)(pkt+src), len);
	} else {
		/* Have to copy around the ring end */
		memcpy(dst, (void*)(pkt+src), RX_BUFFER_LEN - src);
		memcpy(dst+(RX_BUFFER_LEN - src),
			(void*)pkt, len - (RX_BUFFER_LEN - src));
	}
}

/* Flush all RX buffers if possible, using the callback */
static void flush_packets() {
	/* printf("flushing %d packets\n", RX_BUFF_CNT - rxbuffs_free_cnt); */
	if (eth_rx_callback) {
		while (rxbuffs_free_cnt < RX_BUFF_CNT) {
			eth_rx_callback(rxbuffs[rxbuffs_tail], rxbuffs_size[rxbuffs_tail]);
			rxbuffs_tail = (rxbuffs_tail + 1) % RX_BUFF_CNT;
			rxbuffs_free_cnt++;
		}
	}

	/* Free up all RX buffers */
	rxbuffs_free_cnt = RX_BUFF_CNT;
	rxbuffs_tail = rxbuffs_head;
}

/* Copy one received packet out of the RX DMA space and into a RX buffer */
static void rx_enq(int ring_offset, int pkt_size) {
	/* Flush RX packets immidiately if neccessary */
	if (rxbuffs_free_cnt == 0)
		flush_packets();

	/* Copy out the packet */
	eth_copy_packet(rxbuffs[rxbuffs_head], ring_offset, pkt_size);
	rxbuffs_size[rxbuffs_head] = pkt_size;

	/* Move the head pointer */
	rxbuffs_head = (rxbuffs_head + 1) % RX_BUFF_CNT;
	rxbuffs_free_cnt--;
}

/* "Receive" any available packets and send them through the callback. */
static int eth_rx() {
	int	processed;
	uint32	rx_status;
	int	rx_size, pkt_size, ring_offset;
	
	processed = 0;

	/* While we have frames left to process... */	
	while (!(NIC8(RT_CHIPCMD) & 1)) {
		/* Get frame size and status */
		ring_offset = rtl.cur_rx % RX_BUFFER_LEN;
		rx_status = mem32[ring_offset/4];
		rx_size = (rx_status >> 16) & 0xffff;
		pkt_size = rx_size - 4;

		if (rx_size == 0xfff0) {
			dbglog(DBG_KDEBUG, "eth: early receive triggered\n");
			break;
		}
		
		if (!(rx_status & 1)) {
			dbglog(DBG_KDEBUG, "eth: frame receive error, status is %08x; skipping\n", rx_status);
		}

		/* Tell the chip where we are for overflow checking */
		rtl.cur_rx = (rtl.cur_rx + rx_size + 4 + 3) & ~3;
		while (rtl.cur_rx >= RX_BUFFER_LEN)
			rtl.cur_rx = rtl.cur_rx - RX_BUFFER_LEN;
		NIC16(RT_RXBUFTAIL) = rtl.cur_rx - 16;
		
		if ((rx_status & 1) && (pkt_size <= 1514)) {
			/* Add it to the rx queue */
			rx_enq(ring_offset + 4, pkt_size);
		} else {
			dbglog(DBG_KDEBUG, "eth: bogus packet receive detected; skipping packet\n");
		}
		processed++;
	}

	flush_packets();
	
	return processed;
}

/* Transmit a single packet */
int eth_tx(uint8 *pkt, int len, int wait) {
	/* int i;

	printf("Transmitting packet:\r\n");
	for (i=0; i<len; i++) {
		printf("%02x ", pkt[i]);
		if (i && !(i % 16))
			printf("\r\n");
	}
	printf("\r\n"); */

	if (!link_stable) {
		if (wait == ETH_TX_WAIT) {
			while (!link_stable)
				;
		} else
			return ETH_TX_AGAIN;
	}

	/* Wait till it's clear to transmit */
	if (wait == ETH_TX_WAIT) {
		while ( !(NIC32(RT_TXSTATUS0 + 4*rtl.cur_tx) & 0x2000) ) {
			if (NIC32(RT_TXSTATUS0 + 4*rtl.cur_tx) & 0x40000000)
				NIC32(RT_TXSTATUS0 + 4*rtl.cur_tx) |= 1;
		}
	} else {
		if ( !(NIC32(RT_TXSTATUS0 + 4*rtl.cur_tx) & 0x2000) ) {
			return ETH_TX_AGAIN;
		}
	}
	
	/* Copy the packet out to RTL memory */
	/* XXX could use store queues or memcpy8 here */
	/*if (len & 3) len = (len + 3) & ~3; */
	memcpy((void*)txdesc[rtl.cur_tx], pkt, len);
	
	/* All packets must be at least 60 bytes */
	if (len < 60) len = 60;
	
	/* Transmit from the current TX buffer */
	NIC32(RT_TXSTATUS0 + 4*rtl.cur_tx) = len;
	
	/* Go to the next TX buffer */
	rtl.cur_tx = (rtl.cur_tx + 1) % 4;

	return ETH_TX_OK;
}

/* Ethernet IRQ handler */
static void eth_irq_hnd(irq_t src, irq_context_t *context) {
	int intr, hnd;

	/* Acknowledge G2 interrupt */
	G2_ACK_B = 1 << 3;

	/* Acknowledge 8193 interrupt */
	intr = NIC16(RT_INTRSTATUS);
	NIC16(RT_INTRSTATUS) = intr;

	/* Do processing */
	hnd = 0;
	if (intr & RT_INT_RX_OK) {
		eth_rx(); hnd = 1;
	}
	if (intr & RT_INT_TX_OK) {
		hnd = 1;
	}
	if (intr & RT_INT_LINK_CHANGE) {
		if (!link_stable) {
			dbglog(DBG_KDEBUG, "eth: link stabilized\n");
			link_stable = 1;
		} else {
			dbglog(DBG_KDEBUG, "eth: link change\n");
			link_stable = 0;
			NIC16(RT_MII_BMCR) = 0x9200;
		}
		hnd = 1;
	}
	if (intr & RT_INT_RXBUF_OVERFLOW) {
		dbglog(DBG_KDEBUG, "eth: RX overrun\n");
		rx_reset();
		hnd = 1;
	}
	if (!hnd) {
		dbglog(DBG_KDEBUG, "eth: spurious interrupt, status is %04x\n", intr);
	}
}

/****************************************************************************/
/* Default packet handler: responds to ping and that's about it */

#define packed __attribute__((packed))
typedef struct {
	uint8	dest[6]		packed;
	uint8	src[6]		packed;
	uint8	type[2]		packed;
} eth_hdr_t;

typedef struct {
	uint8	version_ihl	packed;
	uint8	tos		packed;
	uint16	length		packed;
	uint16	packet_id	packed;
	uint16	flags_frag_offs	packed;
	uint8	ttl		packed;
	uint8	protocol	packed;
	uint16	checksum	packed;
	uint32	src		packed;
	uint32	dest		packed;
} ip_hdr_t;

typedef struct {
	uint8	type		packed;
	uint8	code		packed;
	uint16	checksum	packed;
	uint32	misc		packed;
} icmp_hdr_t;
#undef packed

/* Perform an IP-style checksum on a block of data */
static uint16 checksum(uint16 *data, int words) {
	uint32 sum;
	int i;

	sum = 0;
	for (i=0; i<words; i++) {
		sum += data[i];
		if (sum & 0xffff0000) {
			sum &= 0xffff;
			sum++;
		}
	}

	return ~(sum & 0xffff);
}

static uint16 ntohs(uint16 n) {
	return ((n & 0xff) << 8) | ((n >> 8) & 0xff);
}

static uint8 pktbuf[1514];
static void default_rx_hnd(uint8 *pkt, int pktsize) {
	eth_hdr_t	*eth;
	ip_hdr_t	*ip;
	icmp_hdr_t	*icmp;
	int		i;
	uint8		tmp[6];
	
	/* Get pointers */
	eth = (eth_hdr_t*)(pkt + 0);
	ip = (ip_hdr_t*)(pkt + sizeof(eth_hdr_t));

	/* Non-IP */
	if (eth->type[0] != 0x08)
		return;

	if (eth->type[1] != 0x00)
		return;

	/* Ignore fragments */
	if (ntohs(ip->flags_frag_offs) & 0x3fff)
		return;

	/* Check ip header checksum */
	i = ip->checksum;
	ip->checksum = 0;
	ip->checksum = checksum((uint16*)ip, 2*(ip->version_ihl & 0x0f));
	if (i != ip->checksum) {
		dbglog(DBG_KDEBUG, "eth: ip with invalid checksum\n");
		return;
	}

	if (ip->protocol != 1)
		return;

	/* Find ICMP header */
	icmp = (icmp_hdr_t*)(pkt + sizeof(eth_hdr_t) + 4*(ip->version_ihl & 0x0f));
	
	/* Check icmp checksum */
	memset(pktbuf, 0, ntohs(ip->length) + (ntohs(ip->length) % 2)
		- 4*(ip->version_ihl & 0x0f));
	i = icmp->checksum;
	icmp->checksum = 0;
	memcpy(pktbuf, icmp, ntohs(ip->length) - 4*(ip->version_ihl & 0x0f));
	icmp->checksum = checksum((uint16*)pktbuf,
		(ntohs(ip->length) + 1) / 2 - 2*(ip->version_ihl & 0x0f));
	if (i != icmp->checksum) {
		dbglog(DBG_KDEBUG, "eth: icmp with invalid checksum\n");
	//	return;
	}

	if (icmp->type == 8) {	/* echo request */
		icmp->type = 0;	/* echo reply */

		/* Swap source and dest addresses */
		memcpy(tmp, eth->dest, 6);
		memcpy(eth->dest, eth->src, 6);
		memcpy(eth->src, tmp, 6);

		/* Swap source and dest ip addresses */
		memcpy(&i, &ip->src, 4);
		memcpy(&ip->src, &ip->dest, 4);
		memcpy(&ip->dest, &i, 4);

		/* Recompute the IP header checksum */
		ip->checksum = 0;
		ip->checksum = checksum((uint16*)ip, 2*(ip->version_ihl & 0x0f));

		/* Recompute the ICMP header checksum */
		icmp->checksum = 0;
		icmp->checksum = checksum((uint16*)icmp, ntohs(ip->length)/2 - 2*(ip->version_ihl & 0x0f));

		/* Send it */
		eth_tx(pkt, sizeof(eth_hdr_t) + ntohs(ip->length), ETH_TX_WAIT);
	}

	/* int i;
	
	for (i=0; i<pktsize; i++) {
		printf("%02x ", pkt[i]);
		if (i && !(i % 16))
			printf("\n");
	}
	printf("\n"); */
}


/****************************************************************************/
/* Initialize */
int eth_init() {
	/* Setup software RX buffers */
	rxbuffs_free_cnt = RX_BUFF_CNT;
	rxbuffs_head = 0;
	rxbuffs_tail = 0;

	/* Start off with no callback */
	eth_set_rx_callback(default_rx_hnd);

	/* Initialize the ethernet */
	if (eth_hw_init() < 0) {
		return -1;
	}

	return 0;
}

/* Shutdown */
int eth_shutdown() {
	eth_hw_shutdown();
	return 0;
}








