/* KallistiOS 1.1.4

   kos.h
   (c)2001 Dan Potter

   kos.h,v 1.3 2001/10/19 04:52:58 tekezo Exp
*/

#ifndef __KOS_H
#define __KOS_H

/* The ultimate for the truly lazy: include and go! No more figuring out
   which headers to include for your project. */

#ifdef __cplusplus
extern "C" {
#endif

#include <ctype.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* These still haven't been fully ported */
/* #include <kos/msg.h> */

#include <kos/fs.h>
#include <kos/fs_builtin.h>
#include <kos/fs_romdisk.h>
#include <kos/limits.h>
#include <kos/pcx.h>
#include <kos/thread.h>
#include <kos/sem.h>
#include <kos/cond.h>

#include <arch/arch.h>
#include <arch/cache.h>
#include <arch/dbgio.h>
#include <arch/irq.h>
#include <arch/spinlock.h>
#include <arch/syscall.h>
#include <arch/timer.h>
#include <arch/types.h>

#ifdef _arch_dreamcast
#	include <dc/biosfont.h>
#	include <dc/cdrom.h>
#	include <dc/controller.h>
#	include <dc/fs_dcload.h>
#	include <dc/fs_iso9660.h>
#	include <dc/fs_vmu.h>
#	include <dc/g2.h>
#	include <dc/keyboard.h>
#	include <dc/maple.h>
#	include <dc/mouse.h>
#	include <dc/spu.h>
#	include <dc/ta.h>
#	include <dc/video.h>
#	include <dc/vmu.h>
#	include <dc/fmath.h>

#	include <mp3/sndserver.h>
#	include <os/process.h>
#	include <os/svcmpx.h>
#	include <dcutils/3dutils.h>
#	include <dcutils/bspline.h>
#	include <dcutils/matrix.h>
#	include <dcutils/pcx.h>
#	include <dcutils/precompiler.h>
#	include <dcutils/pvrutils.h>
#endif	/* _arch_dreamcast */

#ifdef _arch_gba
#	include <gba/keys.h>
#	include <gba/sprite.h>
#	include <gba/video.h>
#endif	/* _arch_gba */


#ifdef __cplusplus
}
#endif

#endif

