/* KallistiOS 1.1.4

   main.c
   (c)2000 Dan Potter
*/

static char id[] = "KOS main.c,v 1.3 2001/10/19 04:52:59 tekezo Exp";

extern int _bss_start, end;

#include <stdio.h>
#include <malloc.h>
#include <arch/syscall.h>
#include <arch/dbgio.h>
#include <arch/timer.h>
#include <arch/arch.h>

int	mm_init();

int	main(int argc, char **argv);

/* This is the entry point inside the C program */
int arch_main() {
	uint8 *bss_start = (uint8 *)(&_bss_start);
	uint8 *bss_end = (uint8 *)(&end);
	int rv;

	/* Clear out the BSS area */
	memset(bss_start, 0, bss_end - bss_start);

	/* Initialize memory management */
	mm_init();

	/* Call the user's main function */
	rv = main(0, NULL);

	/* Call kernel exit */
	arch_exit();

	return rv;
}

/* Called to shut down the system */
void arch_exit() {
	dbglog(DBG_CRITICAL, "arch: shutting down kernel\n");

	/* Shut down kernel functions */
	hardware_shutdown();

	/* Ensure that interrupts are disabled */
	irq_disable();

	/* Shut down Dreamcast functions */
	irq_shutdown();

	/* Jump back to the boot loader */
	arch_real_exit();
}

/* Called from syscall to reboot the system */
void arch_reboot() {
	dbglog(DBG_CRITICAL, "arch: rebooting the system\n");

	/* Ensure that interrupts are disabled */
	irq_disable();

	/* Shut down Dreamcast functions */
	irq_shutdown();

	/* Reboot */
	{ void (*rb)() = (void (*)())0xa0000000; rb(); }
}


/* When you make a function called main() in a GCC program, it wants
   this stuff too. */
void _main() { }
void atexit() { }

/* And some library funcs from newlib want this */
int __errno;

