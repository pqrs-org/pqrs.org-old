/* Tryptonite

   pvrutils.h
   (c)2000 Dan Potter

*/

#ifndef __PVRUTILS_H
#define __PVRUTILS_H

#include <arch/types.h>

/* Twiddle function -- copies from a source rectangle in SH-4 ram to a
   destination texture in PVR ram. */
void txr_twiddle_copy(const uint16 *src, uint32 srcw, uint32 srch,
		uint32 dest, uint32 destw, uint32 desth, uint16 bkg);

/* Twiddle function -- copies from a source rectangle in SH-4 ram to a
   destination texture in PVR ram. The image will be scaled to the texture
   size. */
void txr_twiddle_scale(const uint16 *src, uint32 srcw, uint32 srch,
		uint32 dest, uint32 destw, uint32 desth);

/* Adjusts a 16-bit image so that instead of RGB565 gray scales, you will
   have ARGB4444 alpha scales. The resulting image will be entirely white. */
void txr_to_alpha(uint16 *img, int x, int y);

/* Commits a dummy polygon (for unused lists). Specify the polygon
   type (opaque/translucent). */
void pvr_dummy_poly(int type);

/* Commits an entire blank frame. Assumes two lists active (opaque/translucent) */
void pvr_blank_frame();

#endif	/* __PVRUTILS_H */
