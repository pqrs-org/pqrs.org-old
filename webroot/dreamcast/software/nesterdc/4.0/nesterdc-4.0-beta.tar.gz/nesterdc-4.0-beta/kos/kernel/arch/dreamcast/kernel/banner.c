char banner[] = 
"KallistiOS 1.1.4: Thu Nov 8 01:31:41 JST 2001\n"
"  tekezo@:/home/tekezo/work/tmp/nesterdc-4.0-beta/kos\n"
;
