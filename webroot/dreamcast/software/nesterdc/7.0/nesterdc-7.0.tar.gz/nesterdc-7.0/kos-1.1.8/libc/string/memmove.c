#define	MEMMOVE
#include "bcopy.c"
