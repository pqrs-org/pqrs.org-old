/* KallistiOS 1.1.8

   init_defaults.c
   (c)2002 Dan Potter
*/

#include <arch/arch.h>

CVSID("init_flags_default.c,v 1.1.1.1 2002/10/09 13:59:15 tekezo Exp");

/* Default values which will be used if the user doesn't declare anything */
KOS_INIT_FLAGS(INIT_DEFAULT);

