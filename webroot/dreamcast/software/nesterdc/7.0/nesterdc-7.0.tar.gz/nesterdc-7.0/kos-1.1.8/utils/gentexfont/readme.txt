I downloaded this from the web article which discusses TXF fonts and
included it here as a convienence. Note that this will probably not compile
under Cygwin (though it might... never know =) and so I haven't put it 
in the default build. You can compile your own by just doing "make" here.

                                                   - Dan
                                                   
