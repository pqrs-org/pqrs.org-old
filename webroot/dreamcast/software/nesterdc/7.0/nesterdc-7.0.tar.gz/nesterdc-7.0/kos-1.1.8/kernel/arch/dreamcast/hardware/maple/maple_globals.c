/* KallistiOS 1.1.8

   maple_globals.c
   (c)2002 Dan Potter
 */

#include <dc/maple.h>

CVSID("maple_globals.c,v 1.1.1.1 2002/10/09 13:59:14 tekezo Exp");

/* Global state info */
maple_state_t	maple_state;

