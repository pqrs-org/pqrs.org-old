/* KallistiOS 1.1.8

   getenv.c
   (c)2001 Dan Potter

   getenv.c,v 1.1.1.1 2002/10/09 13:59:14 tekezo Exp
*/

/* getenv() */
char *getenv(const char *name) {
	return (char *)0;
}

