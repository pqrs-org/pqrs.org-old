/* KallistiOS 1.1.8

   wchar.h
   (c)2001 Dan Potter

   wchar.h,v 1.1.1.1 2002/10/09 13:59:14 tekezo Exp
*/

#ifndef __WCHAR_H
#define __WCHAR_H

#define __need_wchar_t
#include <stddef.h>

#endif   /* __WCHAR_H */
