#ifndef __ERRNO_H
#define __ERRNO_H

/* Temporary stand-in for now to make libm happy */

#define EDOM -1
#define ERANGE -2
extern int errno;

#endif
