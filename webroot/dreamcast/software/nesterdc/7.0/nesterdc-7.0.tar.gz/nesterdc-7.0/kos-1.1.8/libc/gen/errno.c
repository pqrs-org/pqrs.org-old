/* KallistiOS 1.1.8

   errno.c
   (c)2002 Dan Potter

   errno.c,v 1.1.1.1 2002/10/09 13:59:14 tekezo Exp
*/

#include <sys/cdefs.h>

CVSID("errno.c,v 1.1.1.1 2002/10/09 13:59:14 tekezo Exp");

int errno = 0;
