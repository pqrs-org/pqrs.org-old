#define	BZERO
#include "memset.c"
