expanded NesterDC memory layout


#========================================
Dreamcast memory: 

0x8c010000: nesterdc
...
_end:       end of nesterdc 
            heap start
...
            heap end (increasing while running)
...
            stack end (decreasing while running)
...
0x8d000000: stack start


#========================================
Video memory: 0xa5000000 - 0xa57fffff

0xa5000000: start
0xa5025800: start screen1 (for triple buffering)
0xa504b000: start screen2 (for triple buffering)
0xa5070800: end of screen buffer 
... (not use)
0xa5800000: end of Video memory


NOTE: 
 Once I try to use Video memory 0xa5100000-0xa5800000 for SNSS. 
But the written data be broken....


#========================================
Sound memory: 0xa0800000 - 0xa09fffff

0xa0800000: start binary for AICA
0xa0880000: stack start
0xa08a0000: start working area 
0xa0900000: heap start 


NOTE:
 Once I try to work apu engine on AICA, 
It's bottleneck that sync working RAM between SH4 and AICA...
If AICA can get System RAM, sync be unnecessary.
(sound memory is too slow for r/w. 
if working RAM puts on sound memory, emulation speed badly down. 
So, working RAM must be on System RAM). 

