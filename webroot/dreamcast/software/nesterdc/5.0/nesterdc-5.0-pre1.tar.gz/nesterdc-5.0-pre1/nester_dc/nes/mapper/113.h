
/////////////////////////////////////////////////////////////////////
// Mapper 113
class NES_mapper113 : public NES_mapper
{
  friend class NES_SNSS;

public:
  NES_mapper113(NES* parent) : NES_mapper(parent) {}
  ~NES_mapper113() {}

  void  Reset();
  void  MemoryWriteLow(uint32 addr, uint8 data);
  void  MemoryWrite(uint32 addr, uint8 data);

protected:
private:
};
/////////////////////////////////////////////////////////////////////

