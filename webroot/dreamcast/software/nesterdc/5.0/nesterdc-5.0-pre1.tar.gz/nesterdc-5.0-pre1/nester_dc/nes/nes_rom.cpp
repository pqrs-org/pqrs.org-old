/*
** nester - NES emulator
** Copyright (C) 2000  Darren Ranalli
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

/* 
** NesterDC by Ken Friece
** This routine was so different than the original, that I included 
** diff output at the bottom of the routine. The orginal is also called
** nes_rom.cpp.original
*/

#include "types.h"
#include "dc_utils.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "nes_rom.h"
#include "nes.h"
#include "debug.h"

NES_ROM::NES_ROM(const char* fn)
{
  file_t fd = 0;
  size_t nread;

  trainer    = NULL;
  ROM_banks  = NULL;
  VROM_banks = NULL;

  rom_name = NULL;
  rom_path = NULL;
  
  uint8 image_type = 0;
  
  try 
  {
    // store filename and path
    rom_name = (char*)malloc(strlen(fn)+1);
    rom_path = (char*)malloc(strlen(fn)+1);
    if(!rom_name || !rom_path) 
      throw "Error loading ROM: out of memory";
    
    GetPathInfo (fn);
    
    fd = fs_open (fn, O_RDONLY);
    if(!fd)
      throw "Error opening ROM file";
    
    nread = 16;
    if(fs_read(fd, (void*)&header, nread) != nread) 
      throw "Error reading from NES ROM";
    
    // patch for 260-in-1(#235)
    header.num_16k_rom_banks = (!header.dummy) ? 256 : header.dummy;
    
    if(!strncmp((const char*)header.id, "NES", 3) || (header.ctrl_z != 0x1A)) 
      image_type = read_nes_rom (fd);
    
    else if(!strncmp((const char*)header.id, "FDS", 3) && (header.ctrl_z == 0x1A))
      image_type = read_fds_rom (fd);

    else
      throw "Invalid NES file";
    
    fs_close (fd);
  } 
  catch(...) 
  {
    if(fd)          fs_close(fd);
    
    if(VROM_banks)  free(VROM_banks);
    if(ROM_banks)   free(ROM_banks);
    if(trainer)     free(trainer);
    
    if(rom_name)    free(rom_name);
    if(rom_path)    free(rom_path);
    throw;
  }

  crc = fds = 0;
  screen_mode = 0;
  
  if(image_type == 1)
  {
    screen_mode = 1;
    mapper = 20;
    
    fds = (ROM_banks[0x1f] << 24) | (ROM_banks[0x20] << 16) |
      (ROM_banks[0x21] <<  8) | (ROM_banks[0x22] <<  0);
    
    for(int i = 0; i < ROM_banks[4]; i++)
    {
      uint8 file_num = 0;
      uint32 pt = 16+65500*i+0x3a;
      while(ROM_banks[pt] == 0x03)
      {
        pt += 0x0d;
        pt += ROM_banks[pt] + ROM_banks[pt+1] * 256 + 4;
        file_num++;
      }
      ROM_banks[16+65500*i+0x39] = file_num;
    }
  }
  else
    crc = calc_crc();
  
  mapper = (header.flags_1 >> 4);
  
  #include "nes_rom_correct.cpp"
  
  // if there is anything in the reserved bytes,
  // don't trust the high nybble of the mapper number
  bool header_valid = true;
  for(uint32 i = 0; i < sizeof(header.reserved); i++) 
  {
    if(header.reserved[i] != 0x00) 
      header_valid = false;
  }
  if (header_valid) 
    mapper |= (header.flags_2 & 0xF0);
  else 
  {
    dc_put_error ("Invalid NES header ($8-$F)");
#ifndef __DREAMCAST__
    throw "Invalid NES header ($8-$F)";
#endif
  }
}


NES_ROM::~NES_ROM()
{
  if(VROM_banks)  free(VROM_banks);
  if(ROM_banks)   free(ROM_banks);
  if(trainer)     free(trainer);
  if(rom_name)    free(rom_name);
  if(rom_path)    free(rom_path);
}


void NES_ROM::GetPathInfo(const char* fn)
{
  // find index of first letter of actual ROM file name (after path)
  uint32 i = strlen(fn); // start at end of string

  while(1)
  {
    // look for directory delimiter
    if((fn[i] == '\\') || (fn[i] == '/'))
    {
      i++;
      break;
    }

    i--;
    if(!i) break;
  }

  // copy rom name
  {
    uint32 j = i;
    uint32 a = 0;

    // copy up to period
    while(1)
    {
      if(!fn[j]) break;
#ifndef __DREAMCAST__
      if(fn[j] == '.') break;
#endif
      
      rom_name[a] = fn[j];

      a++;
      j++;
    }

    // terminate rom name string
    rom_name[a] = '\0';
  }
  
  // copy rom path
  {
    uint32 j = 0;

    // copy up to rom file name
    while(j < i)
    {
      rom_path[j] = fn[j];
      j++;
    }

    // terminate rom path string
    rom_path[i] = '\0';
  }
}


uint8
NES_ROM::read_nes_rom (file_t fd)
{
  size_t nread;
  uint8 image_type = 0;

  // allocate memory
  ROM_banks = (uint8*)malloc(header.num_16k_rom_banks * (16*1024));
  if(!ROM_banks) throw "Out of memory";
  
  VROM_banks = (uint8*)malloc(header.num_8k_vrom_banks * (8*1024));
  if(!VROM_banks) throw "Out of memory";
  
  // load trainer if present
  if (has_trainer()) 
  {
    trainer = (uint8*)malloc(TRAINER_LEN);
    if(!trainer) throw "Out of memory";
    
    if (fs_read (fd, trainer, TRAINER_LEN) < 1) 
      throw "Error reading trainer from NES ROM";
  }
  
  nread = 16 * 1024 * header.num_16k_rom_banks; 
  if (fs_read(fd, ROM_banks, nread) != nread) 
    throw "Error reading ROM banks from NES ROM";
  
  nread = 8 * 1024 * header.num_8k_vrom_banks;
  if (fs_read(fd, VROM_banks, nread) != nread) 
    throw "Error reading VROM banks from NES ROM";
  
  if(((header.flags_1 >> 4) | (header.flags_2 & 0xF0)) == 20)
  {
    image_type = 1;
    
    // convert NES disk image
    uint32 rom_pt, disk_pt, i, j, k;
    uint8 file_num, disk_num;
    uint8 disk[0x40000];
    uint8 disk_header[15] =
      {
	0x01,0x2A,0x4E,0x49,0x4E,0x54,0x45,0x4E,0x44,0x4F,0x2D,0x48,0x56,0x43,0x2A
      };
    
    disk_num = header.num_16k_rom_banks >> 2;
    disk_num = (disk_num > 4) ? 4 : disk_num;
    
    for (i = 0; i < disk_num; i++)
    {
      file_num = ROM_banks[0x10000*i+0x3F];
      rom_pt = 0x10000*i+0x40;
      disk_pt = 0x10000*i+0x3A;
      for(j = 0x00; j <= 0x0E; j++)
      {
	disk[0x10000*i+j] = disk_header[j];
      }
      for(j = 0x0F; j <= 0x37; j++)
      {
	disk[0x10000*i+j] = ROM_banks[0x10000*i+j-0x0F];
      }
      disk[0x10000*i+0x38] = 0x02;
      disk[0x10000*i+0x39] = file_num;
      for(j = 0; j < file_num; j++)
      {
	if(disk_pt < 0x10000*(i+1))
	{
	  uint32 file_size = ROM_banks[rom_pt+13]+ROM_banks[rom_pt+14]*256;
	  for(k = 0; k < 16; k++)
	  {
	    disk[disk_pt++] = ROM_banks[rom_pt++];
	  }
	  disk[disk_pt++] = 0x04;
	  for(k = 0; k < file_size; k++)
	  {
	    disk[disk_pt++] = ROM_banks[rom_pt++];
	  }
	}
      }
    }
    ROM_banks[0] = 'F';
    ROM_banks[1] = 'D';
    ROM_banks[2] = 'S';
    ROM_banks[3] = 0x1A;
    ROM_banks[4] = disk_num;
    for(i = 0; i < disk_num; i++)
    {
      for(uint32 j = 0; j < 65500; j++)
      {
	ROM_banks[65500*i+j+16] = disk[0x10000*i+j];
      }
    }
  }
  return image_type;
}


uint8
NES_ROM::read_fds_rom (file_t fd)
{
  size_t nread;
  uint8 disk_num = header.num_16k_rom_banks;
  
  header.id[0] = 'N';
  header.id[1] = 'E';
  header.id[2] = 'S';
  header.num_16k_rom_banks *= 4;
  header.num_8k_vrom_banks = 0;
  header.flags_1 = 0x40;
  header.flags_2 = 0x10;
  memset(header.reserved, 0, 8);
  
  // allocate memory
  ROM_banks = (uint8*)malloc(16 + 65500 * disk_num);
  if(!ROM_banks) throw "Out of memory";
  
  VROM_banks = (uint8*)malloc(0);
  if(!VROM_banks) throw "Out of memory";
  
  nread = 65500 * disk_num;
  if (fs_read (fd, ROM_banks + 16, nread) != nread)
    throw "Error reading FDS image";
  
  ROM_banks[0] = 'F';
  ROM_banks[1] = 'D';
  ROM_banks[2] = 'S';
  ROM_banks[3] = 0x1A;
  ROM_banks[4] = disk_num;
  
  return 1;
}


uint32
NES_ROM::calc_crc ()
{
  uint32 i, j;
  uint32 c, crctable[256];
  uint32 nes_crc = 0;
  
  for(i = 0; i < 256; i++) {
    c = i;
    for (j = 0; j < 8; j++) {
      if (c & 1)
	c = (c >> 1) ^ 0xedb88320;
      else
	c >>= 1;
    }
    crctable[i] = c;
  }
  
  for(i = 0; i < header.num_16k_rom_banks; i++) {
    c = ~nes_crc;
    for(j = 0; j < 0x4000; j++)
      c = crctable[(c ^ ROM_banks[i*0x4000+j]) & 0xff] ^ (c >> 8);
    nes_crc = ~c;
  }
  
  return nes_crc;
}


const char* 
NES_ROM::GetRomCrc() 
{
  static char rom_crc[12];
  if (fds)
    sprintf(rom_crc, "F%x", fds);
  else
    sprintf(rom_crc, "%x", crc);
  return rom_crc;
}


