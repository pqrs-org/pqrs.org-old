#ifndef _DC_MENU_H_
#define _DC_MENU_H_

#include "types.h"

#ifdef __cplusplus
extern "C" {
#endif

#if 0
}
#endif

int init_menus ();
const char *do_rom_menu();
void do_vmu_menu (uint8 addr);
uint8 do_vmu_select_menu ();

#ifdef __cplusplus
}
#endif

#endif


