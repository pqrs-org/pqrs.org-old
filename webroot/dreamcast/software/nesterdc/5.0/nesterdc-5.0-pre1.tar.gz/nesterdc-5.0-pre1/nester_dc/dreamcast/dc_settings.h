#ifndef _DC_SETTINGS_H_
#define _DC_SETTINGS_H_


#include "types.h"

class DC_settings
{
 public:
  enum cont_scheme_pattern {
    bx_aa, 
    ba_ab, 
    bx_ab, 
    cont_scheme_pattern_num
  };
  
  const char *get_cont_scheme_string () {
    static const char *strings[] = {
      "[NES_B = DC_X] [NES_A = DC_A]", 
      "[NES_B = DC_A] [NES_A = DC_B]",
      "[NES_B = DC_X] [NES_A = DC_B]"
    };
    return strings[cont_scheme];
  }
  
  void set_cont_scheme (uint8 pattern) { 
    if (pattern < cont_scheme_pattern_num)
      cont_scheme = pattern;
    switch (cont_scheme) 
    {
      case bx_aa:
        cont_b_keycode = CONT_X;
        cont_a_keycode = CONT_A;
        break;
      case ba_ab:
        cont_b_keycode = CONT_A;
        cont_a_keycode = CONT_B;
        break;
      case bx_ab:
        cont_b_keycode = CONT_X;
        cont_a_keycode = CONT_B;
        break;
      default:
        cont_b_keycode = CONT_X;
        cont_a_keycode = CONT_A;
        break;
    }
  }
  
  void inc_cont_scheme () { 
    if (cont_scheme < cont_scheme_pattern_num - 1) 
      set_cont_scheme (cont_scheme + 1);
    else
      set_cont_scheme (0);
  }
  
  uint16 get_cont_a () {
    return cont_a_keycode;
  }
  
  uint16 get_cont_b () {
    return cont_b_keycode;
  }
  
  /* */
  enum frameskip_rate {
    no_skip,
    one_per_three,
    one_per_two,
    two_per_three,
    half_skip,
    auto_skip, 
    double_speed_skip, 
    frameskip_rate_num
  };
  
  const char *get_frameskip_short_string () {
    static const char *strings[] = {
      "NO SKIP",
      "SKIP 1/3",
      "SKIP 1/2",
      "SKIP 2/3",
      "HALF AUTO",
      "NORMAL AUTO",
      "DOUBLE AUTO"
    };
    return strings[frameskip];
  }
  
  void set_frameskip (uint8 rate) { 
    if (rate < frameskip_rate_num)
      frameskip = rate;
  }
  void inc_frameskip () {
    if (frameskip < frameskip_rate_num - 1) ++frameskip; 
  }
  void dec_frameskip () { 
    if (frameskip > 0) --frameskip; 
  }
  uint8 get_frameskip () {
    return frameskip;
  }
  
  
  /* */
  void set_sound (bool which) {
    sound_on = which; 
  }
  void toggle_sound () {
    sound_on = !sound_on;
  }
  bool is_sound () { 
    return sound_on;
  }
  
  void set_player2 (bool which) {
    player2 = which;
  }

  void set_save (bool which) {
    save = which;
  }
  void toggle_save () {
    save = !save;
  }
  bool is_save () {
    return save;
  }
  
  /* */
  void set_defaults () {
    set_cont_scheme(bx_aa);
    set_frameskip(auto_skip);
    set_sound(true);
    set_sound(true);
    set_save(true);
  }
  
  uint8 find_vmu ();
  void save_to_vmu (uint8 addr);
  void load_from_vmu (uint8 addr);
  
 private:
  uint8 cont_scheme;
  uint16 cont_a_keycode;
  uint16 cont_b_keycode;
  uint8 frameskip;
  uint8	sound_on;
  uint8	player2;
  uint8	save;
};


#endif
