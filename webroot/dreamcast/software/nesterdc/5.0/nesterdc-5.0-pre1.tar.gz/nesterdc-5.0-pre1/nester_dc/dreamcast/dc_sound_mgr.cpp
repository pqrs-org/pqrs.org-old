/*
** nester - NES emulator
** Copyright (C) 2000  Darren Ranalli
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

#include "types.h"
#include "dc_sound_mgr.h"
#include "dc_utils.h"
#include "sound/aica_fw.h"

#define ARM_OFFSET 0xa0800000
static volatile uint32 *start  = (uint32*)(0x10000 + ARM_OFFSET);
static volatile uint32 *init_done = (uint32*)(0x10004 + ARM_OFFSET);
static volatile uint32 *rate = (uint32*)(0x10010 + ARM_OFFSET);
static volatile uint32 *bits = (uint32*)(0x10014 + ARM_OFFSET);
static volatile uint32 *buf_len = (uint32*)(0x10018 + ARM_OFFSET);
static volatile uint32 *position  = (uint32*)(0x10020 + ARM_OFFSET);
#define BASE_ADDRESS 0x11000

/* SOUND_BUF_LEN = 2 * (rate * buffer_length_in_frames / 60.0) * (bit / 8) */
/* ((lambda (x) (* 2 (/ (* 44100 x) 60) (/ 16 8))) 3) */
/* NOTE: 8820 crash program, so we use 8840 instead 8820 */
#define SAMPLE_RATE 44100
#define SOUND_BUF_LEN 8840
#define SAMPLE_BITS 16

dc_sound_mgr::dc_sound_mgr() : sound_mgr(SAMPLE_RATE, SAMPLE_BITS, SOUND_BUF_LEN)
{
  buffer = (uint8 *)malloc(SOUND_BUF_LEN / 2);
  buffer_locked = false;
  
  spu_disable();
  /* need a rest after spu_disable() */
  timer_sleep (200); 
  
  *init_done = false;
  spu_write_wait ();
  
  clear_buffer();
  spu_memload (0, NDC_sound, sizeof(NDC_sound));
  spu_enable ();
  
  *rate = SAMPLE_RATE;
  *bits = SAMPLE_BITS;
  *buf_len = SOUND_BUF_LEN;
  spu_write_wait ();
  
  for (;;)
  {
    uint32 done = *init_done;
    spu_write_wait ();
    
    if (done)
      break;
    
    timer_sleep (100);
  }
  
  *start = true;
  spu_write_wait ();
}


dc_sound_mgr::~dc_sound_mgr()
{
  free(buffer);
  spu_disable();
  /* need a rest after spu_disable() */
  timer_sleep (200);
}


void
dc_sound_mgr::clear_buffer()
{
  spu_memset (BASE_ADDRESS, 0, SOUND_BUF_LEN);
}


inline boolean 
dc_sound_mgr::lock(sound_buf_pos which, void** buf, uint32* buf_len)
{
  if (buffer_locked) return false;
  
  buffer_locked = true;
  curbuffer = (which == SOUND_BUF_HIGH);
  *buf = buffer;
  *buf_len = SOUND_BUF_LEN / 2;
  return true;
}


inline void
dc_sound_mgr::unlock()
{
  if (!buffer_locked) return;
  
  buffer_locked = false;
  spu_memload (BASE_ADDRESS + (SOUND_BUF_LEN / 2) * curbuffer, 
	       buffer, SOUND_BUF_LEN / 2);
}


/* return the alternation of SOUND_BUF_LOW and SOUND_BUF_HIGH,
   because of NES_APU::DoFrame implement. */
inline sound_mgr::sound_buf_pos
dc_sound_mgr::get_currently_playing_half()
{
  uint32 val;
  val = *position * (SAMPLE_BITS / 8);
  
  if (val < SOUND_BUF_LEN / 2)
    return SOUND_BUF_LOW;
  else
    return SOUND_BUF_HIGH;
}


