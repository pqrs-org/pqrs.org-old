/* 2001 Takayama Fumihiko <tekezo@catv296.ne.jp> */

/* This code is for nes/libsnss. */

#include "dc_utils.h"
#include "dc_mfs.h"
#include "libsnss.h"

/* in the video memory */
static void *quick_slot_memory = NULL;
/* end of the video memory */
static void *quick_slot_memory_end = NULL;
static const uint32 memsize = sizeof(SNSS_FILE) + 0x8000 + 0x40000 * 2; /* last two for mapper 20 */
static size_t filesize = 0;

void m_init()
{
  quick_slot_memory = malloc(memsize);
  quick_slot_memory_end = quick_slot_memory + memsize;
  m_clear();
}


void m_clear()
{
  filesize = 0;
  memset(quick_slot_memory, 0, memsize);
}


M_FILE *
m_open(const char *path, const char *mode)
{
  M_FILE *stream = malloc(sizeof(M_FILE));
  
  stream->quick_slot = quick_slot_memory;
  stream->mode = 0;
  
  if (!strcmp(mode, "r") || !strcmp(mode, "rb")) 
    stream->mode |= READ;
  else if (!strcmp(mode, "w") || !strcmp(mode, "wb")) 
  {
    stream->mode |= WRITE;
    filesize = 0;
  }
  else if (!strcmp(mode, "a") || !strcmp(mode, "ab")) 
  {
    stream->mode |= WRITE;
    fseek (stream, 0, SEEK_END);
  }
  
  return stream;
}


int
m_close(M_FILE *stream)
{
  free(stream);
  return 0;
}


size_t
m_read(void *ptr, size_t size, size_t nmemb, M_FILE *stream)
{
  size_t nread = size * nmemb;

  if (!(stream->mode & READ)) {
    dc_put_error ("m_read: open mode incorrect");
    return 0;
  }
  
  if (stream->quick_slot < quick_slot_memory) {
    dc_put_error ("m_read: invalid file pointer");
    return 0;
  }
  
  if (stream->quick_slot + nread > quick_slot_memory_end) {
    dc_put_error ("m_read: out of memory");
    return 0;
  }
  
  memcpy(ptr, stream->quick_slot, nread);
  stream->quick_slot += nread;
  return nmemb;
}


size_t
m_write(void *ptr, size_t size, size_t nmemb, M_FILE *stream)
{
  size_t nwrite = size * nmemb;
  
  if (!(stream->mode & WRITE)) {
    dc_put_error ("m_read: open mode incorrect");
    return 0;
  }
  
  if (stream->quick_slot < quick_slot_memory) {
    dc_put_error ("m_write: invalid file pointer");
    return 0;
  }
  
  if (stream->quick_slot + nwrite >= quick_slot_memory_end) {
    dc_put_error ("m_write: out of memory");
    return 0;
  }
  
  memcpy(stream->quick_slot, ptr, nwrite);
  stream->quick_slot += nwrite;
  filesize += nwrite;
  return nmemb;
}


int
m_seek(M_FILE *stream, int32 offset, int whence)
{
  switch (whence) {
  case SEEK_SET:
    stream->quick_slot = quick_slot_memory + offset;
    break;
  case SEEK_CUR:
    stream->quick_slot += offset;
    break;
  case SEEK_END:
    stream->quick_slot = quick_slot_memory + filesize;
  }
  return 0;
}


int
m_tell(M_FILE *stream)
{
  return stream->quick_slot - quick_slot_memory;
}


size_t
m_size(M_FILE *stream)
{
  return filesize;
}


