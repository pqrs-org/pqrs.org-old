/*
** nester - NES emulator
** Copyright (C) 2000  Darren Ranalli
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

/* 
** NesterDC by Ken Friece
** This routine was so different than the original, that I included 
** diff output at the bottom of the routine. The orginal is also called
** nes.cpp.original
*/

#include "dc_utils.h"
#include "vmu.h"
#include "stdlib.h"
#include <string.h>
#include <math.h>
#include "nes.h"
#include "nes_screen_mgr.h"
#include "nes_rom.h"
#include "nes_ppu.h"
#include "pixmap.h"
#include "snss.h"

#include "debug.h"
#include "bzlib.h"

#ifndef __DREAMCAST__
const uint8 NES::NES_preset_palette[NES_NUM_COLORS][3] = 
{
// include the NES palette
#include "nes_pal.h"
};
#endif

//const float NES::CYCLES_PER_LINE = (float)113.6;
//const float NES::CYCLES_PER_LINE = (float)113.852;
//const float NES::CYCLES_PER_LINE = (float)113.75;
//const float NES::CYCLES_PER_LINE = (float)113.6666666666666666666;


NES::NES(const char* ROM_name, NES_screen_mgr* _screen_mgr, sound_mgr* _sound_mgr)
{
  scr_mgr = _screen_mgr;
  snd_mgr = _sound_mgr;
  
  scr_mgr->setParentNES(this);
  
  LOG("nester - NES emulator by Darren Ranalli, (c) 2000\n");
  
  cpu = NULL;
  ppu = NULL;
  apu = NULL;
  
  try {
    cpu = new NES_6502(this);
    if(!cpu) throw "error allocating cpu";
    
    ppu = new NES_PPU(this);
    if(!ppu) throw "error allocating ppu";
    
    apu = new NES_APU(this);
    if(!apu) throw "error allocating apu";
    
    snss = new NES_SNSS();
    if (!snss) throw "error allocating snss";
    
    loadROM(ROM_name);
  } catch(...) {
    dc_put_error ("something error in NES::NES");
    
    if(cpu) delete cpu;
    if(ppu) delete ppu;
    if(apu) delete apu;
    if(snss) delete snss;
    throw;
  }
  
  calculate_palette();
  
  pad1 = NULL;
  pad2 = NULL;
  
#ifdef __DREAMCAST__
  sprintf(vmu_filename, "%s", getROMcrc ());
  Load_SaveRAM();
  Load_Disk();
#endif
  
  DPCM_IRQ = true;
  is_frozen = FALSE;
}

NES::~NES()
{
  freeROM();
  
  if(cpu) delete cpu;
  if(ppu) delete ppu;
  if(apu) delete apu;
  if(snss) delete snss;
}

void NES::new_snd_mgr(sound_mgr* _sound_mgr)
{
  snd_mgr = _sound_mgr;
  apu->snd_mgr_changed();
}

void NES::loadROM(const char* fn)
{
  LOG("Loading ROM...");
  dc_print ("Loading ROM...");
  
  ROM = new NES_ROM(fn);
  
  // set up the mapper
  mapper = GetMapper(this, ROM);
  if(!mapper) 
  {
    char str[128];
    sprintf(str, "mapper %d unsupport", ROM->get_mapper_num());
    dc_put_error (str);
    
    delete ROM;
    ROM = NULL;
    
    throw "unsupported mapper";
  }
  
  switch(ROM->get_mirroring())
  {
    case NES_PPU::MIRROR_HORIZ:
      LOG("H ");
      break;
    case NES_PPU::MIRROR_VERT:
      LOG("V ");
      break;
    case NES_PPU::MIRROR_FOUR_SCREEN:
      LOG("F ");
      break;
  }

  if(ROM->has_save_RAM())
  {
    LOG("S ");
  }
  if(ROM->has_trainer())
  {
    LOG("T ");
  }

  LOG(16*ROM->get_num_16k_ROM_banks() << "K/" << 8*ROM->get_num_8k_VROM_banks() << "K " << endl);

#ifndef __DREAMCAST__
  // load datas to save it at the top of reset()
  Load_SaveRAM();
  Load_Disk();
#endif
  
  reset();
  
  LOG("Starting emulation...\n");
}

void NES::freeROM()
{
  Save_SaveRAM();
  Save_Disk();
  
  LOG("Freeing ROM...");
  if(ROM)
  {
    delete ROM;
    ROM = NULL;
  }
  if(mapper)
  {
    delete mapper;
    mapper = NULL;
  }
  
  scr_mgr->clear(0x00);
  scr_mgr->blt();

  LOG("Done\n");
  LOG(endl);
}

const char* 
NES::getROMname()
{
  return ROM->GetRomName();
}

const char* 
NES::getROMpath()
{
  return ROM->GetRomPath();
}


void
NES::reset()
{
  // clear RAM
  memset(RAM, 0x00, sizeof(RAM));

  softreset();
}


void
NES::softreset()
{
#ifndef __DREAMCAST__
  // save SaveRAM
  Save_SaveRAM();
  Save_Disk();
#endif
  
  // set up CPU
  {
    NES_6502::Context context;

    memset((void*)&context, 0x00, sizeof(context));
    cpu->GetContext(&context);

    context.mem_page[0] = RAM;
    context.mem_page[3] = SaveRAM;

    cpu->SetContext(&context);
  }
  
  // reset the PPU
  ppu->reset();
  ppu->vram_write_protect = ROM->get_num_8k_VROM_banks() ? 1 : 0;
  ppu->vram_size = 0x2000;
  ppu->sprite0_hit_flag = 0;
  
  // reset the APU
  apu->reset();
  
  frame_irq_enabled = 0xFF;
  frame_irq_disenabled = 0;
  
  if(mapper)
  {
    // reset the mapper
    mapper->Reset();
  }
  
  // reset the CPU
  cpu->Reset();

#ifndef __DREAMCAST__  
  // load SaveRAM
  Load_SaveRAM();
  Load_Disk();
#endif
  
  // set up the trainer if present
  if(ROM->has_trainer())
  {
    // trainer is located at 0x7000; SaveRAM is 0x2000 bytes at 0x6000
    memcpy(&SaveRAM[0x1000], ROM->get_trainer(), NES_ROM::TRAINER_LEN);
  }
  
#ifndef __DREAMCAST__
  #include "NES_set_Controller.cpp"
  #include "NES_set_VSPalette.cpp"
  #include "NES_set_PPUPatch.cpp"
#endif
  #include "nes_set_cycles.cpp"
  
  ideal_cycle_count  = 0.0;
  emulated_cycle_count = 0;
  
  disk_side_flag = 0;
  
  pad_strobe = FALSE;
  pad1_bits = 0;
  pad2_bits = 0;
}


void 
NES::emulate_frame_skip()
{
  int i;
  
  trim_cycle_counts();

  // do frame
  ppu->start_frame();
  
  // LINES 0-239
  for(i = 0; i < NES_NUM_FRAME_LINES; i++)
  {
    // do one line's worth of CPU cycles
    emulate_CPU_cycles(CYCLES_PER_LINE);
    mapper->HSync(i);
    ppu->do_scanline_and_dont_draw();
  }
  
  ppu->end_frame();

  // fram_IRQ
  if(!(frame_irq_enabled & 0xC0))
    cpu->DoPendingIRQ();
  
  for(i = 240; i <= 261; i++)
  {
    if(i == 241)
    {
      // do v-blank
      ppu->start_vblank();
      mapper->VSync();

      // 1 instruction between vblank flag and NMI
      emulate_CPU_cycles(CYCLES_BEFORE_NMI);
      if(ppu->NMI_enabled()) cpu->DoNMI();
      emulate_CPU_cycles(CYCLES_PER_LINE - CYCLES_BEFORE_NMI);
      mapper->HSync(i);
      continue;
    }
    else if(i == 261)
    {
      ppu->end_vblank();
    }
    
    emulate_CPU_cycles(CYCLES_PER_LINE);
    mapper->HSync(i);
  }

  apu->DoFrame();
  apu->SyncAPURegister();
}


void
NES::emulate_frame()
{
  int i;
#ifdef __WITH_TA__
  uint16 *cur_line = (uint16 *)ta_txr_map(0);
#else
  uint16 *cur_line = dc_get_vram_s () + 24;
#endif
  
  trim_cycle_counts();
  
  // do frame
  ppu->start_frame();
  
#ifdef __NTSC_MODE__
  for (i = 0; i < 8; ++i)
  {
    // do one line's worth of CPU cycles
    emulate_CPU_cycles(CYCLES_PER_LINE);
    mapper->HSync(i);
    ppu->do_scanline_and_dont_draw();
  }
#endif

#ifdef __PRECISION__EMULATE__
  /* changes porting for Dreamcast. 
     extract BANKSWITCH_PER_TILE from loop by hand. (for speedup)
  */
  if (!BANKSWITCH_PER_TILE) 
  {
#ifdef __NTSC_MODE__
    for (i = 8; i < 8 + 224; ++i) 
#else
    for (i = 0; i < 240; ++i) 
#endif
    {
      // do one line's worth of CPU cycles
      emulate_CPU_cycles(CYCLES_PER_LINE);
      mapper->HSync(i);
      // render line
      ppu->do_scanline_and_draw(cur_line, 0);
#ifdef __WITH_TA__
      cur_line += 512;
#else
      // rendered resolution = 272*240
      // NES resolution = 256*240, so there are 8 pixels of 
      // garbage on each side of the screen
      memset(cur_line, 0, sizeof(cur_line[0]) * 8);
      memset(cur_line + 264, 0, sizeof(cur_line[0]) * 8);
      cur_line += 320;
#endif
    }
  }
  else 
  {
#ifdef __NTSC_MODE__
    for (i = 8; i < 8 + 224; ++i) 
#else
    for (i = 0; i < 240; ++i) 
#endif
    {
      // render line
      ppu->do_scanline_and_draw(cur_line, CYCLES_PER_LINE * 32 / 42);
      // do half line's worth of CPU cycles (hblank)
      emulate_CPU_cycles(13);
      mapper->HSync(i);
      emulate_CPU_cycles(CYCLES_PER_LINE * 10 / 42 - 13);
      if (i == 0) 
      {
	emulate_CPU_cycles(CYCLES_PER_LINE * 32 / 42 + 13);
	mapper->HSync(i);
	emulate_CPU_cycles(CYCLES_PER_LINE * 10 / 42 - 13);
      }
#ifdef __WITH_TA__
      cur_line += 512;
#else
      // rendered resolution = 272*240
      // NES resolution = 256*240, so there are 8 pixels of 
      // garbage on each side of the screen
      memset(cur_line, 0, sizeof(cur_line[0]) * 8);
      memset(cur_line + 264, 0, sizeof(cur_line[0]) * 8);
      cur_line += 320;
#endif
    }
  }
#else
#ifdef __NTSC_MODE__
  for (i = 8; i < 8 + 224; ++i) 
#else
  for (i = 0; i < 240; ++i) 
#endif
  {
    // do one line's worth of CPU cycles
    emulate_CPU_cycles(CYCLES_PER_LINE);
    mapper->HSync(i);
    // render line
    ppu->do_scanline_and_draw(cur_line);
#ifdef __WITH_TA__
    cur_line += 512;
#else
    // rendered resolution = 272*240
    // NES resolution = 256*240, so there are 8 pixels of 
    // garbage on each side of the screen
    memset(cur_line, 0, sizeof(cur_line[0]) * 8);
    memset(cur_line + 264, 0, sizeof(cur_line[0]) * 8);
    cur_line += 320;
#endif
  }
#endif

#ifdef __NTSC_MODE__
  for (i = 8 + 224; i < 8 + 224 + 8; ++i)
  {
    emulate_CPU_cycles(CYCLES_PER_LINE);
    mapper->HSync(i);
    ppu->do_scanline_and_dont_draw();
  }
#endif
  
  ppu->end_frame();
  
  // fram_IRQ
  if(!(frame_irq_enabled & 0xC0))
    cpu->DoPendingIRQ();
  
  for(i = 240; i <= 261; i++) 
  {
    if(i == 241) 
    {
      // do v-blank
      ppu->start_vblank();
      mapper->VSync();
      
      // 1 instruction between vblank flag and NMI
      emulate_CPU_cycles(CYCLES_BEFORE_NMI);
      if(ppu->NMI_enabled()) cpu->DoNMI();
      emulate_CPU_cycles(CYCLES_PER_LINE - CYCLES_BEFORE_NMI);
      mapper->HSync(i);
      continue;
    }
    else if(i == 261) 
      ppu->end_vblank();
    
    emulate_CPU_cycles(CYCLES_PER_LINE);
    mapper->HSync(i);
  }
  
  apu->DoFrame();
  apu->SyncAPURegister();
}

void
NES::freeze()
{
  if (!is_frozen) 
  {
    apu->freeze();
    is_frozen = TRUE;
  }
}

void
NES::thaw()
{
  if (is_frozen) 
  {
    apu->thaw();
    is_frozen = FALSE;
  }
}

boolean
NES::frozen()
{
  return is_frozen;
}

uint8
NES::MemoryRead(uint32 addr)
{
//  LOG("Read " << HEX(addr,4) << endl);

  if(addr < 0x2000) // RAM
  {
    return ReadRAM(addr);
  }
  else if(addr < 0x4000) // low registers
  {
    return ReadLowRegs(addr);
  }
  else if(addr < 0x4018) // high registers
  {
    return ReadHighRegs(addr);
  }
  else if(addr < 0x6000) // mapper low
  {
//    LOG("MAPPER LOW READ: " << HEX(addr,4) << endl);
//    return((uint8)(addr >> 8)); // what's good for conte is good for me
    return mapper->MemoryReadLow(addr);
  }
  else // save RAM, or ROM (mapper 40)
  {
    mapper->MemoryReadSaveRAM(addr);
    return cpu->GetByte(addr);
  }
}

void
NES::MemoryWrite(uint32 addr, uint8 data)
{
//  LOG("Write " << HEX(addr,4) << " " << HEX(data,2) << endl);

  if(addr < 0x2000) // RAM
  {
    WriteRAM(addr, data);
  }
  else if(addr < 0x4000) // low registers
  {
    WriteLowRegs(addr, data);
  }
  else if(addr < 0x4018) // high registers
  {
    WriteHighRegs(addr, data);
    mapper->WriteHighRegs(addr, data);
  }
  else if(addr < 0x6000) // mapper low
  {
    mapper->MemoryWriteLow(addr, data);
  }
  else if(addr < 0x8000) // save RAM
  {
    SaveRAM[addr - 0x6000] = data;
    mapper->MemoryWriteSaveRAM(addr, data);
  }
  else // mapper
  {
    mapper->MemoryWrite(addr, data);
  }
}


uint8
NES::ReadRAM(uint32 addr)
{
  return RAM[addr & 0x7FF];
}

void
NES::WriteRAM(uint32 addr, uint8 data)
{
  RAM[addr & 0x7FF] = data;
}


uint8
NES::ReadLowRegs(uint32 addr)
{
  return ppu->ReadLowRegs(addr & 0xE007);
}

void
NES::WriteLowRegs(uint32 addr, uint8 data)
{
  ppu->WriteLowRegs(addr & 0xE007, data);
}


uint8
NES::ReadHighRegs(uint32 addr)
{
  if(addr == 0x4014) // SPR-RAM DMA
  {
    LOG("Read from SPR-RAM DMA reg??" << endl);
    return ppu->Read0x4014();
  } 
  else if(addr == 0x4015 && !(frame_irq_enabled & 0xC0)) // frame_IRQ
  {
    return apu->Read(0x4015) | 0x40;
  }
  else if(addr < 0x4016) // APU
  {
//    LOG("APU READ:" << HEX(addr,4) << endl);
    return apu->Read(addr);
  }
  else // joypad regs
  {
    uint8 retval;

    if(addr == 0x4016)
    {
      // joypad 1
      retval = pad1_bits & 0x01;
      pad1_bits >>= 1;
    }
    else
    {
      // joypad 2
      retval = pad2_bits & 0x01;
      pad2_bits >>= 1;
    }
    return retval;
  }
}

void
NES::WriteHighRegs(uint32 addr, uint8 data)
{
  if(addr == 0x4014) // SPR-RAM DMA
  {
    ppu->Write0x4014(data);
    cpu->SetDMA(514);
  }
  else if(addr < 0x4016) // APU
  {
    apu->Write(addr, data);
  }
  else if(addr == 0x4016) // joy pad
  {
    // bit 0 == joypad strobe
    if(data & 0x01)
    {
      pad_strobe = TRUE;
    }
    else
    {
      if(pad_strobe)
      {
        pad_strobe = FALSE;
        // get input states
        if(pad1) pad1_bits = pad1->get_inp_state();
        if(pad2) pad2_bits = pad2->get_inp_state();
      }
    }
  }
  else if(addr == 0x4017) // frame-IRQ
  {
    if(!frame_irq_disenabled)
    {
      frame_irq_enabled = data;
    }
    apu->Write(addr, data);
  }
}

void 
NES::emulate_CPU_cycles(float num_cycles)
{
  uint32 cycle_deficit;
  
  ideal_cycle_count += num_cycles;
  cycle_deficit = ((uint32)ideal_cycle_count) - emulated_cycle_count;
  if(cycle_deficit > 0)
  {
    emulated_cycle_count += cpu->Execute(cycle_deficit);
    if(apu->SyncDMCRegister(cycle_deficit) && DPCM_IRQ)
    {
      cpu->DoPendingIRQ();
    }
  }
}

// call every once in a while to avoid cycle count overflow
void 
NES::trim_cycle_counts()
{
  uint32 trim_amount;

  trim_amount = (uint32)floor(ideal_cycle_count);
  if(trim_amount > emulated_cycle_count) trim_amount = emulated_cycle_count;

  ideal_cycle_count  -= (float)trim_amount;
  emulated_cycle_count -= trim_amount;
}


extern uint8 mvmu;

void NES::Save_SaveRAM()
{
  if (!is_save) return;
  if(!ROM->has_save_RAM()) return;
  
  if (!mvmu) return;
  
  freeze();
  
  uint32 i;
  bool valid_sram = false;
  for (i = 0; i < sizeof(SaveRAM); ++i)
  {
    if (SaveRAM[i])
    {
      valid_sram = true;
      break;
    }
  }
  if (!valid_sram)
    return;
  
  uint8 compress_SRAM[sizeof(SaveRAM)];
  uint32 compress_len = sizeof(compress_SRAM);
  
  dc_print ("Saving SRAM...");
  
  if (BZ2_bzBuffToBuffCompress((char *)compress_SRAM, (unsigned int*)&compress_len, 
			       (char *)SaveRAM, sizeof(SaveRAM), 9, 0, 0) != BZ_OK) 
  {
    dc_put_error ("bzip2 failed. please report. ");
    return; 
  }
  
  char desc_long[512];
  sprintf(desc_long, "NesterDC %s", ROM->GetRomName());
  if (ndc_vmu_save(compress_SRAM, compress_len, mvmu, 
		   vmu_filename, "NesterDC SRAM", desc_long) < 0)
    dc_put_error ("Save failed");
  
  thaw();
}


void
NES::Load_SaveRAM()
{
  memset(SaveRAM, 0, sizeof(SaveRAM));
  if (!ROM->has_save_RAM()) return;
  
  if (!mvmu) return;
  
  if (ndc_vmu_check_free_blocks (NULL, mvmu) < 18)
    dc_put_error ("caution: VMU free blocks < 18");
  
  dc_print ("Loading SRAM...");
  
  uint8 compressed_SRAM[sizeof(SaveRAM)];
  uint32 compressed_len = sizeof(compressed_SRAM);
  uint32 sram_len = sizeof(SaveRAM);
  
  if (ndc_vmu_load(compressed_SRAM, &compressed_len, mvmu, vmu_filename) == 0) 
  {
    int bz_result;
    
    bz_result = BZ2_bzBuffToBuffDecompress((char *)SaveRAM, (unsigned int*)&sram_len, 
					   (char *)compressed_SRAM, compressed_len, 
					   0, 0);
    if (bz_result != BZ_OK)
    {
      dc_put_error ("bzip2 decompress failed. ");
      memset(SaveRAM, 0, sizeof(SaveRAM));
      return;
    }
  }
  else 
  {
    /* for compatibility */
    char filename[32];
    const char *romname = ROM->GetRomName();
    int i;
    int len;
    
    len = strlen(romname);
    
    for (i = 0; i < 11; ++i)
    {
      if (i < len)
	filename[i] = toupper(romname[i]);
      else
	filename[i] = ' ';
    }
    
    filename[11] = '&';
    filename[12] = '\0';
    
    if (ndc_vmu_load(SaveRAM, &sram_len, mvmu, filename) < 0)
    {
      dc_print ("No savefile in VMU");
      memset(SaveRAM, 0, sizeof(SaveRAM));
      return;
    }
  }
}


void
NES::make_savedata (uint8 *buf)
{
  uint8 *rom_banks = ROM->get_ROM_banks ();
  uint8 *data_buf, *flag_buf;
  int n, i, j;
  
  memset(buf, 0, fds_save_buflen);
  memcpy(buf, "FDS2", 4);
  buf[4] = mapper->GetDiskSideNum();
  
  data_buf = buf + 16;
  flag_buf = buf + 16 + (4 * 65500);
  n = 0;
  for(i = 0; i < mapper->GetDiskSideNum(); ++i)
  {
    for(j = 0; j < 65500; ++j)
    {
      uint8 data = mapper->GetDiskData(i*0x10000+j);
      
      if (data != rom_banks[16 + 65500 * i + j])
      {
	data_buf[n] = data;
	flag_buf[n] = 1;
      }
      ++n;
    }
  }
}


void
NES::Save_Disk()
{
  if (!is_save) return; 
  if (!mvmu) return;
  
  // must not save before load disk image to disk[] in mapper reset
  if(mapper->GetDiskData(0) == 0x01)
  {
    uint8 *buf = NULL;
    uint8 *compress_buf = NULL;
    uint compress_len = fds_save_buflen;
    
    freeze();
    dc_print ("Saving Disk...");
    
    try 
    {
      buf = (uint8 *)malloc(fds_save_buflen);
      if (!buf) throw -1; 
      compress_buf = (uint8 *)malloc(compress_len);
      if (!compress_buf) throw -1;
      
      make_savedata(buf);
      
      if (BZ2_bzBuffToBuffCompress((char *)compress_buf, (unsigned int*)&compress_len, 
				   (char *)buf, fds_save_buflen, 9, 0, 0) != BZ_OK) 
      {
	dc_put_error ("bzip2 failed. please report. ");
	throw -1;
      }
      
      char desc_long[512];
      sprintf(desc_long, "NesterDC %s", ROM->GetRomName());
      if (ndc_vmu_save(compress_buf, compress_len, mvmu, 
		       vmu_filename, "NesterDC FDS", desc_long) < 0)
	throw -1;
      
      free(buf);
      free(compress_buf);
    }
    catch (...)
    {
      if (buf) free(buf);
      if (compress_buf) free(compress_buf);
      dc_put_error ("Save failed");
    }
    thaw();
  }
}


void
NES::restore_savedata (uint8 *buf)
{
  uint8 *rom_banks = ROM->get_ROM_banks ();
  uint8 *data_buf, *flag_buf;
  int i, j, n;
  
  data_buf = buf + 16;
  flag_buf = buf + 16 + (4 * 65500);
  n = 0;
  for (i = 0; i < buf[4]; ++i)
  {
    for (j = 0; j < 65500; ++j)
    {
      uint8 data;
      
      if (flag_buf[n])
	data = data_buf[n];
      else
	data = rom_banks[16 + 65500 * i + j];
      mapper->SetDiskData(i*0x10000+j, data);
      
      ++n;
    }
  }
}


void
NES::Load_Disk()
{
  // must not load before load disk image to disk[] in mapper reset
  if(mapper->GetDiskData(0) == 0x01)
  {
    uint8 *compressed_buf = NULL;
    uint32 compressed_len = fds_save_buflen;
    uint8 *buf = NULL;
    uint32 buf_len = fds_save_buflen;
    
    dc_print ("Loading Disk...");
    try
    {
      compressed_buf = (uint8 *)malloc(compressed_len);
      if (!compressed_buf) throw -1;
      
      buf = (uint8 *)malloc(buf_len);
      if (!buf) throw -1;
      
      if (ndc_vmu_load(compressed_buf, &compressed_len, mvmu, vmu_filename) == 0) 
      {
	int bz_result;
	
	bz_result = BZ2_bzBuffToBuffDecompress((char *)buf, 
					       (unsigned int*)&buf_len, 
					       (char *)compressed_buf, 
					       compressed_len, 
					       0, 0);
	if (bz_result != BZ_OK)
	{
	  dc_put_error ("bzip2 decompress failed. ");
	  throw -1;
	}
	
	if (buf_len < fds_save_buflen) throw -1;
	restore_savedata (buf);
      }
      free(compressed_buf);
      free(buf);
    }
    catch(...) 
    {
      dc_print ("No savefile in VMU");
      if (compressed_buf) free(compressed_buf);
      if (buf) free(buf);
    }
  }
}


boolean 
NES::loadState(const char* fn)
{
  return snss->LoadSNSS(fn, this);
}


boolean
NES::saveState(const char* fn)
{
  return snss->SaveSNSS(fn, this);
}


void
NES::calculate_palette()
{
#ifndef __DREAMCAST__
  //NESTER_settings.nes.graphics.calculate_palette = true;
  //NESTER_settings.nes.graphics.tint = 255;
  //NESTER_settings.nes.graphics.hue = 128; 

  if(NESTER_settings.nes.graphics.calculate_palette)
  {
    int x,z;
    float tint = ((float)NESTER_settings.nes.graphics.tint) / 256.0f;
    float hue = 332.0f + (((float)NESTER_settings.nes.graphics.hue - (float)0x80) * (20.0f / 256.0f));
    float s,y;
    int cols[16] = {0,240,210,180,150,120,90,60,30,0,330,300,270,0,0,0};
    float theta;
    float br1[4] = {0.5f, 0.75f, 1.0f, 1.0f};
    float br2[4] = {0.29f, 0.45f, 0.73f, 0.9f};
    float br3[4] = {0.0f, 0.24f, 0.47f, 0.77f};
    float r,g,b;

    for(x = 0; x <= 3; x++)
    {
      for(z = 0; z <= 15; z++)
      {
        s = tint;
        y = br2[x];
        if(z == 0)
        {
          s = 0;
          y = br1[x];
        }
        else if(z == 13)
        {
          s = 0;
          y = br3[x];
        }
        else if((z == 14) || (z == 15))
        {
          s = 0;
          y = 0;
        }

        theta = 3.14159265f * (((float)(cols[z] + hue)) / 180.0f);

        r = y + (s * (float)sin(theta));
        g = y - ((27.0f / 53.0f) * s * (float)sin(theta)) + ((10.0f / 53.0f) * s * (float)cos(theta));
        b = y - (s * (float)cos(theta));

        r = r * 256.0f;
        g = g * 256.0f;
        b = b * 256.0f;

        if(r > 255.0f) r = 255.0f;
        if(g > 255.0f) g = 255.0f;
        if(b > 255.0f) b = 255.0f;

        if(r < 0.0f) r = 0.0;
        if(g < 0.0f) g = 0.0;
        if(b < 0.0f) b = 0.0;

        NES_RGB_pal[(x*16) + z][0] = (uint8)r;
        NES_RGB_pal[(x*16) + z][1] = (uint8)g;
        NES_RGB_pal[(x*16) + z][2] = (uint8)b;
      }
    }
  }
  else
  {
    memcpy(NES_RGB_pal, NES_preset_palette, sizeof(NES_RGB_pal));
  }

  NESTER_settings.nes.graphics.black_and_white = false;
  if(NESTER_settings.nes.graphics.black_and_white)
  {
    int i;

    for(i = 0; i < NES_NUM_COLORS; i++)
    {
      uint8 Y;
      Y = (uint8)(((float)NES_RGB_pal[i][0] * 0.299) +
                  ((float)NES_RGB_pal[i][1] * 0.587) +
                  ((float)NES_RGB_pal[i][2] * 0.114));
      NES_RGB_pal[i][0] = Y;
      NES_RGB_pal[i][1] = Y;
      NES_RGB_pal[i][2] = Y;
    }
  }
#endif
}


uint8 NES::GetDiskSideNum()
{
  return mapper->GetDiskSideNum();
}
uint8 NES::GetDiskSide()
{
  return mapper->GetDiskSide();
}
void NES::SetDiskSide(uint8 side)
{
  disk_side_flag = side | 0x10;
  mapper->SetDiskSide (disk_side_flag & 0x0f);
  disk_side_flag = 0;
}
uint8 NES::DiskAccessed()
{
  return mapper->DiskAccessed();
}

