#ifndef _DC_UTILS_H_
#define _DC_UTILS_H_

#ifdef __cplusplus
extern "C" {
#endif

#if 0
}
#endif

#include "types.h"

inline void timer_sleep(int msec);

void dc_vid_init ();
void dc_vid_shutdown ();
void dc_vid_clear_queue ();
inline uint16* dc_get_vram_s ();
inline void dc_vid_clear ();
inline void dc_vid_empty ();
inline void dc_vid_enqueue (uint32 vram); 
inline void dc_vid_flip ();

void wait_until_release_button (uint8 addr, uint16 button);
void wait_until_release_rtrig (uint8 addr);

uint8 maple_find_device(uint8 port, int code);

void vmu_icon_clear (char *vmu_screen, int is_black);
void vmu_icon_draw_char (char *vmu_screen, int x, int y, int ch);
void vmu_icon_draw_string (char *vmu_screen, int x, int y, const char *str);
void vmu_icon_flip(const char *vmu_icon, uint8 addr);

uint8 *load_misc(char *fn); 

#ifdef __WITH_TA__
void draw_nes_screen(uint32 textureaddr);
void draw_bmp(uint32 textureaddr);
#endif
void load_bmp (uint8 *pic_buffer, char * pic_name);
void display_bmp (uint8 *pic_buffer);

// define some common colors 
#define _yellow (((255 >> 3) << 11) | ((255 >> 2) << 5) | ((0 >> 3) << 0))
#define _red (((255 >> 3) << 11) | ((0 >> 2) << 5) | ((0 >> 3) << 0))
#define _green (((0 >> 3) << 11) | ((255 >> 2) << 5) | ((0 >> 3) << 0))
#define _blue (((20 >> 3) << 11) | ((20 >> 2) << 5) | ((255 >> 3) << 0))
#define _black (((0 >> 3) << 11) | ((0 >> 2) << 5) | ((0 >> 3) << 0))
#define _white (((255 >> 3) << 11) | ((255 >> 2) << 5) | ((255 >> 3) << 0))
#define _none (((254 >> 3) << 11) | ((254 >> 2) << 5) | ((254 >> 3) << 0))

void font_set(uint8 *fbm, int fh); 
#ifdef __WITH_TA__
void draw_char(int x1, int y1, uint16 fg_color, uint16 bg_color, int ch);
#else
inline void draw_char(int x1, int y1, uint16 fg_color, uint16 bg_color, int ch);
#endif
inline void draw_string(int x1, int y1, uint16 fg_color, uint16 bg_color, const char *str);
void dc_print(const char *string);
void dc_put_error(const char *string);

#ifdef __cplusplus
}
#endif

#endif

