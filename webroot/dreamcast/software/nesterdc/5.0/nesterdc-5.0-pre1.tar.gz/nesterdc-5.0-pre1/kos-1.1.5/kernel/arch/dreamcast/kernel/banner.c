char banner[] = 
"KallistiOS 1.1.5: Mon Dec 3 04:44:58 JST 2001\n"
"  tekezo@:/home/tekezo/work/tmp/nesterdc/kos-1.1.5\n"
;
