/* KallistiOS 1.1.5

   hardware.c
   (c)2000-2001 Dan Potter
*/

static char id[] = "KOS hardware.c,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp";

#include <arch/arch.h>
#include <dc/spu.h>
#include <dc/video.h>
#include <dc/cdrom.h>
#include <dc/g2.h>
#include <dc/maple.h>

static int initted = 0;

int hardware_init() {
	/* Init sound */
	spu_init();
	
	/* Init CD-ROM.. NOTE: NO GD-ROM SUPPORT. ONLY CDs/CDRs. */
	cdrom_init();

	/* Setup G2 bus stuff */
	g2_init();

	/* Setup maple bus */
	maple_init();

	/* Init video */
	vid_init(DEFAULT_VID_MODE, DEFAULT_PIXEL_MODE);

	initted = 1;

	return 0;
}

void hardware_shutdown() {
	if (!initted)
		return;
	maple_shutdown();
	g2_shutdown();
	cdrom_shutdown();
	spu_shutdown();
	vid_shutdown();
}


