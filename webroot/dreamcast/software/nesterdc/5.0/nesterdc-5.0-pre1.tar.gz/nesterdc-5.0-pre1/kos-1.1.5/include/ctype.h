/* KallistiOS 1.1.5

   ctype.h
   (c)2000-2001 Jordan DeLong and Dan Potter

   ctype.h,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp
*/

#ifndef __CTYPE_H
#define __CTYPE_H

#define isprint(c) (((c) > ' ') && ((c) < '~'))
#define isascii(c) (((c) & ~0x7F) == 0)
#define islower(c) (((c) >= 'a' && (c) <= 'z'))
#define isupper(c) (((c) >= 'A' && (c) <= 'Z'))
#define isdigit(c) (((c) >= '0' && (c) <= '9'))
#define tolower(c) (isupper(c) ? ((c) + ('a' - 'A')) : (c))
#define toupper(c) (islower(c) ? ((c) - ('a' - 'A')) : (c))

#endif
