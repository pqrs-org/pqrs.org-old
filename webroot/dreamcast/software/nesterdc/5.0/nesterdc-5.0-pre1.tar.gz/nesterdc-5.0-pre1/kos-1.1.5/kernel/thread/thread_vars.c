/* KallistiOS 1.1.5

   kernel/thread_vars.c
   (c)2000-2001 Dan Potter
*/

static char id[] = "KOS thread_vars.c,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp";

#include <kos/thread.h>
#include <string.h>

/* You may (rightfully) be wondering why the heck this module exists at all.
   Well, those of you not in the know about how a linker works anyway =). 
   What happens when you link a program is that any object file containing
   a requried symbol is automatically linked in, in full. So unless we
   seperate this out, any module that checks to see if you're using
   threads is going to force the inclusion of the entire threads package
   (yuck!).
*/

/* Are threads enabled? */
int thd_enabled = 0;

/* The currently executing thread */
kthread_t *thd_current;

/* Find the current thread */
kthread_t *thd_get_current() {
	if (thd_enabled)
		return thd_current;
	else
		return NULL;
}

/* Set/Get thread pwd (in here so FS doesn't bring in threads) */
/* Retrieve / set thread pwd */   
const char *thd_get_pwd(kthread_t *thd) {
	return thd->pwd;
}

void thd_set_pwd(kthread_t *thd, const char *pwd) {
	strncpy(thd->pwd, pwd, sizeof(thd->pwd) - 1);
}
                

