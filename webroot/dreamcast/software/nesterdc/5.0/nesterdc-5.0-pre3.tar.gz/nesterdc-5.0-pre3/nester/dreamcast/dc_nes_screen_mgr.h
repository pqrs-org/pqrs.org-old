/*
** nester - NES emulator
** Copyright (C) 2000  Darren Ranalli
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

/* 
** NesterDC by Ken Friece
** Any changes that I made to the original source, by Darrin Ranalli, are 
** marked with in the following way:
** KF DD/MM/YYYY <description of the change> 
**
** I renamed this class from win32_NES_screen_mgr to dc_NES_screen_mgr.
** win32 in a class name doesn't make much sense on the Dreamcast.
*/

/*
 * 2001/09/17 Takayama Fumihiko<tekezo@catv296.ne.jp> 
 * brush up code. 
 * 
 * dc_NES_screen_mgr isn't implemented but works,
 * because nes/nes.cpp was changed screen_mgr independent. 
 */

#ifndef _DC_NES_SCREEN_MGR_H_
#define _DC_NES_SCREEN_MGR_H_

#include <kos.h>
#include "types.h"
#include "nes_screen_mgr.h"

class dc_NES_screen_mgr : public NES_screen_mgr
{
public:
  boolean set_palette(const uint8 pal[256][3]) {
    return false;
  }
  boolean get_palette(uint8 pal[256][3]) {
    return false;
  }
  boolean set_palette_section(uint8 start, uint8 len, const uint8 pal[][3]) {
    return false;
  }
  boolean get_palette_section(uint8 start, uint8 len, uint8 pal[][3]) {
    return false;
  }
  
  void assert_palette() {}
protected:
private:
};

#endif


