#include <kos.h>
#include "dc_stdio.h"

FILE *
fopen(const char *path, const char *mode)
{
  FILE *fp; 
  int mode_flag;
  file_t fd;
  
  mode_flag = 0;
  if (!strcmp(mode, "r") || !strcmp(mode, "rb"))
    mode_flag |= O_RDONLY;
  else if (!strcmp(mode, "w") || !strcmp(mode, "wb"))
    mode_flag |= O_WRONLY;
  else if (!strcmp(mode, "a") || !strcmp(mode, "ab"))
    mode_flag |= O_APPEND;
  
  if (!mode_flag)
    return NULL;
  
  fd = fs_open(path, mode_flag);
  if (!fd)
    return NULL;
  
  fp = malloc(sizeof(FILE));
  fp->fd = fd;
  
  return fp;
}


int
fclose(FILE *stream)
{
  fs_close(stream->fd);
  free(stream);
  
  return 0;
}


size_t
fread(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
  int i, cnt;
  
  if (!size || !nmemb || !stream)
    return 0;
  
  for (i = 0; i < nmemb; ++i)
  {
    cnt = fs_read(stream->fd, ptr, size);
    if (cnt != size)
    {
      fs_seek(stream->fd, -cnt, SEEK_CUR);
      break;
    }
    ptr += size;
  }
  
  return i;
}


size_t
fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{
  int i, cnt;
  
  if (!size || !nmemb || !stream)
    return 0;
  
  for (i = 0; i < nmemb; ++i)
  {
    cnt = fs_write(stream->fd, ptr, size);
    if (cnt != size)
    {
      fs_seek(stream->fd, -cnt, SEEK_CUR);
      break;
    }
    ptr += size;
  }
  
  return i;
}


int
fseek(FILE *stream, long offset, int whence)
{
  fs_seek(stream->fd, offset, whence);
  return 0;
}


long
ftell(FILE *stream)
{
  return fs_tell(stream->fd);
}


void
rewind(FILE *stream)
{
  fseek(stream, 0, SEEK_SET);
}

