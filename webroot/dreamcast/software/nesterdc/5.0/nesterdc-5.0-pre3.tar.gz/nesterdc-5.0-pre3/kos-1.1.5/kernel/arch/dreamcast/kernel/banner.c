char banner[] = 
"KallistiOS 1.1.5: Mon Jan 7 00:52:33 JST 2002\n"
"  tekezo@:/home/tekezo/work/tmp/nesterdc-5.0-pre3/kos-1.1.5\n"
;
