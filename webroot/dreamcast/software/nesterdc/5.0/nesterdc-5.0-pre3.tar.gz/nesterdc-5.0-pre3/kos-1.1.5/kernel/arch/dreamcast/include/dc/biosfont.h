/* KallistiOS 1.1.5

   dc/biosfont.h
   (c)2000-2001 Dan Potter

   biosfont.h,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp

*/

#ifndef __DC_BIOSFONT_H
#define __DC_BIOSFONT_H

#include <arch/types.h>

void *bfont_find_char(int ch);
void bfont_draw(uint16 *buffer, int bufwidth, int opaque, int c);
void bfont_draw_str(uint16 *buffer, int width, int opaque, char *str);

#endif	/* __DC_BIOSFONT_H */

