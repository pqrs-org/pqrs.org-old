#ifndef __SNDMP3_H
#define __SNDMP3_H

int sndmp3_init(const char *fn, int loop);

/* Initialize the MP3 driver; takes an input filename and starts the
   decoding process. */
int sndmp3_start(const char *fn, int loop);

/* Shut everything down */
void sndmp3_shutdown();

#endif	/* __SNDMP3_H */
