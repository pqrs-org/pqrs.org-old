/* KallistiOS 1.1.5

   abort.c
   (c)2001 Dan Potter

   abort.c,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp
*/

#include <arch/arch.h>

/* This is probably the closest mapping we've got for abort() */
void abort() {
	arch_exit();
}

