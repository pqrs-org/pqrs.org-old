/* KallistiOS 1.1.5

   unistd.h
   (c)2000-2001 Dan Potter

   unistd.h,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp

*/

#ifndef __UNISTD_H
#define __UNISTD_H

#include <stddef.h>
#include <arch/types.h>

#define true (1)
#define false (0)

#endif	/* __UNISTD_H */

