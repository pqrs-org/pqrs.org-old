/*
** NesterDC - NES emulator for Dreamcast
** Copyright (C) 2001  Ken Friece
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

#include <kos.h>
#include <string.h>
#include "nester.h"
#include "nes.h"
#include "null_sound_mgr.h"
#include "dc_nes_screen_mgr.h"
#include "dc_sound_mgr.h"
#include "dc_settings.h"
#include "dc_utils.h"
#include "dc_menu.h"
#include "dc_saving.h"
#include "dc_vmu.h"
#include "fs_md.h"
#include "emulator.h"
#include "nes_pad.h"
#include "bzlib.h"

/* for bzip2 */
extern "C" void 
bz_internal_error (int errorcode) 
{
  char str[128];
  sprintf(str, "bzip2 error (errorcode = 0x%x\n)", errorcode);
  dc_put_error (str);
}


// vmu screen image
#include "vmu_icons/kos.h"

NES_settings *nes_settings = NULL;

// device addresses
static uint8 mldc = 0;
static uint8 mvmu = 0;

// global user settings data
static DC_settings dc_settings;

static uint16 startup_image[320 * 240];
static uint16 menu_image[320 * 240];
static uint16 credits_image[320 * 240];
static uint16 options_image[320 * 240];

static boolean exit_game_loop = false;
static boolean interrupt_game_loop = false;

static char last_romfile_dir[256];

static volatile int rest_frames = 0;
#ifdef __DRAW_FPS__
static volatile int drop_frames_per_sec = 0;
static volatile int drop_frames = 0;
#endif


static void 
toupper_string (char *str)
{
  char *p = str;
  while (*p)
  {
    *p = toupper(*p);
    ++p;
  }
}


static void 
vmu_draw_settings (NES *emu)
{
  char vmu_screen[48 * 32];
  char str[256];
  
  vmu_icon_clear (vmu_screen, 1);
  
  vmu_icon_draw_string (vmu_screen, 1, 1, "FRAME RATE:");
  vmu_icon_draw_string (vmu_screen, 3, 7, 
			dc_settings.get_frameskip_short_string ());
  
  sprintf(str, "AUTOFIRE: %s", dc_settings.is_autofire_base () ? "Y" : "N");
  vmu_icon_draw_string (vmu_screen, 1, 13, str);
  
  sprintf(str, "%s", emu->getROMname ());
  toupper_string (str);
  vmu_icon_draw_string (vmu_screen, 1, 26, str);
  
  vmu_icon_flip (vmu_screen, mldc);
}


static int
set_frameskip_during_game (cont_cond_t *cont)
{
  uint8 x, y;
  uint8 rtrig;
  
  x = cont->joyx;
  y = cont->joyy;
  rtrig = cont->rtrig;
  
  if (y < 5) 
  {
    /* analog UP */
    interrupt_game_loop = true;
    if (rtrig)
      dc_settings.set_frameskip(DC_settings::double_skip);
    else
      dc_settings.set_frameskip(DC_settings::no_skip);
    return 1;
  } 
  else if (y > 250) 
  {
    /* analog DOWN */
    interrupt_game_loop = true;
    dc_settings.set_frameskip(DC_settings::half_skip);
    return 1;
  }
  else if (x > 250) 
  {
    /* analog RIGHT */
    interrupt_game_loop = true;
    dc_settings.set_frameskip(DC_settings::auto_skip);
    return 1;
  }
  else if (x < 5) 
  {
    /* analog LEFT */
    interrupt_game_loop = true;
    if (rtrig) 
      dc_settings.set_frameskip(DC_settings::full_skip);
    else
      dc_settings.set_frameskip(DC_settings::one_and_half_skip);
    
    return 1;
  }
  
  return 0;
}


static void
draw_quick_menu ()
{
  dc_vid_clear ();
  
  draw_string (80,  30,   _white,  _black, "QUICK SAVE MENU");
  draw_string (100, 60,   _green,  _black, "Y: ");
  draw_string (10,  100,  _yellow, _black, "X: quick save");
  draw_string (130, 100,  _blue,   _black, "B: return to game");
  draw_string (100, 140, _red,     _black, "A: quick load");
}


static void 
do_quick_menu (NES* emu) 
{
  cont_cond_t cont;
  
  emu->freeze();

  draw_quick_menu ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  wait_until_release_trigger (dc_controller_addr[0]);
  
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (set_frameskip_during_game (&cont))
      vmu_draw_settings (emu);
    
    if (!(cont.buttons & CONT_B))
    {
      timer_sleep (100);
      break;
    }
    
    if (!(cont.buttons & CONT_X))
    {
      bool save_success;
      
      draw_quick_menu ();
      draw_string (100, 200, _white, _black, "save...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      /* filename is dummy */
      save_success = emu->saveState("/md/quick");
      
      draw_quick_menu ();
      if (save_success)
	draw_string (100, 200, _white, _black, "save...done");
      else 
	draw_string (100, 200, _red, _black, "save...failed");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    if (!(cont.buttons & CONT_A))
    {
      bool load_success;
      
      draw_quick_menu ();
      draw_string (100, 200, _white, _black, "load...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      /* filename is dummy */	
      load_success = emu->loadState("/md/quick");
      
      draw_quick_menu ();
      if (load_success)
	draw_string (100, 200, _white, _black, "load...done");
      else
	draw_string (100, 200, _red, _black, "load...failed");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    draw_quick_menu ();
    dc_vid_flip (draw_type_fullscreen);
  }
  
  dc_vid_empty ();
  emu->thaw();
}


static void
draw_save_menu ()
{
  dc_vid_clear ();

  draw_string (80,  30,   _white,  _black, "VMU MENU");
  draw_string (100, 60,   _green,  _black, "Y: ");
  draw_string (10,  100,  _yellow, _black, "X: snap save");
  draw_string (130, 100,  _blue,   _black, "B: return to game");
  draw_string (100, 140,  _red,    _black, "A: snap load");
}


static void
do_save_menu (NES *emu)
{
  cont_cond_t cont;
  
  emu->freeze();
  
  draw_save_menu ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  wait_until_release_trigger (dc_controller_addr[0]);
  
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (set_frameskip_during_game (&cont))
      vmu_draw_settings (emu);
    
    if (!(cont.buttons & CONT_B))
    {
      timer_sleep(100);
      break;
    }
    
    if (!(cont.buttons & CONT_X))
    {
      bool save_success = false;
      
      draw_save_menu ();
      draw_string (100, 200, _white, _black, "save...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      save_success = snap_save_to_vmu (mvmu, emu);
      
      draw_save_menu ();
      if (save_success) 
	draw_string (100, 200, _white, _black, "save...done");
      else
	draw_string (100, 200, _red, _black, "save...failed");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    if (!(cont.buttons & CONT_A))
    {
      bool load_success = false;
      
      draw_save_menu ();
      draw_string (100, 200, _white, _black, "load...");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      load_success = snap_load_from_vmu (mvmu, emu);
      
      draw_save_menu ();
      if (load_success)
	draw_string (100, 200, _white, _black, "load...done");
      else
	draw_string (100, 200, _red, _black, "load...failed");
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      timer_sleep(1000);
      break;
    }
    
    draw_save_menu ();
    dc_vid_flip (draw_type_fullscreen);
  }
  
  dc_vid_empty ();
  emu->thaw();
}


static void
draw_system_menu (NES *emu)
{
  char str[128];
  
  dc_vid_clear ();
  
  draw_string (100, 30,   _white,  _black, "SYSTEM MENU");
  draw_string (100, 60,   _green,  _black, "Y: reset");
  draw_string (10,  100,  _yellow, _black, "X:");
  draw_string (130, 100,  _blue,   _black, "B: return to game");
  draw_string (100, 140,  _red,    _black, "A:");
  
  if (emu->get_rom_image_type () == NES_ROM::fds_image)
  {
    const char *disksidestr[] = {0, "1A", "1B", "2A", "2B"};
    draw_string (60, 180, _gray, _black, "UP/DOWN/LEFT/RIGHT:");
    draw_string (80, 190, _gray, _black, "set disk 1A/1B/2A/2B");
    sprintf(str, "currnet disk side: %s", disksidestr[emu->GetDiskSide ()]);
    draw_string (60, 200, _white, _black, str);
  }
}


static void
do_system_menu (NES *emu)
{
  cont_cond_t cont;
  uint16 all_buttons = 
    CONT_B | 
    CONT_Y | 
    CONT_DPAD_UP | 
    CONT_DPAD_DOWN | 
    CONT_DPAD_LEFT | 
    CONT_DPAD_RIGHT;
  
  emu->freeze();
  
  draw_system_menu (emu);
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  wait_until_release_trigger (dc_controller_addr[0]);
  wait_until_release_buttons (dc_controller_addr[0], all_buttons);
  
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (set_frameskip_during_game (&cont))
      vmu_draw_settings (emu);
    
    if (!(cont.buttons & CONT_B))
    {
      timer_sleep (100);
      break;
    }
    
    if (!(cont.buttons & CONT_Y))
    {
      emu->reset();
      timer_sleep(100);
      break;
    }
    
    if (emu->get_rom_image_type () == NES_ROM::fds_image)
    {
      if (!(cont.buttons & CONT_DPAD_UP))
	emu->SetDiskSide (0x01);
      if (!(cont.buttons & CONT_DPAD_DOWN))
	emu->SetDiskSide (0x02);
      if (!(cont.buttons & CONT_DPAD_LEFT))
	emu->SetDiskSide (0x03);
      if (!(cont.buttons & CONT_DPAD_RIGHT))
	emu->SetDiskSide (0x04);
    }
    
    if ((cont.buttons & all_buttons) != all_buttons)
    {
      draw_system_menu (emu);
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      wait_until_release_buttons (dc_controller_addr[0], all_buttons);
    }
  }
  
  dc_vid_empty ();
  emu->thaw();
}


static void
draw_ingame_option_menu (NES *emu)
{
  char str[128];
  
  dc_vid_clear ();
  
  draw_string (100, 30,  _white,  _black, "OPTION MENU");
  draw_string (100, 60,  _green,  _black, "Y: adjust screen");
  draw_string (10,  100, _yellow, _black, "X: autofire B");
  draw_string (130, 100, _blue,   _black, "B: return to game");
  draw_string (100, 140, _red,    _black, "A: autofire A");
  draw_string (40,  160, _gray,   _black, "START: toggle fullscreen");
  
  sprintf(str, "autofire B%s / A%s",
	  dc_settings.is_autofire_b () ? "[ON] " : "[OFF]",
	  dc_settings.is_autofire_a () ? "[ON] " : "[OFF]"); 
  draw_string (50, 190, _white,   _black, str);
  
  sprintf(str, "fullscreen %s", 
	  dc_settings.is_fullscreen () ? "[ON] " : "[OFF]");
  draw_string (50, 200, _white, _black, str);
}


static void
do_ingame_option_menu (NES *emu)
{
  cont_cond_t cont;
  uint16 all_buttons = 
    CONT_Y | 
    CONT_X | 
    CONT_B | 
    CONT_A | 
    CONT_START;
  
  emu->freeze();
  
  draw_ingame_option_menu (emu);
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  wait_until_release_trigger (dc_controller_addr[0]);
  wait_until_release_buttons (dc_controller_addr[0], all_buttons);
  
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (set_frameskip_during_game (&cont))
      vmu_draw_settings (emu);
    
    if (!(cont.buttons & CONT_B))
    {
      timer_sleep (100);
      break;
    }
    
    if (!(cont.buttons & CONT_Y))
      do_adjust_screen_rect_menu ();
    
    if (!(cont.buttons & CONT_A))
      dc_settings.toggle_autofire_a ();
    
    if (!(cont.buttons & CONT_X))
      dc_settings.toggle_autofire_b ();
    
    if (!(cont.buttons & CONT_START))
      dc_settings.toggle_fullscreen ();
    
    if ((cont.buttons & all_buttons) != all_buttons)
    {
      draw_ingame_option_menu (emu);
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      wait_until_release_buttons (dc_controller_addr[0], all_buttons);
    }
  }
  
  dc_vid_empty ();
  emu->thaw();
}


static void 
poll_input(NES* emu) 
{
  cont_cond_t cont;
  int i;
  
  if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
    return;
  
  set_frameskip_during_game (&cont);
  
  if (cont.rtrig) 
  {
    if (cont.ltrig && !(cont.buttons & CONT_START))
    {
      exit_game_loop = true;
      interrupt_game_loop = true;
    }
    else if (!(cont.buttons & CONT_B))
    {
      do_quick_menu(emu);
      interrupt_game_loop = true;
      rest_frames = 0;
    }
    else if (!(cont.buttons & CONT_Y))
    {
      do_save_menu (emu);
      interrupt_game_loop = true;
      rest_frames = 0;
    }
    else if (!(cont.buttons & CONT_X))
    {
      do_system_menu (emu);
      interrupt_game_loop = true;
      rest_frames = 0;
    }
    else if (!(cont.buttons & CONT_A))
    {
      do_ingame_option_menu (emu);
      interrupt_game_loop = true;
      rest_frames = 0;
    }
    
    return;
  }
  
  static bool release_ltrig = true;
  if (cont.ltrig)
  {
    if (release_ltrig)
    {
      release_ltrig = false;
      
      dc_settings.toggle_autofire_base ();
      interrupt_game_loop = true;
      rest_frames = 0;
    }
    return;
  }
  release_ltrig = true;
  
  i = 0;
  for (;;)
  {
    static int autofire_counter = 0;
    NES_pad *pad = emu->get_pad(i);
    
    autofire_counter ^= 1;
    if (dc_settings.is_autofire_base () && autofire_counter)
    {
      if (dc_settings.is_autofire_b () && !(cont.buttons & CONT_X))
	cont.buttons |= dc_settings.get_cont_b ();
      if (dc_settings.is_autofire_a () && !(cont.buttons & CONT_A))
	cont.buttons |= dc_settings.get_cont_a ();
    }
    
    pad->set_button_state(NES_UP,     !(cont.buttons & CONT_DPAD_UP));
    pad->set_button_state(NES_DOWN,   !(cont.buttons & CONT_DPAD_DOWN));
    pad->set_button_state(NES_LEFT,   !(cont.buttons & CONT_DPAD_LEFT));
    pad->set_button_state(NES_RIGHT,  !(cont.buttons & CONT_DPAD_RIGHT));
    pad->set_button_state(NES_SELECT, !(cont.buttons & CONT_Y));
    pad->set_button_state(NES_START,  !(cont.buttons & CONT_START));
    pad->set_button_state(NES_B,      !(cont.buttons & dc_settings.get_cont_b ()));
    pad->set_button_state(NES_A,      !(cont.buttons & dc_settings.get_cont_a ()));
    
    ++i;
    if (i == 4) break;
    if (!(dc_controller_addr[i])) break;
    cont_get_cond (dc_controller_addr[i], &cont);
  }
}


static void 
draw_main_option_menu ()
{
  char str[128];
  
  display_rawimage (options_image);
  
  draw_string (50, 30, _yellow, _none, "L+R: return to main menu");
  
  draw_string (30, 50, _white, _none,  "START: adjust NES A and B buttons");
  draw_string (50, 60, _white, _none, dc_settings.get_cont_scheme_string());
  
  draw_string (30, 80, _white, _none,  "UP:    sound");
  if (dc_settings.is_sound()) 
    draw_string (260, 80, _white, _none, "[ON]");
  else
    draw_string (260, 80, _white, _none, "[OFF]");
  
  draw_string (30, 90, _white, _none,  "DOWN:  save support");
  if (dc_settings.is_save())
    draw_string (260, 90, _white, _none, "[ON]");
  else
    draw_string (260, 90, _white, _none, "[OFF]");
  
  draw_string (30, 100, _white, _none, "LEFT:  exsound support");
  if (dc_settings.is_exsound ())
    draw_string (260, 100, _white, _none, "[ON]");
  else
    draw_string (260, 100, _white, _none, "[OFF]");
  
  draw_string (30, 110, _white, _none, "RIGHT: fullscreen");
  if (dc_settings.is_fullscreen ())
    draw_string (260, 110, _white, _none, "[ON]");
  else
    draw_string (260, 110, _white, _none, "[OFF]");
  
  draw_string (30, 130, _white, _none, "Y: adjust screen position");
  draw_string (30, 140, _white, _none, "R + B: set default");
  draw_string (30, 150, _white, _none, "X: save config to VMU");
  
  fm_config_t *fm_config = &(dc_settings.fm_config);
  draw_string (30, 170, _white, _none, "analog: adjust rom menu wait");
  sprintf(str, "vertical %d / horizontal %d", 
	  fm_config->vertical_wait, fm_config->horizontal_wait);
  draw_string (30, 180, _white, _none, str);
}


static void
do_main_options () 
{
  bool is_update;
  cont_cond_t cont;
  uint16 all_buttons = 
    CONT_START | 
    CONT_DPAD_UP | 
    CONT_DPAD_DOWN | 
    CONT_DPAD_LEFT |
    CONT_DPAD_RIGHT | 
    CONT_A | 
    CONT_B | 
    CONT_Y | 
    CONT_X;
  
  draw_main_option_menu ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  wait_until_release_buttons (dc_controller_addr[0], CONT_X);
  
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;

    is_update = false;
    if ((cont.buttons & all_buttons) != all_buttons) 
      is_update = true;
    
    if (cont.ltrig && cont.rtrig)
      break;
    
    if (!(cont.buttons & CONT_START)) 
      dc_settings.inc_cont_scheme ();
    
    if (!(cont.buttons & CONT_DPAD_UP)) 
      dc_settings.toggle_sound ();
    
    if (!(cont.buttons & CONT_DPAD_DOWN)) 
      dc_settings.toggle_save ();
    
    if (!(cont.buttons & CONT_DPAD_LEFT))
      dc_settings.toggle_exsound ();
    
    if (!(cont.buttons & CONT_DPAD_RIGHT))
      dc_settings.toggle_fullscreen ();
    
    if (!(cont.buttons & CONT_Y))
      do_adjust_screen_rect_menu ();
    
    if (!(cont.buttons & CONT_B) & cont.rtrig)
      dc_settings.set_default ();
    
    if (!(cont.buttons & CONT_X))
      dc_settings.save_to_vmu(mvmu);
    
    {
      /* for rom menu options */
      fm_config_t *config = &(dc_settings.fm_config);
      
      /* analog up */
      if (cont.joyy < 5)
      {
	if (config->vertical_wait > 0)
	  --config->vertical_wait;
	is_update = true;
      }
      /* analog down */
      if (cont.joyy > 250)
      {
	if (config->vertical_wait < 200)
	  ++config->vertical_wait;
	is_update = true;
      }
      /* analog right */
      if (cont.joyx > 250) 
      {
	if (config->horizontal_wait < 200) 
	  ++config->horizontal_wait;
	is_update = true;
      }
      /* analog left */
      if (cont.joyx < 5)
      {
	if (config->horizontal_wait > 0) 
	  --config->horizontal_wait;
	is_update = true;
      }
    }
    
    if (is_update)
    {
      draw_main_option_menu ();
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      wait_until_release_buttons (dc_controller_addr[0], all_buttons);
      /* wait release trigger for do_adjust_screen_rect_menu */
      wait_until_release_trigger (dc_controller_addr[0]);
    }
  }
}


static void 
do_credits() 
{
  int state = 0;
  cont_cond_t cont;
  
  for (;;)
  {
    if (!(dc_cont_get_cond (dc_controller_addr[0], &cont)))
      continue;
    
    if (cont.rtrig && cont.ltrig)
	break;
    
    display_rawimage (credits_image);
    if (!(state & 0x8))
      ++state;
    else
    {
      draw_string (10, 10, _white, _black, "pull L+R");
      state = (state + 1) & 0xf;
    }
    dc_vid_flip_fill_renderer (draw_type_fullscreen);
    timer_sleep (100);
  }
}


static void
timer_handler(irq_t source, irq_context_t *context)
{
#ifdef __DRAW_FPS__
  static int times = 0;
  ++times;
  if (times == 60)
  {
    times = 0;
    drop_frames_per_sec = drop_frames;
    drop_frames = 0;
  }
#endif
  ++rest_frames;
}


static void
do_autoloop (NES *emu, int cycles_per_sec, draw_type_t dt)
{
  int before_skip = 0;
  
  timer_prime (TMU2, cycles_per_sec, true);
  irq_set_handler(EXC_TMU2_TUNI2, timer_handler);
  timer_start(TMU2);
  
  rest_frames = 1;
  while (!interrupt_game_loop) 
  {
    emu->emulate_frame (dc_get_screen ());
#ifdef __DRAW_FPS__
    {
      char str[128];
      sprintf(str, "drop frame: %d", drop_frames_per_sec);
      draw_string (30, 10, _white, _black, str);
    }
#endif
    dc_vid_flip (dt);
    --rest_frames;
    
    if (rest_frames <= 0)
    {
      if (!before_skip)
      {
	while (rest_frames < 0)
	  ;
      }
      before_skip = 0;
      
      poll_input (emu);
    }
    else
    {
      int skip_frame = rest_frames;
      
      poll_input (emu);
      rest_frames = 0;
      
      while (skip_frame--)
      {
#ifdef __DRAW_FPS__
	++drop_frames;
#endif
	emu->emulate_frame_skip ();
	poll_input(emu);
	if (interrupt_game_loop)
	  break;
      }
      before_skip = 1;
    }
  }
  
  timer_stop(TMU2);
}


static void
do_loop (NES *emu)
{
  exit_game_loop = false;
  interrupt_game_loop = false;
  
  while (!exit_game_loop) 
  {
    draw_type_t dt;
    
    if (dc_settings.is_fullscreen ())
      dt = draw_type_nes_fullscreen;
    else
      dt = draw_type_nes_regular;
    vmu_draw_settings (emu);
    interrupt_game_loop = false;
    
    if (dc_settings.get_frameskip () == DC_settings::no_skip)
    {
      while (!interrupt_game_loop) 
      {
	emu->emulate_frame (dc_get_screen ());
	dc_vid_flip (dt);
	poll_input(emu);
      }
    }
    else
    {
      do_autoloop (emu, dc_settings.get_frameskip_cycles (), dt);
    }
  }
}


static void
md_clear ()
{
  FILE *fp;
  
  fp = fopen("/md/quick", "w");
  if (fp)
    fclose(fp);
}


static void
run_game(const char *filename)
{
  NES *emu = NULL;
  sound_mgr *snd_mgr = NULL;
  dc_NES_screen_mgr *scr_mgr = NULL;
  NES_pad *pad[4] = {NULL, NULL, NULL, NULL};
  int i;
  
  dc_vid_empty ();
  
  for (i = 0; i < 4; ++i)
  {
    pad[i] = new NES_pad ();
    if (!(pad[i])) goto finish;
  }
  
  if (dc_settings.is_sound ())
    snd_mgr = new dc_sound_mgr ();
  else
    snd_mgr = new null_sound_mgr ();
  if (!snd_mgr) goto finish;
  if (!(snd_mgr->initialize ())) goto finish;
  
  scr_mgr = new dc_NES_screen_mgr ();
  if (!scr_mgr) goto finish;
  
  emu = new NES (scr_mgr, snd_mgr);
  if (!emu) goto finish;
  if (!(emu->initialize (filename))) goto finish;
  
  sram_load_from_vmu (mvmu, emu);
  disk_load_from_vmu (mvmu, emu);
  
  for (i = 0; i < 4; ++i)
    emu->set_pad (i, pad[i]);
  
  md_clear ();
  dc_vid_empty ();
  
  dc_settings.set_frameskip (DC_settings::auto_skip);
  dc_settings.set_autofire_base (false);
  
  do_loop (emu);
  
  emu->freeze ();
  dc_vid_empty ();
  if (dc_settings.is_save ())
  {
    sram_save_to_vmu (mvmu, emu);
    disk_save_to_vmu (mvmu, emu);
  }
  emu->thaw ();
  
finish:
  if (emu) delete (emu);
  if (scr_mgr) delete (scr_mgr);
  if (snd_mgr) delete (snd_mgr);
  for (i = 0; i < 4; ++i)
    if (pad[i]) delete (pad[i]);
}


static void
draw_main_menu ()
{
  display_rawimage (menu_image);
}


static void
draw_main_menu_vmu_icon ()
{
  char vmu_screen[48 * 32];
  int vmu_free_blocks;
  char str[32];
  
  timer_spin_sleep (50); /* need wait */
  vmu_free_blocks = ndc_vmu_check_free_blocks (NULL, mvmu);
  
  vmu_icon_clear (vmu_screen, 1);
  vmu_icon_draw_string (vmu_screen, 1, 1, "VMU FREE:");
  sprintf(str, "%d BLOCKS", vmu_free_blocks);
  vmu_icon_draw_string (vmu_screen, 3, 7, str);
  
  vmu_icon_draw_string (vmu_screen, 1, 20, "NESTERDC");
  vmu_icon_draw_string (vmu_screen, 3, 26, "5.0 RELEASE");
  
  vmu_icon_flip (vmu_screen, mldc);
  
  timer_spin_sleep (200); /* need wait */
}


static void
load_main_menu ()
{
  cont_cond_t cont;
  
  draw_main_menu_vmu_icon ();
  
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (cont.rtrig && cont.ltrig && 
	!(cont.buttons & CONT_Y) &&
	!(cont.buttons & CONT_START))
      break;
    
    if (!(cont.buttons & CONT_A)) 
    {
      fm_result_t result;
      
      dc_settings.fm_config.root_path = "/cd";
      if (do_file_menu (&result, last_romfile_dir, &(dc_settings.fm_config)))
      {
	char *p;
	run_game (result.path);
	
	sprintf (last_romfile_dir, "%s", result.path);
	p = strrchr(last_romfile_dir, '/');
	*p = '\0';
      }
      
      draw_main_menu_vmu_icon ();
    }
    
    if (!(cont.buttons & CONT_X)) 
      do_main_options ();
    
    if (!(cont.buttons & CONT_Y)) 
      do_credits ();
    
    if (!(cont.buttons & CONT_B)) 
    {
      do_vmu_menu (mvmu);
      draw_main_menu_vmu_icon ();
    }
    
    draw_main_menu ();
    dc_vid_flip (draw_type_fullscreen);
  }
}


#if 0
#include "testing.cpp"
#endif


static void
draw_startup_image (const char *string)
{
  display_rawimage (startup_image);
  draw_string(10, 200, _white, _black, "NesterDC 5.0 release");
  draw_string(10, 210, _white, _none, string);
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
}

extern "C" int
main() 
{
  kos_init_all(IRQ_ENABLE | TA_ENABLE, NULL);
  
  fs_md_init (NES::snss_buflen);
  dc_maple_controller_init ();
  dc_vid_init ();
  init_vsync_handler ();
  
#if 0
  test_all ();
#endif
  mldc = maple_first_lcd ();
  if (mldc)
    vmu_icon_flip (vmu_kos_xpm, mldc);
  
  load_bmp (startup_image, "/cd/pics/startup.bmp");
  
  draw_startup_image ("startup");
  load_bmp (menu_image, "/cd/pics/menu.bmp");
  draw_startup_image ("startup.");
  load_bmp (credits_image, "/cd/pics/credits.bmp");
  draw_startup_image ("startup..");
  load_bmp (options_image, "/cd/pics/options.bmp");
  draw_startup_image ("startup...");
  init_menus ();
  
  nes_settings = new NES_settings ();
  nes_settings->initialize ();
  sprintf (nes_settings->module_dirname, "/cd/games");
  
  sprintf (last_romfile_dir, "/cd/games");
  
  draw_startup_image ("load setting");
  dc_settings.initialize ();
  mvmu = dc_settings.find_vmu ();
  if (mvmu)
    dc_settings.load_from_vmu (mvmu);
  else
  {
    mvmu = do_vmu_select_menu ();
    if (mvmu)
      dc_settings.save_to_vmu (mvmu);
  }
  
  run_game ("/cd/games/game.nes");
#if 0
  run_game ("/cd/games/punch_out.nes");
#endif
  load_main_menu();
  
  if (mldc)
  {
    char vmu_screen[48 * 32];
    vmu_icon_clear (vmu_screen, 0);
    vmu_icon_flip(vmu_screen, mldc);
  }
  
  shutdown_vsync_handler ();
  fs_md_shutdown ();
  kos_shutdown_all();
  return 0;
}


