#include <stdio.h>
#include <math.h>
#include "tbl_param.h"

static unsigned int lineartbl[lineartable_len];

int
main()
{
  int i;
  double a;
  unsigned int ua;
  
  memset(lineartbl, 0, sizeof(lineartbl));
  
  lineartbl[0] = LOG_LIN_BITS << LOG_BITS;
  
  for (i = 1; i < lineartable_len; i++)
  {
    a = i << (LOG_LIN_BITS - LIN_BITS);
    ua = (unsigned int)((LOG_LIN_BITS - (log(a) / log(2))) * (1 << LOG_BITS));
    lineartbl[i] = ua << 1;
  }
  
  for (i = 0; i < lineartable_len; ++i)
  {
    printf("%d,\n", lineartbl[i]);
  }
}


