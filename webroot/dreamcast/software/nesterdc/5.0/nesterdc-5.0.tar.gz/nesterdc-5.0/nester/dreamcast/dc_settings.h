#ifndef _DC_SETTINGS_H_
#define _DC_SETTINGS_H_


#include "nes_settings.h"
#include "dc_menu.h"
#include "types.h"

class DC_settings
{
 public:
  enum cont_scheme_pattern 
  {
    bx_aa, 
    ba_ab, 
    bx_ab, 
    cont_scheme_pattern_num
  };
  
  const char *get_cont_scheme_string () 
  {
    static const char *strings[] = {
      "[NES_B = DC_X] [NES_A = DC_A]", 
      "[NES_B = DC_A] [NES_A = DC_B]",
      "[NES_B = DC_X] [NES_A = DC_B]"
    };
    return strings[cont_scheme];
  }
  
  void set_cont_scheme (uint8 pattern) 
  {
    if (pattern < cont_scheme_pattern_num)
      cont_scheme = pattern;
    else
      cont_scheme = 0;
    
    switch (cont_scheme) 
    {
      case bx_aa:
        cont_b_keycode = CONT_X;
        cont_a_keycode = CONT_A;
        break;
      case ba_ab:
        cont_b_keycode = CONT_A;
        cont_a_keycode = CONT_B;
        break;
      case bx_ab:
        cont_b_keycode = CONT_X;
        cont_a_keycode = CONT_B;
        break;
      default:
        cont_b_keycode = CONT_X;
        cont_a_keycode = CONT_A;
        break;
    }
  }
  
  void inc_cont_scheme () 
  {
    ++cont_scheme;
    if (cont_scheme == cont_scheme_pattern_num)
      cont_scheme = 0;
    
    set_cont_scheme (cont_scheme);
  }
  
  uint16 get_cont_a () { return cont_a_keycode; }
  uint16 get_cont_b () { return cont_b_keycode; }
  
  
  /* */
  enum frameskip_rate 
  {
    no_skip,
    half_skip,
    auto_skip, 
    one_and_half_skip,
    double_skip,
    full_skip,
    frameskip_rate_num
  };
  
  const char *get_frameskip_short_string () 
  {
    static const char *strings[] = 
    {
      "NO SKIP",
      "AUTO: x0.5",
      "AUTO: x1.0",
      "AUTO: x1.5", 
      "AUTO: x2.0", 
      "AUTO: x4.0"
    };
    return strings[frameskip];
  }
  
  const int get_frameskip_cycles ()
  {
    static const int cycles[] = 
    {
      0,
      30,
      60,
      90,
      120,
      240
    };
    return cycles[frameskip];
  }
  
  void set_frameskip (uint8 rate) 
  { 
    if (rate < frameskip_rate_num)
      frameskip = rate;
  }
  uint8 get_frameskip () { return frameskip; }
  
  /* */
  void set_sound (bool which) { sound_on = which; }
  void toggle_sound () { set_sound(!sound_on); }
  bool is_sound () { return sound_on; }
  
  void set_save (bool which) { save = which; }
  void toggle_save () { set_save(!save); }
  bool is_save () { return save; }
  
  void set_exsound (bool which)
  {
    exsound = which; 
    nes_settings->external_enabled = which;
  }
  void toggle_exsound () { set_exsound(!exsound); }
  bool is_exsound () { return exsound; }
  
  void set_fullscreen (bool which) { fullscreen = which; }
  void toggle_fullscreen () { set_fullscreen (!fullscreen); }
  bool is_fullscreen () { return fullscreen; }
  
  void set_autofire_base (bool which) { autofire_base = which; }
  void set_autofire(bool which_a, bool which_b)
  {
    autofire_a = which_a;
    autofire_b = which_b;
  }
  void toggle_autofire_base () { set_autofire_base (!autofire_base); }
  void toggle_autofire_a () { set_autofire (!autofire_a, autofire_b); }
  void toggle_autofire_b () { set_autofire (autofire_a, !autofire_b); }
  bool is_autofire_base () { return autofire_base; }
  bool is_autofire_a () { return autofire_a; }
  bool is_autofire_b () { return autofire_b; }
  
  void set_default ()
  {
    set_cont_scheme (bx_aa);
    set_frameskip (auto_skip);
    set_sound (true);
    set_save (true);
    set_exsound (true);
    set_fullscreen (true);
    
    set_autofire_base (false);
    set_autofire(true, true);
    
    fm_config.vertical_wait = 80;
    fm_config.horizontal_wait = 80;
  }
  
  /* */
  bool initialize () 
  {
    set_default ();
    return true;
  }
  
  uint8 find_vmu ();
  void save_to_vmu (uint8 addr);
  void load_from_vmu (uint8 addr);
  
 private:
  uint16 cont_a_keycode;
  uint16 cont_b_keycode;
  uint8 cont_scheme;
  uint8 frameskip;
  uint8	sound_on;
  uint8	save;
  uint8 exsound;
  uint8 fullscreen;
  
  uint8 autofire_base;
  uint8 autofire_a;
  uint8 autofire_b;
  
public:
  fm_config_t fm_config;
};


#endif
