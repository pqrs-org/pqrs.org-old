#!/bin/sh

stamp=$(date '+%Y-%m-%d')
ndcelf="nesterdc-$stamp.elf"

#----------------------------------------
cd obj

cp nester.elf $ndcelf
sh-elf-strip $ndcelf
zip $ndcelf.zip $ndcelf

chmod 644 $ndcelf.zip
mv $ndcelf.zip ~/public_html/nesterdc/daily


#----------------------------------------
cd ..
cat > index.html <<EOF 
<html>

<head>
 <title>daily NesterDC</title>
</head>
<body>
<h1>daily NesterDC</h1>

<h2>Note</h2>
<p>
If you want to make CD-R from this, 
you must convert the format to 1ST_READ.BIN from elf. 
</p>

<h2>File</h2>
EOF

echo "<ul>"
echo "<li><a href=\"$ndcelf.zip\">$ndcelf.zip</a></li>" >> index.html
echo "<li><a href=\"README\">README</a></li>" >> index.html
echo "<li><a href=\"README.keybind\">README.keybind</a></li>" >> index.html
echo "</ul>"

echo "<h2>Changes from last release</h2>" >> index.html
echo "<ul>" >> index.html

ruby -ne 'print "<li>#{$_.strip}</li>\n" unless $_.strip.empty?' >> index.html doc/changes
echo "</ul>" >> index.html

cat >> index.html <<EOF
</body>
</html>
EOF


chmod 644 index.html
mv index.html ~/public_html/nesterdc/daily
#----------------------------------------
cp README ~/public_html/nesterdc/daily
chmod 644 ~/public_html/nesterdc/daily/README

cp README.keybind ~/public_html/nesterdc/daily
chmod 644 ~/public_html/nesterdc/daily/README.keybind

