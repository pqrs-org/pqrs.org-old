#ifndef __ARCH_DC_QUEUE_H__
#define __ARCH_DC_QUEUE_H__

#define DC_QUEUE_LEN 32

typedef struct {
  int head;
  int tail;
  
  void *queue[DC_QUEUE_LEN];
  int size;
} dc_queue_t;

void *dc_queue_enqueue (dc_queue_t *queue, void *p);
void *dc_queue_dequeue (dc_queue_t *queue);
void dc_queue_clear (dc_queue_t *queue);
int dc_queue_init (dc_queue_t *queue, int size);

#endif
