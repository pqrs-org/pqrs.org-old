/* KallistiOS 1.1.6

   exit.c
   (c)2001 Dan Potter

   exit.c,v 1.1 2002/01/14 11:01:56 tekezo Exp
*/

#include <arch/arch.h>

/* exit() */
void exit() {
	arch_exit();
}

