/* KallistiOS 1.1.6

   strnicmp.c
   (c)2000 Dan Potter

   strnicmp.c,v 1.2 2002/02/15 16:36:08 tekezo Exp
*/

#include <string.h>

/* Works like strncmp, but not case sensitive */
int strnicmp(const char * cs, const char * ct, int count) {
	int c1, c2 = 0;
	
	if (count != 0) {
		do {
			if (tolower(*cs) != tolower(*ct++))
				return tolower(*cs) - tolower(*--ct);
			if (*cs++ == '\0')
				break;
		} while (--count != 0);
	}
	return 0;
}

/* Provides strncasecmp also (same thing) */
int strncasecmp(const char *cs, const char *ct, int count) {
	return strnicmp(cs, ct, count);
}

