/* KallistiOS 1.1.6

   panic.c
   (c)2001 Dan Potter
*/

#include <stdio.h>
#include <malloc.h>
#include <arch/arch.h>
#if 1
#include <dc/biosfont.h>
#include <arch/timer.h>
#endif

CVSID("panic.c,v 1.3 2002/02/12 09:17:18 tekezo Exp");

/* If something goes badly wrong in the kernel and you don't think you
   can recover, call this. This is a pretty standard tactic from *nixy
   kernels which ought to be avoided if at all possible. */
void panic(const char *msg) {
	printf("%s\r\n", msg);
#if 1
        vid_set_start(0);
        bfont_draw_str((uint16 *)0xA5000000, 640, 1, msg);
        timer_spin_sleep(5000);
#endif
	arch_exit();
}

