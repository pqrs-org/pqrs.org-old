#include <arch/queue.h>
#include <stdio.h>

void *
dc_queue_enqueue (dc_queue_t *queue, void *p)
{
  int next_index;
  
  next_index = queue->head + 1;
  if (next_index == queue->size)
    next_index = 0;
  
  if (next_index == queue->tail)
    return NULL;
  else 
  {
    (queue->queue)[queue->head] = p;
    queue->head = next_index;
    
    return p;
  }
}


void *
dc_queue_dequeue (dc_queue_t *queue)
{
  if (queue->tail == queue->head)
    return NULL;
  else
  {
    int tail = queue->tail;
    
    ++queue->tail;
    if (queue->tail == queue->size)
      queue->tail = 0;
    
    return (queue->queue)[tail];
  }
}


void
dc_queue_clear (dc_queue_t *queue)
{
  int i;
  
  for (i = 0; i < queue->size; ++i)
    (queue->queue)[i] = NULL;
  
  queue->head = 0;
  queue->tail = 0;
}


int
dc_queue_init (dc_queue_t *queue, int size)
{
  if (size > DC_QUEUE_LEN)
    return -1;
  
  queue->size = size;
  dc_queue_clear (queue);
  return 0;
}


