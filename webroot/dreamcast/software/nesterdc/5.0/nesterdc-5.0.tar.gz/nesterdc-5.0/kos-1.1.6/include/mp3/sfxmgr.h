/* KallistiOS 1.1.6

   sfxmgr.h
   (c)2000 Dan Potter

   sfxmgr.h,v 1.1 2002/01/14 11:01:55 tekezo Exp
   
*/

#ifndef __SFXMGR_H
#define __SFXMGR_H

#include <sys/cdefs.h>
__BEGIN_DECLS

int sfx_load(const char *fn);
void sfx_play(int idx, int vol, int pan);
void sfx_unload_all();

__END_DECLS

#endif	/* __SFXMGR_H */

