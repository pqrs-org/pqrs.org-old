/* KallistiOS 1.1.6

   stricmp.c
   (c)2000 Dan Potter

   stricmp.c,v 1.2 2002/02/15 16:36:08 tekezo Exp
*/

#include <string.h>

/* Works like strcmp, but not case sensitive */
int stricmp(const char * cs,const char * ct) {
	int c1, c2, res;
        
        while (tolower(*cs) == tolower(*ct++))
		if (*cs++ == '\0')
			return 0;
	return tolower(*cs) - tolower(*--ct);
}

/* Also provides strcasecmp (same thing) */
int strcasecmp(const char *cs, const char *ct) {
	return stricmp(cs, ct);
}
