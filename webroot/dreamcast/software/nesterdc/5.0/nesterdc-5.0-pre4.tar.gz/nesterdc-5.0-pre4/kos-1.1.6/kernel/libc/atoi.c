/* KallistiOS 1.1.6

   atoi.c
   (c)2001 Vincent Penne

   atoi.c,v 1.1 2002/01/14 11:01:56 tekezo Exp
*/

int atoi(const char * s) {
	int m, v;

	v = 0;

	if (*s == '-') {
		m = -1;
		s++;
	} else {
		m = 1;
		if (*s == '+')
			s++;
	}

	while (*s >= '0' && *s <= '9') {
		v = v*10 + *s-'0';
		s++;
	}

	return m * v;
}

