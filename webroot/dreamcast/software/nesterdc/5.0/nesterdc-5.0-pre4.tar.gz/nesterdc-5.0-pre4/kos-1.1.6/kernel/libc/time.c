/* KallistiOS 1.1.6

   time.c
   (c)2001 Dan Potter

   time.c,v 1.1 2002/01/14 11:01:57 tekezo Exp
*/

#include <time.h>
#include <arch/timer.h>

/* time() */
time_t time(time_t *ptr) {
	time_t t = timer_count(TMU0) * 100;
	if (ptr) {
		*ptr = t;
	}
	return t;
}

/* time() */
double difftime(time_t time1, time_t time0) {
	return (double)(time1 - time0);
}

