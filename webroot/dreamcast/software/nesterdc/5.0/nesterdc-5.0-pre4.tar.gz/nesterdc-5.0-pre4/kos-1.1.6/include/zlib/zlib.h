#ifndef __ZLIB_H__
#define __ZLIB_H__

#include <zlib.h>

uint32 zlib_getlength(gzFile f);
#endif
