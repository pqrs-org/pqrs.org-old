/* KallistiOS 1.1.6

   abort.c
   (c)2001 Dan Potter

   abort.c,v 1.1 2002/01/14 11:01:56 tekezo Exp
*/

#include <arch/arch.h>

/* This is probably the closest mapping we've got for abort() */
void abort() {
	arch_exit();
}

