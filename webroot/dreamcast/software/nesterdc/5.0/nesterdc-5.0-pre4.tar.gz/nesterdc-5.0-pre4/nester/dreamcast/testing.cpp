static void
test_md ()
{
  FILE *fp = NULL;
  int i;
  char buf[0x10000];
  
  for (i = 0; i < 0x10000; ++i)
  {
    fp = fopen ("/md/quick", "r");
    if (!fp)
      dc_put_error ("md open error");
    fclose(fp);
    
    if (!(i % 0x100))
    {
      sprintf(buf, "test_md step1 %x", i);
      dc_print(buf);
    }
  }
  
  for (i = 0; i < 0x1000; ++i)
  {
    fp = fopen("/md/quick", "w");
    if (!fp)
      dc_put_error ("md open error");
    
    if (fwrite(buf, sizeof(buf), 1, fp) != 1)
      dc_put_error ("write error");
    
    fclose(fp);
    
    if (!(i % 0x100))
    {
      sprintf(buf, "test_md step2 %x", i);
      dc_print(buf);
    }
  }
  
  for (i = 0; i < 0x1000; ++i)
  {
    fp = fopen("/md/quick", "r");
    if (!fp)
      dc_put_error ("md open error");
    
    if (fread(buf, sizeof(buf), 1, fp) != 1)
      dc_put_error ("read error");
    
    fclose(fp);
    
    if (!(i % 0x100))
    {
      sprintf(buf, "test_md step3 %x", i);
      dc_print(buf);
    }
  }
}


static void
test_nes ()
{
  int i;
  NES_pad *pad = NULL;
  sound_mgr *snd_mgr = NULL;
  dc_NES_screen_mgr *scr_mgr = NULL;
  char buf[128];
  
  for (i = 0; i < 0x10000; ++i)
  {
    pad = new NES_pad ();
    scr_mgr = new dc_NES_screen_mgr ();
    // snd_mgr = new dc_sound_mgr ();
    
    delete (scr_mgr);
    delete (pad);
    
    if (!(i % 0x100))
    {
      sprintf(buf, "test_nes step1 %x", i);
      dc_print(buf);
    }
  }
}


static void
test_bzip2 ()
{
  char buf[128];
  char buf1[0x4000];
  char buf2[0x4000];
  int buf1_len = sizeof(buf1);
  int buf2_len = sizeof(buf2);
  int i;
  
  for (i = 0; i < sizeof(buf1); ++i)
  {
    if (i & 0x01)
      buf1[i] = buf1[i - 1] >> 1;
    else
      buf1[i] = (i >> 1) ^ 0xedb88320;
    
    if (!(i % 0x100))
    {
      sprintf(buf, "test_bzip2 step0 %x", i);
      dc_print(buf);
    }
  }
  
  for (i = 0; i < 0x10; ++i)
  {
    buf2_len = sizeof(buf2);
    if (BZ2_bzBuffToBuffCompress (buf2, (unsigned int *)&buf2_len, 
				  buf1, sizeof(buf1), 
				  9, 0, 0) != BZ_OK)
    {
      dc_put_error ("compress error");
    }
    
    buf1_len = sizeof(buf1);
    if (BZ2_bzBuffToBuffDecompress (buf1, (unsigned int *)&buf1_len,
				    buf2, buf2_len,
				    0, 0) != BZ_OK)
    {
      dc_put_error ("decompress error");
    }
    
    sprintf(buf, "test_bzip2 step1 %x", i);
    dc_print(buf);
  }
}


static void
test_maple ()
{
  cont_cond_t cont;
  int i;
  
  dc_print ("test_maple");
  
  /* need tight loop for dc_cont_get_cond testing. (don't dc_print) */
  for (i = 0; i < 0x10000; ++i)
    dc_cont_get_cond (dc_controller_addr[0], &cont);
}


static void
test_all ()
{
  test_md ();
  test_nes ();
  test_bzip2 ();
}
