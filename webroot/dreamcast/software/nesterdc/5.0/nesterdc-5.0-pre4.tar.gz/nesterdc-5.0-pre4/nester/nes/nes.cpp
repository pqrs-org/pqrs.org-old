/*
** nester - NES emulator
** Copyright (C) 2000  Darren Ranalli
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

/* 
** NesterDC by Ken Friece
** This routine was so different than the original, that I included 
** diff output at the bottom of the routine. The orginal is also called
** nes.cpp.original
*/

#include "nester.h"
#include "stdlib.h"
#include <string.h>
#include <math.h>
#include "nes.h"
#include "nes_screen_mgr.h"
#include "nes_rom.h"
#include "nes_ppu.h"
#include "snss.h"
#include "debug.h"

//const float NES::CYCLES_PER_LINE = (float)113.6;
//const float NES::CYCLES_PER_LINE = (float)113.852;
//const float NES::CYCLES_PER_LINE = (float)113.75;
//const float NES::CYCLES_PER_LINE = (float)113.6666666666666666666;


NES::NES(NES_screen_mgr* _screen_mgr, sound_mgr* _sound_mgr)
{
  int i;
  
  scr_mgr = _screen_mgr;
  snd_mgr = _sound_mgr;
  
  LOG("nester - NES emulator by Darren Ranalli, (c) 2000");
  
  cpu = NULL;
  ppu = NULL;
  apu = NULL;
  ROM = NULL;
  mapper = NULL;
  for (i = 0; i < 4; ++i)
    pad[i] = NULL;
  
  DPCM_IRQ = true;
  is_frozen = FALSE;
  
  memset(SaveRAM, 0, sizeof(SaveRAM));
}


bool 
NES::initialize (const char *filename)
{
  LOG("Creating NES CPU");
  cpu = new NES_6502 ();
  if (!cpu) return false;
  if (!(cpu->initialize(this))) return false;
  
  LOG("Creating NES PPU");
  ppu = new NES_PPU ();
  if (!ppu) return false;
  if (!(ppu->initialize(this))) return false;
  
  LOG("Creating NES APU");
  apu = new NES_APU ();
  if (!apu) return false;
  if (!(apu->initialize(this))) return false;
  
  LOG("Creating SNSS");
  snss = new NES_SNSS ();
  if (!snss) return false;
  
  if (!(loadROM(filename))) return false;
  
  return true;
}


NES::~NES()
{
  freeROM();
  
  if(cpu) delete cpu;
  if(ppu) delete ppu;
  if(apu) delete apu;
  if(snss) delete snss;
}

void NES::new_snd_mgr(sound_mgr* _sound_mgr)
{
  snd_mgr = _sound_mgr;
  apu->snd_mgr_changed();
}

bool
NES::loadROM(const char* fn)
{
  LOG("Loading ROM...");
  ROM = new NES_ROM ();
  if (!ROM) goto error;
  if (!(ROM->initialize (fn))) goto error;
  
  LOG("Set up the mapper");
  mapper = GetMapper(ROM->get_mapper_num());
  if (!mapper) goto error;
  if (!(mapper->initialize (this))) goto error;
  
  reset();
  
  LOG("Starting emulation...");
  
  return true;
  
error:
  if (ROM)
  {
    delete ROM;
    ROM = NULL;
  }
  if (mapper)
  {
    delete mapper;
    mapper = NULL;
  }
  return false;
}

void NES::freeROM()
{
  if(ROM)
  {
    delete ROM;
    ROM = NULL;
  }
  if(mapper)
  {
    delete mapper;
    mapper = NULL;
  }
}

const char* 
NES::getROMname()
{
  return ROM->GetRomName();
}

const char* 
NES::getROMpath()
{
  return ROM->GetRomPath();
}


void
NES::reset()
{
  // clear RAM
  memset(RAM, 0x00, sizeof(RAM));

  softreset();
}


void
NES::softreset()
{
  int i;
  
  // set up CPU
  {
    NES_6502::Context context;

    memset((void*)&context, 0x00, sizeof(context));
    cpu->GetContext(&context);

    context.mem_page[0] = RAM;
    context.mem_page[3] = SaveRAM;

    cpu->SetContext(&context);
  }
  
  // reset the PPU
  ppu->reset();
  ppu->vram_write_protect = ROM->get_num_8k_VROM_banks() ? 1 : 0;
  ppu->vram_size = 0x2000;
  
  // reset the APU
  apu->reset();
  
  frame_irq_enabled = 0xFF;
  frame_irq_disenabled = 0;
  
  if(mapper)
  {
    // reset the mapper
    mapper->Reset();
  }
  
  // reset the CPU
  cpu->Reset();
  
  // set up the trainer if present
  if(ROM->has_trainer())
  {
    // trainer is located at 0x7000; SaveRAM is 0x2000 bytes at 0x6000
    memcpy(&SaveRAM[0x1000], ROM->get_trainer(), NES_ROM::TRAINER_LEN);
  }
  
#if 0
  #include "NES_set_Controller.cpp"
  #include "NES_set_VSPalette.cpp"
#endif
  #include "nes_set_cycles.cpp"
  
  ideal_cycle_count  = 0.0;
  emulated_cycle_count = 0;
  
  disk_side_flag = 0;
  
  pad_strobe = FALSE;
  for (i = 0; i < 4; ++i)
    pad_bits[i] = 0;
}


#include "nes_emulate_frame.cpp"
#define EMULATE_FRAME
#include "nes_emulate_frame.cpp"
#undef EMULATE_FRAME

void
NES::freeze()
{
  if (!is_frozen) 
  {
    apu->freeze();
    is_frozen = TRUE;
  }
}

void
NES::thaw()
{
  if (is_frozen) 
  {
    apu->thaw();
    is_frozen = FALSE;
  }
}

boolean
NES::frozen()
{
  return is_frozen;
}

uint8
NES::MemoryRead(uint32 addr)
{
//  LOG("Read " << HEX(addr,4) << endl);

  if(addr < 0x2000) // RAM
  {
    return ReadRAM(addr);
  }
  else if(addr < 0x4000) // low registers
  {
    return ReadLowRegs(addr);
  }
  else if(addr < 0x4018) // high registers
  {
    return ReadHighRegs(addr);
  }
  else if(addr < 0x6000) // mapper low
  {
//    LOG("MAPPER LOW READ: " << HEX(addr,4) << endl);
//    return((uint8)(addr >> 8)); // what's good for conte is good for me
    return mapper->MemoryReadLow(addr);
  }
  else // save RAM, or ROM (mapper 40)
  {
    mapper->MemoryReadSaveRAM(addr);
    return cpu->GetByte(addr);
  }
}

void
NES::MemoryWrite(uint32 addr, uint8 data)
{
//  LOG("Write " << HEX(addr,4) << " " << HEX(data,2) << endl);

  if(addr < 0x2000) // RAM
  {
    WriteRAM(addr, data);
  }
  else if(addr < 0x4000) // low registers
  {
    WriteLowRegs(addr, data);
  }
  else if(addr < 0x4018) // high registers
  {
    WriteHighRegs(addr, data);
    mapper->WriteHighRegs(addr, data);
  }
  else if(addr < 0x6000) // mapper low
  {
    mapper->MemoryWriteLow(addr, data);
  }
  else if(addr < 0x8000) // save RAM
  {
    SaveRAM[addr - 0x6000] = data;
    mapper->MemoryWriteSaveRAM(addr, data);
  }
  else // mapper
  {
    mapper->MemoryWrite(addr, data);
  }
}


uint8
NES::ReadRAM(uint32 addr)
{
  return RAM[addr & 0x7FF];
}

void
NES::WriteRAM(uint32 addr, uint8 data)
{
  RAM[addr & 0x7FF] = data;
}


uint8
NES::ReadLowRegs(uint32 addr)
{
  return ppu->ReadLowRegs(addr & 0xE007);
}

void
NES::WriteLowRegs(uint32 addr, uint8 data)
{
  ppu->WriteLowRegs(addr & 0xE007, data);
}


uint8
NES::ReadHighRegs(uint32 addr)
{
  if(addr == 0x4014) // SPR-RAM DMA
  {
    LOG("Read from SPR-RAM DMA reg??");
    return ppu->Read0x4014();
  } 
  else if(addr == 0x4015 && !(frame_irq_enabled & 0xC0)) // frame_IRQ
  {
    return apu->Read(0x4015) | 0x40;
  }
  else if(addr < 0x4016) // APU
  {
//    LOG("APU READ:" << HEX(addr,4) << endl);
    return apu->Read(addr);
  }
  else // joypad regs
  {
    uint8 retval;

    if(addr == 0x4016)
    {
      // joypad 1
      retval = ((pad_bits[2] & 0x01) << 1) | (pad_bits[0] & 0x01);
      pad_bits[0] >>= 1;
      pad_bits[2] >>= 1;
    }
    else
    {
      // joypad 2
      retval = ((pad_bits[3] & 0x01) << 1) | (pad_bits[1] & 0x01);
      pad_bits[1] >>= 1;
      pad_bits[3] >>= 1;
    }
    return retval;
  }
}

void
NES::WriteHighRegs(uint32 addr, uint8 data)
{
  if(addr == 0x4014) // SPR-RAM DMA
  {
    ppu->Write0x4014(data);
    cpu->SetDMA(514);
  }
  else if(addr < 0x4016) // APU
  {
    apu->Write(addr, data);
  }
  else if(addr == 0x4016) // joy pad
  {
    // bit 0 == joypad strobe
    if(data & 0x01)
    {
      pad_strobe = TRUE;
    }
    else
    {
      if(pad_strobe)
      {
	uint8 state;
        pad_strobe = FALSE;
        // get input states
	if (pad[0])
	{
	  if (pad[2])
	  {
	    state = pad[2]->get_inp_state ();
	    pad_bits[0] = (1 << 19) | (state << 8) | pad[0]->get_inp_state ();
	    pad_bits[2] = state;
	  }
	  else
	  {
	    pad_bits[0] = pad[0]->get_inp_state ();
	  }
	}
	
	if (pad[1])
	{
	  if (pad[3])
	  {
	    state = pad[3]->get_inp_state ();
	    pad_bits[1] = (1 << 18) | (state << 8) | pad[1]->get_inp_state ();
	  }
	  else
	  {
	    pad_bits[1] = pad[1]->get_inp_state ();
	  }
	}
      }
    }
  }
  else if(addr == 0x4017) // frame-IRQ
  {
    if(!frame_irq_disenabled)
    {
      frame_irq_enabled = data;
    }
    apu->Write(addr, data);
  }
}

void 
NES::emulate_CPU_cycles(float num_cycles)
{
  uint32 cycle_deficit;
  
  ideal_cycle_count += num_cycles;
  cycle_deficit = ((uint32)ideal_cycle_count) - emulated_cycle_count;
  if(cycle_deficit > 0)
  {
    emulated_cycle_count += cpu->Execute(cycle_deficit);
    if(apu->SyncDMCRegister(cycle_deficit) && DPCM_IRQ)
    {
      cpu->DoPendingIRQ();
    }
  }
}

// call every once in a while to avoid cycle count overflow
void 
NES::trim_cycle_counts()
{
  uint32 trim_amount;

  trim_amount = (uint32)floor(ideal_cycle_count);
  if(trim_amount > emulated_cycle_count) trim_amount = emulated_cycle_count;

  ideal_cycle_count  -= (float)trim_amount;
  emulated_cycle_count -= trim_amount;
}


void
NES::set_SaveRAM (const uint8 *buffer, int size)
{
  memcpy(SaveRAM, buffer, size); 
}


bool
NES::is_invalid_sram ()
{
  int i;
  
  for (i = 0; i < sizeof(SaveRAM); ++i)
  {
    if (SaveRAM[i])
      return false;
  }
  return true;
}


void
NES::make_savedata (uint8 *buf)
{
  uint8 *rom_banks = ROM->get_ROM_banks ();
  uint8 *data_buf, *flag_buf;
  int n, i, j;
  
  memset(buf, 0, fds_save_buflen);
  memcpy(buf, "FDS2", 4);
  buf[4] = mapper->GetDiskSideNum();
  
  data_buf = buf + 16;
  flag_buf = buf + 16 + (4 * 65500);
  n = 0;
  for(i = 0; i < mapper->GetDiskSideNum(); ++i)
  {
    for(j = 0; j < 65500; ++j)
    {
      uint8 data = mapper->GetDiskData(i*0x10000+j);
      
      if (data != rom_banks[16 + 65500 * i + j])
      {
	data_buf[n] = data;
	flag_buf[n] = 1;
      }
      ++n;
    }
  }
}


void
NES::restore_savedata (uint8 *buf)
{
  uint8 *rom_banks = ROM->get_ROM_banks ();
  uint8 *data_buf, *flag_buf;
  int i, j, n;
  
  data_buf = buf + 16;
  flag_buf = buf + 16 + (4 * 65500);
  n = 0;
  for (i = 0; i < buf[4]; ++i)
  {
    for (j = 0; j < 65500; ++j)
    {
      uint8 data;
      
      if (flag_buf[n])
	data = data_buf[n];
      else
	data = rom_banks[16 + 65500 * i + j];
      mapper->SetDiskData(i*0x10000+j, data);
      
      ++n;
    }
  }
}


boolean 
NES::loadState(const char* fn)
{
  bool success = snss->LoadSNSS(fn, this);
  if (success)
    ppu->set_palette ();
  return success;
}


boolean
NES::saveState(const char* fn)
{
  return snss->SaveSNSS(fn, this);
}


uint8 NES::GetDiskData(uint32 pt)
{
  return mapper->GetDiskData(pt);
}
uint8 NES::GetDiskSideNum()
{
  return mapper->GetDiskSideNum();
}
uint8 NES::GetDiskSide()
{
  return mapper->GetDiskSide();
}
void NES::SetDiskSide(uint8 side)
{
  disk_side_flag = side | 0x10;
  mapper->SetDiskSide (disk_side_flag & 0x0f);
  disk_side_flag = 0;
}
uint8 NES::DiskAccessed()
{
  return mapper->DiskAccessed();
}

