#ifndef __NESTER_H
#define __NESTER_H

#ifdef __cplusplus
#include <new>
#define new new (std::nothrow)
#endif

#ifdef __DREAMCAST__
#include "dc_utils.h"
#include "dc_stdio.h"
#endif

#endif
