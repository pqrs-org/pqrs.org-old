/*
** nester - NES emulator
** Copyright (C) 2000  Darren Ranalli
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

/* 
** NesterDC by Ken Friece
** Any changes that I made to the original source are 
** marked with in the following way:
** KF DD/MM/YYYY <description of the change> 
*/

#ifndef _NES_H_
#define _NES_H_

#include <stdio.h>

#include "types.h"
#include "emulator.h"
#include "nes_6502.h"
#include "nes_mapper.h"
#include "mapper/nes_mapper_decl.h"
#include "nes_rom.h"
#include "nes_ppu.h"
#include "nes_apu_wrapper.h"
#include "nes_pad.h"
#include "nes_settings.h"

class NES_screen_mgr;
class NES_SNSS;

class NES : public emulator
{
  // friend classes
  friend class NES_screen_mgr;
  friend class NES_6502;
  friend class NES_PPU;
  friend class NES_APU;
  friend class NES_SNSS;
  friend class NES_mapper;
#include "mapper/nes_mapper_friend_decl.h"
  
public:
  NES(NES_screen_mgr* _screen_mgr, sound_mgr* _sound_mgr);
  bool initialize (const char *filename);
  ~NES();
  
  void new_snd_mgr(sound_mgr* _sound_mgr);
  
  void set_pad1(controller* c) { pad1 = (NES_pad*)c; }
  void set_pad2(controller* c) { pad2 = (NES_pad*)c; }
  NES_pad* get_pad1() { return pad1; }
  NES_pad* get_pad2() { return pad2; }
  
  /* KF 06/03/2001 */
  void emulate_frame(uint16 *screen);
  void emulate_frame_skip(); 
  
  void reset();
  void softreset();
  
  const char* getROMname();
  const char* getROMpath();
  const char* getROMcrc() {
    return ROM->GetRomCrc(); 
  }
  
  boolean loadState(const char* fn);
  boolean saveState(const char* fn);
  
  void freeze();
  void thaw();
  boolean frozen();
  
  uint8 getBGColor() { return ppu->getBGColor(); }
  void  ppu_rgb() {}
  
  enum {
    NES_NUM_VBLANK_LINES = 20,
    NES_NUM_FRAME_LINES = 240,

    // these are 0-based, and actions occur at start of line
    NES_NMI_LINE = 241,
    NES_VBLANK_FLAG_SET_LINE = 241,
    NES_VBLANK_FLAG_RESET_LINE = 261,
    NES_SPRITE0_FLAG_RESET_LINE = 261,

    NES_COLOR_BASE = 0x40, // NES palette is set starting at color 0x40 (64)
    NES_NUM_COLORS = 64    // 64 colors in the NES palette
  };
  
  uint32 crc32()  { return ROM->crc32();  }
  uint32 fds_id() { return ROM->fds_id(); }
  
  float CYCLES_PER_LINE;
  float CYCLES_BEFORE_NMI;
  boolean BANKSWITCH_PER_TILE;
  boolean DPCM_IRQ;
  
  // Disk System
  uint8 GetDiskData(uint32 pt);
  uint8 GetDiskSideNum();
  uint8 GetDiskSide();
  void SetDiskSide(uint8 side);
  uint8 DiskAccessed();
  
  // frame-IRQ
  uint8 frame_irq_enabled;
  uint8 frame_irq_disenabled;
  
  // SaveRAM control
  void  WriteSaveRAM(uint32 addr, uint8 data) { SaveRAM[addr] = data;}
  uint8 ReadSaveRAM(uint32 addr) { return SaveRAM[addr]; }
  
  // file stuff
  bool has_sram () { return ROM->has_save_RAM (); }
  const uint8 *get_SaveRAM () { return SaveRAM; }
  void set_SaveRAM(const uint8 *buffer, int size);
  bool is_invalid_sram ();
  
  /* change 0x2000 to 0x10000 for mapper 005 */
  static const int sram_buflen = 0x10000; 
  static const int fds_save_buflen = 16 + (4 * 65500) * 2;
  /* snss_buflen: 
     0x8000: fds's WRAM
     0x40000 * 2: fds's quick disk state */
  static const int snss_buflen = sizeof(SNSS_FILE) + 0x8000 + 0x40000 * 2;
  /* buf length must be fds_save_buflen */
  void make_savedata(uint8 *buf);
  void restore_savedata(uint8 *buf);
  
protected:
  NES_screen_mgr* scr_mgr;
  sound_mgr* snd_mgr;
  NES_6502* cpu;
  NES_PPU* ppu;
  NES_APU* apu;
  NES_ROM* ROM;
  NES_mapper* mapper;
  
  boolean is_frozen;
  
  float  ideal_cycle_count;   // number of cycles that should have executed so far
  uint32 emulated_cycle_count;  // number of cycles that have executed so far
  
  // internal memory
  uint8 RAM[0x800];
  uint8 SaveRAM[sram_buflen]; 
  
  // joypad stuff
  NES_pad* pad1;
  NES_pad* pad2;
  boolean  pad_strobe;
  uint8 pad1_bits;
  uint8 pad2_bits;
  
  // Disk System
  uint8 disk_side_flag;
  
  bool loadROM(const char* fn); 
  void freeROM();
  
  // these are called by the CPU
  uint8 MemoryRead(uint32 addr);
  void  MemoryWrite(uint32 addr, uint8 data);
  
  // internal read/write functions
  uint8 ReadRAM(uint32 addr);
  void  WriteRAM(uint32 addr, uint8 data);
  
  uint8 ReadLowRegs(uint32 addr);
  void  WriteLowRegs(uint32 addr, uint8 data);
  
  uint8 ReadHighRegs(uint32 addr);
  void  WriteHighRegs(uint32 addr, uint8 data);
  
  void  emulate_CPU_cycles(float num_cycles);
  void  trim_cycle_counts();
  
private:
  NES_SNSS* snss;
  
  /* helper for emulate_frame */
  void emulate_frame_skip_line (int i);
  void emulate_frame_line_out_screen (int i, uint16 *cur_line);
  void emulate_frame_line (int i, uint16 *cur_line);
};

#endif
