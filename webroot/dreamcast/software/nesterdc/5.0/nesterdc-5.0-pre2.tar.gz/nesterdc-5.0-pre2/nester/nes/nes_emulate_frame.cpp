#ifndef __NES_EMULATE_FRAME_CPP__
#define __NES_EMULATE_FRAME_CPP__


void
NES::emulate_frame_skip_line (int i)
{
  emulate_CPU_cycles(CYCLES_PER_LINE);
  mapper->HSync(i); 
  ppu->do_scanline_and_dont_draw(); 
}


void
NES::emulate_frame_line_out_screen (int i, uint16 *cur_line)
{
#ifdef __PRECISION__EMULATE__
  /* Bankswitch per line Support for Mother */
  if(BANKSWITCH_PER_TILE) 
  {
    /* render line */
    ppu->do_scanline_and_draw(cur_line, CYCLES_PER_LINE * 32 / 42); 
    /* do half line's worth of CPU cycles (hblank) */ 
    emulate_CPU_cycles(13); 
    mapper->HSync(i); 
    emulate_CPU_cycles(CYCLES_PER_LINE * 10 / 42 - 13); 
    if(i == 0) 
    { 
       emulate_CPU_cycles(CYCLES_PER_LINE * 32 / 42 + 13); 
       mapper->HSync(i); 
       emulate_CPU_cycles(CYCLES_PER_LINE * 10 / 42 - 13); 
    } 
  } 
  else 
  { 
    /* do one line's worth of CPU cycles */ 
    emulate_CPU_cycles(CYCLES_PER_LINE); 
    mapper->HSync(i); 
    /* render line */
    ppu->do_scanline_and_draw(cur_line, 0); 
  }
#else
  emulate_frame_skip_line (i);
#endif
}


void
NES::emulate_frame_line (int i, uint16 *cur_line)
{
#ifdef __PRECISION__EMULATE__
  emulate_frame_line_out_screen (i, cur_line);
#else
  emulate_CPU_cycles(CYCLES_PER_LINE);
  mapper->HSync(i);
  ppu->do_scanline_and_draw(cur_line);
#endif
}


/* rendered resolution = 272*240 
   NES resolution = 256*240, so there are 8 pixels of 
   garbage on each side of the screen */
#define SET_CURLINE_NEXT_LINE() \
  *screen++ = 0; *screen++ = 0; \
  *screen++ = 0; *screen++ = 0; \
  *screen++ = 0; *screen++ = 0; \
  *screen++ = 0; *screen++ = 0; \
  \
  screen += 256; \
  \
  *screen++ = 0; *screen++ = 0; \
  *screen++ = 0; *screen++ = 0; \
  *screen++ = 0; *screen++ = 0; \
  *screen++ = 0; *screen++ = 0; \
  \
  screen += 24 + 24; \


#endif /* __NES_EMULATE_FRAME_CPP__ */


void 
#ifdef EMULATE_FRAME
NES::emulate_frame(uint16 *screen)
#else
NES::emulate_frame_skip()
#endif
{
  int i;
  
  trim_cycle_counts();
  
  ppu->start_frame();
  
#ifdef EMULATE_FRAME
  screen += 24;
  
  for (i = 0; i < 8; ++i)
    emulate_frame_line_out_screen (i, screen);
  
  for(i = 8; i < 8 + 224; ++i)
  {
    emulate_frame_line (i, screen);
    SET_CURLINE_NEXT_LINE();
  }
  
  for (i = 8 + 224; i < 8 + 224 + 8; ++i)
    emulate_frame_line_out_screen (i, screen);
  
#else
  for (i = 0; i < 240; ++i)
    emulate_frame_skip_line (i);
  
#endif
  
  ppu->end_frame();
  
  if(!(frame_irq_enabled & 0xC0))
    cpu->DoPendingIRQ();
  
  for(i = 240; i <= 261; i++)
  {
    if(i == 241)
    {
      ppu->start_vblank();
      mapper->VSync();
      
      /* 1 instruction between vblank flag and NMI */
      emulate_CPU_cycles(CYCLES_BEFORE_NMI);
      if(ppu->NMI_enabled()) cpu->DoNMI();
      emulate_CPU_cycles(CYCLES_PER_LINE - CYCLES_BEFORE_NMI);
      mapper->HSync(i);
      continue;
    }
    else if(i == 261)
      ppu->end_vblank();
    
    emulate_CPU_cycles(CYCLES_PER_LINE);
    mapper->HSync(i);
  }
  
  apu->DoFrame();
  apu->SyncAPURegister();
}

