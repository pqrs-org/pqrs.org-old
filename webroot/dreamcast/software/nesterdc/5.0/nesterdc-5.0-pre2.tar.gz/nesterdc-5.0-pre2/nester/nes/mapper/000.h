#ifndef __NES_MAPPER_000_H
#define __NES_MAPPER_000_H

#include "nes_mapper.h"
#include "nes_mapper.h"

/////////////////////////////////////////////////////////////////////
// Mapper 0
class NES_mapper0 : public NES_mapper
{
public:
  ~NES_mapper0() {}
  
  void  Reset();
  
protected:
private:
};
/////////////////////////////////////////////////////////////////////

#endif
