/*
** nester - NES emulator
** Copyright (C) 2000  Darren Ranalli
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful, 
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
** Library General Public License for more details.  To obtain a 
** copy of the GNU Library General Public License, write to the Free 
** Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Any permitted reproduction of these routines, in whole or in part,
** must bear this legend.
*/

#ifndef NES_SETTINGS_H_
#define NES_SETTINGS_H_

#include "types.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


class NES_settings
{
public:
  char module_dirname[512];
  
  uint32 show_more_than_8_sprites;
  uint32 show_all_scanlines;
  
  uint32 rectangle1_enabled;
  uint32 rectangle2_enabled;
  uint32 triangle_enabled;
  uint32 noise_enabled;
  uint32 dpcm_enabled;
  uint32 external_enabled;
  enum filter_type_t { FILTER_NONE, FILTER_LOWPASS, FILTER_LOWPASS_WEIGHTED };
  filter_type_t filter_type;
  
  void SetDefaults() 
  {
    memset(module_dirname, 0, sizeof(module_dirname));
    
    show_more_than_8_sprites = false;
    show_all_scanlines = false;
    
    rectangle1_enabled = true;
    rectangle2_enabled = true;
    triangle_enabled = true;
    noise_enabled = true;
    dpcm_enabled = true;
    external_enabled = true;
    filter_type = FILTER_NONE;
  }
  
  NES_settings () { SetDefaults (); }
};

extern NES_settings *nes_settings;

#endif
