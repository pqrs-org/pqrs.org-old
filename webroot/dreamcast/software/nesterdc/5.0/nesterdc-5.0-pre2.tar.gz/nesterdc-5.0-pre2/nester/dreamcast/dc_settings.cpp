#include <kos.h>
#include "debug.h"
#include "dc_settings.h"
#include "dc_utils.h"
#include "dc_vmu.h"

static const char *save_filename = "settings";

uint8 
DC_settings::find_vmu ()
{
  int n;
  uint8 addr;
  
  timer_spin_sleep (100); /* need wait */
  
  n = 0;
  for (;;)
  {
    addr = maple_find_nth_device (n, MAPLE_FUNC_MEMCARD);
    ++n;
    if (!addr)
      return 0;
    else
    {
      if (ndc_vmu_get_dirent (NULL, addr, save_filename) >= 0)
	return addr;
    }
  }
  return 0;
}


void
DC_settings::load_from_vmu(uint8 addr)
{
  set_defaults ();
  
  if (!addr) return;
  
  dc_print ("Loading User Settings...");
  
  timer_spin_sleep (100); /* need wait */
  
  int32 firstblk = ndc_vmu_get_dirent (NULL, addr, save_filename);
  if (firstblk < 0) return;
  
  uint8 buf[1024];
  if (ndc_vmu_read_blocks (addr, firstblk, buf, 2) != 2)
  {
    dc_put_error ("error loading user settings");
    return;
  }
  
  set_cont_scheme (buf[640 + 0]);
  set_sound       (buf[640 + 2]);
  set_player2     (buf[640 + 3]);
  set_save        (buf[640 + 4]);
}


void
DC_settings::save_to_vmu(uint8 addr)
{
  if (!addr) return;
  
  dc_print ("Saving User Settings...");
  
  timer_spin_sleep (100); /* need wait */
  
  uint8 buf[1024];
  ndc_vmu_create_vmu_header (buf, save_filename, "NesterDC User Settings File", 
			     1024 - 128);
  memset(buf + 640, 0, 1024 - 640);
  buf[640 + 0] = cont_scheme;
  buf[640 + 2] = sound_on;
  buf[640 + 3] = player2;
  buf[640 + 4] = save;
  ndc_vmu_do_crc (buf, 1024);
  
  int32 firstblk = ndc_vmu_get_dirent (NULL, addr, save_filename);
  if (firstblk < 0) 
  {
    uint8 free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
    
    if (free_blocks < 2) 
    {
      dc_put_error ("You need 2 free blocks to Save user settings");
      return;
    }
    
    firstblk = ndc_vmu_allocate_file (addr, save_filename, 2);
    if (firstblk < 0)
    {
      dc_put_error ("error updating fat & directory");
      return;
    }
  }
  
  if (ndc_vmu_write_blocks (addr, firstblk, buf, 2) != 2)
  {
    dc_put_error ("error writing data");
    return;
  }
}


