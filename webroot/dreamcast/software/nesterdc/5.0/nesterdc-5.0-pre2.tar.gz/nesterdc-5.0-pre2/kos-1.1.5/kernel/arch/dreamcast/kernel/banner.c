char banner[] = 
"KallistiOS 1.1.5: Mon Dec 24 01:35:06 JST 2001\n"
"  tekezo@:/home/tekezo/work/tmp/nesterdc-5.0-pre2/kos-1.1.5\n"
;
