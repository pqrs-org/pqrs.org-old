/* KallistiOS 1.1.5
 *
 * video.c
 *
 * (c)2001 Anders Clerwall (scav)
 * Parts (c)2000-2001 Dan Potter
 *
 */
 
//-----------------------------------------------------------------------------
static char id[] = "KOS video.c,v 1.3 2001/12/18 03:09:03 tekezo Exp";
//-----------------------------------------------------------------------------

#include <dc/video.h>
#include <dc/sq.h>
#include <string.h>
#include <stdio.h>

#define VRAM_BASE_ADDR 0xa5000000

//-----------------------------------------------------------------------------
// This table is indexed w/ DM_*
vid_mode_t vid_builtin[DM_MODE_COUNT] = {
	// NULL mode..
	// DM_INVALID = 0
	{ 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, { 0, 0, 0, 0 } },

	// 320x240 NTSC 60Hz
	// DM_320x240_NTSC
	{
		320, 240,
#if 0
		VID_PIXELDOUBLE|VID_LINEDOUBLE,
#else
		VID_PIXELDOUBLE, 
#endif
		CT_ANY,
		0,
		262, 857,
		0xA4, 0x18,
		21, 82,
		141, 843,
		24, 263,
		0, 1,
		{ 0, 0, 0, 0 }
	},

	// 640x480 NTSC 60Hz IL
	// DM_640x480_NTSC_IL
	{
		640, 480,
		VID_INTERLACE,
		CT_ANY,
		0,
		0x20C, 0x359,
		0xA4, 0x12,
		0x15, 0x104,
		0x7E, 0x345,
		0x24, 0x204,
		0, 1,
		{ 0, 0, 0, 0 }
	},

	// 800x608 NTSC 60Hz (VGA) [BROKEN!]
	// DM_800x608_VGA
	{
		320, 240,
		VID_INTERLACE,
		1/*CT_ANY*/, // This will block the mode from being set.
		0,
		262, 857,
		164, 24,
		21, 82,
		141, 843,
		24, 264,
		0, 1,
		{ 0, 0, 0, 0 }
	},

	// 640x480 PAL 50Hz IL
	// DM_640x480_PAL_IL
	{
		640, 480,
		VID_INTERLACE|VID_PAL,
		CT_ANY,
		0,
		0x270, 0x35F,
		0xAE, 0x2D,
		0x15, 0x104,
		0x8D, 0x34B,
		0x2C, 0x26C,
		0, 1,
		{ 0, 0, 0, 0 }
	},

	// 256x256 PAL 50Hz IL (seems to output the same w/o VID_PAL, ie. in NTSC IL mode)
	// DM_256x256_PAL_IL
	{
		256, 256,
		VID_PIXELDOUBLE|VID_LINEDOUBLE|VID_INTERLACE|VID_PAL,
		CT_ANY,
		0,
		624, 863,
		226, 37,
		0x15, 0x104,
		0x8D, 0x34B,
		0x2C, 0x26C,
		0, 1,
		{ 0, 0, 0, 0 }
	},

	// END
	// DM_SENTINEL
	{ 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, { 0, 0, 0, 0 } }

	// DM_MODE_COUNT
};

//-----------------------------------------------------------------------------
volatile uint32	*regs = (uint32*)0xA05F8000;
vid_mode_t	currmode;
vid_mode_t	*vid_mode = 0;
uint16		*vram_s;
uint32	 	*vram_l;

//-----------------------------------------------------------------------------
/* Checks the attached cable type (to the A/V port). Returns
   one of the following:
     0 == VGA
     1 == (nothing)
     2 == RGB
     3 == Composite
   
   This is a direct port of Marcus' assembly function of the
   same name.
   
   [This is the old KOS function by Dan.]
*/
int vid_check_cable() {
	uint32 * porta = (uint32 *)0xff80002c;
	
	*porta = (*porta & 0xfff0ffff) | 0x000a0000;
	
	// Read port8 and port9
	return (*((uint16*)(porta + 1)) >> 8) & 3;
}

//-----------------------------------------------------------------------------
void vid_set_mode(int dm, int pm) {
	vid_mode_t mode;
	
	if (dm>0 && dm<DM_MODE_COUNT) {
                mode = vid_builtin[dm];
                
		// We set this here so actual mode is bit-depth independent..
		mode.pm = pm;
		
		// This is also to be generic
		mode.cable_type = vid_check_cable();
                
		// This will make a private copy of our "mode"
		vid_set_mode_ex(&mode);
	}
}

//-----------------------------------------------------------------------------
void vid_set_mode_ex(vid_mode_t *mode) {
	static uint8 bpp[4] = { 2, 2, 0, 4 };
	uint16 ct;
	uint32 data;
	
	
	// Verify cable type for video mode.
	ct = vid_check_cable();
	if (mode->cable_type != CT_ANY) {
		if (mode->cable_type != ct) {
			// Maybe this should have the ability to be forced (thru param)
			// so you can set a mode with VGA params with RGB cable type?
			//ct=mode->cable_type;
			dbglog(DBG_ERROR, "vid_set_mode: Mode not allowed for this cable type (%i!=%i)\n", mode->cable_type, ct);
			return;
		}
	}

	// Blank screen and reset display enable (looks nicer)
	regs[0x3A] |= 8;	// Blank
	regs[0x11] &= ~1;	// Display disable

	// Clear interlace flag if VGA (this maybe should be in here?)
	if (ct == CT_VGA) {
		mode->flags &= ~VID_INTERLACE;
	}

	dbglog(DBG_INFO, "vid_set_mode: %ix%i%s %s\n", mode->width, mode->height,
		(mode->flags & VID_INTERLACE) ? "IL" : "",
		(mode->flags & VID_PAL) ? "PAL" : "NTSC");
	
	vid_border_color(0, 0, 0);
	
	// Pixelformat
	data = (mode->pm << 2);
	if (ct == CT_VGA) {
		data |= 1 << 23;
                if (mode->height == 240)
                        mode->flags |= VID_LINEDOUBLE;
	}
	if (mode->flags & VID_LINEDOUBLE) {
		data |= 2;
	}
	regs[0x11] = data;

	// Linestride
	regs[0x13] = (mode->width * bpp[mode->pm]) / 8;

	// Display size
	data = ((mode->width * bpp[mode->pm]) / 4) - 1;
	if (ct == CT_VGA) {
		data |= (1 << 20) | ((mode->height - 1) << 10);
	} else {
#ifdef __WITH_TA__
		data |= (((mode->width * bpp[mode->pm] >> 2) + 1) << 20)
			| (((mode->height / 2) - 1) << 10);
#else
                data = (1 << 20) | (((480 / 2) - 1) << 10) | 
                  (((320/4) << 1) - 1);
#endif
	}
	regs[0x17] = data;

	// vblank irq
	if(ct == CT_VGA) {
		regs[0x33] = (mode->scanint1 << 16) | (mode->scanint2 << 1);
	} else {
		regs[0x33] = (mode->scanint1 << 16) | mode->scanint2;
	}
	
	// Interlace stuff
	data = 0x100;
	if (mode->flags & VID_INTERLACE) {
		data |= 0x10;
		if (mode->flags & VID_PAL) {
			data |= 0x80;
		} else {
			data |= 0x40;
		}
	}
	regs[0x34] = data;

	// Border window
	regs[0x35] = (mode->borderx1 << 16) | mode->borderx2;
	regs[0x37] = (mode->bordery1 << 16) | mode->bordery2;

	// Scanlines and clocks.
        if (ct == CT_VGA && mode->height == 240)
          regs[0x36] = ((mode->scanlines << 1) << 16) | mode->clocks;
        else
          regs[0x36] = (mode->scanlines << 16) | mode->clocks;
	
	// Horizontal pixel doubling
	if (mode->flags & VID_PIXELDOUBLE) {
		regs[0x3A] |= 0x100;
	} else {
		regs[0x3A] &= ~0x100;
	}
	
	// Bitmap window
	regs[0x3B] = mode->bitmapx;
	data = mode->bitmapy;
	if (mode->flags & VID_PAL) {
		data++;
	}
	data = (data << 16) | mode->bitmapy;
	regs[0x3C] = data;
	
	// Everything is ok
	memcpy(&currmode, mode, sizeof(vid_mode_t));
	vid_mode = &currmode;
	
	vid_set_start(0);

	// Re-enable the display
	regs[0x3A] &= ~8;
	regs[0x11] |= 1;
}

//-----------------------------------------------------------------------------
void vid_set_start(uint32 base) {
	static uint8 bpp[4] = { 2, 2, 0, 4 };

	// Set vram base of current framebuffer
	base &= 0x007FFFFF;
	regs[0x14] = base;
	
	// These are nice to have.
	vram_s = (uint16*)(VRAM_BASE_ADDR|base);
	vram_l = (uint32*)(VRAM_BASE_ADDR|base);

	// Set odd-field if interlaced.
	if (vid_mode->flags & VID_INTERLACE) {
		regs[0x15] = base + (currmode.width * bpp[currmode.pm]);
	}
}

//-----------------------------------------------------------------------------
void vid_flip(int fb) {
	uint16 oldfb;

	oldfb = vid_mode->fb_curr;
	if (fb < 0) {
		vid_mode->fb_curr++;
	} else {
		vid_mode->fb_curr = fb;
	}
	vid_mode->fb_curr &= (vid_mode->fb_count - 1);

	if (vid_mode->fb_curr == oldfb) {
		return;
	}

	vid_set_start(vid_mode->fb_base[vid_mode->fb_curr]);
}

//-----------------------------------------------------------------------------
void vid_border_color(int r, int g, int b) {
	regs[0x0040/4] = ((r & 0xFF) << 16) |
			 ((g & 0xFF) << 8) |
			 (b & 0xFF);
}

//-----------------------------------------------------------------------------
/* Clears the screen with a given color

	[This is the old KOS function by Dan.]
*/
void vid_clear(int r, int g, int b) {
	uint16 pixel16;
	uint32 pixel32;
	
	switch (vid_mode->pm) {
		case PM_RGB555:
			pixel16 = ((r >> 3) << 10)
				| ((g >> 3) << 5)
				| ((b >> 3) << 0);
			sq_set16(vram_s, pixel16, (vid_mode->width * vid_mode->height) * 2);
			break;
		case PM_RGB565:
			pixel16 = ((r >> 3) << 11)
				| ((g >> 2) << 5)
				| ((b >> 3) << 0);
			sq_set16(vram_s, pixel16, (vid_mode->width * vid_mode->height) * 2);
			break;
		case PM_RGB888:
			pixel32 = (r << 16) | (g << 8) | (b << 0);
			sq_set32(vram_l, pixel32, (vid_mode->width * vid_mode->height) * 4);
			break;
	}
}

//-----------------------------------------------------------------------------
/* Clears all of video memory as quickly as possible

	[This is the old KOS function by Dan.]
*/
void vid_empty() {
	sq_clr((uint32 *)VRAM_BASE_ADDR, 8*1024*1024);
}

//-----------------------------------------------------------------------------
/* Waits for a vertical refresh to start. This is the period between
   when the scan beam reaches the bottom of the picture, and when it
   starts again at the top.
   
   Thanks to HeroZero for this info.
   
   [This is the old KOS function by Dan.]
*/
void vid_waitvbl() {
	vuint32 *vbl = regs + 0x010c/4;
	while (!(*vbl & 0x01ff))
		;
	while (*vbl & 0x01ff)
		;
}

//-----------------------------------------------------------------------------
void vid_init(int disp_mode, int pixel_mode) {
	// Set mode and clear vram
	vid_set_mode(disp_mode, pixel_mode);
	vid_clear(0, 0, 0);
	vid_flip(0);
}

//-----------------------------------------------------------------------------
void vid_shutdown() {
	// Play nice with loaders, like KOS used to do.
	vid_init(DM_640x480, PM_RGB565);
}


