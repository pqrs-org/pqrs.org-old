/* KallistiOS 1.1.5

   stdlib.h
   (c)2001 Dan Potter

   stdlib.h,v 1.2 2001/11/15 18:53:20 tekezo Exp

*/

#ifndef __STDLIB_H
#define __STDLIB_H

#include <unistd.h>

/* To be compatible with newer ANSI C */
#include <malloc.h>

/* To make future porting efforts simpler */
#define __P(x) x

/* Absolute value functions */
int abs(int src);
long labs(long src);

/* qsort */
void qsort(void * base, size_t nmemb, size_t size,
	int (*cmp)(const void *, const void *));

#define _MAX_PATH 50

#endif	/* __STDLIB_H */

