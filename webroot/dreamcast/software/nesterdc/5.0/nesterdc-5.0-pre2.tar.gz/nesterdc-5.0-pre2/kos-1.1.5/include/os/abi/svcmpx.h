/* KallistiOS 1.1.5

   os/abi/svcmpx.h - adding/removing services
   (C) 2000-2001 Jordan DeLong

   svcmpx.h,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp

 */

#ifndef __OS_ABI_SVCMPX_H
#define __OS_ABI_SVCMPX_H

#include <os/process.h>

typedef struct {
	service_abi_t	hdr;	/* header info */

	void *	(*get_handler)(const char *svcname);	/* here for completeness: progs use lib_open */
	int	(*add_handler)(const char *name, void *svc_struct);
	int	(*remove_handler)(const char *name);
} abi_svcmpx_t;

#endif	/* __OS_ABI_SVCMPX_H */

