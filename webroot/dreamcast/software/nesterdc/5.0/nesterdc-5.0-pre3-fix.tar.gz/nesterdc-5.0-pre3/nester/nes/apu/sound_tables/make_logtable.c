#include <stdio.h>
#include <math.h>
#include "tbl_param.h"

static unsigned int logtbl[logtable_len];

int
main()
{
  int i;
  double a;
  
  memset(logtbl, 0, sizeof(logtbl));
  
  for (i = 0; i < logtable_len; i++)
  {
    a = (1 << LOG_LIN_BITS) / pow(2, i / (double)logtable_len);
    logtbl[i] = (unsigned int)a;
  }
  
  for (i = 0; i < logtable_len; ++i)
  {
    printf("%d,\n", logtbl[i]);
  }
}

