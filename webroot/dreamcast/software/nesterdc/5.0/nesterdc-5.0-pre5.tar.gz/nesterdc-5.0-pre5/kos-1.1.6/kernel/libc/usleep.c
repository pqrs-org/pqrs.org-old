/* KallistiOS 1.1.6

   usleep.c
   (c)2001 Dan Potter

   usleep.c,v 1.1 2002/01/14 11:01:57 tekezo Exp
*/

#include <arch/timer.h>

/* usleep() */
void usleep(unsigned long usec) {
	timer_spin_sleep (usec / 1000);
}

