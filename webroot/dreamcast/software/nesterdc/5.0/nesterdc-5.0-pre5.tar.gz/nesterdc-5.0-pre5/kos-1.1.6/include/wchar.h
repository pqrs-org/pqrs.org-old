/* KallistiOS 1.1.6

   wchar.h
   (c)2001 Dan Potter

   wchar.h,v 1.1 2002/01/14 11:01:55 tekezo Exp
*/

#ifndef __WCHAR_H
#define __WCHAR_H

#define __need_wchar_t
#include <stddef.h>

#endif   /* __WCHAR_H */
