/* KallistiOS 1.1.6

   getenv.c
   (c)2001 Dan Potter

   getenv.c,v 1.1 2002/01/14 11:01:56 tekezo Exp
*/

/* getenv() */
char *getenv(const char *name) {
	return (char *)0;
}

