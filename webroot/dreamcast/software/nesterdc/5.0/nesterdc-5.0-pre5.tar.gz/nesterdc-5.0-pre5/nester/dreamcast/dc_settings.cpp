#include <kos.h>
#include "debug.h"
#include "dc_settings.h"
#include "dc_utils.h"
#include "dc_vmu.h"

static const char *save_filename = "ndc_r5p4";

uint8 
DC_settings::find_vmu ()
{
  int n;
  uint8 addr;
  
  timer_spin_sleep (100); /* need wait */
  
  n = 0;
  for (;;)
  {
    addr = dc_maple_find_nth_device (n, MAPLE_FUNC_MEMCARD);
    ++n;
    if (!addr)
      return 0;
    else
    {
      if (ndc_vmu_get_dirent (NULL, addr, save_filename) >= 0)
	return addr;
    }
  }
  return 0;
}


void
DC_settings::load_from_vmu(uint8 addr)
{
  if (!addr) return;
  
  timer_spin_sleep (100); /* need wait */
  
  int32 firstblk = ndc_vmu_get_dirent (NULL, addr, save_filename);
  if (firstblk < 0) return;
  
  uint8 buf[1024];
  if (ndc_vmu_read_blocks (addr, firstblk, buf, 2) != 2)
  {
    dc_put_error ("error loading user settings");
    return;
  }
  
  set_cont_scheme              (buf[640 + 0]);
  set_sound                    (buf[640 + 1]);
  set_save                     (buf[640 + 2]);
  set_exsound                  (buf[640 + 3]);
  set_fullscreen               (buf[640 + 4]);
  set_rom_menu_wait_vertical   (buf[640 + 5]);
  set_rom_menu_wait_horizontal (buf[640 + 6]);
}


void
DC_settings::save_to_vmu(uint8 addr)
{
  if (!addr) return;
  
  dc_print ("Saving User Settings...");
  
  timer_spin_sleep (100); /* need wait */
  
  uint8 buf[1024];
  ndc_vmu_create_vmu_header (buf, save_filename, "NesterDC Settings comp5.0pre4", 
			     1024 - 128);
  memset(buf + 640, 0, 1024 - 640);
  buf[640 + 0] = cont_scheme;
  buf[640 + 1] = sound_on;
  buf[640 + 2] = save;
  buf[640 + 3] = exsound;
  buf[640 + 4] = fullscreen;
  buf[640 + 5] = rom_menu_wait_vertical;
  buf[640 + 6] = rom_menu_wait_horizontal;
  ndc_vmu_do_crc (buf, 1024);
  
  int32 firstblk = ndc_vmu_get_dirent (NULL, addr, save_filename);
  if (firstblk < 0) 
  {
    uint8 free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
    
    if (free_blocks < 2) 
    {
      dc_put_error ("You need 2 free blocks to Save user settings");
      return;
    }
    
    firstblk = ndc_vmu_allocate_file (addr, save_filename, 2);
    if (firstblk < 0)
    {
      dc_put_error ("error updating fat & directory");
      return;
    }
  }
  
  if (ndc_vmu_write_blocks (addr, firstblk, buf, 2) != 2)
  {
    dc_put_error ("error writing data");
    return;
  }
}


