#include "dc_menu.h"
#include "dc_utils.h"
#include "dc_vmu.h"


/* ============================================================ */
static int init_rom_menu ();
static int init_vmu_menu ();
static int init_vmu_select_menu ();

int
init_menus ()
{
  init_rom_menu ();
  init_vmu_menu ();
  init_vmu_select_menu ();
  
  return 1;
}


/* ============================================================ */
#define MAX_ROM_FILES 4096
#define ROM_NAME_LEN 64
#define ROM_PATH_LEN 128
struct {
  char name[ROM_NAME_LEN];
  char path[ROM_PATH_LEN];
} rom_files[MAX_ROM_FILES];
static const int draw_rom_files_line_default = 20;

static uint16 rom_menu_image[320 * 240];
static uint16 rom_menu_no_games_image[320 * 240];

static int
init_rom_menu ()
{
  load_bmp (rom_menu_image, "/cd/pics/menu_selection.bmp");
  load_bmp (rom_menu_no_games_image, "/cd/pics/nogamecd.bmp");
  return 1;
}


static void
draw_rom_files (int base_pos, int cur_pos, int num_roms, int draw_lines) 
{
  int i;
  int y_pos = 10;
  int x_pos = 75;
  int line;
  int ndraw;
  
  if (num_roms < draw_lines)
    ndraw = num_roms;
  else
    ndraw = draw_lines;
  
  display_rawimage (rom_menu_image);
  
  line = base_pos;
  for (i = 0; i < ndraw; ++i)
  {
    if (line >= num_roms)
      line = 0;
    
    uint16 fg_color = cur_pos == line ? _yellow : _white;
    draw_string (x_pos, y_pos, fg_color, _none, rom_files[line].name);
    ++line;
    y_pos += 10;
  }
  
  timer_sleep (50);
}


static int
read_rom_index (const char *path)
{
  int i;
  int num_roms;
  file_t d; 
  dirent_t *de;
  cont_cond_t cont;
  
  memset(rom_files, 0, sizeof(rom_files));
  
  iso_ioctl (0, NULL, 0);
  d = fs_open(path, O_RDONLY | O_DIR);
  while (!d) 
  {
    display_rawimage (rom_menu_no_games_image);
    dc_vid_flip_fill_renderer (draw_type_fullscreen);
    
    for (;;)
    {
      if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
        continue;
      
      if (!(cont.buttons & CONT_A))
        break;
      if (cont.rtrig && cont.ltrig)
        return 0;
    }
    iso_ioctl (0, NULL, 0);
    d = fs_open (path, O_RDONLY | O_DIR);
  }
  
  num_roms = 0;
  for (i = 0; i < MAX_ROM_FILES; ++i)
  {
    de = fs_readdir (d);
    if (de)
    {
      char *name;
      
      name = rom_files[i].name;
      strncpy (name, de->name, ROM_NAME_LEN);
      name[ROM_NAME_LEN - 1] = '\0';
      
      sprintf (rom_files[i].path, "%s/%s", path, name);
      
      ++num_roms;
    }
    else
    {
      *(rom_files[i].name) = '\0';
      *(rom_files[i].path) = '\0';
      break;
    }
  }
  fs_close (d);
  
  return num_roms;
}

const char *
do_rom_menu(const char *path, uint8 vertical_wait, uint8 horizontal_wait) 
{
  int i;
  int base_pos = 0;
  int cur_pos = 0;
  int cur_row = 0;
  int num_roms;
  int draw_lines = draw_rom_files_line_default;
  cont_cond_t cont;
  
  display_rawimage (rom_menu_image);
  draw_string (75, 75, _white, _none, "Now loading");
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  num_roms = read_rom_index (path);
  if (!num_roms)
  {
    dc_put_error ("No romfiles");
    return NULL;
  }
  
  draw_lines = draw_rom_files_line_default;
  if (num_roms < draw_lines)
    draw_lines = num_roms;
  
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (!(cont.buttons & CONT_DPAD_UP))
    {
      if (cur_row > 0)
	--cur_row;
      else
      {
	if (base_pos == 0)
	  base_pos = num_roms - 1;
	else
	  --base_pos;
      }
      if (cur_pos == 0) 
	cur_pos = num_roms - 1;
      else
	--cur_pos;
      
      if (cont.buttons & CONT_X)
        timer_spin_sleep (vertical_wait);
    }
    
    if (!(cont.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_row < draw_lines - 1)
	++cur_row;
      else
      {
	if (base_pos >= num_roms - 1)
	  base_pos = 0;
	else
	  ++base_pos;
      }
      if (cur_pos >= num_roms - 1)
	cur_pos = 0;
      else
	++cur_pos;
      if (cont.buttons & CONT_X)
        timer_spin_sleep (vertical_wait);
    }
    
    if (!(cont.buttons & CONT_DPAD_LEFT)) 
    {
      for (i = 0; i < draw_lines; ++i)
      {
	if (base_pos == 0)
	  base_pos = num_roms - 1;
	else
	  --base_pos;
      	if (cur_pos == 0) 
	  cur_pos = num_roms - 1;
	else
	  --cur_pos;
      }
      if (cont.buttons & CONT_X)
        timer_spin_sleep (horizontal_wait);
    } 
    
    if (!(cont.buttons & CONT_DPAD_RIGHT)) 
    {
      for (i = 0; i < draw_lines; ++i)
      {
	if (base_pos == (num_roms - 1))
	  base_pos = 0;
	else
	  ++base_pos;
	if (cur_pos == (num_roms - 1))
	  cur_pos = 0;
	else
	  ++cur_pos;
      }
      if (cont.buttons & CONT_X)
        timer_spin_sleep (horizontal_wait);
    }
    
    if (!(cont.buttons & CONT_START)) 
      return rom_files[cur_pos].path;
    
    if (cont.rtrig  & cont.ltrig) 
      return NULL;
    
    draw_rom_files (base_pos, cur_pos, num_roms, draw_lines);
    dc_vid_flip (draw_type_fullscreen);
  }
  
  dc_vid_clear ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
}


/* ============================================================ */
typedef struct {
  char desc_long[64];
  char filename[32];
  uint8 filesize;
  uint8 filetype;
  boolean selected;
} vmu_item;


typedef struct {
  uint8 addr;
  int free_blocks;
  int use_blocks;
  int file_num;
} vmu_info;


#define MAX_VMU_FILES 256
static vmu_item vmu_files[MAX_VMU_FILES];

const int draw_vmu_files_line = 15;

static uint16 vmu_menu_image[320 * 240];

static int 
init_vmu_menu ()
{
  load_bmp (vmu_menu_image, "/cd/pics/vmu_menu.bmp");
  return 1;
}


static void
draw_vmu_menu_help ()
{
  display_rawimage (vmu_menu_image);
  draw_string (80, 30, _white, _none, "help");
  draw_string (60, 60, _white, _none, "L: select file");
  draw_string (60, 70, _white, _none, "R+Y: remove selected files");
  draw_string (60, 80, _white, _none, "L+R: exit VMU menu");
  draw_string (80, 200, _white, _none, "start: exit help");
}


static void
do_vmu_menu_help ()
{
  cont_cond_t cont;
  
  draw_vmu_menu_help ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  wait_until_release_buttons (dc_controller_addr[0], CONT_START);
  
  for (;;)
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      break;
    
    if (!(cont.buttons & CONT_START))
      break;
  }
}


static void
draw_vmu_files (int base_pos, int cur_pos, vmu_info *vi)
{
  int nline;
  char str[128];
  int i;
  int x_pos = 10;
  int y_pos;
  uint16 fg_color, bg_color;
  
  display_rawimage (vmu_menu_image);
  
  if (MAX_VMU_FILES - base_pos > draw_vmu_files_line)
    nline = draw_vmu_files_line;
  else
    nline = MAX_VMU_FILES - base_pos;
  
  draw_string (10, 30, _white, _none, "press L+R to exit/press start to help");
  sprintf (str, "%d free/%d ndc use", vi->free_blocks, vi->use_blocks);
  draw_string (80, 40, _white, _none, str);
  
  y_pos = 60;
  for (i = base_pos; i < base_pos + nline; ++i)
  {
    if (vmu_files[i].filetype != 0x00)
    {
      fg_color = cur_pos == i ? _yellow : _white;
      bg_color = vmu_files[i].selected ? _blue : _none;
      
      sprintf(str, "%s(%d)", vmu_files[i].desc_long, vmu_files[i].filesize);
      draw_string (x_pos, y_pos, fg_color, bg_color, str);
      y_pos += 10;
    }
  }
  
  timer_sleep (50);
}


extern const char *progname;


static int
read_vmu_items (vmu_info *vi, uint8 addr)
{
  int num_entries;
  dirent_vmu entries[MAX_VMU_FILES];
  int num_vmu_files;
  int i;
  
  num_entries = MAX_VMU_FILES;
  if (ndc_vmu_getall_dirent (entries, &num_entries, addr) < 0)
    return -1;
  
  memset (vmu_files, 0, sizeof(vmu_files));
  num_vmu_files = 0;
  for (i = 0; i < num_entries; ++i)
  {
    if (entries[i].filetype != 0x00)
    {
      char *p;
      uint8 buf[512];
      file_hdr_vmu *hdr = (file_hdr_vmu *)buf;
      
      if (ndc_vmu_read (addr, entries[i].firstblk, buf) < 0)
        continue;
      
      if (strcmp(hdr->app_id, progname))
        continue;
      
      p = vmu_files[num_vmu_files].desc_long;
      strncpy (p, hdr->desc_long, 32);
      p[32] = '\0';
      
      p = vmu_files[num_vmu_files].filename;
      strncpy (p, entries[i].filename, 12);
      p[12] = '\0';
      
      vmu_files[num_vmu_files].filesize = entries[i].filesize;
      vmu_files[num_vmu_files].filetype = entries[i].filetype;
      vmu_files[num_vmu_files].selected = 0;
      
      ++num_vmu_files;
    }
  }
  
  vi->free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
  vi->use_blocks = 0;
  vi->file_num = num_vmu_files;
  for (i = 0; i < num_vmu_files; ++i)
    vi->use_blocks += vmu_files[i].filesize;
  
  return 1;
}


void
do_vmu_menu (uint8 addr)
{
  vmu_info vi;
  int base_pos = 0;
  int cur_pos = 0;
  cont_cond_t cont;
  boolean pulling_ltrig = 0;
  boolean select_mode = 0;
  
  display_rawimage (vmu_menu_image);
  draw_string (75, 75, _white, _none, "reading VMU");
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  if (read_vmu_items (&vi, addr) < 0)
    return;
  
  for (;;)
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (!(cont.buttons & CONT_DPAD_UP))
    {
      if (cur_pos > 0)
      {
        if (cur_pos == base_pos)
          --base_pos;
        --cur_pos;
      }
      if (pulling_ltrig)
        vmu_files[cur_pos].selected = select_mode;
    }
    
    if (!(cont.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_pos < vi.file_num - 1)
      {
        if (cur_pos == base_pos + draw_vmu_files_line - 1)
          ++base_pos;
        ++cur_pos;
      }
      if (pulling_ltrig)
        vmu_files[cur_pos].selected = select_mode;
    }
    
    if (!(cont.buttons & CONT_Y) && cont.rtrig)
    {
      int i;
      for (i = 0; i < vi.file_num; ++i)
      {
        if (vmu_files[i].selected)
        {
          char str[128];
          sprintf(str, "remove %s", vmu_files[i].desc_long);
          dc_print (str);
          ndc_vmu_remove_file (addr, vmu_files[i].filename);
        }
      }
      break;
    }
    
    if (!(cont.buttons & CONT_START))
    {
      do_vmu_menu_help ();
      
      draw_vmu_files (base_pos, cur_pos, &vi);
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      
      wait_until_release_buttons (dc_controller_addr[0], CONT_START);
    }
    
    if (!(cont.ltrig))
      pulling_ltrig = 0;
    else
    {
      if (cont.rtrig)
        break;
      else
      {
        if (!pulling_ltrig)
        {
          pulling_ltrig = 1;
          vmu_files[cur_pos].selected = !(vmu_files[cur_pos].selected);
          select_mode = vmu_files[cur_pos].selected;
        }
      }
    }
    draw_vmu_files (base_pos, cur_pos, &vi);
    dc_vid_flip (draw_type_fullscreen);
  }
  
  dc_vid_clear ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
}


/* ============================================================ */
struct {
  char name[32];
  uint8 addr;
  uint8 free_blocks;
} vmu_slots[32];

static uint16 vmu_select_menu_image[320 * 240];

static int
init_vmu_select_menu ()
{
  load_bmp (vmu_select_menu_image, "/cd/pics/vmu_menu.bmp");
  return 1;
}


static void
draw_vmu_select_slots (int cur_pos, int vmu_num)
{
  int i;
  int y_pos = 40;
  int x_pos = 75;
  char str[128];
  
  display_rawimage (vmu_select_menu_image);
  
  draw_string (100, 10, _white, _none, "VMU select");
  draw_string (100, 20, _white, _none, "press A to select");
  for (i = 0; i < vmu_num; ++i)
  {
    uint16 fg_color = cur_pos == i ? _yellow : _white;
    sprintf (str, "%s (%d free blocks)", vmu_slots[i].name, vmu_slots[i].free_blocks);
    draw_string (x_pos, y_pos, fg_color, _none, str);
    y_pos += 10;
  }
}


uint8 
do_vmu_select_menu ()
{
  int port, unit;
  int vmu_num;
  int cur_pos = 0;
  
  dc_vid_clear ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  vmu_num = 0;
  for (port=0; port<4; port++)
  {
    for (unit=0; unit<6; unit++) 
    {
      if (maple_device_func(port, unit) & MAPLE_FUNC_MEMCARD)
      {
        uint8 addr = maple_create_addr(port, unit);
        
        sprintf(vmu_slots[vmu_num].name, "p%d/u%d", port, unit);
        vmu_slots[vmu_num].addr = addr; 
        vmu_slots[vmu_num].free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
        ++vmu_num;
      }
    }
  }
  
  if (!vmu_num)
    return 0;
  
  for (;;)
  {
    cont_cond_t cont;
    int update = 0;
    
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (!(cont.buttons & CONT_DPAD_UP))
    {
      if (cur_pos > 0)
	--cur_pos;
      update = 1;
    }
    else if (!(cont.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_pos < vmu_num - 1)
	++cur_pos;
      update = 1;
    }
    else if (!(cont.buttons & CONT_A))
      break;
    
    if (update)
    {
      draw_vmu_select_slots (cur_pos, vmu_num);
      dc_vid_flip_fill_renderer (draw_type_fullscreen);
      wait_until_release_buttons (dc_controller_addr[0], 
                                  CONT_DPAD_UP | CONT_DPAD_DOWN);
    }
  }
  
  dc_vid_clear ();
  dc_vid_flip_fill_renderer (draw_type_fullscreen);
  
  return vmu_slots[cur_pos].addr;
}


/* ============================================================ */
void
draw_adjust_screen_rect_menu ()
{
  uint16 *screen;
  int x, y;
  
  screen = dc_get_screen ();
  for (y = 0; y < 8; ++y)
    for (x = 0; x < 320; ++x)
      *screen++ = _black;
  
  for (y = 8; y < 16; ++y)
    for (x = 0; x < 320; ++x)
      *screen++ = _red;
  
  for (y = 16; y < 224; ++y)
  {
    for (x = 0; x < 8; ++x)
      *screen++ = _red;
    
    for (x = 8; x < 312; ++x)
      *screen++ = _black;
    
    for (x = 312; x < 320; ++x)
      *screen++ = _red;
  }
  
  for (y = 224; y < 232; ++y)
    for (x = 0; x < 320; ++x)
      *screen++ = _red;
  
  for (y = 232; y < 240; ++y)
    for (x = 0; x < 320; ++x)
      *screen++ = _black;
  
  draw_string (80, 50, _white, _black, "Screen adjust menu");
  
  draw_string (100, 60, _white, _black, "L + R: exit");
  
  draw_string (80,  80, _white, _black, "up/down/left/right:");
  draw_string (100, 90, _white, _black, "adjust position");
  
  draw_string (80,  110, _white, _black, "A + up/down/left/right:");
  draw_string (100, 120, _white, _black, "adjust size");
  
  draw_string (80, 140, _white, _black, "R + Y: reset setting");
  draw_string (80, 150, _white, _black, "R + B: set default");
  
  draw_string (80, 170, _white, _black, "X: speedup");
}


void
do_adjust_screen_rect_menu ()
{
  cont_cond_t cont;
  screen_rect new_rect;
  screen_rect orig_rect;
  
  draw_adjust_screen_rect_menu ();
  
  dc_get_screen_rect (&new_rect);
  dc_get_screen_rect (&orig_rect);
  for (;;)
  {
    int adjust_size;
    
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (cont.rtrig & cont.ltrig) 
      break;
    
    if (!(cont.buttons & CONT_X))
      adjust_size = 2;
    else
      adjust_size = 1;
    
    if (!(cont.buttons & CONT_DPAD_UP))
    {
      if (cont.buttons & CONT_A)
      {
        new_rect.y1 -= adjust_size;
        new_rect.y2 -= adjust_size;
      }
      else
      {
        new_rect.y1 -= adjust_size;
        new_rect.y2 += adjust_size;
      }
      dc_set_screen_rect (&new_rect);
    }
    
    if (!(cont.buttons & CONT_DPAD_DOWN))
    {
      if (cont.buttons & CONT_A)
      {
        new_rect.y1 += adjust_size;
        new_rect.y2 += adjust_size;
      }
      else
      {
        new_rect.y1 += adjust_size;
        new_rect.y2 -= adjust_size;
      }
      dc_set_screen_rect (&new_rect);
    }
    
    if (!(cont.buttons & CONT_DPAD_LEFT))
    {
      if (cont.buttons & CONT_A)
      {
        new_rect.x1 -= adjust_size;
        new_rect.x2 -= adjust_size;
      }
      else
      {
        new_rect.x1 -= adjust_size;
        new_rect.x2 += adjust_size;
      }
      dc_set_screen_rect (&new_rect);
    }
    
    if (!(cont.buttons & CONT_DPAD_RIGHT))
    {
      if (cont.buttons & CONT_A)
      {
        new_rect.x1 += adjust_size;
        new_rect.x2 += adjust_size;
      }
      else
      {
        new_rect.x1 += adjust_size;
        new_rect.x2 -= adjust_size;
      }
      dc_set_screen_rect (&new_rect);
    }
    
    if (!(cont.buttons & CONT_Y) && cont.rtrig)
    {
      new_rect = orig_rect;
      dc_set_screen_rect (&new_rect);
    }
    
    if (!(cont.buttons & CONT_B) && cont.rtrig)
    {
      dc_set_default_screen_rect ();
      dc_get_screen_rect (&new_rect);
    }
    
    dc_vid_flip (draw_type_fullscreen);
  }  
}


