#ifndef __NESTER_H
#define __NESTER_H

#ifdef __DREAMCAST__
#include "dc_utils.h"
#endif

#endif
