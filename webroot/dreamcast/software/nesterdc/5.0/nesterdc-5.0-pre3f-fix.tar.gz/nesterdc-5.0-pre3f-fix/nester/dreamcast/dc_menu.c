#include "dc_menu.h"
#include "dc_utils.h"
#include "dc_vmu.h"

/* ============================================================ */
static int init_rom_menu ();
static int init_vmu_menu ();
static int init_vmu_select_menu ();

int
init_menus ()
{
  init_rom_menu ();
  init_vmu_menu ();
  init_vmu_select_menu ();
  
  return 1;
}


/* ============================================================ */
#define MAX_ROM_FILES 2048
struct {
  char name[256];
  char path[256];
  int filesize;
} rom_files[MAX_ROM_FILES];
static const int draw_rom_files_line_default = 20;

static uint16 rom_menu_image[320 * 240];
static uint16 rom_menu_no_games_image[320 * 240];

static int
init_rom_menu ()
{
  load_bmp (rom_menu_image, "/cd/pics/menu_selection.bmp");
  load_bmp (rom_menu_no_games_image, "/cd/pics/nogamecd.bmp");
  return 1;
}


static void
draw_rom_files (int base_pos, int cur_pos, int num_roms, int draw_lines) 
{
  int i;
  int y_pos = 10;
  int x_pos = 75;
  int line;
  int ndraw;
  
  if (num_roms < draw_lines)
    ndraw = num_roms;
  else
    ndraw = draw_lines;
  
  display_rawimage (rom_menu_image);
  
  line = base_pos;
  for (i = 0; i < ndraw; ++i)
  {
    if (line >= num_roms)
      line = 0;
    
    uint16 fg_color = cur_pos == line ? _yellow : _white;
    draw_string (x_pos, y_pos, fg_color, _none, rom_files[line].name);
    ++line;
    y_pos += 10;
  }
  
  timer_sleep (50);
}


static int
read_rom_index (const char *path)
{
  int i;
  int num_roms;
  file_t d; 
  dirent_t *de;
  cont_cond_t cont;
  
  memset(rom_files, 0, sizeof(rom_files));
  
  iso_ioctl (0, NULL, 0);
  d = fs_open(path, O_RDONLY | O_DIR);
  while (!d) 
  {
    display_rawimage (rom_menu_no_games_image);
    dc_vid_flip ();
    
    for (;;)
    {
      if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
        continue;
      
      if (!(cont.buttons & CONT_A))
        break;
      if (cont.rtrig && cont.ltrig)
        return 0;
    }
    iso_ioctl (0, NULL, 0);
    d = fs_open (path, O_RDONLY | O_DIR);
  }
  
  num_roms = 0;
  for (i = 0; i < MAX_ROM_FILES; ++i)
  {
    de = fs_readdir (d);
    if (de)
    {
      strcpy (rom_files[i].name, de->name);
      sprintf (rom_files[i].path, "%s/%s", path, de->name);
      rom_files[i].filesize = de->size;
      ++num_roms;
    }
    else
    {
      *(rom_files[i].name) = '\0';
      *(rom_files[i].path) = '\0';
      rom_files[i].filesize = 0;
      break;
    }
  }
  fs_close (d);
  
  return num_roms;
}

const char *
do_rom_menu(const char *path) 
{
  int i;
  int base_pos = 0;
  int cur_pos = 0;
  int cur_row = 0;
  int num_roms;
  int draw_lines = draw_rom_files_line_default;
  cont_cond_t cont;
  
  display_rawimage (rom_menu_image);
  draw_string (75, 75, _white, _none, "Now loading");
  dc_vid_flip ();
  
  num_roms = read_rom_index (path);
  if (!num_roms)
  {
    dc_put_error ("No romfiles");
    return NULL;
  }
  
  draw_lines = draw_rom_files_line_default;
  if (num_roms < draw_lines)
    draw_lines = num_roms;
  
  draw_rom_files (base_pos, cur_pos, num_roms, draw_lines);
  dc_vid_flip ();
  for (;;) 
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (!(cont.buttons & CONT_DPAD_UP))
    {
      if (cur_row > 0)
	--cur_row;
      else
      {
	if (base_pos == 0)
	  base_pos = num_roms - 1;
	else
	  --base_pos;
      }
      if (cur_pos == 0) 
	cur_pos = num_roms - 1;
      else
	--cur_pos;
    }
    
    if (!(cont.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_row < draw_lines - 1)
	++cur_row;
      else
      {
	if (base_pos >= num_roms - 1)
	  base_pos = 0;
	else
	  ++base_pos;
      }
      if (cur_pos >= num_roms - 1)
	cur_pos = 0;
      else
	++cur_pos;
    }
    
    if (!(cont.buttons & CONT_DPAD_LEFT)) 
    {
      for (i = 0; i < draw_lines; ++i)
      {
	if (base_pos == 0)
	  base_pos = num_roms - 1;
	else
	  --base_pos;
      	if (cur_pos == 0) 
	  cur_pos = num_roms - 1;
	else
	  --cur_pos;
      }
    } 
    
    if (!(cont.buttons & CONT_DPAD_RIGHT)) 
    {
      for (i = 0; i < draw_lines; ++i)
      {
	if (base_pos == (num_roms - 1))
	  base_pos = 0;
	else
	  ++base_pos;
	if (cur_pos == (num_roms - 1))
	  cur_pos = 0;
	else
	  ++cur_pos;
      }
    } 
    
    if (!(cont.buttons & CONT_START)) 
      return rom_files[cur_pos].path;
    
    if (cont.rtrig  & cont.ltrig) 
      return NULL;
    
    draw_rom_files (base_pos, cur_pos, num_roms, draw_lines);
    dc_vid_flip ();
  }
  dc_vid_clear ();
  dc_vid_flip ();
}


/* ============================================================ */
typedef struct {
  char desc_long[64];
  char filename[32];
  uint8 filesize;
  uint8 filetype;
  boolean selected;
} vmu_item;


typedef struct {
  uint8 addr;
  int free_blocks;
  int use_blocks;
  int file_num;
} vmu_info;


#define MAX_VMU_FILES 256
static vmu_item vmu_files[MAX_VMU_FILES];

const int draw_vmu_files_line = 15;

static int 
init_vmu_menu ()
{
  return 1;
}


static void
draw_vmu_menu_help ()
{
  dc_vid_clear ();
  draw_string (80, 10, _white, _black, "VMU menu help");
  draw_string (60, 40, _white, _black, "L: select file");
  draw_string (60, 50, _white, _black, "R+Y: remove selected files");
  draw_string (60, 60, _white, _black, "L+R: exit VMU menu");
  draw_string (80, 200, _white, _black, "start: exit help");
}


static void
draw_vmu_files (int base_pos, int cur_pos, vmu_info *vi)
{
  int nline;
  char str[128];
  int i;
  int x_pos = 10;
  int y_pos = 50;
  uint16 fg_color, bg_color;
  
  dc_vid_clear ();
  
  if (MAX_VMU_FILES - base_pos > draw_vmu_files_line)
    nline = draw_vmu_files_line;
  else
    nline = MAX_VMU_FILES - base_pos;
  
  draw_string (80, 10, _white, _black, "VMU menu");
  draw_string (10, 20, _white, _black, "press L+R to exit/press start to help");
  sprintf (str, "%d free/%d ndc use", vi->free_blocks, vi->use_blocks);
  draw_string (80, 30, _white, 0, str);
  for (i = base_pos; i < base_pos + nline; ++i)
  {
    if (vmu_files[i].filetype != 0x00)
    {
      fg_color = cur_pos == i ? _yellow : _white;
      bg_color = vmu_files[i].selected ? _blue : _black;
      
      sprintf(str, "%s(%d)", vmu_files[i].desc_long, vmu_files[i].filesize);
      draw_string (x_pos, y_pos, fg_color, bg_color, str);
      y_pos += 10;
    }
  }
  
  timer_sleep (50);
}


extern const char *progname;


static int
read_vmu_items (vmu_info *vi, uint8 addr)
{
  int num_entries;
  dirent_vmu entries[MAX_VMU_FILES];
  int num_vmu_files;
  int i;
  
  num_entries = MAX_VMU_FILES;
  if (ndc_vmu_getall_dirent (entries, &num_entries, addr) < 0)
    return -1;
  
  memset (vmu_files, 0, sizeof(vmu_files));
  num_vmu_files = 0;
  for (i = 0; i < num_entries; ++i)
  {
    if (entries[i].filetype != 0x00)
    {
      char *p;
      uint8 buf[512];
      file_hdr_vmu *hdr = (file_hdr_vmu *)buf;
      
      if (ndc_vmu_read (addr, entries[i].firstblk, buf) < 0)
        continue;
      
      if (strcmp(hdr->app_id, progname))
        continue;
      
      p = vmu_files[num_vmu_files].desc_long;
      strncpy (p, hdr->desc_long, 32);
      p[32] = '\0';
      
      p = vmu_files[num_vmu_files].filename;
      strncpy (p, entries[i].filename, 12);
      p[12] = '\0';
      
      vmu_files[num_vmu_files].filesize = entries[i].filesize;
      vmu_files[num_vmu_files].filetype = entries[i].filetype;
      vmu_files[num_vmu_files].selected = 0;
      
      ++num_vmu_files;
    }
  }
  
  vi->free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
  vi->use_blocks = 0;
  vi->file_num = num_vmu_files;
  for (i = 0; i < num_vmu_files; ++i)
    vi->use_blocks += vmu_files[i].filesize;
  
  return 1;
}


void
do_vmu_menu (uint8 addr)
{
  vmu_info vi;
  int base_pos = 0;
  int cur_pos = 0;
  cont_cond_t cont;
  boolean pulling_ltrig = 0;
  boolean select_mode = 0;
  
  dc_print ("reading VMU");
  
  if (read_vmu_items (&vi, addr) < 0)
    return;
  
  /* draw lines */
  draw_vmu_files (base_pos, cur_pos, &vi);
  dc_vid_flip ();
  for (;;)
  {
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (!(cont.buttons & CONT_DPAD_UP))
    {
      if (cur_pos > 0)
      {
        if (cur_pos == base_pos)
          --base_pos;
        --cur_pos;
      }
      if (pulling_ltrig)
        vmu_files[cur_pos].selected = select_mode;
    }
    
    if (!(cont.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_pos < vi.file_num - 1)
      {
        if (cur_pos == base_pos + draw_vmu_files_line - 1)
          ++base_pos;
        ++cur_pos;
      }
      if (pulling_ltrig)
        vmu_files[cur_pos].selected = select_mode;
    }
    
    if (!(cont.buttons & CONT_Y) && cont.rtrig)
    {
      int i;
      for (i = 0; i < vi.file_num; ++i)
      {
        if (vmu_files[i].selected)
        {
          char str[128];
          sprintf(str, "remove %s", vmu_files[i].desc_long);
          dc_print (str);
          ndc_vmu_remove_file (addr, vmu_files[i].filename);
        }
      }
      break;
    }
    
    if (!(cont.buttons & CONT_START))
    {
      draw_vmu_menu_help ();
      dc_vid_flip ();
      
      wait_until_release_buttons (dc_controller_addr[0], CONT_START);
      
      for (;;)
      {
        if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
          continue;
        
        if (!(cont.buttons & CONT_START))
        {
          draw_vmu_files (base_pos, cur_pos, &vi);
          dc_vid_flip ();
          
          wait_until_release_buttons (dc_controller_addr[0], CONT_START);
          break;
        }
      }
    }
    
    if (!(cont.ltrig))
      pulling_ltrig = 0;
    else
    {
      if (cont.rtrig)
        break;
      else
      {
        if (!pulling_ltrig)
        {
          pulling_ltrig = 1;
          vmu_files[cur_pos].selected = !(vmu_files[cur_pos].selected);
          select_mode = vmu_files[cur_pos].selected;
        }
      }
    }
    draw_vmu_files (base_pos, cur_pos, &vi);
    dc_vid_flip ();
  }
    
  dc_vid_clear ();
  dc_vid_flip ();
}


/* ============================================================ */
struct {
  char name[32];
  uint8 addr;
  uint8 free_blocks;
} vmu_slots[32];


static int
init_vmu_select_menu ()
{
  return 1;
}


static void
draw_vmu_select_slots (int cur_pos, int vmu_num)
{
  int i;
  int y_pos = 40;
  int x_pos = 75;
  char str[128];
  
  dc_vid_clear ();
  
  draw_string (100, 10, _white, _black, "VMU select");
  draw_string (100, 20, _white, _black, "press A to select");
  for (i = 0; i < vmu_num; ++i)
  {
    uint16 fg_color = cur_pos == i ? _yellow : _white;
    sprintf (str, "%s (%d free blocks)", vmu_slots[i].name, vmu_slots[i].free_blocks);
    draw_string (x_pos, y_pos, fg_color, _black, str);
    y_pos += 10;
  }
}


uint8 
do_vmu_select_menu ()
{
  int port, unit;
  int vmu_num;
  int cur_pos = 0;
  
  dc_vid_clear ();
  dc_vid_flip ();
  
  vmu_num = 0;
  for (port=0; port<4; port++)
  {
    for (unit=0; unit<6; unit++) 
    {
      if (maple_device_func(port, unit) & MAPLE_FUNC_MEMCARD)
      {
        uint8 addr = maple_create_addr(port, unit);
        
        sprintf(vmu_slots[vmu_num].name, "p%d/u%d", port, unit);
        vmu_slots[vmu_num].addr = addr; 
        vmu_slots[vmu_num].free_blocks = ndc_vmu_check_free_blocks (NULL, addr);
        ++vmu_num;
      }
    }
  }
  
  if (!vmu_num)
    return 0;
  
  draw_vmu_select_slots (cur_pos, vmu_num);
  dc_vid_flip ();
  for (;;)
  {
    cont_cond_t cont;
    
    if (!dc_cont_get_cond (dc_controller_addr[0], &cont))
      continue;
    
    if (!(cont.buttons & CONT_DPAD_UP))
    {
      if (cur_pos > 0)
	--cur_pos;
    }
    else if (!(cont.buttons & CONT_DPAD_DOWN)) 
    {
      if (cur_pos < vmu_num - 1)
	++cur_pos;
    }
    else if (!(cont.buttons & CONT_A))
      break;
    
    draw_vmu_select_slots (cur_pos, vmu_num);
    dc_vid_flip ();
  }
  
  dc_vid_clear ();
  dc_vid_flip ();
  
  return vmu_slots[cur_pos].addr;
}


