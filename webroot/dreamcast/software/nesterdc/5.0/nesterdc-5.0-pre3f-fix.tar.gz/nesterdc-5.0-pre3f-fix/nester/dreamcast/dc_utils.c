#include <kos.h>
#include "dc_utils.h"


void 
timer_sleep(int msec)
{
  if (thd_enabled)
    thd_sleep(msec);
  else
    timer_spin_sleep(msec);
}


#include <dc/sq.h>
/* n must be multiple of 64 */
void
dc_sq_cpy(void *dest, void *src, int n)
{
  uint32 *sq;
  uint32 *d = (uint32 *)dest;
  uint32 *s = (uint32 *)src;
  uint32 *pref_addr;
  
  /* Set store queue memory area as desired */
  QACR0 = ((((uint32)dest)>>26)<<2)&0x1c;
  QACR1 = ((((uint32)dest)>>26)<<2)&0x1c;
  
  n >>= 6;
  while (n--) 
  {
    /* sq0 */ 
    sq = (uint32 *)(0xe0000000);
    pref_addr = (uint32 *)(0xe0000000 | ((uint32)d & 0x3ffffc0));
    *sq++ = *s++; *sq++ = *s++;
    *sq++ = *s++; *sq++ = *s++;
    *sq++ = *s++; *sq++ = *s++;
    *sq++ = *s++; *sq++ = *s++;
    asm("pref @%0" : : "r" (pref_addr));
    d += 8;
    
    /* sq1 */
    sq = (uint32 *)(0xe0000000 | 0x20);
    pref_addr = (uint32 *)(0xe0000000 | ((uint32)d & 0x3ffffc0) | 0x20);
    *sq++ = *s++; *sq++ = *s++;
    *sq++ = *s++; *sq++ = *s++;
    *sq++ = *s++; *sq++ = *s++;
    *sq++ = *s++; *sq++ = *s++;
    asm("pref @%0" : : "r" (pref_addr));
    d += 8;
  }
}


void
dc_wait_sq_cpy_done ()
{
  /* wait for both store queues to complete */
  *((uint32 *)(0xe0000000)) = 0;
  *((uint32 *)(0xe0000000 | 0x20)) = 0;
}


#define VRAM_BASE_ADDR 0xa5000000
#define FB_SCREEN_SIZE (320 * 240 * 2)

static uint16 *dc_vram_s = (uint16 *)VRAM_BASE_ADDR;
static uint16 dc_screen[320 * 240] __attribute__ ((aligned (32)));

static uint32 dc_vid_queue[8];
static int dc_vid_queue_head = 0;
static int dc_vid_queue_tail = 0;

#ifdef __WITH_TA__
static uint32 dc_ta_screen[4];
#endif

uint32
dc_vid_enqueue (uint32 vram)
{
  int next_index = (dc_vid_queue_head + 1) & 0x07;
  
  if (next_index == dc_vid_queue_tail)
    return 0;
  else
  {
    dc_vid_queue[dc_vid_queue_head] = vram;
    dc_vid_queue_head = next_index;
    
    return vram;
  }
}


uint32
dc_vid_dequeue ()
{
  if (dc_vid_queue_tail == dc_vid_queue_head)
    return 0;
  else
  {
    int tail = dc_vid_queue_tail;
    
    dc_vid_queue_tail = (dc_vid_queue_tail + 1) & 0x07;
    
    return dc_vid_queue[tail];
  }
}


void
dc_vid_clear_queue ()
{
  int i;
  
  for (i = 0; i < 8; ++i)
    dc_vid_queue[i] = 0;
  
  dc_vid_queue_head = 0;
  dc_vid_queue_tail = 0;
}


void
dc_vid_init ()
{
  dc_vram_s = (uint16 *)VRAM_BASE_ADDR;
  dc_vid_clear_queue ();
#ifdef __WITH_TA__
  {
    int i;
    for (i = 0; i < 4; ++i)
      dc_ta_screen[i] = ta_txr_allocate (256 * 256 * 2);
  }
#endif
}


void
dc_vid_shutdown ()
{
  dc_vid_clear_queue ();
}


uint16*
dc_get_vram_s ()
{
  return dc_screen;
}


void
dc_vid_clear ()
{
  memset(dc_screen, 0, sizeof(dc_screen));
}


void
dc_vid_empty ()
{
  memset(dc_screen, 0, sizeof(dc_screen));
}


#ifdef __WITH_TA__
/* 256x240 texture */ 
static void
draw_nes_screen(uint32 textureaddr)
{
  poly_hdr_t poly;
  vertex_ot_t   vert;
  const float u1 = 0;
  const float v1 = 0;
  const float u2 = 1;
  const float v2 = 224.0/256;
  uint32 x, y;
  
  /* Begin opaque polygons */
  ta_begin_render();
  
  ta_poly_hdr_txr(&poly, TA_OPAQUE, TA_RGB565, 256, 256, textureaddr, TA_NO_FILTER);
  ta_commit_poly_hdr(&poly);
  
  vert.flags = TA_VERTEX_NORMAL;
  vert.x = 0;
  vert.y = 480;
  vert.z = 512.0f;
  vert.u = u1;
  vert.v = v2;
  vert.a = 1;
  vert.r = 1;
  vert.g = 1;
  vert.b = 1;
  vert.oa = vert.or = vert.og = vert.ob = 0.0f;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = 0;
  vert.y = 0;
  vert.u = u1;
  vert.v = v1;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = 640;
  vert.y = 480;
  vert.u = u2;
  vert.v = v2;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.flags = TA_VERTEX_EOL;
  vert.x = 640;
  vert.y = 0;
  vert.u = u2;
  vert.v = v1;
  ta_commit_vertex(&vert, sizeof(vert));
  
  /* Begin translucent polygons */
  ta_commit_eol();
  
  ta_poly_hdr_col(&poly, TA_TRANSLUCENT);
  ta_commit_poly_hdr(&poly);
  
  /* Finish up */
  ta_commit_eol();
  ta_finish_frame();
}
#endif


void
dc_vid_flip ()
{
  static int screen_buffer_num = 0;
  
#ifndef __WITH_TA__
  dc_sq_cpy(dc_vram_s, dc_screen, sizeof(dc_screen));
  dc_wait_sq_cpy_done ();
  
  if (!dc_vid_enqueue ((uint32)dc_vram_s))
    return;
  
  screen_buffer_num = (screen_buffer_num + 1) & 0x0f;
  dc_vram_s = (uint16 *)(VRAM_BASE_ADDR + FB_SCREEN_SIZE * screen_buffer_num);
  
#else
  int i;
  
  uint16 *d = ta_txr_map(dc_ta_screen[screen_buffer_num]);
  uint16 *s = dc_screen;
  s += 32;
  for (i = 0; i < 224; ++i)
  {
    dc_sq_cpy (d, s, 256 * 2);
    d += 256;
    s += 320;
  }
  dc_wait_sq_cpy_done ();
#if 1
  draw_nes_screen (dc_ta_screen[screen_buffer_num]);
#endif
  screen_buffer_num = (screen_buffer_num + 1) & 0x03;
  
#endif
}


static volatile int cont_get_cond_available = 0;

static void
vsync_handler (uint32 code)
{
#ifndef __WITH_TA__
  uint32 vram = dc_vid_dequeue ();
  
  if (vram)
    vid_set_start (vram);
#endif
  ++cont_get_cond_available;
}


void
init_vsync_handler ()
{
  g2evt_set_handler (G2EVT_TA_VBLINT, vsync_handler);
  g2evt_enable (G2EVT_TA_VBLINT);
  
  cont_get_cond_available = -1;
}


void
shutdown_vsync_handler ()
{
  g2evt_disable (G2EVT_TA_VBLINT);
  g2evt_set_handler (G2EVT_TA_VBLINT, NULL);
}


/* same as maple_first_device but assign ordinal. */
uint8
maple_find_nth_device(int n, int code) 
{
  int port, unit;
  
  for (port = 0; port < 4; ++port)
  {
    for (unit = 0; unit < 6; ++unit) 
    {
      if (maple_device_func(port, unit) & code)
      {
        if (n)
          --n;
        else
          return maple_create_addr(port, unit);
      }
    }
  }
  return 0;
}


uint8 dc_controller_addr[4];

void
maple_controller_init ()
{
  int i;
  
  for (i = 0; i < 4; ++i)
    dc_controller_addr[i] = maple_find_nth_device (i, MAPLE_FUNC_CONTROLLER);
}


int
dc_cont_get_cond (uint8 addr, cont_cond_t *cont)
{
  if (cont_get_cond_available <= 0)
    return 0;
  
  cont_get_cond (addr, cont);
  cont_get_cond_available = -1;
  return 1;
}


void
wait_until_release_buttons (uint8 addr, uint16 buttons)
{
  cont_cond_t cont;
  
  for (;;)
  {
    if (dc_cont_get_cond (addr, &cont))
    {
      if (cont.buttons & buttons)
        break;
    }
  }
}


void
wait_until_release_trigger (uint8 addr)
{
  cont_cond_t cont;
  
  for (;;)
  {
    if (dc_cont_get_cond (addr, &cont))
    {
      if (!(cont.rtrig || cont.ltrig))
        break;
    }
  }
}


#include "vmu_icons/3x5fonts.h"

void
vmu_icon_clear (char *vmu_screen, int is_black)
{
  if (is_black)
    memset(vmu_screen, '+', 48 * 32);
  else
    memset(vmu_screen, '.', 48 * 32);
}


void
vmu_icon_draw_char (char *vmu_screen, int x, int y, int ch)
{
  const char *f;
  char *v;
  int x1, y1;
  
  if (ch <= 31 || ch >= 127) return;
  if (x < 0 || x >= 48 - 3) return;
  if (y < 0 || y >= 32 - 5) return;
  
  f = vmu_3x5fonts + 3 * 5 * (ch - 32);
  v = vmu_screen + y * 48 + x;
  
  for (y1 = 0; y1 < 5; ++y1)
  {
    for (x1 = 0; x1 < 3; ++x1)
    {
      if (*f == '#')
        *v = '.';
      ++f;
      ++v;
    }
    v += 48 - 3;
  }
}


void
vmu_icon_draw_string (char *vmu_screen, int x, int y, const char *str)
{
  while (*str) 
  {
    vmu_icon_draw_char(vmu_screen, x, y, *str);
    x += 4;
    str++;
  }
}


void
vmu_icon_flip(const char *vmu_icon, uint8 addr) 
{
  int x, y, xi, xb;
  uint8 bitmap[48*32/8];
  
  memset (bitmap, 0, sizeof(bitmap));
  for (y=0; y<32; y++)
  {
    for (x=0; x<48; x++) 
    {
      xi = x / 8;
      xb = 0x80 >> (x % 8);
      if (vmu_icon[(31-y)*48+(47-x)] == '+')
        bitmap[y*(48/8)+xi] |= xb;
    }
  }
  vmu_draw_lcd(addr, bitmap);
}


int
load_bmp (uint16 *raw, char *filename)
{
  file_t fd = 0;
  uint8 bmp[320 * 240 * 3];
  int x, y, n;
  uint16 *p;
  uint16 r, g, b;
  
  fd = fs_open(filename, O_RDONLY);
  if (!fd)
    goto error;
  
  fs_seek(fd, 54, SEEK_SET);
  if (fs_read(fd, bmp, sizeof(bmp)) != sizeof(bmp))
    goto error;
  
  fs_close(fd);
  
  n = 0;
  for (y = 0; y < 240; ++y)
  {
    p = raw + 320 * (239 - y);
    for (x = 0; x < 320; ++x)
    {
      b = bmp[n++] * 32 / 256;
      g = bmp[n++] * 64 / 256;
      r = bmp[n++] * 32 / 256;
      
      *p++ = (r << 11) | (g << 5) | (b << 0);
    }
  }
  
  return 0;
  
error:
  if (fd) fs_close(fd);
  return -1;
}


void
display_rawimage (uint16 *raw)
{
  uint16 *p = dc_get_vram_s ();
  int i;
  
  for (i = 0; i < 320 * 240; ++i)
    *p++ = *raw++;
}


static uint8 dc_font_8x8[] = {
#include "dc_font_8x8.h"
};

/* Assumes a PM_RGB565 display mode. */
/* now works only 320x240. */
void 
draw_char(int x1, int y1, uint16 fg_color, uint16 bg_color, int ch)
{
  int offs = 4 + ch * 8;
  uint16 *out = dc_get_vram_s () + y1 * 320 + x1;
  int x, y;
  
  if (x1 < 0 || x1 >= 320 - 8) return;
  if (y1 < 0 || y1 >= 240 - 8) return;
  
  for (y = 0; y < 8; y++)
  {
    int mask = 0x80;
    for (x = 0; x < 8; x++)
    {
      if (dc_font_8x8[offs] & mask) 
        out[x] = fg_color;
      else 
      {
        if (bg_color != _none)
          out[x] = bg_color;
      }
      mask >>= 1;
    }
    out += 320; 
    offs++;
  }
}


void
draw_string(int x1, int y1, uint16 fg_color, uint16 bg_color, const char *str) 
{
  while (*str) 
  {
    draw_char(x1, y1, fg_color, bg_color, *str);
    x1 += 8; str++;
  }
}


void
dc_print(const char *string)
{
  dc_vid_clear ();
  draw_string(10, 10, _white, _black, string);
  dc_vid_flip ();
}


void 
dc_put_error (const char *string)
{
  dc_vid_clear ();
  draw_string(10, 10, _red, _black, string);
  dc_vid_flip ();
  timer_sleep (1000);
}


#if 0
void
font_set(uint8 *fbm, int fh) 
{
  uint16 *vram;
  int x, y;
  
  vram = (uint16 *) ta_txr_map(texture_base);
  
  for (y = 0; y < 8; y++) {
    for (x = 0; x < 16; x++) {
      bfont_draw(vram, 256, 0, y*16 + x);
      vram += 16;
      texture_base += 16;
    }
    vram += 23*256;
    texture_base += 23*256; 
  }
}


uint32 texture_base = 0;

/* 512x240 texture (draw 256x224+8+0) */
void
draw_nes_screen(uint32 textureaddr)
{
  poly_hdr_t poly;
  vertex_ot_t   vert;
  const float u1 = 8.0/512;
  const float v1 = 0;
  const float u2 = 264.0/512;
  const float v2 = 224.0/256;
  
  /* Begin opaque polygons */
  ta_begin_render();
  
  ta_poly_hdr_txr(&poly, TA_OPAQUE, TA_RGB565,
                  512, 256, textureaddr, TA_NO_FILTER);
  ta_commit_poly_hdr(&poly);
  
  vert.flags = TA_VERTEX_NORMAL;
  vert.x = 0;
  vert.y = 480;
  vert.z = 512.0f;
  vert.u = u1;
  vert.v = v2;
  vert.a = 1;
  vert.r = 1;
  vert.g = 1;
  vert.b = 1;
  vert.oa = vert.or = vert.og = vert.ob = 0.0f;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = 0;
  vert.y = 0;
  vert.u = u1;
  vert.v = v1;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = 640;
  vert.y = 480;
  vert.u = u2;
  vert.v = v2;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.flags = TA_VERTEX_EOL;
  vert.x = 640;
  vert.y = 0;
  vert.u = u2;
  vert.v = v1;
  ta_commit_vertex(&vert, sizeof(vert));
  
  /* Begin translucent polygons */
  ta_commit_eol();
  
  ta_poly_hdr_col(&poly, TA_TRANSLUCENT);
  ta_commit_poly_hdr(&poly);
  
  /* Finish up */
  ta_commit_eol();
  ta_finish_frame();
}


/* vertical mirroring */
void
draw_bmp(uint32 textureaddr)
{
  poly_hdr_t poly;
  vertex_ot_t   vert;
  float u, v;

  u = 320.0 / 512; 
  v = 240.0 / 256;
  
  /* Begin opaque polygons */
  ta_begin_render();
  
  /* Start a textured polygon set (with the font texture) */
  ta_poly_hdr_txr(&poly, TA_OPAQUE, TA_RGB565,
                  512, 256, textureaddr, TA_NO_FILTER);
  ta_commit_poly_hdr(&poly);
  
  vert.flags = TA_VERTEX_NORMAL;
  vert.x = 0;
  vert.y = 480;
  vert.z = 512.0f;
  vert.u = 0;
  vert.v = 0;
  vert.a = 1;
  vert.r = 1;
  vert.g = 1;
  vert.b = 1;
  vert.oa = vert.or = vert.og = vert.ob = 0.0f;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = 0;
  vert.y = 0;
  vert.u = 0;
  vert.v = v;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = 640;
  vert.y = 480;
  vert.u = u;
  vert.v = 0;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.flags = TA_VERTEX_EOL;
  vert.x = 640;
  vert.y = 0;
  vert.u = u;
  vert.v = v;
  ta_commit_vertex(&vert, sizeof(vert));
  
  /* Begin translucent polygons */
  ta_commit_eol();
  
  /* Send polygon header to the TA using store queues */
  ta_poly_hdr_col(&poly, TA_TRANSLUCENT);
  ta_commit_poly_hdr(&poly);
  
  /* Finish up */
  ta_commit_eol();
  ta_finish_frame();
}



/* Draw one font character (6x12) */
void 
draw_char(int x1, int y1, uint16 fg_color, uint16 bg_color, int ch)
{
  vertex_ot_t	vert;
  int ix, iy;
  float u1, v1, u2, v2;
  float fg_r, fg_g, fg_b;
  
  fg_r = (fg_color & 0xf800) * 1.0 / 0x1f;
  fg_g = (fg_color & 0x07e0) * 1.0 / 0x2f;
  fg_b = (fg_color & 0x001f) * 1.0 / 0x1f;
  
  if (ch == ' ')
    return;

  /* adjust x1, y1 320x240 => 640x480 */
  x1 *= 2;
  y1 *= 2;
  
  ix = (ch % 16) * 16;
  iy = (ch / 16) * 24;
  u1 = ix * 1.0f / 256.0f;
  v1 = iy * 1.0f / 256.0f;
  u2 = (ix+12) * 1.0f / 256.0f;
  v2 = (iy+24) * 1.0f / 256.0f;
  
  vert.flags = TA_VERTEX_NORMAL;
  vert.x = x1;
  //vert.y = y1 + 16.0f;
  vert.y = y1 + 24;
  vert.z = 512;
  vert.u = u1;
  vert.v = v2;
  vert.dummy1 = vert.dummy2 = 0;
  vert.a = 1;
  vert.r = fg_r;
  vert.g = fg_g;
  vert.b = fg_b;
  vert.oa = vert.or = vert.og = vert.ob = 0.0f;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = x1;
  vert.y = y1;
  vert.u = u1;
  vert.v = v1;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.x = x1 + 12;
  //vert.y = y1 + 16.0f;
  vert.y = y1 + 24;
  vert.u = u2;
  vert.v = v2;
  ta_commit_vertex(&vert, sizeof(vert));
  
  vert.flags = TA_VERTEX_EOL;
  vert.x = x1 + 12;
  vert.y = y1;
  vert.u = u2;
  vert.v = v1;
  ta_commit_vertex(&vert, sizeof(vert));
}


void
draw_string(int x1, int y1, uint16 fg_color, uint16 bg_color, const char *str) 
{
  poly_hdr_t poly;
  
  ta_poly_hdr_txr(&poly, TA_TRANSLUCENT, TA_ARGB4444, 256, 256, font_texture, 0);
  ta_commit_poly_hdr(&poly);
  while (*str) 
  {
    draw_char(x1, y1, fg_color, bg_color, *str);
    x1 += 8; str++;
  }
}

#endif


