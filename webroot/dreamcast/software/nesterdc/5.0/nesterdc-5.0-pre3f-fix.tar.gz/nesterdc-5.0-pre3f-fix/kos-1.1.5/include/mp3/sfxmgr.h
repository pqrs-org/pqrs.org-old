/* Tryptonite

   sfxmgr.h
   (c)2000 Dan Potter
*/

#ifndef __SFXMGR_H
#define __SFXMGR_H

int sfx_load(const char *fn);
void sfx_play(int idx, int vol, int pan);
void sfx_unload_all();


#endif	/* __SFXMGR_H */
