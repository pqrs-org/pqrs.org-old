/* KallistiOS 1.1.5

   initall.c
   (c)2001 Dan Potter
*/

static char id[] = "KOS initall.c,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp";

/*

 The function in this file (arch_init_all) sets up all of the hardware
 and software subsystems in the OS so it's all ready to use. If you
 don't care about the size of your binary and/or limiting what gets
 included, you can use this function.

 This is in a seperate file to force seperate linking so it doesn't
 automatically include all that stuff.

 */

#include <stdio.h>
#include <kos/fs.h>
#include <kos/thread.h>
#include <kos/fs_romdisk.h>
#include <dc/fs_iso9660.h>
#include <dc/fs_vmu.h>
#include <dc/fs_dcload.h>
#include <dc/ta.h>
#include <arch/irq.h>
#include <arch/timer.h>
#include <arch/dbgio.h>

extern const char banner[];

int kos_init_all(uint32 enables, void *romdisk) {
	/* If DC-Load is in use, then we'll want to enable that
	   before anything else happens. */
	fs_dcload_init_console();

	/* Do the banner */
	dbgio_init();
	dbglog(DBG_INFO, "\n--\n");		/* Spacer for multiple sessions */
	dbglog(DBG_INFO, banner);

	/* Initialize all of the basic hardware systems */
	irq_init();		/* IRQ */
	timer_init();		/* Timers */
	hardware_init();	/* DC Hardware */
	syscall_init();		/* System call interface */

	/* Initialize VFS */
	dbglog(DBG_KDEBUG, "Initializing VFS\n");
	fs_init();
	if (romdisk != NULL) {
		dbglog(DBG_KDEBUG, "Initializing RD file system\n");
		fs_romdisk_init(romdisk);
	}
	if (*DCLOADMAGICADDR == DCLOADMAGICVALUE) {
		dbglog(DBG_KDEBUG, "Initializing DCLOAD Console file system\n");
		fs_dcload_init();
	}
	dbglog(DBG_KDEBUG, "Initializing CD file system\n");
	fs_iso9660_init();
	dbglog(DBG_KDEBUG, "Initializing VMU file system\n");
	fs_vmu_init();

	/* Enable threads */
	if (enables & THD_ENABLE) {
		dbglog(DBG_KDEBUG, "Initializing threads\n");
		thd_init();
	}

	/* Enable IRQs */
	if (enables & IRQ_ENABLE) {
		dbglog(DBG_KDEBUG, "Enabling IRQs\n");
		irq_enable();
	}

	/* Potentially enable TA */
	if (enables & TA_ENABLE) {
		dbglog(DBG_KDEBUG, "Initializing 3D system\n");
		ta_init_defaults();
	}

	return 0;
}

void kos_shutdown_all() {
	irq_disable();
	thd_shutdown();
	ta_shutdown();
	fs_dcload_shutdown();
	fs_vmu_shutdown();
	fs_iso9660_shutdown();
	fs_romdisk_shutdown();
	fs_shutdown();
	irq_shutdown();
}


