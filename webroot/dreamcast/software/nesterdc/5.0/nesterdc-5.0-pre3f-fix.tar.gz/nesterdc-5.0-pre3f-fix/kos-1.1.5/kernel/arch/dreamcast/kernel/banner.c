char banner[] = 
"KallistiOS 1.1.5: Tue Jan 8 05:12:55 JST 2002\n"
"  tekezo@:/home/tekezo/work/tmp/nesterdc-5.0-pre3fullscreen/kos-1.1.5\n"
;
