#ifndef __SNDSERVER_H
#define __SNDSERVER_H

#include <mp3/sndmp3.h>
#include <mp3/sfxmgr.h>

/* Starts the MP3 server thread */
int mp3_init();

/* Starts a song playing */
int mp3_start(const char *fn, int loop);

/* Stops the playing song */
int mp3_stop();

/* Shuts down the MP3 server thread */
int mp3_quit();

#endif	/* __SNDSERVER_H */

