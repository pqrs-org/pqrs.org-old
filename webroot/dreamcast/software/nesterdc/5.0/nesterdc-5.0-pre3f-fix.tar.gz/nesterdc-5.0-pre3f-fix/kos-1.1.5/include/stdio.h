/* KallistiOS 1.1.5

   stdio.h
   (c)2000 Dan Potter

   stdio.h,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp

*/

#ifndef __STDIO_H
#define __STDIO_H

#include <unistd.h>
#include <stdarg.h>

/* vsprintf.c */
int vsprintf(char *buf, const char *fmt, va_list args);
int sprintf(char * buf, const char *fmt, ...);

/* printf.c */
int printf(const char *fmt, ...);

/* To make porting programs a bit easier.. WARNING: only works on GCC */
#define fprintf(BLAGH, ARGS...) printf(ARGS)

/* Kernel debugging printf; all output sent to this is filtered through
   a kernel log level check before actually being printed. This way, you
   can set the level of debug info you want to see (or want your users
   to see). */
void dbglog(int level, const char *fmt, ...);

/* Log levels for the above */
#define DBG_DEAD	0		/* The system is dead */
#define DBG_CRITICAL	1		/* A critical error message */
#define DBG_ERROR	2		/* A normal error message */
#define DBG_WARNING	3		/* Potential problem */
#define DBG_NOTICE	4		/* Normal but significant */
#define DBG_INFO	5		/* Informational messages */
#define DBG_DEBUG	6		/* User debug messages */
#define DBG_KDEBUG	7		/* Kernel debug messages */

/* Set debug level */
void dbglog_set_level(int level);

#endif	/* __STDIO_H */

