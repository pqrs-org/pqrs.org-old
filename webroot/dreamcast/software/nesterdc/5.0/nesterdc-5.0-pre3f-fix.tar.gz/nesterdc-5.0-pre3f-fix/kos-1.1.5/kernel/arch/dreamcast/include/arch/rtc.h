/* KallistiOS 1.1.5

   arch/dreamcast/include/rtc.h
   (c)2000-2001 Dan Potter

   rtc.h,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp

 */

#ifndef __ARCH_RTC_H
#define __ARCH_RTC_H

#include <arch/types.h>

/* Dreamcast UNIX timestamp type */
typedef uint32 time_t;

/* Returns the date/time value as a UNIX epoch time stamp */
time_t rtc_unix_secs();


#endif	/* __ARCH_RTC_H */

