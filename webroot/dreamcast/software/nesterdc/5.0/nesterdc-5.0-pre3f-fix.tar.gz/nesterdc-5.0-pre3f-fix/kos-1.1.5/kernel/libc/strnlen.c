/* KallistiOS 1.1.5

   strnlen.c
   (c)2000 Dan Potter

   strnlen.c,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp
*/


#include <string.h>

size_t strnlen(const char * s, size_t count) {
	const char *t = s;

	while (count-- && *t != '\0') t++;
	return t - s;
}
