/* KallistiOS 1.1.5

   os/svcmpx.h
   (c)2000-2001 Dan Potter

   svcmpx.h,v 1.1.1.1 2001/11/15 18:40:30 tekezo Exp

*/

#ifndef __OS_SVCMPX_H
#define __OS_SVCMPX_H

/* Gets a current handler */
void *svcmpx_get_handler(const char *name);

/* Adds a new service handler (replacing any previous handler) */
int svcmpx_add_handler(const char *name, void *svc_struct);

/* Removes the handler of the given name (if any) */
int svcmpx_remove_handler(const char *name);

/* Returns 1 if the svcmpx module is active */
int svcmpx_enabled();

int svcmpx_init();
void svcmpx_shutdown();

#endif	/* __OS_SVCMPX_H */

