#ifndef __DC_GG_H
#define __DC_GG_H

#include "types.h"
#include "nes.h"

void load_genie_from_file(const char *filename, NES *emu); 

#endif

