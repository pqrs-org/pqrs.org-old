/* KallistiOS ##version##

   ta.h
   (c)2000-2002 Dan Potter
   
   ta.h,v 1.5 2002/02/09 05:52:48 bardtx Exp
*/

#include <dc/ta_compat.h>


