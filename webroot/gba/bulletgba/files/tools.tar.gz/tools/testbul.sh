#!/bin/sh

[ -f "$1" ] || exit 1

destfile=$(dirname $1)/$(basename $1 .bnml).xml
java -jar ~/gba/tools/bulletnotml.jar $1 > $destfile
if [ -s $destfile ]; then
    echo "<!--" >> $destfile
    cat $1 >> $destfile
    echo "-->" >> $destfile

    realfile=$(realpath $destfile)
    [ "$2" = "batch" ] || (cd ~/src/sdl/sdmkun; ./sdmkun -w $realfile)
fi
