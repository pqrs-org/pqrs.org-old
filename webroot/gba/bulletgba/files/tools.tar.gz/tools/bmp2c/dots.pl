#!/usr/bin/perl

$foo = 0;

@lines = ();

while(<>)
	{
	s/value/short/;
	push @lines, $_ unless  (/\.glob/ || /\.section/ || /\.type/ || 
		/\.file/ || /gcc2_compiled/ || /\.version/ || /\.data/ || 
		/\.align/ || /\.size/ || /\.ident/);
		 
	}

foreach $line (@lines)
	{
	print $line;
	}
