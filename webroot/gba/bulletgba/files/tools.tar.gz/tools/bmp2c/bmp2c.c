/*
 *
 * (c) Bruno Vedder 11/2001 Pour compiler: Gcc bmp2c.c -o bmp2c
 * -fpack-struct -fpack-struct est indispensable pour empecher le
 * compilateur d'aligner certaines choses qui ne doivent pas l'etre.
 *
 * Le prg prends des bmp 4/8 bits, de taille multiple de 8. Pour diriger
 * la sortie dans un fichier: bmp2c truc.bmp >out.c
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  unsigned short  signature;
  unsigned int    filesize;
  unsigned short  zero1;
  unsigned short  zero2;
  unsigned int    Offset;

  unsigned int    bisize;   // Bmp Info Hdr Size ...
  unsigned int    width;
  unsigned int    height;
  unsigned short  plane;    // Plane numbre
  unsigned short  bpp;  // Bit per pixel 4 or 8 here.
  unsigned int    comptype; // 0 mean no compression.
  unsigned int    dummy[3]; // Useless ms data :)
  unsigned int    colused;  // Nb of used colors
  unsigned int    dummytoo;
} BmpH;


void            ConvertToC(unsigned char *buff, BmpH * BmpInf);
void            Dump8BitColTile(int x, int y, unsigned char *Buff,
                                unsigned int width);
void            Dump4BitColTile(int x, int y, unsigned char *Buff,
                                unsigned int width);
void            DumpCMap(BmpH * bmp, unsigned char *CmapData);
void            InvertBmp(unsigned char *Buff, BmpH * H);

/*
 * SLOPPY!!
 */
char            palname[251] = "Cmap_16c",
  tilename[251] = "Data";

int
main(int argc, char *argv[])
{
  FILE           *bmpfile;
  unsigned char   CMapBuffer[1024];
  unsigned char  *BmpBuffer;
  unsigned int    size;
  int             ret;
  BmpH            h;

  printf("/*\nBmp 4/8 Bits to GBA Converter By Bruno Vedder.\n");
  printf("With modifications by Pete Elmore.\n");

  switch (argc) {
    case 3:
      strcpy(tilename, argv[2]);
    case 2:
      break;
    default:
      printf("Usage: bmp2c file.bmp dataname\n");
      return (-1);
  }

  bmpfile = fopen(argv[1], "rb");
  if (bmpfile == NULL) {
    printf("Unable to open %s.\n", argv[1]);
    return (-1);
  }
  printf("%s Opened.\n", argv[1]);
  ret = fread(&h, sizeof(BmpH), 1, bmpfile);
  if (!ret) {
    printf("Unable to read bmp header %s.\n", argv[1]);
    return (-1);
  }
  if (h.signature != 19778) {
    printf("Halted: bmp signature not found !\n");
    exit(-1);
  } else
    printf("Bmp signature found.\n");
  /*
   * if ((h.zero1 !=0) || (h.zero2 !=0)) { printf ("Not a bmp
   * format.\n"); printf ("zero1 = %d. zero2 = %d. \n",h.zero1,h.zero2);
   * exit (-1); }
   */
  printf("Bmp width: %d\n", h.width);
  if ((h.width % 8) != 0) {
    printf("Bmp width must be multiple of 8.\n");
    return (-1);
  }
  printf("Bmp height: %d\n", h.height);
  if ((h.height % 8) != 0) {
    printf("Bmp width must be multiple of 8.\n");
    return (-1);
  }
  printf("Bmp not compressed: ok.\n", h.height);
  if (h.comptype != 0) {
    printf("Bmp must be uncompressed.\n");
    return (-1);
  }
  printf("One plane.\n");
  if (h.plane != 1) {
    printf("Bmp must be one plane picture.\n");
    return (-1);
  }
  printf("Bmp is %d Bit per pixel.\n", h.bpp);
  if ((h.bpp != 8) && (h.bpp != 4)) {
    printf("Bmp must be 16 or 256 colors .\n");
    return (-1);
  }
  printf("%d colors used. (0 mean full bpp).\n", h.colused);
  printf("Bmp data starts at %xh.\n", h.Offset);

  size = h.width * h.height;
  if (h.bpp == 4)
    size >>= 1;

  BmpBuffer = (unsigned char *) malloc(size);
  if (BmpBuffer != NULL) {
    printf("Allocating %d bytes.\n", size);
  } else {
    printf("Can t get enough mem.\n");
    return (-1);
  }

  ret = fseek(bmpfile, 54, SEEK_SET);
  if (ret) {
    printf("Unable to reach offset 54\n");
    return (-1);
  }
  ret = fread(CMapBuffer, 1, 1024, bmpfile);
  if (!ret) {
    printf("Can t read bmp CMAP.\n");
    return (-1);
  } else {
    printf("CMAP loaded.\n");
  }

  ret = fseek(bmpfile, h.Offset, SEEK_SET);
  if (ret) {
    printf("Unable to reach %.8x\n", h.Offset);
    return (-1);
  }
  ret = fread(BmpBuffer, size, 1, bmpfile);
  if (!ret) {
    printf("Can t read bmp data.\n");
    return (-1);
  } else {
    printf("Data loaded. */\n");
  }

  {
    // output info
    int tileWidth = h.width / 8;
    int tileHeight = h.height / 8;

    printf("namespace TILEINFO_%s {\n", tilename);
    printf("  enum {\n");
    printf("    w = %d,\n", tileWidth);
    printf("    h = %d,\n", tileHeight);
    printf("    size = %d,\n", tileWidth * tileHeight);
    printf("  };\n");
  }

  DumpCMap(&h, CMapBuffer);
  InvertBmp(BmpBuffer, &h);
  ConvertToC(BmpBuffer, &h);
  fclose(bmpfile);

  {
    printf("  inline u16 *copyImage(u16 *vram) {\n");
    printf("    for (u32 i = 0; i < sizeof(img) / 2; ++i) {\n");
    printf("      *vram++ = img[i * 2] | (img[i * 2 + 1] << 8);\n");
    printf("    }\n");
    printf("    return vram;\n");
    printf("  }\n");
    printf("  inline u16 *copyPalette(u16 *pal) {\n");
    printf("    for (u32 i = 0; i < sizeof(palette) / 2; ++i) {\n");
    printf("      *pal++ = palette[i];\n");
    printf("    }\n");
    printf("    return pal;\n");
    printf("  }\n");
    printf("};\n");
  }

  return (0);
}

void
ConvertToC(unsigned char *buff, BmpH * H)
{
  unsigned int    i,
    o;

  printf("  const unsigned char img[] = {\n");
  if (H->bpp == 8) {
    for (i = 0; i < H->height / 8; i++) {
      for (o = 0; o < H->width / 8; o++) {
        printf("\n    // Tile [%d , %d] \n    ", o, i);
        Dump8BitColTile(o, i, buff, H->width);
      }
    }
  } else {
    for (i = 0; i < H->height / 8; i++) {
      for (o = 0; o < H->width / 8; o++) {
        printf("\n    // Tile [%d , %d] \n    ", o, i);
        Dump4BitColTile(o, i, buff, H->width);
      }
    }
  }
  printf("  };\n");
}

void
Dump8BitColTile(int x, int y, unsigned char *Buff, unsigned int width)
{
  unsigned int    i,
    o;
  unsigned int    index,
    baseindex;
  index = ((y * 8) * width) + (x * 8);
  baseindex = index;

  for (i = 0; i < 8; i++) {
    for (o = 0; o < 8; o++) {
      printf("0x%x,", Buff[index]);
      index++;
    }
    printf("\n    ");
    baseindex += width;
    index = baseindex;
  }
}

void
Dump4BitColTile(int x, int y, unsigned char *Buff, unsigned int width)
{
  unsigned int    i,
    o;
  unsigned int    index,
    baseindex;

  width = width / 2;

  index = ((y * 8) * width) + (x * 4);
  baseindex = index;

  for (i = 0; i < 8; i++) {
    for (o = 0; o < 4; o++) {
      /*
       * Klugey fix for 4-bit problem: I have to reverse the halves
       * of the byte, otherwise the sprite looks all fsck'd up.
       * Unfortunately, I can't think of a way to make this line
       * look cleaner.
       */
      Buff[index] =
        ((Buff[index] & 0xf) << 4) | ((Buff[index] & 0xf0) >> 4);
      printf("0x%x,", Buff[index]);
      index++;
    }
    printf("\n    ");
    baseindex += width;
    index = baseindex;
  }
}

void
InvertBmp(unsigned char *Buff, BmpH * H)
{
  unsigned int    i,
    o,
    w;
  unsigned int    baseup = 0;
  unsigned int    basedown;
  unsigned char   col;

  if (H->bpp == 4)
    w = H->width / 2;
  else
    w = H->width;

  basedown = ((H->height - 1) * w);
  for (i = 0; i < H->height >> 1; i++) {
    for (o = 0; o < w; o++) {
      col = Buff[basedown];
      Buff[basedown] = Buff[baseup];
      Buff[baseup] = col;
      basedown++;
      baseup++;
    }
    basedown -= 2 * w;
  }
}

void
DumpCMap(BmpH * bmp, unsigned char *CmapData)
{
  unsigned int    i,
    nb_color;
  unsigned short  col,
    c;


  c = 0;
  printf("  const unsigned short palette[] = {\n");
  printf("    ");
  nb_color = bmp->colused;
  if (nb_color == 0) {
    if (bmp->bpp == 4)
      nb_color = 16;
    else
      nb_color = 256;
  }
  for (i = 0; i < nb_color; i++) {
    col =
      (CmapData[i * 4 + 2] >> 3) | ((CmapData[i * 4 + 1] >> 3) << 5)
      | ((CmapData[i * 4]) >> 3 << 10);
    printf("0x%x,", col);
    c++;
    if (c > 15) {
      printf("\n    ");
      c = 0;
    }
  }
  if (c != 0) {
    for (i = 0; i < (1 << bmp->bpp) - nb_color; i++) {
      printf("0x0,");
      c++;
      if (c > 15) {
        printf("\n");
        c = 0;
        break;
      }
    }
  }
  printf("};\n\n");
}
