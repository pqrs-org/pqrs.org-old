I.	Legal
II.	Changes
III.	Usage
IV.	Credits

I.  Legal
I have no idea what license the original author intended or what rights he
wanted to reserve or if it was public domain or anything like that.  My changes
to his code may be considered public domain if the original code is.
Otherwise, it's probably up to the original author, as my changes were so 
trivial.  

II.  Changes
This program was originally by Bruno Vedder.  I performed some very minor 
changes to it, namely:
	* All of the stuff it prints at the beginning goes into a comment now.
		It was very annoying to have to strip it from every file
		that bmp2c generated.
	* You can change the names of the arrays it generates.
		That was something else that bothered me.  Run the program with
		no args to get the syntax.
	* I added a Makefile and a readme.txt!
	* I ran "indent -orig" on it to make the code a little cleaner looking.
	* I removed all of the ^M's that were all over the file, a telltale
		sign that it was made in Windows, and an annoyance if you edit
		it using Linux.
	* I fixed a big bug that swapped groups of columns in 4bpp.
	* I added a Perl script that will clean up gcc's assembly language
		output when doing a "gcc -S" on one of bmp2c's output files.
		See Usage.

All of my changes to the bmp2c.c source file were kinda (or very) sloppy, but 
they didn't take long to do and they _work_, so I'm happy.  Your mileage may 
vary.

III.  Usage
It's very easy!  bmp2c reads the first file specified and sends output to 
stdout.  The simplest way is:
	bmp2c foo.bmp > foo.c
If you want to specify two more options, you can name the arrays.  Make sure
it's a legal name for an array in C, as the program does not check this!  So
to read foo.bmp, name the tile array tiles and the palette array palette, and
send output to foo.c, do
	bmp2c foo.bmp tiles palette > foo.c
If you don't specify the second two args, the defaults are 'Tiles' and
'Cmap_16c'.  If you don't specify anything, you'll get the usage info.
Note that it works under Linux on x86.  I have no idea about other archs/OS's. 
If you're an assembly programmer, the dots.pl program may be useful for you.
Basically, it's designed to be used like this:
	bmp2c foo.bmp > foo.c
	gcc -S foo.c -o foo_.s
	dots.pl foo_.s > foo.s
And you should be able to use the newly created foo.s in your assembly language
program.

I should warn you that I have not tested the entire makefile, and so it may not
work.


IV.  Credits
Original Program:
	Bruno Vedder  (I couldn't find any contact info.)
Sloppy Modifications, Makefile, dots.pl, and readme.txt:
	Pete Elmore  (crayon at bnet.org)


