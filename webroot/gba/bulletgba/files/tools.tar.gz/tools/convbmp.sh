#!/bin/sh

[ -f "$1" ] && \
    ~/gba/tools/bmp2c/bmp2c $1 $(basename $1 .bmp)
