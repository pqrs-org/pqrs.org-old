// XXX uniqID XXX dcd6df7bf28f1e5fc90a46a17c16a023 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx_proto02.hpp" 

extern const BulletStepFunc bullet_db110046a7795883a49cd88ff33a207a_dcd6df7bf28f1e5fc90a46a17c16a023[] = { 
stepfunc_6ca1811d71d4608041ea93954477c3b7_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_dcd6df7bf28f1e5fc90a46a17c16a023,
NULL}; 
extern const BulletStepFunc bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023[] = { 
stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_4e354e14ca11914396d967ab898b985c_dcd6df7bf28f1e5fc90a46a17c16a023,
NULL}; 
extern const BulletStepFunc bullet_60873238238282c26e998fa0956194f0_dcd6df7bf28f1e5fc90a46a17c16a023[] = { 
stepfunc_15007e8a81d8aa46641d7ae97bab9e64_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_6536e4546bdcfcf651852434db03b678_dcd6df7bf28f1e5fc90a46a17c16a023,
stepfunc_db1155ec63325d8427fce5b0158b4a91_dcd6df7bf28f1e5fc90a46a17c16a023,
NULL}; 
void stepfunc_fcfc3ec6da193566063956a334304226_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(1.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(40.0);  FixedPointNum speed = FixedPointNum(0.1 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_4e354e14ca11914396d967ab898b985c_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(170.0));  p->lastBulletSpeed = p->getSpeed() + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 10; ++i) { 
stepfunc_fcfc3ec6da193566063956a334304226_dcd6df7bf28f1e5fc90a46a17c16a023(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_57535cf79ecaa892327d3e8bdf7f7e38_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0-6.6));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_6ca1811d71d4608041ea93954477c3b7_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((90.0)));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_01d34603100df1f4c8e96bf5a42cd072_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_15007e8a81d8aa46641d7ae97bab9e64_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 4.0 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = (FixedPointNum::degree2angle(180.0)) - p->getAngle();p->setRound(speed, life);}
p->wait = static_cast<u16>(9.0); 
}
void stepfunc_6536e4546bdcfcf651852434db03b678_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_db1155ec63325d8427fce5b0158b4a91_dcd6df7bf28f1e5fc90a46a17c16a023(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_db110046a7795883a49cd88ff33a207a_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_dcd6df7bf28f1e5fc90a46a17c16a023(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_60873238238282c26e998fa0956194f0_dcd6df7bf28f1e5fc90a46a17c16a023); 
  }
return bi;}


