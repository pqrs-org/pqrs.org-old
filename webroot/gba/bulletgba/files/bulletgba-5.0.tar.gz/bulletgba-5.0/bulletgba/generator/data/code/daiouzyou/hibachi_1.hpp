#ifndef GENERATED_4bbf766ca53ea6f07f3f0d46f7f661ce_HPP 
#define GENERATED_4bbf766ca53ea6f07f3f0d46f7f661ce_HPP 

#include "bullet.hpp" 

void stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_3956f53e0fa8316cb053b080649e6fbd(BulletInfo *p); 


extern const BulletStepFunc bullet_e24edde112e7378f1a216ad6c9866473_3956f53e0fa8316cb053b080649e6fbd[]; 
const unsigned int bullet_e24edde112e7378f1a216ad6c9866473_3956f53e0fa8316cb053b080649e6fbd_size = 82; 


#endif 

