// XXX uniqID XXX 605df41862177d37e537d64869a050c9 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "daiouzyou/round_3_boss_2.hpp" 

extern const BulletStepFunc bullet_7686d20a9f317cf1c68158f5c21df35a_605df41862177d37e537d64869a050c9[] = { 
stepfunc_e3fbf28c16ad6a8c781b78e6124895bc_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_605df41862177d37e537d64869a050c9,
NULL}; 
extern const BulletStepFunc bullet_c86cd846af3372d3630b3ecfcd6e2aac_605df41862177d37e537d64869a050c9[] = { 
stepfunc_9d9358fda94559afc6829bc3937fe39e_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_605df41862177d37e537d64869a050c9,
NULL}; 
extern const BulletStepFunc bullet_4f851fdf2f59918b25f9b88629b88b94_605df41862177d37e537d64869a050c9[] = { 
stepfunc_432c2a72ebe3e5356791a8122241e090_605df41862177d37e537d64869a050c9,
stepfunc_e4547dce74c2f31cf07f256255486988_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9,
stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_605df41862177d37e537d64869a050c9,
NULL}; 
extern const BulletStepFunc bullet_bccafd744bd3bffb532779da1f8ae528_605df41862177d37e537d64869a050c9[] = { 
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_605df41862177d37e537d64869a050c9,
NULL}; 
extern const BulletStepFunc bullet_d748d8fb67f7d3f0d36baea5eaeee4b9_605df41862177d37e537d64869a050c9[] = { 
stepfunc_ee29804f888a6333ad89cab8e9abfa9f_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_605df41862177d37e537d64869a050c9,
NULL}; 
extern const BulletStepFunc bullet_b76a48a2ef1c69a2a98bb852fddd9e81_605df41862177d37e537d64869a050c9[] = { 
stepfunc_ee29804f888a6333ad89cab8e9abfa9f_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_605df41862177d37e537d64869a050c9,
NULL}; 
extern const BulletStepFunc bullet_d33a1609c5b82ee13af9642abff8b7fe_605df41862177d37e537d64869a050c9[] = { 
stepfunc_42d9b4bc61232ce697cbbbcf4bfa4b03_605df41862177d37e537d64869a050c9,
NULL}; 
void stepfunc_9984dc6ea2915a7cf16c6d91dd6674ec_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 -(
 -13.0
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_9b9ab1b2ff4dad57c1d47a0b03432091_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
1.3*(
 -13.0
)
));  p->lastBulletSpeed = (
 1.4+1.0*0.8
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_9984dc6ea2915a7cf16c6d91dd6674ec_605df41862177d37e537d64869a050c9(p);}
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_4e1c77282b15ebf5fd60f168da58a9de_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 (
 -13.0
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_e59d9e561081bac475ced3b0a6d2c3a8_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-1.3*(
 -13.0
)
));  p->lastBulletSpeed = (
 1.4+1.0*0.8
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_4e1c77282b15ebf5fd60f168da58a9de_605df41862177d37e537d64869a050c9(p);}
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_ee29804f888a6333ad89cab8e9abfa9f_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
180.0
));  p->lastBulletSpeed = 1;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_bccafd744bd3bffb532779da1f8ae528_605df41862177d37e537d64869a050c9); 
  }
}
}
void stepfunc_857998d636a2efe74a83550d8021cacf_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 -(
 13.0
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_3c8f00720f37f335ab17ea53101f9ee8_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
1.3*(
 13.0
)
));  p->lastBulletSpeed = (
 1.4+1.0*0.8
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_857998d636a2efe74a83550d8021cacf_605df41862177d37e537d64869a050c9(p);}
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_5e70067cf2885af56205980b4490c489_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 (
 13.0
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_4f1068fe681e79a6adc4a12894c39568_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-1.3*(
 13.0
)
));  p->lastBulletSpeed = (
 1.4+1.0*0.8
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_5e70067cf2885af56205980b4490c489_605df41862177d37e537d64869a050c9(p);}
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_5465a9054178f11d9472204f5258ba8a_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 -7.0
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.3
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_6e41be3a73ebcd621ad69bf943606b4e_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-(
 -7.0
)*2.1
));  p->lastBulletSpeed = (
 1.2+1.0*0.4
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_5465a9054178f11d9472204f5258ba8a_605df41862177d37e537d64869a050c9(p);}
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_e3fbf28c16ad6a8c781b78e6124895bc_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 -7.0
)*8.0
));  p->lastBulletSpeed = 1;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_bccafd744bd3bffb532779da1f8ae528_605df41862177d37e537d64869a050c9); 
  }
}
}
void stepfunc_dc74a46869a569becc2bdc858ac3eeff_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 7.0
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.3
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_d6c1ad678f65d9998a136cc183abcb91_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-(
 7.0
)*2.1
));  p->lastBulletSpeed = (
 1.2+1.0*0.4
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_dc74a46869a569becc2bdc858ac3eeff_605df41862177d37e537d64869a050c9(p);}
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_9d9358fda94559afc6829bc3937fe39e_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 7.0
)*8.0
));  p->lastBulletSpeed = 1;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_bccafd744bd3bffb532779da1f8ae528_605df41862177d37e537d64869a050c9); 
  }
}
}
void stepfunc_aec694bb35839077da312ab4df624331_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
p->wait = (
 320.0/(14.0+1.0*12.0)+FixedPointNum::random()
).toInt(); 
}
void stepfunc_66afe88fdc54516490fa360aeeebb765_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
0.0
));  p->lastBulletSpeed = (
 1.4+1.0*0.8
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_432c2a72ebe3e5356791a8122241e090_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
p->wait = static_cast<u16>(
 8.0
); 
}
void stepfunc_e4547dce74c2f31cf07f256255486988_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
 1.0
);  FixedPointNum speed = FixedPointNum(
 0.0
 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_42d9b4bc61232ce697cbbbcf4bfa4b03_605df41862177d37e537d64869a050c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
90.0
));  p->lastBulletSpeed = (
 1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4f851fdf2f59918b25f9b88629b88b94_605df41862177d37e537d64869a050c9); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-90.0
));  p->lastBulletSpeed = (
 1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4f851fdf2f59918b25f9b88629b88b94_605df41862177d37e537d64869a050c9); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (
 0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c86cd846af3372d3630b3ecfcd6e2aac_605df41862177d37e537d64869a050c9); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (
 0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7686d20a9f317cf1c68158f5c21df35a_605df41862177d37e537d64869a050c9); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_605df41862177d37e537d64869a050c9(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_d33a1609c5b82ee13af9642abff8b7fe_605df41862177d37e537d64869a050c9); 
  }
  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_b76a48a2ef1c69a2a98bb852fddd9e81_605df41862177d37e537d64869a050c9); 
  }
  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_d748d8fb67f7d3f0d36baea5eaeee4b9_605df41862177d37e537d64869a050c9); 
  }
return bi;}


