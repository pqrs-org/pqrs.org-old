// XXX uniqID XXX 02e10ec6978b2a27ab619e02f878cb38 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "garegga/black_heart_mk2_winder.hpp" 

extern const BulletStepFunc bullet_cbca17e67a7471711ca7c13b9290f161_02e10ec6978b2a27ab619e02f878cb38[] = { 
stepfunc_19821f11904f21483bbc290f3f120b00_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_77d0d3f5f5ea501f0b600d6bea5cdcb6_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_02e10ec6978b2a27ab619e02f878cb38,
NULL}; 
extern const BulletStepFunc bullet_75f8203f90472fdc6588f7e0d68d7fb9_02e10ec6978b2a27ab619e02f878cb38[] = { 
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_02e10ec6978b2a27ab619e02f878cb38,
NULL}; 
extern const BulletStepFunc bullet_a218b4e6a77ffa6c87462d2a93e97ff8_02e10ec6978b2a27ab619e02f878cb38[] = { 
stepfunc_38c6c12600348e2bf65335867d5b0d59_02e10ec6978b2a27ab619e02f878cb38,
NULL}; 
void stepfunc_50a41ff9c682dad15ce5e83805da2d68_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(25.0));  p->lastBulletSpeed = (5.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_f3bdba9ae392e439755d8b66fcfc6d9b_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((0.7+1.0)-100.0));  p->lastBulletSpeed = (5.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_50a41ff9c682dad15ce5e83805da2d68_02e10ec6978b2a27ab619e02f878cb38(p);}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_dac8b92753aa1753961e89084ecc5fe0_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((-0.7-1.0)-100.0));  p->lastBulletSpeed = (5.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_50a41ff9c682dad15ce5e83805da2d68_02e10ec6978b2a27ab619e02f878cb38(p);}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_0b2f2089984f0361234b3a681cd84aed_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((0.0)-100.0));  p->lastBulletSpeed = (5.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_50a41ff9c682dad15ce5e83805da2d68_02e10ec6978b2a27ab619e02f878cb38(p);}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_19821f11904f21483bbc290f3f120b00_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_77d0d3f5f5ea501f0b600d6bea5cdcb6_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(230.0));  p->lastBulletSpeed = 1;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_75f8203f90472fdc6588f7e0d68d7fb9_02e10ec6978b2a27ab619e02f878cb38); 
  }
}
}
void stepfunc_38c6c12600348e2bf65335867d5b0d59_02e10ec6978b2a27ab619e02f878cb38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(135.0));  p->lastBulletSpeed = (2.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cbca17e67a7471711ca7c13b9290f161_02e10ec6978b2a27ab619e02f878cb38); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(225.0));  p->lastBulletSpeed = (2.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cbca17e67a7471711ca7c13b9290f161_02e10ec6978b2a27ab619e02f878cb38); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_02e10ec6978b2a27ab619e02f878cb38(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_a218b4e6a77ffa6c87462d2a93e97ff8_02e10ec6978b2a27ab619e02f878cb38); 
  }
return bi;}


