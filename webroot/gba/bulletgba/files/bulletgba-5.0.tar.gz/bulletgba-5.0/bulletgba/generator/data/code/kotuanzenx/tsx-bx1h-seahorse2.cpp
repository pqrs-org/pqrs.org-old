// XXX uniqID XXX 827fbfaef7fbe35d7558c2e7767e1c18 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx-bx1h-seahorse2.hpp" 

extern const BulletStepFunc bullet_64a2e84891d3ec636ce50b20961cea68_827fbfaef7fbe35d7558c2e7767e1c18[] = { 
stepfunc_89e35ecb8cdbaeddbc2fc189d396fa52_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_2d8d20189622e956f048cb5da553d994_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_d689fba28236496c6ce22e558471d232_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_2d8d20189622e956f048cb5da553d994_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_89e35ecb8cdbaeddbc2fc189d396fa52_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_827fbfaef7fbe35d7558c2e7767e1c18,
NULL}; 
void stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(22.5*(1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_92883cc32401a86194f4776a2d65f643_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(25.5*(1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c_827fbfaef7fbe35d7558c2e7767e1c18(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_c3b756461ba1f824d06b0d5c9b42b398_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(22.5*(-1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_9b7be14aa8b3aae9a615817df27bb772_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(25.5*(-1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_c3b756461ba1f824d06b0d5c9b42b398_827fbfaef7fbe35d7558c2e7767e1c18(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_89e35ecb8cdbaeddbc2fc189d396fa52_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-45.0+FixedPointNum::random()*90.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c_827fbfaef7fbe35d7558c2e7767e1c18(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_2d8d20189622e956f048cb5da553d994_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
p->wait = static_cast<u16>(60.0-1.0*30.0); 
}
void stepfunc_d689fba28236496c6ce22e558471d232_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-45.0+FixedPointNum::random()*90.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_c3b756461ba1f824d06b0d5c9b42b398_827fbfaef7fbe35d7558c2e7767e1c18(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_827fbfaef7fbe35d7558c2e7767e1c18(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_827fbfaef7fbe35d7558c2e7767e1c18(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_64a2e84891d3ec636ce50b20961cea68_827fbfaef7fbe35d7558c2e7767e1c18); 
  }
return bi;}


