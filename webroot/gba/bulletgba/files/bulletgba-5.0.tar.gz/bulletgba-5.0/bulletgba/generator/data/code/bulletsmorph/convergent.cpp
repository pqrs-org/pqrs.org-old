// XXX uniqID XXX 3e6833f584fc2f554ebd83c73675c333 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "bulletsmorph/convergent.hpp" 

extern const BulletStepFunc bullet_878bfd46c7f3d416a509e7725b0faa8e_3e6833f584fc2f554ebd83c73675c333[] = { 
stepfunc_20aa66f3f0b5006a13a5b98569a869dc_3e6833f584fc2f554ebd83c73675c333,
stepfunc_7e28cc8374d7b707eb7239c7adafb419_3e6833f584fc2f554ebd83c73675c333,
stepfunc_7e28cc8374d7b707eb7239c7adafb419_3e6833f584fc2f554ebd83c73675c333,
stepfunc_7e28cc8374d7b707eb7239c7adafb419_3e6833f584fc2f554ebd83c73675c333,
stepfunc_7e28cc8374d7b707eb7239c7adafb419_3e6833f584fc2f554ebd83c73675c333,
stepfunc_7e28cc8374d7b707eb7239c7adafb419_3e6833f584fc2f554ebd83c73675c333,
stepfunc_7e28cc8374d7b707eb7239c7adafb419_3e6833f584fc2f554ebd83c73675c333,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_3e6833f584fc2f554ebd83c73675c333,
NULL}; 
extern const BulletStepFunc bullet_57dcf454df4bab3cfe500f57cce0a050_3e6833f584fc2f554ebd83c73675c333[] = { 
stepfunc_24c959caaf784942d91df4934f9d1c45_3e6833f584fc2f554ebd83c73675c333,
stepfunc_579f2a6ac5473c37e1346f17e47cb5c6_3e6833f584fc2f554ebd83c73675c333,
stepfunc_579f2a6ac5473c37e1346f17e47cb5c6_3e6833f584fc2f554ebd83c73675c333,
stepfunc_579f2a6ac5473c37e1346f17e47cb5c6_3e6833f584fc2f554ebd83c73675c333,
stepfunc_579f2a6ac5473c37e1346f17e47cb5c6_3e6833f584fc2f554ebd83c73675c333,
stepfunc_579f2a6ac5473c37e1346f17e47cb5c6_3e6833f584fc2f554ebd83c73675c333,
stepfunc_579f2a6ac5473c37e1346f17e47cb5c6_3e6833f584fc2f554ebd83c73675c333,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_3e6833f584fc2f554ebd83c73675c333,
NULL}; 
extern const BulletStepFunc bullet_971ce4cf35831165dc4427f098d62063_3e6833f584fc2f554ebd83c73675c333[] = { 
stepfunc_954a269b040929a951e55eaf6239db26_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_3e6833f584fc2f554ebd83c73675c333,
NULL}; 
void stepfunc_579f2a6ac5473c37e1346f17e47cb5c6_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((-3.0)));  p->lastBulletSpeed = ((1.5 * (0.5 + 0.5 * 1.0)));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(4.0); 
}
void stepfunc_24c959caaf784942d91df4934f9d1c45_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((-90.0)));  p->lastBulletSpeed = ((1.5 * (0.5 + 0.5 * 1.0)));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(4.0); 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_000ad2a5d2a5a0897c650c800bf147cb_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_57dcf454df4bab3cfe500f57cce0a050_3e6833f584fc2f554ebd83c73675c333); 
  }
}
}
void stepfunc_7e28cc8374d7b707eb7239c7adafb419_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((3.0)));  p->lastBulletSpeed = ((1.5 * (0.5 + 0.5 * 1.0)));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(4.0); 
}
void stepfunc_20aa66f3f0b5006a13a5b98569a869dc_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((90.0)));  p->lastBulletSpeed = ((1.5 * (0.5 + 0.5 * 1.0)));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(4.0); 
}
void stepfunc_e0ccd969a4790bf60aae4d114a7f39bb_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_878bfd46c7f3d416a509e7725b0faa8e_3e6833f584fc2f554ebd83c73675c333); 
  }
}
}
void stepfunc_954a269b040929a951e55eaf6239db26_3e6833f584fc2f554ebd83c73675c333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(360.0 * FixedPointNum::random()));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_878bfd46c7f3d416a509e7725b0faa8e_3e6833f584fc2f554ebd83c73675c333); 
  }
}
}


BulletInfo *genBulletFunc_3e6833f584fc2f554ebd83c73675c333(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_971ce4cf35831165dc4427f098d62063_3e6833f584fc2f554ebd83c73675c333); 
  }
return bi;}


