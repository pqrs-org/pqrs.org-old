// XXX uniqID XXX 9fddd916a4bdce1577bc4e8beafadb8b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/easy-round-line.hpp" 

extern const BulletStepFunc bullet_41ab7381a3d54ae92089537db06ebf3d_9fddd916a4bdce1577bc4e8beafadb8b[] = { 
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_9fddd916a4bdce1577bc4e8beafadb8b,
NULL}; 
extern const BulletStepFunc bullet_08e84197717e6e61c7db927c0b261844_9fddd916a4bdce1577bc4e8beafadb8b[] = { 
stepfunc_a346a8d4d02a88f33001701926ee4d48_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_30c4f3c019cbe3f059e80224d713f453_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_b4457dfd258316236a932c31812a56db_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_b4457dfd258316236a932c31812a56db_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_b4457dfd258316236a932c31812a56db_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_9fddd916a4bdce1577bc4e8beafadb8b,
NULL}; 
extern const BulletStepFunc bullet_f64c578ead7c94241ecae5c47418d864_9fddd916a4bdce1577bc4e8beafadb8b[] = { 
stepfunc_aefb29de7427b46d96e2984da3359948_9fddd916a4bdce1577bc4e8beafadb8b,
NULL}; 
extern const BulletStepFunc bullet_bf8ff6a55ad88dee75202b6cf57c7f52_9fddd916a4bdce1577bc4e8beafadb8b[] = { 
stepfunc_c172a15bb6eca889f748350b364028cc_9fddd916a4bdce1577bc4e8beafadb8b,
stepfunc_0fdd59aa50ca3c3515c1b7e88bbab930_9fddd916a4bdce1577bc4e8beafadb8b,
NULL}; 
extern const BulletStepFunc bullet_b404482308b659e440a6f5b0cf6f1707_9fddd916a4bdce1577bc4e8beafadb8b[] = { 
stepfunc_55d3e170e59c65efe4f28a1faf252eb2_9fddd916a4bdce1577bc4e8beafadb8b,
NULL}; 
void stepfunc_c172a15bb6eca889f748350b364028cc_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_0fdd59aa50ca3c3515c1b7e88bbab930_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0)) - p->getAngle();p->setRound(speed, life);}
}
void stepfunc_2768f2b4be1b3e309cf1abe06c013fbb_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_bf8ff6a55ad88dee75202b6cf57c7f52_9fddd916a4bdce1577bc4e8beafadb8b); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_7a3f13ea9cbdc8ae8d58ee734bc8da3d_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_aefb29de7427b46d96e2984da3359948_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = ((1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 10; ++i) { 
stepfunc_7a3f13ea9cbdc8ae8d58ee734bc8da3d_9fddd916a4bdce1577bc4e8beafadb8b(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_b4457dfd258316236a932c31812a56db_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f64c578ead7c94241ecae5c47418d864_9fddd916a4bdce1577bc4e8beafadb8b); 
  }
}
p->wait = static_cast<u16>(120.0); 
}
void stepfunc_a346a8d4d02a88f33001701926ee4d48_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_30c4f3c019cbe3f059e80224d713f453_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.5 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = static_cast<u16>(200.0);  FixedPointNum speed = FixedPointNum::degree2angle(3.0);p->setRound(speed, life);}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_ade56c614a15d18311d29d69fba565a0_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_08e84197717e6e61c7db927c0b261844_9fddd916a4bdce1577bc4e8beafadb8b); 
  }
}
}
void stepfunc_55d3e170e59c65efe4f28a1faf252eb2_9fddd916a4bdce1577bc4e8beafadb8b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_41ab7381a3d54ae92089537db06ebf3d_9fddd916a4bdce1577bc4e8beafadb8b); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_9fddd916a4bdce1577bc4e8beafadb8b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_b404482308b659e440a6f5b0cf6f1707_9fddd916a4bdce1577bc4e8beafadb8b); 
  }
return bi;}


