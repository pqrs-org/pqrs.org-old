// XXX uniqID XXX 3956f53e0fa8316cb053b080649e6fbd XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "daiouzyou/hibachi_1.hpp" 

extern const BulletStepFunc bullet_e24edde112e7378f1a216ad6c9866473_3956f53e0fa8316cb053b080649e6fbd[] = { 
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_3956f53e0fa8316cb053b080649e6fbd,
NULL}; 
void stepfunc_136de4399b4d50e4ea5dc8f3f11a378a_3956f53e0fa8316cb053b080649e6fbd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(FixedPointNum::random()*30.0-74.0+1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(FixedPointNum::random()*2.0+7.0-1.0*2.0));  p->lastBulletSpeed = (0.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(14.0-1.0*10.0); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_3956f53e0fa8316cb053b080649e6fbd(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_3956f53e0fa8316cb053b080649e6fbd(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_e24edde112e7378f1a216ad6c9866473_3956f53e0fa8316cb053b080649e6fbd); 
  }
return bi;}


