// XXX uniqID XXX b6bae10db253c2c2c72e4d06013ab8ab XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/rand-spear.hpp" 

extern const BulletStepFunc bullet_680d49174d8dbf00786e3445fc952607_b6bae10db253c2c2c72e4d06013ab8ab[] = { 
stepfunc_c172a15bb6eca889f748350b364028cc_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_c2db9f05d4f182941e7e9906f14f63c0_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_b6bae10db253c2c2c72e4d06013ab8ab,
NULL}; 
extern const BulletStepFunc bullet_61089479a14698815cdbaf359b6cba3c_b6bae10db253c2c2c72e4d06013ab8ab[] = { 
stepfunc_b9f3746024faf71a948d02a3f58cba12_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_15670c3dbbd432b0b029421922fd7894_b6bae10db253c2c2c72e4d06013ab8ab,
NULL}; 
extern const BulletStepFunc bullet_75877e426e18d2eb28ac4693acb08709_b6bae10db253c2c2c72e4d06013ab8ab[] = { 
stepfunc_eea4b0247fbf385b5ae27d1012d30544_b6bae10db253c2c2c72e4d06013ab8ab,
NULL}; 
extern const BulletStepFunc bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab[] = { 
stepfunc_8fff89501dcb48caade16bb16deb7b61_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_b6bae10db253c2c2c72e4d06013ab8ab,
NULL}; 
extern const BulletStepFunc bullet_ce0c6ca4cc4e9e377808660c7bf7d04a_b6bae10db253c2c2c72e4d06013ab8ab[] = { 
stepfunc_75f213cad9d8cbebd5f40201e798b8e3_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_75f213cad9d8cbebd5f40201e798b8e3_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_75f213cad9d8cbebd5f40201e798b8e3_b6bae10db253c2c2c72e4d06013ab8ab,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_b6bae10db253c2c2c72e4d06013ab8ab,
NULL}; 
void stepfunc_8fff89501dcb48caade16bb16deb7b61_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(40.0);  FixedPointNum speed = 0.2;p->setAccel(speed, life);}
}
void stepfunc_eea4b0247fbf385b5ae27d1012d30544_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a89d93fdc969532066c9a6c08f8b364_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_15670c3dbbd432b0b029421922fd7894_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_75877e426e18d2eb28ac4693acb08709_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_b10d9d9064969247bfa55043d224d74f_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(360.0*FixedPointNum::random()));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_SMALL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_61089479a14698815cdbaf359b6cba3c_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_c172a15bb6eca889f748350b364028cc_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_c2db9f05d4f182941e7e9906f14f63c0_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_75f213cad9d8cbebd5f40201e798b8e3_b6bae10db253c2c2c72e4d06013ab8ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_680d49174d8dbf00786e3445fc952607_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
}
p->wait = static_cast<u16>(120.0); 
}


BulletInfo *genBulletFunc_b6bae10db253c2c2c72e4d06013ab8ab(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_ce0c6ca4cc4e9e377808660c7bf7d04a_b6bae10db253c2c2c72e4d06013ab8ab); 
  }
return bi;}


