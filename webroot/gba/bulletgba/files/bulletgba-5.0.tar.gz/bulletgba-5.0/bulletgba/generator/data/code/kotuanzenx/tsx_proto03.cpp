// XXX uniqID XXX d66b2dfd97443d7881cd41327638670d XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx_proto03.hpp" 

extern const BulletStepFunc bullet_40ef74039a6d02c3b060660331f7d03d_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_10c3a88a8e44bab5c0812abd588467e2_d66b2dfd97443d7881cd41327638670d,
stepfunc_6536e4546bdcfcf651852434db03b678_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_0177664d4bd1d008e2786f153c546ccc_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_10c3a88a8e44bab5c0812abd588467e2_d66b2dfd97443d7881cd41327638670d,
stepfunc_6536e4546bdcfcf651852434db03b678_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_f35005dda93d6100902ad47d76705fcd_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_9c2a3ce6b91e6099a8005f1aa83f94c6_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_9930f1d102942314ea1e3391cd647e65_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_be61072ced3ae5c69115961b3f5acd2d_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_f5ebf109585aa015dc154cf6db392fa9_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_32ed45228dd0d7331f20d5bf4a07aef1_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_e13b10033dc1b65a8be0c623a8de0f51_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_c9a1ce30507de87584bb644f2b75338e_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_209174eb5fd715ee6ff8fbbcffc77a87_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_0ad88355da05177d367427fdbe4e63b9_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_8560f58dcbb1a539b96bbd21a935adbc_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_eba3c310548c07d8e129d92ab75b5783_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_132fe74a000f6cdf459ab729d0a33864_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_5f24dc9e56d3822748a8e48c4795ff48_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_d5b895e2dbfaa96ec5b8638b848a4ea9_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_6c9aef6dea7b14b163bfdb1608ee7df0_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_1beff4e2a1cf5379f22a6d6789d43a9d_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_5212655d3108478e1032cba040f78ac9_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_6668485d6ffed303dabc1a144c1959e5_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_d3768310bd469b38860abf2c55b2dbda_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_d405956db52e4fc050cf8a4e34e12ef1_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_1c31356784e72e00138f3f6d119d1dca_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_deba902befdc25129a6ed77559f09dc2_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_f782f453f6ad9c23ff2b1121ad31a875_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_41e320ae6c7ac38ea1a4ab3823e331fa_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_4fa23d879fa0491f8b07c7a8eb4b2285_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_327e2759172b196e217fe55d834dacad_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_30eaa70ca5c6fb38ae22209177ae7065_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_d42d9da7886b11f3e879ea5a8928a7ef_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_c2462046f27d2f862239b7f49ab1fc71_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_cdac718b1bb6879649f97bfae7cbb877_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_4c421aa1f952fa217fde3b1972c6a4a3_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_57e9be9abc1dc95582e0a562f0a2f081_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_ed97661496fd6ddab2aa559a5c254cbb_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_df1684e32e7e11d448dcfb652f4d7b86_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_77d11f8386c4595bdf9c28562763a67e_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_11a48686267db24e097b43181b098062_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_a1d4e25bda33a6d127915d20f01f88a2_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_4adced4f4a8a88d04d94ed473ee5d3bb_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_4137f33ca3e1b1cbb668a7f08b2df27a_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_3f220b99fb0d7b58e2e407452380a919_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_7cf8fc93aed0c410ef629bd104fb087e_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_a99c16420eaeb04cacec19f0116423a3_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_5193acd15d1427568861719f5b959fdd_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_2ebede46064ec5172b91c70494767513_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_6617a9ca47a4756575d42c51bcef6f44_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_e861ef26901315ac6b0423eef30c288f_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_a4fe785b89eb40e718be26adc1c2a360_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_e98f633c6ff029aced23cc6a2c15f0d3_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_3b1f7b3ae652d28a643b9962cd0097ee_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_8cd28f58d8cab9b0cd93332211c6e2f5_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_5fd919062339d7235508fb1a908aa3ae_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_e0ba9efc946fd29f19119c50bb88f485_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_34acfb9e73e83b3e596e258c766402f2_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_38fe4376c3365756922a75521bcbe5aa_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_dde1c606d39d480bd252dce44813a6de_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_55dd9def8404fa11686f2a2f695a70ce_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_eedb512eef06b1fc7ad10b24987e5037_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_8a84d7319a4c3e8b4850e3fa354a9034_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d,
stepfunc_952edcc429b0eea008b651e4440e8909_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_b19c7c448c522bdadc6599146c98e994_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_9cab9c78511c471d60633a41a0ab5fa0_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_53c07428be47cf74dec373d97e8ead5d_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_b7e3c4ce063b770d5b9f21e507bcbf7b_d66b2dfd97443d7881cd41327638670d,
NULL}; 
extern const BulletStepFunc bullet_e195bc9ac1955de0018740752367f5e5_d66b2dfd97443d7881cd41327638670d[] = { 
stepfunc_dc97d133675f06225d69e8c4ca840916_d66b2dfd97443d7881cd41327638670d,
stepfunc_51faedaa03706034ae73ccf08ddf5a82_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d,
stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_d66b2dfd97443d7881cd41327638670d,
NULL}; 
void stepfunc_ae28776ef42d7ff2045aa76bcbdd6f9d_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((8.0)*-1.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_9cab9c78511c471d60633a41a0ab5fa0_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((8.0)*3.0));  p->lastBulletSpeed = (1.0+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_ae28776ef42d7ff2045aa76bcbdd6f9d_d66b2dfd97443d7881cd41327638670d(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_d803b58b96b9c74b680b0672f1c602c6_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((2.0)*-1.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_b7e3c4ce063b770d5b9f21e507bcbf7b_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((2.0)*3.0));  p->lastBulletSpeed = (1.0+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_d803b58b96b9c74b680b0672f1c602c6_d66b2dfd97443d7881cd41327638670d(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_a6598fe0d55fb8e0a39c9c48547a87a5_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_53c07428be47cf74dec373d97e8ead5d_d66b2dfd97443d7881cd41327638670d); 
  }
}
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_dd15267a9176cd57557e8d5297920c23_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b19c7c448c522bdadc6599146c98e994_d66b2dfd97443d7881cd41327638670d); 
  }
}
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_4137f33ca3e1b1cbb668a7f08b2df27a_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((2.8)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(30.0);  FixedPointNum speed = FixedPointNum(0.0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_7cf8fc93aed0c410ef629bd104fb087e_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4adced4f4a8a88d04d94ed473ee5d3bb_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((3.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4adced4f4a8a88d04d94ed473ee5d3bb_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_a1d4e25bda33a6d127915d20f01f88a2_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((2.6)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_5193acd15d1427568861719f5b959fdd_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11a48686267db24e097b43181b098062_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((6.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11a48686267db24e097b43181b098062_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_77d11f8386c4595bdf9c28562763a67e_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((2.4)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_6617a9ca47a4756575d42c51bcef6f44_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_df1684e32e7e11d448dcfb652f4d7b86_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((9.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_df1684e32e7e11d448dcfb652f4d7b86_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_ed97661496fd6ddab2aa559a5c254cbb_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((2.2)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_a4fe785b89eb40e718be26adc1c2a360_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_57e9be9abc1dc95582e0a562f0a2f081_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((12.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_57e9be9abc1dc95582e0a562f0a2f081_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_4c421aa1f952fa217fde3b1972c6a4a3_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((2.0)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_3b1f7b3ae652d28a643b9962cd0097ee_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cdac718b1bb6879649f97bfae7cbb877_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((15.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cdac718b1bb6879649f97bfae7cbb877_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_c2462046f27d2f862239b7f49ab1fc71_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((1.8)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_5fd919062339d7235508fb1a908aa3ae_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d42d9da7886b11f3e879ea5a8928a7ef_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((18.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d42d9da7886b11f3e879ea5a8928a7ef_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_30eaa70ca5c6fb38ae22209177ae7065_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((1.6)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_34acfb9e73e83b3e596e258c766402f2_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_327e2759172b196e217fe55d834dacad_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((21.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_327e2759172b196e217fe55d834dacad_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_4fa23d879fa0491f8b07c7a8eb4b2285_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((1.4)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_dde1c606d39d480bd252dce44813a6de_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_41e320ae6c7ac38ea1a4ab3823e331fa_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((24.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_41e320ae6c7ac38ea1a4ab3823e331fa_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_f782f453f6ad9c23ff2b1121ad31a875_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((1.2)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_eedb512eef06b1fc7ad10b24987e5037_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_deba902befdc25129a6ed77559f09dc2_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((27.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_deba902befdc25129a6ed77559f09dc2_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_1c31356784e72e00138f3f6d119d1dca_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum((((1.0)))+1.0*2.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_952edcc429b0eea008b651e4440e8909_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d405956db52e4fc050cf8a4e34e12ef1_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((30.0)))*(((-1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d405956db52e4fc050cf8a4e34e12ef1_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_47495ee117117ae5fa49286ac537ac6e_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((0.48));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8a84d7319a4c3e8b4850e3fa354a9034_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((0.96));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_55dd9def8404fa11686f2a2f695a70ce_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((1.44));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_38fe4376c3365756922a75521bcbe5aa_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((1.92));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e0ba9efc946fd29f19119c50bb88f485_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((2.40));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8cd28f58d8cab9b0cd93332211c6e2f5_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((2.88));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e98f633c6ff029aced23cc6a2c15f0d3_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((3.36));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e861ef26901315ac6b0423eef30c288f_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((3.84));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2ebede46064ec5172b91c70494767513_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((4.32));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a99c16420eaeb04cacec19f0116423a3_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((-1.0))));  p->lastBulletSpeed = ((4.80));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_3f220b99fb0d7b58e2e407452380a919_d66b2dfd97443d7881cd41327638670d); 
  }
}
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_10c3a88a8e44bab5c0812abd588467e2_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
p->wait = static_cast<u16>(9.0); 
}
void stepfunc_6536e4546bdcfcf651852434db03b678_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_9c2a3ce6b91e6099a8005f1aa83f94c6_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4adced4f4a8a88d04d94ed473ee5d3bb_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((3.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4adced4f4a8a88d04d94ed473ee5d3bb_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_be61072ced3ae5c69115961b3f5acd2d_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11a48686267db24e097b43181b098062_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((6.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11a48686267db24e097b43181b098062_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_32ed45228dd0d7331f20d5bf4a07aef1_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_df1684e32e7e11d448dcfb652f4d7b86_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((9.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_df1684e32e7e11d448dcfb652f4d7b86_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_c9a1ce30507de87584bb644f2b75338e_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_57e9be9abc1dc95582e0a562f0a2f081_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((12.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_57e9be9abc1dc95582e0a562f0a2f081_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_0ad88355da05177d367427fdbe4e63b9_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cdac718b1bb6879649f97bfae7cbb877_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((15.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cdac718b1bb6879649f97bfae7cbb877_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_eba3c310548c07d8e129d92ab75b5783_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d42d9da7886b11f3e879ea5a8928a7ef_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((18.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d42d9da7886b11f3e879ea5a8928a7ef_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_5f24dc9e56d3822748a8e48c4795ff48_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_327e2759172b196e217fe55d834dacad_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((21.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_327e2759172b196e217fe55d834dacad_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_6c9aef6dea7b14b163bfdb1608ee7df0_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_41e320ae6c7ac38ea1a4ab3823e331fa_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((24.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_41e320ae6c7ac38ea1a4ab3823e331fa_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_5212655d3108478e1032cba040f78ac9_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_deba902befdc25129a6ed77559f09dc2_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((27.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_deba902befdc25129a6ed77559f09dc2_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_d3768310bd469b38860abf2c55b2dbda_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d405956db52e4fc050cf8a4e34e12ef1_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((164.0+((30.0)))*(((1.0)))));  p->lastBulletSpeed = p->getSpeed() + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d405956db52e4fc050cf8a4e34e12ef1_d66b2dfd97443d7881cd41327638670d); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_9a5094473a30c8a995a961384b39a339_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((0.48));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6668485d6ffed303dabc1a144c1959e5_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((0.96));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1beff4e2a1cf5379f22a6d6789d43a9d_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((1.44));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d5b895e2dbfaa96ec5b8638b848a4ea9_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((1.92));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_132fe74a000f6cdf459ab729d0a33864_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((2.40));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8560f58dcbb1a539b96bbd21a935adbc_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((2.88));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_209174eb5fd715ee6ff8fbbcffc77a87_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((3.36));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e13b10033dc1b65a8be0c623a8de0f51_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((3.84));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5ebf109585aa015dc154cf6db392fa9_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((4.32));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9930f1d102942314ea1e3391cd647e65_d66b2dfd97443d7881cd41327638670d); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(35.0*((1.0))));  p->lastBulletSpeed = ((4.80));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f35005dda93d6100902ad47d76705fcd_d66b2dfd97443d7881cd41327638670d); 
  }
}
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_dc97d133675f06225d69e8c4ca840916_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(110.0*(1.0)));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0177664d4bd1d008e2786f153c546ccc_d66b2dfd97443d7881cd41327638670d); 
  }
}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_51faedaa03706034ae73ccf08ddf5a82_d66b2dfd97443d7881cd41327638670d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(110.0*(-1.0)));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_40ef74039a6d02c3b060660331f7d03d_d66b2dfd97443d7881cd41327638670d); 
  }
}
}


BulletInfo *genBulletFunc_d66b2dfd97443d7881cd41327638670d(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_e195bc9ac1955de0018740752367f5e5_d66b2dfd97443d7881cd41327638670d); 
  }
return bi;}


