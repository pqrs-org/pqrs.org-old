// XXX uniqID XXX c51998a9446860818c4c78a406bd9b23 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/bb10-doublebody.hpp" 

extern const BulletStepFunc bullet_9ce92243f74c7028a1716db573ac0054_c51998a9446860818c4c78a406bd9b23[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23,
stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23,
stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_c51998a9446860818c4c78a406bd9b23,
NULL}; 
extern const BulletStepFunc bullet_0ebea615ebd903e77e22640c8ef4856b_c51998a9446860818c4c78a406bd9b23[] = { 
stepfunc_13aa4638da0dd9414673c77032bba749_c51998a9446860818c4c78a406bd9b23,
stepfunc_960e7f3735019e4c445aa59741237fef_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23,
stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23,
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_c51998a9446860818c4c78a406bd9b23,
NULL}; 
void stepfunc_3491256c43b05cb1ba4cb801973a724f_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(1.0));  p->lastBulletSpeed = (1.0+0.4*1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_fbca86bc71d73074d1be1413ca166601_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
for (u32 i = 0; i < 17; ++i) { 
stepfunc_3491256c43b05cb1ba4cb801973a724f_c51998a9446860818c4c78a406bd9b23(p);}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(18.0));  p->lastBulletSpeed = (1.0+0.4*1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_be96ec69e5012af27f30e5ce968967df_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(-1.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_2196d879f66529c3cf3034d2092c7c9c_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
for (u32 i = 0; i < 17; ++i) { 
stepfunc_be96ec69e5012af27f30e5ce968967df_c51998a9446860818c4c78a406bd9b23(p);}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_7424e8b218d3bd101c65f652976c7b7f_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(-18.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-15.0));  p->lastBulletSpeed = (0.7+1.0*1.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-5.0));  p->lastBulletSpeed = (0.7+1.0*1.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(5.0));  p->lastBulletSpeed = (0.7+1.0*1.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(15.0));  p->lastBulletSpeed = (0.7+1.0*1.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_9538014c64f1ddabbe581babf4685107_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-20.0));  p->lastBulletSpeed = (0.7+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-10.0));  p->lastBulletSpeed = (0.7+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.7+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (0.7+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(20.0));  p->lastBulletSpeed = (0.7+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_faeb9ac81b7a64ffed123259883c3994_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_8c6b914b881b0800d2914da88568f3d6_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
p->wait = static_cast<u16>(40.0); 
}
void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(30.0);  FixedPointNum speed = FixedPointNum(0.0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_13aa4638da0dd9414673c77032bba749_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((70.0)));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9ce92243f74c7028a1716db573ac0054_c51998a9446860818c4c78a406bd9b23); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((290.0)));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9ce92243f74c7028a1716db573ac0054_c51998a9446860818c4c78a406bd9b23); 
  }
}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_960e7f3735019e4c445aa59741237fef_c51998a9446860818c4c78a406bd9b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}


BulletInfo *genBulletFunc_c51998a9446860818c4c78a406bd9b23(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_0ebea615ebd903e77e22640c8ef4856b_c51998a9446860818c4c78a406bd9b23); 
  }
return bi;}


