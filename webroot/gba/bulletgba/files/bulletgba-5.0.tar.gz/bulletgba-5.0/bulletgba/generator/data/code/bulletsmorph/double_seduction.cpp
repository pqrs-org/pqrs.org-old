// XXX uniqID XXX e88aeb37a2ec76b4a86215c15c013d7e XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "bulletsmorph/double_seduction.hpp" 

extern const BulletStepFunc bullet_1109bb4cb865899f8201089a32355036_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_26101d50173259c8ab68b98272eaa417_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_76153b1974208141dcce0958dc38141f_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_9aec233d182da3d0be4bf3f992b05b2b_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_e4ff31a8b206ccea4bff925a6ac437f3_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_481de4a4e8f49b171fab2501a1f092e4_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_bf797573cfc1c0936e66bd01ae1a2f16_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_38f66f9b3f23ada172121e87716d92e9_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_01758b813f5d8d4ce94c3dc337ec33c1_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_199b3413494ae8aa21c2ac262a7411de_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_97515f27bebcee76332b63e179cf8de4_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_f14d17ca349ea587fa84c30e4bc657fa_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_481de4a4e8f49b171fab2501a1f092e4_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_ef125d0e9dc083622b656074a0d2db7a_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_26101d50173259c8ab68b98272eaa417_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_76153b1974208141dcce0958dc38141f_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_9aec233d182da3d0be4bf3f992b05b2b_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_e4ff31a8b206ccea4bff925a6ac437f3_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_481de4a4e8f49b171fab2501a1f092e4_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_bf797573cfc1c0936e66bd01ae1a2f16_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_bdb4f1520ff1b4a425d0371612a8748f_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_1f35be9cb5f916d7305b8818bdc8d5d6_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_4ff26826e0ab54843a4411088ea95693_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_d6068e9f8294597788ed36d0918e6386_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_977299317fab14a748a4c017fcba34a7_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_481de4a4e8f49b171fab2501a1f092e4_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_9ccef7caf23c8fba0410725dccb3e913_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_27b44ec9237c5b0d5cc61b83dcf390c6_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_ceee1ec746368867a48e1c8b1d6bb64c_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_6a0861f3b29204e6789095f78ba218bd_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_a56b783b7d312bc55eb8213a16933c15_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_974b7933558104b302f848597a7e1267_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_92bd7c293fe85b08201c79b097fe4fad_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_1440e47e2b75c90dedec0e18cc73656b_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_89da1d1f9a7197fc4579690f6becfc07_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_de7254a3285f16f973088d20913e9d43_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_227d4848aeb793a15f767732b60f258c_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_2893ec47d2ec536e6be7a443e0fa2ad1_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_5a7942de676b85b1b56227d099001d26_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_7f83a3d35d4b5dfae5b2de681971bb74_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_6e2b8a74114f791de2a3af533c603110_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_cc47ee69e4a13eede0ba3af173cd42e4_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_27b44ec9237c5b0d5cc61b83dcf390c6_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_eba27d741782d32b11c937e53b96565c_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_20e15e20b88891eb978e2b9dc1c8be07_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_a56b783b7d312bc55eb8213a16933c15_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_b23550e8c62d5008263cef4ea116835a_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_59c0673e6871eaa9d3f5527507ea0bac_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_1440e47e2b75c90dedec0e18cc73656b_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_e0cc3cb96d93a85f405922d3872268f3_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_80b9a5b8aba8e2ed274f89c349f083da_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_227d4848aeb793a15f767732b60f258c_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_eb8d6e04dfe4def55cdd89422d6b244c_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_8fc0abfceb91e520a499b6a72ab9dde6_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_7f83a3d35d4b5dfae5b2de681971bb74_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_2ab98ac96405f46af65c375301ff1aab_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_c9e94d5899042cd31e8c3730eb18990d_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_94cf6e0b24f0068332e201ebda090d9f_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_1a90263b0d3ca6446b8d971065f385e6_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_af50b57f6e4e3df31e42f006bb3dc574_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_62edfe97229772b9ec79b75a34de92df_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_1a90263b0d3ca6446b8d971065f385e6_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_5a935cc5fd54ae830242311626d5957c_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_27b44ec9237c5b0d5cc61b83dcf390c6_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_1a90263b0d3ca6446b8d971065f385e6_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_f54db40f340bac413ca53943c18125a5_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_a56b783b7d312bc55eb8213a16933c15_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_1a90263b0d3ca6446b8d971065f385e6_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_289bf3ed750ac352edb5ff35453395f7_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_1440e47e2b75c90dedec0e18cc73656b_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_1a90263b0d3ca6446b8d971065f385e6_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_11fe24f4619a9b1771c0abe9beb46ac1_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_227d4848aeb793a15f767732b60f258c_e88aeb37a2ec76b4a86215c15c013d7e,
stepfunc_1a90263b0d3ca6446b8d971065f385e6_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
extern const BulletStepFunc bullet_108e8205807842f3e189584faf09233e_e88aeb37a2ec76b4a86215c15c013d7e[] = { 
stepfunc_08eb440f1d05c1b67229dfd98fa2b564_e88aeb37a2ec76b4a86215c15c013d7e,
NULL}; 
void stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_62edfe97229772b9ec79b75a34de92df_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
p->wait = static_cast<u16>(((55.0))); 
}
void stepfunc_1a90263b0d3ca6446b8d971065f385e6_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((0.0))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_27b44ec9237c5b0d5cc61b83dcf390c6_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
p->wait = static_cast<u16>(((60.0))); 
}
void stepfunc_eba27d741782d32b11c937e53b96565c_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((1.0 * (-1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_a56b783b7d312bc55eb8213a16933c15_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
p->wait = static_cast<u16>(((65.0))); 
}
void stepfunc_b23550e8c62d5008263cef4ea116835a_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((3.0 * (-1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_1440e47e2b75c90dedec0e18cc73656b_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
p->wait = static_cast<u16>(((70.0))); 
}
void stepfunc_e0cc3cb96d93a85f405922d3872268f3_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((6.0 * (-1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_227d4848aeb793a15f767732b60f258c_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
p->wait = static_cast<u16>(((75.0))); 
}
void stepfunc_eb8d6e04dfe4def55cdd89422d6b244c_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((10.0 * (-1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_7f83a3d35d4b5dfae5b2de681971bb74_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
p->wait = static_cast<u16>(((80.0))); 
}
void stepfunc_2ab98ac96405f46af65c375301ff1aab_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((15.0 * (-1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_94cf6e0b24f0068332e201ebda090d9f_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
p->wait = static_cast<u16>(((50.0))); 
}
void stepfunc_26101d50173259c8ab68b98272eaa417_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11fe24f4619a9b1771c0abe9beb46ac1_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11fe24f4619a9b1771c0abe9beb46ac1_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11fe24f4619a9b1771c0abe9beb46ac1_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_11fe24f4619a9b1771c0abe9beb46ac1_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_76153b1974208141dcce0958dc38141f_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_289bf3ed750ac352edb5ff35453395f7_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_289bf3ed750ac352edb5ff35453395f7_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_289bf3ed750ac352edb5ff35453395f7_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_289bf3ed750ac352edb5ff35453395f7_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_9aec233d182da3d0be4bf3f992b05b2b_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f54db40f340bac413ca53943c18125a5_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f54db40f340bac413ca53943c18125a5_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f54db40f340bac413ca53943c18125a5_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f54db40f340bac413ca53943c18125a5_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_e4ff31a8b206ccea4bff925a6ac437f3_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a935cc5fd54ae830242311626d5957c_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a935cc5fd54ae830242311626d5957c_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a935cc5fd54ae830242311626d5957c_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a935cc5fd54ae830242311626d5957c_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_481de4a4e8f49b171fab2501a1f092e4_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_af50b57f6e4e3df31e42f006bb3dc574_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_af50b57f6e4e3df31e42f006bb3dc574_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_af50b57f6e4e3df31e42f006bb3dc574_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_af50b57f6e4e3df31e42f006bb3dc574_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_bf797573cfc1c0936e66bd01ae1a2f16_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c9e94d5899042cd31e8c3730eb18990d_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c9e94d5899042cd31e8c3730eb18990d_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c9e94d5899042cd31e8c3730eb18990d_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c9e94d5899042cd31e8c3730eb18990d_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_38f66f9b3f23ada172121e87716d92e9_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8fc0abfceb91e520a499b6a72ab9dde6_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8fc0abfceb91e520a499b6a72ab9dde6_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8fc0abfceb91e520a499b6a72ab9dde6_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8fc0abfceb91e520a499b6a72ab9dde6_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_01758b813f5d8d4ce94c3dc337ec33c1_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_80b9a5b8aba8e2ed274f89c349f083da_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_80b9a5b8aba8e2ed274f89c349f083da_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_80b9a5b8aba8e2ed274f89c349f083da_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_80b9a5b8aba8e2ed274f89c349f083da_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_199b3413494ae8aa21c2ac262a7411de_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_59c0673e6871eaa9d3f5527507ea0bac_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_59c0673e6871eaa9d3f5527507ea0bac_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_59c0673e6871eaa9d3f5527507ea0bac_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_59c0673e6871eaa9d3f5527507ea0bac_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_97515f27bebcee76332b63e179cf8de4_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_20e15e20b88891eb978e2b9dc1c8be07_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_20e15e20b88891eb978e2b9dc1c8be07_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_20e15e20b88891eb978e2b9dc1c8be07_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_20e15e20b88891eb978e2b9dc1c8be07_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_f14d17ca349ea587fa84c30e4bc657fa_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cc47ee69e4a13eede0ba3af173cd42e4_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cc47ee69e4a13eede0ba3af173cd42e4_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cc47ee69e4a13eede0ba3af173cd42e4_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cc47ee69e4a13eede0ba3af173cd42e4_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_ceee1ec746368867a48e1c8b1d6bb64c_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((1.0 * (1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_974b7933558104b302f848597a7e1267_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((3.0 * (1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_89da1d1f9a7197fc4579690f6becfc07_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((6.0 * (1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_2893ec47d2ec536e6be7a443e0fa2ad1_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((10.0 * (1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_6e2b8a74114f791de2a3af533c603110_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(((15.0 * (1.0)))));  p->lastBulletSpeed = (1.6 * (0.5 + 0.5 * 1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338_e88aeb37a2ec76b4a86215c15c013d7e(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_bdb4f1520ff1b4a425d0371612a8748f_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a7942de676b85b1b56227d099001d26_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a7942de676b85b1b56227d099001d26_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a7942de676b85b1b56227d099001d26_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5a7942de676b85b1b56227d099001d26_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_1f35be9cb5f916d7305b8818bdc8d5d6_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_de7254a3285f16f973088d20913e9d43_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_de7254a3285f16f973088d20913e9d43_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_de7254a3285f16f973088d20913e9d43_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_de7254a3285f16f973088d20913e9d43_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_4ff26826e0ab54843a4411088ea95693_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_92bd7c293fe85b08201c79b097fe4fad_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_92bd7c293fe85b08201c79b097fe4fad_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_92bd7c293fe85b08201c79b097fe4fad_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_92bd7c293fe85b08201c79b097fe4fad_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_d6068e9f8294597788ed36d0918e6386_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6a0861f3b29204e6789095f78ba218bd_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6a0861f3b29204e6789095f78ba218bd_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6a0861f3b29204e6789095f78ba218bd_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6a0861f3b29204e6789095f78ba218bd_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_977299317fab14a748a4c017fcba34a7_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9ccef7caf23c8fba0410725dccb3e913_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9ccef7caf23c8fba0410725dccb3e913_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9ccef7caf23c8fba0410725dccb3e913_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9ccef7caf23c8fba0410725dccb3e913_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_08eb440f1d05c1b67229dfd98fa2b564_e88aeb37a2ec76b4a86215c15c013d7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(30.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ef125d0e9dc083622b656074a0d2db7a_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-30.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1109bb4cb865899f8201089a32355036_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_e88aeb37a2ec76b4a86215c15c013d7e(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_108e8205807842f3e189584faf09233e_e88aeb37a2ec76b4a86215c15c013d7e); 
  }
return bi;}


