// XXX uniqID XXX 97b41852e7de9d3bc167753276079fd3 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/easy-round-downline.hpp" 

extern const BulletStepFunc bullet_c5eaad1797f249efe0b8482d16d71ac8_97b41852e7de9d3bc167753276079fd3[] = { 
stepfunc_72253f16e0c3e71ffa1d4be4c5e0e23f_97b41852e7de9d3bc167753276079fd3,
stepfunc_d61148d6a8733372b0866f4ea8f11a47_97b41852e7de9d3bc167753276079fd3,
stepfunc_d61148d6a8733372b0866f4ea8f11a47_97b41852e7de9d3bc167753276079fd3,
stepfunc_d61148d6a8733372b0866f4ea8f11a47_97b41852e7de9d3bc167753276079fd3,
stepfunc_d61148d6a8733372b0866f4ea8f11a47_97b41852e7de9d3bc167753276079fd3,
stepfunc_d61148d6a8733372b0866f4ea8f11a47_97b41852e7de9d3bc167753276079fd3,
stepfunc_43b90c1ea803c11e90f075e19525944b_97b41852e7de9d3bc167753276079fd3,
stepfunc_7750912abfc0fbcfe1f4f399f7e756be_97b41852e7de9d3bc167753276079fd3,
stepfunc_7750912abfc0fbcfe1f4f399f7e756be_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_97b41852e7de9d3bc167753276079fd3,
NULL}; 
extern const BulletStepFunc bullet_ca0f345433187ab04bbf42bc3e19799d_97b41852e7de9d3bc167753276079fd3[] = { 
stepfunc_16193720fedcc607d5f7c9736d53a5a0_97b41852e7de9d3bc167753276079fd3,
stepfunc_ef7ef7f2cf0818ea7943788e94373cc6_97b41852e7de9d3bc167753276079fd3,
stepfunc_ef7ef7f2cf0818ea7943788e94373cc6_97b41852e7de9d3bc167753276079fd3,
stepfunc_ef7ef7f2cf0818ea7943788e94373cc6_97b41852e7de9d3bc167753276079fd3,
stepfunc_ef7ef7f2cf0818ea7943788e94373cc6_97b41852e7de9d3bc167753276079fd3,
stepfunc_ef7ef7f2cf0818ea7943788e94373cc6_97b41852e7de9d3bc167753276079fd3,
stepfunc_43b90c1ea803c11e90f075e19525944b_97b41852e7de9d3bc167753276079fd3,
stepfunc_7750912abfc0fbcfe1f4f399f7e756be_97b41852e7de9d3bc167753276079fd3,
stepfunc_7750912abfc0fbcfe1f4f399f7e756be_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_97b41852e7de9d3bc167753276079fd3,
NULL}; 
extern const BulletStepFunc bullet_e8d767bb9ccb55cb10840eb5563b3cb1_97b41852e7de9d3bc167753276079fd3[] = { 
stepfunc_63abc839da541683e8509b293ea10416_97b41852e7de9d3bc167753276079fd3,
NULL}; 
extern const BulletStepFunc bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3[] = { 
stepfunc_8fff89501dcb48caade16bb16deb7b61_97b41852e7de9d3bc167753276079fd3,
stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_97b41852e7de9d3bc167753276079fd3,
NULL}; 
extern const BulletStepFunc bullet_178173508e04c04d9ea99ab21e487fac_97b41852e7de9d3bc167753276079fd3[] = { 
stepfunc_cfbffca500046e9205aaea0eee7c2563_97b41852e7de9d3bc167753276079fd3,
NULL}; 
extern const BulletStepFunc bullet_b8fcd200c8133e8885a91a666fe62c27_97b41852e7de9d3bc167753276079fd3[] = { 
stepfunc_aeed2281cb13dc4200b18bce60b3ab17_97b41852e7de9d3bc167753276079fd3,
stepfunc_aeed2281cb13dc4200b18bce60b3ab17_97b41852e7de9d3bc167753276079fd3,
stepfunc_aeed2281cb13dc4200b18bce60b3ab17_97b41852e7de9d3bc167753276079fd3,
stepfunc_aeed2281cb13dc4200b18bce60b3ab17_97b41852e7de9d3bc167753276079fd3,
stepfunc_aeed2281cb13dc4200b18bce60b3ab17_97b41852e7de9d3bc167753276079fd3,
stepfunc_aeed2281cb13dc4200b18bce60b3ab17_97b41852e7de9d3bc167753276079fd3,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_97b41852e7de9d3bc167753276079fd3,
NULL}; 
void stepfunc_a687886e84743dd3c7fe8d55c3a8d7eb_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((90.0)));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_7a3f13ea9cbdc8ae8d58ee734bc8da3d_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_cfbffca500046e9205aaea0eee7c2563_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = ((1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_7a3f13ea9cbdc8ae8d58ee734bc8da3d_97b41852e7de9d3bc167753276079fd3(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_7750912abfc0fbcfe1f4f399f7e756be_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_178173508e04c04d9ea99ab21e487fac_97b41852e7de9d3bc167753276079fd3); 
  }
}
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_8fff89501dcb48caade16bb16deb7b61_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(40.0);  FixedPointNum speed = 0.2;p->setAccel(speed, life);}
}
void stepfunc_63abc839da541683e8509b293ea10416_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0f315ff05ea3e42e95d840f4d4e4d3cf_97b41852e7de9d3bc167753276079fd3); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_d61148d6a8733372b0866f4ea8f11a47_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((90.0)));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e8d767bb9ccb55cb10840eb5563b3cb1_97b41852e7de9d3bc167753276079fd3); 
  }
}
p->wait = static_cast<u16>(45.0); 
}
void stepfunc_72253f16e0c3e71ffa1d4be4c5e0e23f_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(999.0);  FixedPointNum speed = FixedPointNum::degree2angle(-1.0);p->setRound(speed, life);}
p->wait = static_cast<u16>(120.0); 
}
void stepfunc_43b90c1ea803c11e90f075e19525944b_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
p->wait = static_cast<u16>(150.0); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_4ae1374257e81f61443f9ef99869ad01_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((270.0)));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_ef7ef7f2cf0818ea7943788e94373cc6_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((270.0)));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e8d767bb9ccb55cb10840eb5563b3cb1_97b41852e7de9d3bc167753276079fd3); 
  }
}
p->wait = static_cast<u16>(45.0); 
}
void stepfunc_16193720fedcc607d5f7c9736d53a5a0_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(999.0);  FixedPointNum speed = FixedPointNum::degree2angle(1.0);p->setRound(speed, life);}
p->wait = static_cast<u16>(120.0); 
}
void stepfunc_aeed2281cb13dc4200b18bce60b3ab17_97b41852e7de9d3bc167753276079fd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ca0f345433187ab04bbf42bc3e19799d_97b41852e7de9d3bc167753276079fd3); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c5eaad1797f249efe0b8482d16d71ac8_97b41852e7de9d3bc167753276079fd3); 
  }
}
p->wait = static_cast<u16>(60.0); 
}


BulletInfo *genBulletFunc_97b41852e7de9d3bc167753276079fd3(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_b8fcd200c8133e8885a91a666fe62c27_97b41852e7de9d3bc167753276079fd3); 
  }
return bi;}


