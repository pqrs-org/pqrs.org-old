// XXX uniqID XXX fb04b0768d0f863b0b4185bec94e6ce6 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/round-laser-leftside.hpp" 

extern const BulletStepFunc bullet_129ec33fc03416287198f82862344f76_fb04b0768d0f863b0b4185bec94e6ce6[] = { 
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_fb04b0768d0f863b0b4185bec94e6ce6,
NULL}; 
extern const BulletStepFunc bullet_a51db8432d500e0765fc9fe1abcc868f_fb04b0768d0f863b0b4185bec94e6ce6[] = { 
stepfunc_0a4f5c16cd08f4bcc662e3f857bcb0ee_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_fb04b0768d0f863b0b4185bec94e6ce6,
NULL}; 
void stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_fb04b0768d0f863b0b4185bec94e6ce6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_fb04b0768d0f863b0b4185bec94e6ce6(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_fb04b0768d0f863b0b4185bec94e6ce6(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_a517005a7f2956bff73660309f3f11d6_fb04b0768d0f863b0b4185bec94e6ce6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(20.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_129ec33fc03416287198f82862344f76_fb04b0768d0f863b0b4185bec94e6ce6); 
  }
}
}
void stepfunc_0a4f5c16cd08f4bcc662e3f857bcb0ee_fb04b0768d0f863b0b4185bec94e6ce6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_129ec33fc03416287198f82862344f76_fb04b0768d0f863b0b4185bec94e6ce6); 
  }
}
}


BulletInfo *genBulletFunc_fb04b0768d0f863b0b4185bec94e6ce6(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_a51db8432d500e0765fc9fe1abcc868f_fb04b0768d0f863b0b4185bec94e6ce6); 
  }
return bi;}


