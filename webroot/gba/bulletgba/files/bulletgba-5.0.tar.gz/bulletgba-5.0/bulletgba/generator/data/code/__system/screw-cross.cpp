// XXX uniqID XXX a0673b8ebef401df5a08e9d1cd31a424 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/screw-cross.hpp" 

extern const BulletStepFunc bullet_f98160bf2a640b5d1309a7d1bdd20869_a0673b8ebef401df5a08e9d1cd31a424[] = { 
stepfunc_c0b75cfcbe25fd6ce5034d8c0b1841c2_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_a0673b8ebef401df5a08e9d1cd31a424,
NULL}; 
extern const BulletStepFunc bullet_4dbce8a387859d5efd20706a1b46472a_a0673b8ebef401df5a08e9d1cd31a424[] = { 
stepfunc_96cf7912238afc1f75038e8fb50a7100_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_a0673b8ebef401df5a08e9d1cd31a424,
NULL}; 
extern const BulletStepFunc bullet_d59f03120d3c85dbe53c574294b25d91_a0673b8ebef401df5a08e9d1cd31a424[] = { 
stepfunc_6c1ff233a0e7e7791619b2a51fe83f76_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_aee34571aef381e726f37b5509238ab6_a0673b8ebef401df5a08e9d1cd31a424,
NULL}; 
extern const BulletStepFunc bullet_36ca925f4d89ba58e6c04c396663b3d2_a0673b8ebef401df5a08e9d1cd31a424[] = { 
stepfunc_31afbc40223f0361ec06ab2c1dff4261_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_aee34571aef381e726f37b5509238ab6_a0673b8ebef401df5a08e9d1cd31a424,
NULL}; 
extern const BulletStepFunc bullet_def008f768dac7820678ab633c3a6713_a0673b8ebef401df5a08e9d1cd31a424[] = { 
stepfunc_c00d2f2b01bf8ab1787007df9c7b9590_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_9e9bdd589ca2368aa030ba4ee781324d_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_9e9bdd589ca2368aa030ba4ee781324d_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_9e9bdd589ca2368aa030ba4ee781324d_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_9e9bdd589ca2368aa030ba4ee781324d_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_9e9bdd589ca2368aa030ba4ee781324d_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_a0673b8ebef401df5a08e9d1cd31a424,
NULL}; 
extern const BulletStepFunc bullet_67787ce2da43709a2f094ed61d28ce31_a0673b8ebef401df5a08e9d1cd31a424[] = { 
stepfunc_a865c6c8b44585d6739ff7b1938fd90f_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_bd3f52686c38f15b96588ef80ccc277d_a0673b8ebef401df5a08e9d1cd31a424,
NULL}; 
extern const BulletStepFunc bullet_afe7e8381fc79c0d5ff2e7134c404015_a0673b8ebef401df5a08e9d1cd31a424[] = { 
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_496a177f09c6c70ac478a8ede25ddcfc_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_591c742cd28d7ec81751f00be4edf892_a0673b8ebef401df5a08e9d1cd31a424,
stepfunc_16204a74de7215ef4d39e0c4a561f4a4_a0673b8ebef401df5a08e9d1cd31a424,
NULL}; 
void stepfunc_46d8db6617cce1142690a89c5d26314c_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_DIRECTION, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_DIRECTION, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_DIRECTION, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_DIRECTION, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_c0b75cfcbe25fd6ce5034d8c0b1841c2_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(999.0);  FixedPointNum speed = FixedPointNum::degree2angle((1.0));p->setRound(speed, life);}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_96cf7912238afc1f75038e8fb50a7100_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(999.0);  FixedPointNum speed = FixedPointNum::degree2angle((-1.0));p->setRound(speed, life);}
}
void stepfunc_a865c6c8b44585d6739ff7b1938fd90f_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_bd3f52686c38f15b96588ef80ccc277d_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 2.0 - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_9e9bdd589ca2368aa030ba4ee781324d_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_SMALL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_67787ce2da43709a2f094ed61d28ce31_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
}
void stepfunc_c00d2f2b01bf8ab1787007df9c7b9590_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_SMALL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_67787ce2da43709a2f094ed61d28ce31_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
}
void stepfunc_3c8b77ad41cda31141a7918cf3e7b4fc_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(4.0); 
}
void stepfunc_6c1ff233a0e7e7791619b2a51fe83f76_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum::degree2angle((1.0));p->setRound(speed, life);}
}
void stepfunc_aee34571aef381e726f37b5509238ab6_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0+45.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_def008f768dac7820678ab633c3a6713_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(90.0+45.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_def008f768dac7820678ab633c3a6713_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0+45.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_def008f768dac7820678ab633c3a6713_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(270.0+45.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_THIN, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_def008f768dac7820678ab633c3a6713_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_31afbc40223f0361ec06ab2c1dff4261_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum::degree2angle((-1.0));p->setRound(speed, life);}
}
void stepfunc_82b63f3aa89279484df6a72e921678e1_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_36ca925f4d89ba58e6c04c396663b3d2_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d59f03120d3c85dbe53c574294b25d91_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
p->wait = static_cast<u16>(40.0); 
}
void stepfunc_496a177f09c6c70ac478a8ede25ddcfc_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
p->wait = static_cast<u16>(120.0); 
}
void stepfunc_591c742cd28d7ec81751f00be4edf892_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4dbce8a387859d5efd20706a1b46472a_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_16204a74de7215ef4d39e0c4a561f4a4_a0673b8ebef401df5a08e9d1cd31a424(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f98160bf2a640b5d1309a7d1bdd20869_a0673b8ebef401df5a08e9d1cd31a424); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_a0673b8ebef401df5a08e9d1cd31a424(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_afe7e8381fc79c0d5ff2e7134c404015_a0673b8ebef401df5a08e9d1cd31a424); 
  }
return bi;}


