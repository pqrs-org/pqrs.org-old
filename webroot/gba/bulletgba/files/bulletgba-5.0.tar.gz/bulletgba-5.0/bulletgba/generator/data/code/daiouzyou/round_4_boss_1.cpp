// XXX uniqID XXX 67282d4d149d442e6a0edf83bf861696 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "daiouzyou/round_4_boss_1.hpp" 

extern const BulletStepFunc bullet_6286a9c6fec71a8d8045ecfeda8fdc69_67282d4d149d442e6a0edf83bf861696[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_67282d4d149d442e6a0edf83bf861696,
stepfunc_e4547dce74c2f31cf07f256255486988_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696,
stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_67282d4d149d442e6a0edf83bf861696,
NULL}; 
extern const BulletStepFunc bullet_f1b866f583992e3b3fe9f83e142967fe_67282d4d149d442e6a0edf83bf861696[] = { 
stepfunc_a678d8bc571ed6f1d4e72f41bfaa998f_67282d4d149d442e6a0edf83bf861696,
NULL}; 
void stepfunc_4fd9cb086608cf7afaae6eaa73a4e2bc_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
3.0
));  p->lastBulletSpeed = (
 1.5
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_e170367e74fd2935ce3aecc3f76bbd41_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
116.0+FixedPointNum::random()*6.0-1.0*15.0
));  p->lastBulletSpeed = (
 1.5
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 8; ++i) { 
stepfunc_4fd9cb086608cf7afaae6eaa73a4e2bc_67282d4d149d442e6a0edf83bf861696(p);}
}
void stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
p->wait = static_cast<u16>(
 20.0
); 
}
void stepfunc_f3aa7fee26dafd5f4f1a065c8ead4e21_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
for (u32 i = 0; i < 3; ++i) { 
stepfunc_e170367e74fd2935ce3aecc3f76bbd41_67282d4d149d442e6a0edf83bf861696(p);}
}
void stepfunc_5aa98bab57516922045abb7f2c427635_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_e4547dce74c2f31cf07f256255486988_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
 1.0
);  FixedPointNum speed = FixedPointNum(
 0.0
 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_a678d8bc571ed6f1d4e72f41bfaa998f_67282d4d149d442e6a0edf83bf861696(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
110.0
));  p->lastBulletSpeed = (
 4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6286a9c6fec71a8d8045ecfeda8fdc69_67282d4d149d442e6a0edf83bf861696); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-110.0
));  p->lastBulletSpeed = (
 4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6286a9c6fec71a8d8045ecfeda8fdc69_67282d4d149d442e6a0edf83bf861696); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_67282d4d149d442e6a0edf83bf861696(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_f1b866f583992e3b3fe9f83e142967fe_67282d4d149d442e6a0edf83bf861696); 
  }
return bi;}


