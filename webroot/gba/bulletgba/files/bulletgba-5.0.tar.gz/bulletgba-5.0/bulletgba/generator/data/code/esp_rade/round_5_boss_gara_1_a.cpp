// XXX uniqID XXX 4230f8cdb144a840367f5c7e948669f1 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "esp_rade/round_5_boss_gara_1_a.hpp" 

extern const BulletStepFunc bullet_0fa0fba4c5637ddcd681573350fad904_4230f8cdb144a840367f5c7e948669f1[] = { 
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_99a7499d8b7fc20af1292913912de134_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_99a7499d8b7fc20af1292913912de134_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_99a7499d8b7fc20af1292913912de134_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_99a7499d8b7fc20af1292913912de134_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1,
stepfunc_99a7499d8b7fc20af1292913912de134_4230f8cdb144a840367f5c7e948669f1,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4230f8cdb144a840367f5c7e948669f1,
NULL}; 
void stepfunc_c1982a1f7d17f8161d8d29002c76d6b5_4230f8cdb144a840367f5c7e948669f1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(3.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_e459e5cb3438d225e253db4405e4933f_4230f8cdb144a840367f5c7e948669f1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(12.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5_4230f8cdb144a840367f5c7e948669f1(p);}
}
void stepfunc_c3f9553dcb35b886292b77ddcb69ffa1_4230f8cdb144a840367f5c7e948669f1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(-213.0));  p->lastBulletSpeed = (1.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5_4230f8cdb144a840367f5c7e948669f1(p);}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_e459e5cb3438d225e253db4405e4933f_4230f8cdb144a840367f5c7e948669f1(p);}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_843e45f3976b749cc3b433680fbea656_4230f8cdb144a840367f5c7e948669f1(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(360.0*FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.5*FixedPointNum::random()+0.5 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-90.0));  p->lastBulletSpeed = (1.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5_4230f8cdb144a840367f5c7e948669f1(p);}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_e459e5cb3438d225e253db4405e4933f_4230f8cdb144a840367f5c7e948669f1(p);}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_99a7499d8b7fc20af1292913912de134_4230f8cdb144a840367f5c7e948669f1(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(50.0); 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4230f8cdb144a840367f5c7e948669f1(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_4230f8cdb144a840367f5c7e948669f1(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_0fa0fba4c5637ddcd681573350fad904_4230f8cdb144a840367f5c7e948669f1); 
  }
return bi;}


