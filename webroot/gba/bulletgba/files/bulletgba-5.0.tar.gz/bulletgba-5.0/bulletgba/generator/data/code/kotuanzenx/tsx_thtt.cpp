// XXX uniqID XXX e155d5d1ea2c8ae30d36b8e619a47085 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx_thtt.hpp" 

extern const BulletStepFunc bullet_a267e65bfea8cdf4b814bee53476ca4d_e155d5d1ea2c8ae30d36b8e619a47085[] = { 
stepfunc_343145895d3eaf60e7a36470f61db5e2_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e155d5d1ea2c8ae30d36b8e619a47085,
NULL}; 
extern const BulletStepFunc bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085[] = { 
stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_87b5c7c1a073d75bfacc097e84bcf517_e155d5d1ea2c8ae30d36b8e619a47085,
NULL}; 
extern const BulletStepFunc bullet_014e64886e2dc60a8f897dd49afc1e99_e155d5d1ea2c8ae30d36b8e619a47085[] = { 
stepfunc_15007e8a81d8aa46641d7ae97bab9e64_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_6536e4546bdcfcf651852434db03b678_e155d5d1ea2c8ae30d36b8e619a47085,
stepfunc_613cc90e5717d92d57eec62d009da0c4_e155d5d1ea2c8ae30d36b8e619a47085,
NULL}; 
void stepfunc_1aaa93f8ddcc9676ff7413a0933118d0_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(40.0);  FixedPointNum speed = FixedPointNum(0.1 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_87b5c7c1a073d75bfacc097e84bcf517_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(170.0));  p->lastBulletSpeed = p->getSpeed() + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 10; ++i) { 
stepfunc_1aaa93f8ddcc9676ff7413a0933118d0_e155d5d1ea2c8ae30d36b8e619a47085(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_373f9a938dc66024f90d31b13be0af55_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0-6.6));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_343145895d3eaf60e7a36470f61db5e2_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((90.0)));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5a55ee543b3236a75c9e42095fc7e59_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_15007e8a81d8aa46641d7ae97bab9e64_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 4.0 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = (FixedPointNum::degree2angle(180.0)) - p->getAngle();p->setRound(speed, life);}
p->wait = static_cast<u16>(9.0); 
}
void stepfunc_6536e4546bdcfcf651852434db03b678_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_613cc90e5717d92d57eec62d009da0c4_e155d5d1ea2c8ae30d36b8e619a47085(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a267e65bfea8cdf4b814bee53476ca4d_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_e155d5d1ea2c8ae30d36b8e619a47085(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_014e64886e2dc60a8f897dd49afc1e99_e155d5d1ea2c8ae30d36b8e619a47085); 
  }
return bi;}


