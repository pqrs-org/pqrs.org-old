// XXX uniqID XXX 5b3de107f763f45f711859024683942c XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/circle-spear.hpp" 

extern const BulletStepFunc bullet_bf38adb1f7f09da794f3d0d778078d1a_5b3de107f763f45f711859024683942c[] = { 
stepfunc_c172a15bb6eca889f748350b364028cc_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_5b3de107f763f45f711859024683942c,
NULL}; 
extern const BulletStepFunc bullet_46351162b3733adb114d4b820b333850_5b3de107f763f45f711859024683942c[] = { 
stepfunc_b9f3746024faf71a948d02a3f58cba12_5b3de107f763f45f711859024683942c,
stepfunc_5af03e3b70acdef3e811d4b95b8f0781_5b3de107f763f45f711859024683942c,
NULL}; 
extern const BulletStepFunc bullet_e41e28b34e2b9e5febeeaab762777150_5b3de107f763f45f711859024683942c[] = { 
stepfunc_fe781b5b1e98853b0850a52f0f4d28cc_5b3de107f763f45f711859024683942c,
NULL}; 
extern const BulletStepFunc bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c[] = { 
stepfunc_8fff89501dcb48caade16bb16deb7b61_5b3de107f763f45f711859024683942c,
stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_5b3de107f763f45f711859024683942c,
NULL}; 
extern const BulletStepFunc bullet_7b4addb6445be2530996d8435a5ca7ff_5b3de107f763f45f711859024683942c[] = { 
stepfunc_af6445e1d78937e343a8f52b6fb52257_5b3de107f763f45f711859024683942c,
stepfunc_af6445e1d78937e343a8f52b6fb52257_5b3de107f763f45f711859024683942c,
stepfunc_af6445e1d78937e343a8f52b6fb52257_5b3de107f763f45f711859024683942c,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_5b3de107f763f45f711859024683942c,
NULL}; 
void stepfunc_8fff89501dcb48caade16bb16deb7b61_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(40.0);  FixedPointNum speed = 0.2;p->setAccel(speed, life);}
}
void stepfunc_fe781b5b1e98853b0850a52f0f4d28cc_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4fe2bfe654bdf4718c669e478f5f438c_5b3de107f763f45f711859024683942c); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_5af03e3b70acdef3e811d4b95b8f0781_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_SMALL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e41e28b34e2b9e5febeeaab762777150_5b3de107f763f45f711859024683942c); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_913c43f1778c0ec781d6daecb8525a49_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(360.0*FixedPointNum::random()));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_DIRECTION, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_46351162b3733adb114d4b820b333850_5b3de107f763f45f711859024683942c); 
  }
}
}
void stepfunc_c172a15bb6eca889f748350b364028cc_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_af6445e1d78937e343a8f52b6fb52257_5b3de107f763f45f711859024683942c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_bf38adb1f7f09da794f3d0d778078d1a_5b3de107f763f45f711859024683942c); 
  }
}
p->wait = static_cast<u16>(120.0); 
}


BulletInfo *genBulletFunc_5b3de107f763f45f711859024683942c(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_7b4addb6445be2530996d8435a5ca7ff_5b3de107f763f45f711859024683942c); 
  }
return bi;}


