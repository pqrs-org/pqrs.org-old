// XXX uniqID XXX 815f04c6e7c16510dee2e20568d79164 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx_kohaku_first.hpp" 

extern const BulletStepFunc bullet_2e09bc7d2d29b2ccad9cd4c615f0a990_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_10c3a88a8e44bab5c0812abd588467e2_815f04c6e7c16510dee2e20568d79164,
stepfunc_6536e4546bdcfcf651852434db03b678_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164,
NULL}; 
extern const BulletStepFunc bullet_d7dc91a92dfb7c608a4d34371c98fba7_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_10c3a88a8e44bab5c0812abd588467e2_815f04c6e7c16510dee2e20568d79164,
stepfunc_6536e4546bdcfcf651852434db03b678_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164,
NULL}; 
extern const BulletStepFunc bullet_7a6648e06c77ce4765b6739e1fca0a85_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_10c3a88a8e44bab5c0812abd588467e2_815f04c6e7c16510dee2e20568d79164,
stepfunc_6536e4546bdcfcf651852434db03b678_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164,
NULL}; 
extern const BulletStepFunc bullet_073f651c3c2109eeed7d4ef4f75ccea3_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_10c3a88a8e44bab5c0812abd588467e2_815f04c6e7c16510dee2e20568d79164,
stepfunc_6536e4546bdcfcf651852434db03b678_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164,
NULL}; 
extern const BulletStepFunc bullet_c45b43c191093c23eff71a54233dae69_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_d015bfb36207eb8a130c8425966e5116_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164,
NULL}; 
extern const BulletStepFunc bullet_627a231e3db33feb69b86daabf5493ad_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_d015bfb36207eb8a130c8425966e5116_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164,
NULL}; 
extern const BulletStepFunc bullet_79167f9e12b873ec51c2fc14bb5db9bb_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_d015bfb36207eb8a130c8425966e5116_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164,
NULL}; 
extern const BulletStepFunc bullet_eaa1c47ab5f044627185f9a6f08b329b_815f04c6e7c16510dee2e20568d79164[] = { 
stepfunc_10c6f9df3a5692edf2c39e1070040029_815f04c6e7c16510dee2e20568d79164,
NULL}; 
void stepfunc_b54c77a3891eb81da56b9c73de37adab_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((0.1)));  p->lastBulletSpeed = p->lastBulletSpeed + ((0.1));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_d015bfb36207eb8a130c8425966e5116_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.8+1.0*1.6);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((-0.1)));  p->lastBulletSpeed = p->lastBulletSpeed + ((0.1));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_7b97d2fef0b347f15073441526869f72_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(120.0+FixedPointNum::random()*60.0));  p->lastBulletSpeed = (0.0001);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_79167f9e12b873ec51c2fc14bb5db9bb_815f04c6e7c16510dee2e20568d79164); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0+FixedPointNum::random()*60.0));  p->lastBulletSpeed = (0.0001);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_627a231e3db33feb69b86daabf5493ad_815f04c6e7c16510dee2e20568d79164); 
  }
}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_10c3a88a8e44bab5c0812abd588467e2_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
p->wait = static_cast<u16>(9.0); 
}
void stepfunc_6536e4546bdcfcf651852434db03b678_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_76f7c0bd4e2461e011ddd3fa50d95203_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((0.0)));  p->lastBulletSpeed = p->lastBulletSpeed + ((0.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(2.0); 
}
void stepfunc_c4366e6538d73598daf058bd323fcd28_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.0001);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c45b43c191093c23eff71a54233dae69_815f04c6e7c16510dee2e20568d79164); 
  }
}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_6793cb48748fb690ab08be463778bf84_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (1.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((-1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_ae72ab3a38cf5a7b54f5387b022734bc_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (1.5+1.0*2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_10c6f9df3a5692edf2c39e1070040029_815f04c6e7c16510dee2e20568d79164(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = ((4.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_073f651c3c2109eeed7d4ef4f75ccea3_815f04c6e7c16510dee2e20568d79164); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = ((2.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_073f651c3c2109eeed7d4ef4f75ccea3_815f04c6e7c16510dee2e20568d79164); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = ((-2.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a6648e06c77ce4765b6739e1fca0a85_815f04c6e7c16510dee2e20568d79164); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = ((-4.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7a6648e06c77ce4765b6739e1fca0a85_815f04c6e7c16510dee2e20568d79164); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d7dc91a92dfb7c608a4d34371c98fba7_815f04c6e7c16510dee2e20568d79164); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2e09bc7d2d29b2ccad9cd4c615f0a990_815f04c6e7c16510dee2e20568d79164); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_815f04c6e7c16510dee2e20568d79164(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_eaa1c47ab5f044627185f9a6f08b329b_815f04c6e7c16510dee2e20568d79164); 
  }
return bi;}


