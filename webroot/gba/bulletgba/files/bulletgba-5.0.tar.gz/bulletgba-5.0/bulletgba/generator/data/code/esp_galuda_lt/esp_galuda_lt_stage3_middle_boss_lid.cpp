// XXX uniqID XXX 7711b9e645c967c0c9a7b66a9bb949fc XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "esp_galuda_lt/esp_galuda_lt_stage3_middle_boss_lid.hpp" 

extern const BulletStepFunc bullet_6da8893228a9afe0e1cacbbe654b91ec_7711b9e645c967c0c9a7b66a9bb949fc[] = { 
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_05be517a7e47129bc0f07a71f03adbc2_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_4e41b098e24b76fd215dd051e9f7def7_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_692170fb71ba1a7ff3f40c3f4f4416e5_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_a348dc0cbfc7f4d2c2cfcfc4122cddd3_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_1a4ef607bbfc993d704aa5b0924baf3c_7711b9e645c967c0c9a7b66a9bb949fc,
stepfunc_b92ae3eeb067c5c01dff5e71e0203590_7711b9e645c967c0c9a7b66a9bb949fc,
NULL}; 
void stepfunc_fa8e7fa1f65ce38523253b595a1c506e_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
0.5
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_7e8d45d0b5fd48b91feb4f713a1bd456_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
10.0
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_dc4266d1ac5aa5136ff3a0443b693616_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
p->wait = static_cast<u16>(
2.0
); 
}
void stepfunc_00cc1c3441251988c95660ed27d94ac8_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-25.0
));  p->lastBulletSpeed = (
3.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_7e8d45d0b5fd48b91feb4f713a1bd456_7711b9e645c967c0c9a7b66a9bb949fc(p);}
}
void stepfunc_05be517a7e47129bc0f07a71f03adbc2_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
p->wait = static_cast<u16>(
30.0
); 
}
void stepfunc_4e41b098e24b76fd215dd051e9f7def7_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-3.75-1.0*5.0
));  p->lastBulletSpeed = (
4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_fa8e7fa1f65ce38523253b595a1c506e_7711b9e645c967c0c9a7b66a9bb949fc(p);}
p->wait = static_cast<u16>(
34.0-1.0*8.0
); 
}
void stepfunc_692170fb71ba1a7ff3f40c3f4f4416e5_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
p->wait = static_cast<u16>(
28.0-1.0*8.0
); 
}
void stepfunc_a348dc0cbfc7f4d2c2cfcfc4122cddd3_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-3.75-1.0*5.0
));  p->lastBulletSpeed = (
4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_fa8e7fa1f65ce38523253b595a1c506e_7711b9e645c967c0c9a7b66a9bb949fc(p);}
p->wait = static_cast<u16>(
30.0
); 
}
void stepfunc_1a4ef607bbfc993d704aa5b0924baf3c_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
p->wait = static_cast<u16>(
22.0-1.0*8.0
); 
}
void stepfunc_b92ae3eeb067c5c01dff5e71e0203590_7711b9e645c967c0c9a7b66a9bb949fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-3.75-1.0*5.0
));  p->lastBulletSpeed = (
4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_fa8e7fa1f65ce38523253b595a1c506e_7711b9e645c967c0c9a7b66a9bb949fc(p);}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_7711b9e645c967c0c9a7b66a9bb949fc(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_6da8893228a9afe0e1cacbbe654b91ec_7711b9e645c967c0c9a7b66a9bb949fc); 
  }
return bi;}


