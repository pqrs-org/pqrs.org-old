// XXX uniqID XXX e5074f93c232080a85d74bb0f50e38b6 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/round-laser-rightside.hpp" 

extern const BulletStepFunc bullet_81bd755d7007e1e3302860a31912a85d_e5074f93c232080a85d74bb0f50e38b6[] = { 
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_e5074f93c232080a85d74bb0f50e38b6,
NULL}; 
extern const BulletStepFunc bullet_ba00a30909c104d097a4d7f7e46e032d_e5074f93c232080a85d74bb0f50e38b6[] = { 
stepfunc_46adac1c4e2987aca78bfea756a8c2cb_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_e5074f93c232080a85d74bb0f50e38b6,
NULL}; 
void stepfunc_bbf4d4d1a84fe518316ecf2f20d6a516_e5074f93c232080a85d74bb0f50e38b6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (2.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_e5074f93c232080a85d74bb0f50e38b6(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_e5074f93c232080a85d74bb0f50e38b6(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_e40a44188abe5117021b5e13df8eb823_e5074f93c232080a85d74bb0f50e38b6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(-20.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_81bd755d7007e1e3302860a31912a85d_e5074f93c232080a85d74bb0f50e38b6); 
  }
}
}
void stepfunc_46adac1c4e2987aca78bfea756a8c2cb_e5074f93c232080a85d74bb0f50e38b6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_81bd755d7007e1e3302860a31912a85d_e5074f93c232080a85d74bb0f50e38b6); 
  }
}
}


BulletInfo *genBulletFunc_e5074f93c232080a85d74bb0f50e38b6(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_ba00a30909c104d097a4d7f7e46e032d_e5074f93c232080a85d74bb0f50e38b6); 
  }
return bi;}


