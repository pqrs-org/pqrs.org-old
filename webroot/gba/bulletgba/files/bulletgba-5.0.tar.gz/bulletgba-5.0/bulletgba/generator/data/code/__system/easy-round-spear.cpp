// XXX uniqID XXX 06ced1be6ed08db13361b6de812049ec XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/easy-round-spear.hpp" 

extern const BulletStepFunc bullet_a70e32e9e62d194cae33c05fa045666f_06ced1be6ed08db13361b6de812049ec[] = { 
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_47a97b3be9c771b19ee13e9ec8fdf4b8_06ced1be6ed08db13361b6de812049ec,
NULL}; 
extern const BulletStepFunc bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec[] = { 
stepfunc_8fff89501dcb48caade16bb16deb7b61_06ced1be6ed08db13361b6de812049ec,
stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_06ced1be6ed08db13361b6de812049ec,
NULL}; 
extern const BulletStepFunc bullet_6cf6dfe767c589ba67ecd3812f3d49d8_06ced1be6ed08db13361b6de812049ec[] = { 
stepfunc_cd63811f8ad0515426824f6177942bd6_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec,
stepfunc_cd63811f8ad0515426824f6177942bd6_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec,
stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_06ced1be6ed08db13361b6de812049ec,
NULL}; 
void stepfunc_8fff89501dcb48caade16bb16deb7b61_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_6c88a51082ed4fd2337504d13a7f1d2c_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(40.0);  FixedPointNum speed = 0.2;p->setAccel(speed, life);}
}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_47a97b3be9c771b19ee13e9ec8fdf4b8_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.4);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e6ceefb1ffa1075e73cf1487315e030d_06ced1be6ed08db13361b6de812049ec); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_819631d756f29c3e2d9197366ebdf3a0_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(-10.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a70e32e9e62d194cae33c05fa045666f_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a70e32e9e62d194cae33c05fa045666f_06ced1be6ed08db13361b6de812049ec); 
  }
}
}
void stepfunc_0ee09641f2519196f8ed99f1e87ed8d0_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a70e32e9e62d194cae33c05fa045666f_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a70e32e9e62d194cae33c05fa045666f_06ced1be6ed08db13361b6de812049ec); 
  }
}
}
void stepfunc_cd63811f8ad0515426824f6177942bd6_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a70e32e9e62d194cae33c05fa045666f_06ced1be6ed08db13361b6de812049ec); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a70e32e9e62d194cae33c05fa045666f_06ced1be6ed08db13361b6de812049ec); 
  }
}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_06ced1be6ed08db13361b6de812049ec(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_06ced1be6ed08db13361b6de812049ec(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_6cf6dfe767c589ba67ecd3812f3d49d8_06ced1be6ed08db13361b6de812049ec); 
  }
return bi;}


