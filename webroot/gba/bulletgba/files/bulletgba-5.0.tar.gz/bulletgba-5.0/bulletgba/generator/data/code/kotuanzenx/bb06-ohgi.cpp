// XXX uniqID XXX 6fc23e00f21b932af8d16becde354c9a XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/bb06-ohgi.hpp" 

extern const BulletStepFunc bullet_6928ccf960e6dbb1ddfc53486139628f_6fc23e00f21b932af8d16becde354c9a[] = { 
stepfunc_ef9871788c6d3fbe38b09c429f6b93ac_6fc23e00f21b932af8d16becde354c9a,
stepfunc_30f0d9da7d51625b08908d839d04eb6d_6fc23e00f21b932af8d16becde354c9a,
NULL}; 
extern const BulletStepFunc bullet_f9047353390ae10ddcf3a2d64fef5dd5_6fc23e00f21b932af8d16becde354c9a[] = { 
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6fc23e00f21b932af8d16becde354c9a,
NULL}; 
void stepfunc_ef9871788c6d3fbe38b09c429f6b93ac_6fc23e00f21b932af8d16becde354c9a(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(19.0);  FixedPointNum speed = FixedPointNum(8.0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = static_cast<u16>(19.0); 
}
void stepfunc_30f0d9da7d51625b08908d839d04eb6d_6fc23e00f21b932af8d16becde354c9a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(145.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_b5e1170ef8971d6b2b29cfc0c254b0a9_6fc23e00f21b932af8d16becde354c9a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(120.0+FixedPointNum::random()*120.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6928ccf960e6dbb1ddfc53486139628f_6fc23e00f21b932af8d16becde354c9a); 
  }
}
p->wait = static_cast<u16>(6.0); 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6fc23e00f21b932af8d16becde354c9a(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_6fc23e00f21b932af8d16becde354c9a(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_f9047353390ae10ddcf3a2d64fef5dd5_6fc23e00f21b932af8d16becde354c9a); 
  }
return bi;}


