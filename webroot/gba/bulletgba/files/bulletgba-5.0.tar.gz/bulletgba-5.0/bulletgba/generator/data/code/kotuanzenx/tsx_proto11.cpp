// XXX uniqID XXX e9c5251663b26b8b849de773f3f9b7a0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx_proto11.hpp" 

extern const BulletStepFunc bullet_2e26dec57daafc633062db6aca6be43b_e9c5251663b26b8b849de773f3f9b7a0[] = { 
stepfunc_10c3a88a8e44bab5c0812abd588467e2_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_6536e4546bdcfcf651852434db03b678_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e9c5251663b26b8b849de773f3f9b7a0,
NULL}; 
extern const BulletStepFunc bullet_8edd83cfae72c5dbe91c2e130d65b723_e9c5251663b26b8b849de773f3f9b7a0[] = { 
stepfunc_6c1f8924f1816c4b17037ca35cdfb188_e9c5251663b26b8b849de773f3f9b7a0,
NULL}; 
extern const BulletStepFunc bullet_3232f0156ec2c5040d5cdc3a1657932a_e9c5251663b26b8b849de773f3f9b7a0[] = { 
stepfunc_f802ea525850e7f56f2d815678960bc3_e9c5251663b26b8b849de773f3f9b7a0,
NULL}; 
void stepfunc_faeb9ac81b7a64ffed123259883c3994_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_6c1f8924f1816c4b17037ca35cdfb188_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((0.0)));  p->lastBulletSpeed = p->getSpeed() + ((0.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((0.0)));  p->lastBulletSpeed = p->getSpeed() + ((0.3));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((-4.0)));  p->lastBulletSpeed = p->getSpeed() + ((0.15));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle((4.0)));  p->lastBulletSpeed = p->getSpeed() + ((0.15));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_f46bc191f7167f122835b57dc03cf3ba_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(30.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8edd83cfae72c5dbe91c2e130d65b723_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
}
void stepfunc_afa1c1a48bcda114ef4e13212c0aee71_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(120.0+FixedPointNum::random()*60.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8edd83cfae72c5dbe91c2e130d65b723_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_f46bc191f7167f122835b57dc03cf3ba_e9c5251663b26b8b849de773f3f9b7a0(p);}
}
void stepfunc_10c3a88a8e44bab5c0812abd588467e2_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
p->wait = static_cast<u16>(9.0); 
}
void stepfunc_6536e4546bdcfcf651852434db03b678_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_f802ea525850e7f56f2d815678960bc3_e9c5251663b26b8b849de773f3f9b7a0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((90.0)));  p->lastBulletSpeed = ((6.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2e26dec57daafc633062db6aca6be43b_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((-90.0)));  p->lastBulletSpeed = ((6.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2e26dec57daafc633062db6aca6be43b_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((60.0)));  p->lastBulletSpeed = ((5.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2e26dec57daafc633062db6aca6be43b_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((-60.0)));  p->lastBulletSpeed = ((5.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2e26dec57daafc633062db6aca6be43b_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((30.0)));  p->lastBulletSpeed = ((4.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2e26dec57daafc633062db6aca6be43b_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((-30.0)));  p->lastBulletSpeed = ((4.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2e26dec57daafc633062db6aca6be43b_e9c5251663b26b8b849de773f3f9b7a0); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_e9c5251663b26b8b849de773f3f9b7a0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_3232f0156ec2c5040d5cdc3a1657932a_e9c5251663b26b8b849de773f3f9b7a0); 
  }
return bi;}


