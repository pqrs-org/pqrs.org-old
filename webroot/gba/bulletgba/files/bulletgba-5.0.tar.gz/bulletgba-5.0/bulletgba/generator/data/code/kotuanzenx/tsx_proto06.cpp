// XXX uniqID XXX b31da9eec102fa80a3eebd847d7c8af9 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx_proto06.hpp" 

extern const BulletStepFunc bullet_d8e934a9ad64e72980c6705404c12fa7_b31da9eec102fa80a3eebd847d7c8af9[] = { 
stepfunc_5b502751f1728a011324a94f95d35d7d_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_335203fb678266e1601218bb1f76f232_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9,
NULL}; 
extern const BulletStepFunc bullet_6cab55e7bbd9ffd429350e9713d0ad7f_b31da9eec102fa80a3eebd847d7c8af9[] = { 
stepfunc_5b502751f1728a011324a94f95d35d7d_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_335203fb678266e1601218bb1f76f232_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9,
NULL}; 
extern const BulletStepFunc bullet_97bfd84aa004bfa746f3703875248e39_b31da9eec102fa80a3eebd847d7c8af9[] = { 
stepfunc_0eec21fa66dcbdfe4a80555b66c50849_b31da9eec102fa80a3eebd847d7c8af9,
NULL}; 
extern const BulletStepFunc bullet_adab0acb75bd1c876906bf4780a6aeac_b31da9eec102fa80a3eebd847d7c8af9[] = { 
stepfunc_00c40f6516a243c7f06295574ba9b580_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_14ba39322376cdd81fe318cf23914efd_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_4ac0fd8550fcf23fba772cea731b3187_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_ce6aef889299639c1904ddf842d67f0b_b31da9eec102fa80a3eebd847d7c8af9,
stepfunc_687c01e4585eaab1a67bea80cca6a00c_b31da9eec102fa80a3eebd847d7c8af9,
NULL}; 
void stepfunc_33381006f67f0b2a6227e555c2039d06_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0*(1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_0eec21fa66dcbdfe4a80555b66c50849_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(60.0);  FixedPointNum speed = FixedPointNum(4.0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_a6dce02a6502044fb70a1fe450adfe87_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_97bfd84aa004bfa746f3703875248e39_b31da9eec102fa80a3eebd847d7c8af9); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(200.0*(1.0)));  p->lastBulletSpeed = (1.0+1.0*1.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_33381006f67f0b2a6227e555c2039d06_b31da9eec102fa80a3eebd847d7c8af9(p);}
p->wait = static_cast<u16>(6.0); 
}
void stepfunc_5b502751f1728a011324a94f95d35d7d_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_335203fb678266e1601218bb1f76f232_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 3.0 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = (FixedPointNum::degree2angle(0.0)) - p->getAngle();p->setRound(speed, life);}
}
void stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(10.0*(-1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_0580e19282c4e8265fc5bf0238d2fe59_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_97bfd84aa004bfa746f3703875248e39_b31da9eec102fa80a3eebd847d7c8af9); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(200.0*(-1.0)));  p->lastBulletSpeed = (1.0+1.0*1.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798_b31da9eec102fa80a3eebd847d7c8af9(p);}
p->wait = static_cast<u16>(6.0); 
}
void stepfunc_00c40f6516a243c7f06295574ba9b580_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(155.0*(1.0)));  p->lastBulletSpeed = (3.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d8e934a9ad64e72980c6705404c12fa7_b31da9eec102fa80a3eebd847d7c8af9); 
  }
}
p->wait = static_cast<u16>(120.0); 
}
void stepfunc_14ba39322376cdd81fe318cf23914efd_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(155.0*(-1.0)));  p->lastBulletSpeed = (3.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6cab55e7bbd9ffd429350e9713d0ad7f_b31da9eec102fa80a3eebd847d7c8af9); 
  }
}
p->wait = static_cast<u16>(100.0); 
}
void stepfunc_4ac0fd8550fcf23fba772cea731b3187_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(155.0*(1.0)));  p->lastBulletSpeed = (3.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d8e934a9ad64e72980c6705404c12fa7_b31da9eec102fa80a3eebd847d7c8af9); 
  }
}
p->wait = static_cast<u16>(80.0); 
}
void stepfunc_ce6aef889299639c1904ddf842d67f0b_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(155.0*(-1.0)));  p->lastBulletSpeed = (3.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6cab55e7bbd9ffd429350e9713d0ad7f_b31da9eec102fa80a3eebd847d7c8af9); 
  }
}
p->wait = static_cast<u16>(60.0); 
}
void stepfunc_687c01e4585eaab1a67bea80cca6a00c_b31da9eec102fa80a3eebd847d7c8af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(155.0*(1.0)));  p->lastBulletSpeed = (3.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d8e934a9ad64e72980c6705404c12fa7_b31da9eec102fa80a3eebd847d7c8af9); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_b31da9eec102fa80a3eebd847d7c8af9(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_adab0acb75bd1c876906bf4780a6aeac_b31da9eec102fa80a3eebd847d7c8af9); 
  }
return bi;}


