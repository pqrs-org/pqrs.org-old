// XXX uniqID XXX 597ca46820b192d2dc82c4d9f6d60588 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "bulletgba/targetself.hpp" 

extern const BulletStepFunc bullet_9511b3f45fe9f2f5d8f6ac5f19c2e2fe_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_c172a15bb6eca889f748350b364028cc_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_a67986d5c459823ec078bcdcec0009dd_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_b9f3746024faf71a948d02a3f58cba12_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_b9f3746024faf71a948d02a3f58cba12_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_b9f3746024faf71a948d02a3f58cba12_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_b9f3746024faf71a948d02a3f58cba12_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_b9f3746024faf71a948d02a3f58cba12_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
extern const BulletStepFunc bullet_aac13b1b9d2f8760f1acd2dff6933224_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_a28cd147b42d4c4733373a0cacdb33ce_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
extern const BulletStepFunc bullet_636d0eef2e5a5c2ac99310c70127881c_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_5b17df237cea305ffccefce169ada8ed_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
extern const BulletStepFunc bullet_4e28e0c6590a826629c4bf1bf9b77fd1_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_3c4e83059dad211762bb7c0c15ffffb2_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
extern const BulletStepFunc bullet_d161e506d3be41948b9c12b0ea00829f_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_a865c6c8b44585d6739ff7b1938fd90f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_87ec5065657e247c445e68a277c61385_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_87ec5065657e247c445e68a277c61385_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
extern const BulletStepFunc bullet_0c3e603191af4c6a273f048a48006064_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_a865c6c8b44585d6739ff7b1938fd90f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_4b008e5e964a0382eecfffcc49a8401e_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_4b008e5e964a0382eecfffcc49a8401e_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
extern const BulletStepFunc bullet_6592c6f0840d292abe0420d4f7c02ee2_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_c81adf7df8bd376b67b691ecd5270b79_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
extern const BulletStepFunc bullet_9b15a455c3f4f31aac648abbb4cce010_597ca46820b192d2dc82c4d9f6d60588[] = { 
stepfunc_5a8975c062915529fcbc5d1b7bd32707_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_db1b8c68597b484c4220d821b171b296_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_db1b8c68597b484c4220d821b171b296_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_db1b8c68597b484c4220d821b171b296_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_db1b8c68597b484c4220d821b171b296_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c6b5edeed3975bdd3d27823b95004f61_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c6b5edeed3975bdd3d27823b95004f61_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c6b5edeed3975bdd3d27823b95004f61_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c6b5edeed3975bdd3d27823b95004f61_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_c6b5edeed3975bdd3d27823b95004f61_597ca46820b192d2dc82c4d9f6d60588,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_597ca46820b192d2dc82c4d9f6d60588,
NULL}; 
void stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(5.0));  p->lastBulletSpeed = (3.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_c81adf7df8bd376b67b691ecd5270b79_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (3.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_c6b5edeed3975bdd3d27823b95004f61_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6592c6f0840d292abe0420d4f7c02ee2_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_ccea2eb178a32635cebde8abe3449975_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((-15.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_a3a897c8160713fd874566a816f11df8_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((-10.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_a865c6c8b44585d6739ff7b1938fd90f_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_87ec5065657e247c445e68a277c61385_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((-10.0)));  p->lastBulletSpeed = ((3.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a3a897c8160713fd874566a816f11df8_597ca46820b192d2dc82c4d9f6d60588(p);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((-15.0)));  p->lastBulletSpeed = ((3.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_ccea2eb178a32635cebde8abe3449975_597ca46820b192d2dc82c4d9f6d60588(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_655fd0b2377a859fd835562851c5262e_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((15.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_1f8f9493d984c5245f32e70ccc8bc434_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((10.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_4b008e5e964a0382eecfffcc49a8401e_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((10.0)));  p->lastBulletSpeed = ((3.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_1f8f9493d984c5245f32e70ccc8bc434_597ca46820b192d2dc82c4d9f6d60588(p);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle((15.0)));  p->lastBulletSpeed = ((3.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_655fd0b2377a859fd835562851c5262e_597ca46820b192d2dc82c4d9f6d60588(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_3c4e83059dad211762bb7c0c15ffffb2_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-30.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0c3e603191af4c6a273f048a48006064_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(30.0));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d161e506d3be41948b9c12b0ea00829f_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_db1b8c68597b484c4220d821b171b296_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4e28e0c6590a826629c4bf1bf9b77fd1_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_316cfb1238c9f69150a9e7f84621788f_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4e28e0c6590a826629c4bf1bf9b77fd1_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_c0c09b023a7c2b95fa658481862481de_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((5.0)));  p->lastBulletSpeed = ((5.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_a28cd147b42d4c4733373a0cacdb33ce_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((5.0)));  p->lastBulletSpeed = ((5.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_91c8fbb49855bdcb26e359162a821ef0_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle((-5.0)));  p->lastBulletSpeed = ((5.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(1.0); 
}
void stepfunc_5b17df237cea305ffccefce169ada8ed_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((-5.0)));  p->lastBulletSpeed = ((5.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_c172a15bb6eca889f748350b364028cc_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
p->wait = static_cast<u16>(20.0); 
}
void stepfunc_a67986d5c459823ec078bcdcec0009dd_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_636d0eef2e5a5c2ac99310c70127881c_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aac13b1b9d2f8760f1acd2dff6933224_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
p->wait = static_cast<u16>(40.0); 
}
void stepfunc_5a8975c062915529fcbc5d1b7bd32707_597ca46820b192d2dc82c4d9f6d60588(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((70.0)));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9511b3f45fe9f2f5d8f6ac5f19c2e2fe_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((120.0)));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9511b3f45fe9f2f5d8f6ac5f19c2e2fe_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((-70.0)));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9511b3f45fe9f2f5d8f6ac5f19c2e2fe_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((-120.0)));  p->lastBulletSpeed = (1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9511b3f45fe9f2f5d8f6ac5f19c2e2fe_597ca46820b192d2dc82c4d9f6d60588); 
  }
}
p->wait = static_cast<u16>(50.0); 
}


BulletInfo *genBulletFunc_597ca46820b192d2dc82c4d9f6d60588(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_9b15a455c3f4f31aac648abbb4cce010_597ca46820b192d2dc82c4d9f6d60588); 
  }
return bi;}


