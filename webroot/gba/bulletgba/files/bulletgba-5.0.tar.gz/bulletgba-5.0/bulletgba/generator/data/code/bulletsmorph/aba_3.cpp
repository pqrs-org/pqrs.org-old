// XXX uniqID XXX fae91ac0b40ddf09295bda3baabb089a XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "bulletsmorph/aba_3.hpp" 

extern const BulletStepFunc bullet_e0c6df1ef8e424fafaebdde8a3e69818_fae91ac0b40ddf09295bda3baabb089a[] = { 
stepfunc_b29cebfac2f19abeac4b7b53f6b48124_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_4bf3f922b2860db283223aee2bf3ad2d_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_fae91ac0b40ddf09295bda3baabb089a,
NULL}; 
extern const BulletStepFunc bullet_1e1c2d7257fcfcb737eb7d39b89940a8_fae91ac0b40ddf09295bda3baabb089a[] = { 
stepfunc_4353a7676635a508b7e4a5b8e0e9754f_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_23d87c75ba66bf7b57e8da4a6bb2cb3e_fae91ac0b40ddf09295bda3baabb089a,
NULL}; 
extern const BulletStepFunc bullet_b97db37057f136a5857b8d845e612913_fae91ac0b40ddf09295bda3baabb089a[] = { 
stepfunc_327970f328d8befd7f085a1a3242f8df_fae91ac0b40ddf09295bda3baabb089a,
NULL}; 
extern const BulletStepFunc bullet_00e158d4a8947de24e07cdd42109a394_fae91ac0b40ddf09295bda3baabb089a[] = { 
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_fae91ac0b40ddf09295bda3baabb089a,
NULL}; 
void stepfunc_327970f328d8befd7f085a1a3242f8df_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->getSpeed() + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_4353a7676635a508b7e4a5b8e0e9754f_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
p->wait = static_cast<u16>(120.0); 
}
void stepfunc_23d87c75ba66bf7b57e8da4a6bb2cb3e_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(120.0));  p->lastBulletSpeed = (1.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(240.0));  p->lastBulletSpeed = (1.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (1.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b97db37057f136a5857b8d845e612913_fae91ac0b40ddf09295bda3baabb089a); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_6e48341f4f2b70ee63ecf562ee8d788e_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(360.0 / (4.0 + 8.0 * 1.0)));  p->lastBulletSpeed = (0.8);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1e1c2d7257fcfcb737eb7d39b89940a8_fae91ac0b40ddf09295bda3baabb089a); 
  }
}
}
void stepfunc_b29cebfac2f19abeac4b7b53f6b48124_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
p->wait = static_cast<u16>(50.0); 
}
void stepfunc_4bf3f922b2860db283223aee2bf3ad2d_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(360.0 * FixedPointNum::random()));  p->lastBulletSpeed = (0.8);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1e1c2d7257fcfcb737eb7d39b89940a8_fae91ac0b40ddf09295bda3baabb089a); 
  }
}
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_db41bb152748c75b9eef0a372bac21b6_fae91ac0b40ddf09295bda3baabb089a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(120.0 + 120.0 * FixedPointNum::random()));  p->lastBulletSpeed = (0.5 + 1.9 * FixedPointNum::random());  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e0c6df1ef8e424fafaebdde8a3e69818_fae91ac0b40ddf09295bda3baabb089a); 
  }
}
p->wait = static_cast<u16>(60.0 - 30.0 * 1.0); 
}


BulletInfo *genBulletFunc_fae91ac0b40ddf09295bda3baabb089a(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_00e158d4a8947de24e07cdd42109a394_fae91ac0b40ddf09295bda3baabb089a); 
  }
return bi;}


