// XXX uniqID XXX 0d4a29b0f7ee9e714a5883286267b5df XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "esp_galuda_lt/esp_galuda_lt_stage4_middle_boss_2fan.hpp" 

extern const BulletStepFunc bullet_7f6157def46079d63e37a99fe3c4fcce_0d4a29b0f7ee9e714a5883286267b5df[] = { 
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0d4a29b0f7ee9e714a5883286267b5df,
NULL}; 
extern const BulletStepFunc bullet_d1ae2445f6728a509e721f9b07131ee8_0d4a29b0f7ee9e714a5883286267b5df[] = { 
stepfunc_be16bf0af59475cb27c7188323dceff4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_56a74d93a7af0038df1bf24a5aee1e67_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_b1ec2157d01ea1c74d1c3b04e576096d_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_1ce47ef0b98b914b05c4d94a6025c28b_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_b1ec2157d01ea1c74d1c3b04e576096d_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_1ce47ef0b98b914b05c4d94a6025c28b_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_b1ec2157d01ea1c74d1c3b04e576096d_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_1ce47ef0b98b914b05c4d94a6025c28b_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0d4a29b0f7ee9e714a5883286267b5df,
NULL}; 
extern const BulletStepFunc bullet_1a0a8ca90d40daaf020c093ddaba04c1_0d4a29b0f7ee9e714a5883286267b5df[] = { 
stepfunc_ac8d5893a2e49607f48a5d93ddc80f1d_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_12b4b897dbc7ad9187df80724c494298_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_121530962f10352aa7940f86921cc11b_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_6cae87bec011c04fee33c529fbd0ed67_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_121530962f10352aa7940f86921cc11b_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_6cae87bec011c04fee33c529fbd0ed67_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_121530962f10352aa7940f86921cc11b_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_6cae87bec011c04fee33c529fbd0ed67_0d4a29b0f7ee9e714a5883286267b5df,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0d4a29b0f7ee9e714a5883286267b5df,
NULL}; 
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_402f1330cd0bc2671ade724ebb360893_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
20.0*(
-1.0
)
));  p->lastBulletSpeed = (
(
1.3+1.0*0.4
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_9e8f4aa8e5ae0a3403953c0de8a23d26_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
p->wait = (
12.0-1.0*6.0+FixedPointNum::random()
).toInt(); 
}
void stepfunc_42ca496d141190554c948467fb9823cb_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-146.0*(
-1.0
)
));  p->lastBulletSpeed = (
(
1.3+1.0*0.4
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 8; ++i) { 
stepfunc_402f1330cd0bc2671ade724ebb360893_0d4a29b0f7ee9e714a5883286267b5df(p);}
}
void stepfunc_58d7aae1b16a29551f222eae69b0ea52_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-20.0*(
-1.0
)
));  p->lastBulletSpeed = (
(
1.3+1.0*0.4
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_a9f5d9529c91123c2611d5fccddec31e_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
146.0*(
-1.0
)
));  p->lastBulletSpeed = (
(
1.3+1.0*0.4
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 8; ++i) { 
stepfunc_58d7aae1b16a29551f222eae69b0ea52_0d4a29b0f7ee9e714a5883286267b5df(p);}
}
void stepfunc_121530962f10352aa7940f86921cc11b_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
126.0*(
-1.0
)
));  p->lastBulletSpeed = (
(
1.3+1.0*0.4
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7f6157def46079d63e37a99fe3c4fcce_0d4a29b0f7ee9e714a5883286267b5df); 
  }
}
}
void stepfunc_6cae87bec011c04fee33c529fbd0ed67_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-126.0*(
-1.0
)
));  p->lastBulletSpeed = (
(
1.3+1.0*0.4
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7f6157def46079d63e37a99fe3c4fcce_0d4a29b0f7ee9e714a5883286267b5df); 
  }
}
}
void stepfunc_0e7a44d2846eecdd003c53f71aa00aba_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
20.0*(
1.0
)
));  p->lastBulletSpeed = (
(
1.1+1.0*0.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_e6ad729ef836ac5fbf8b502641679701_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-146.0*(
1.0
)
));  p->lastBulletSpeed = (
(
1.1+1.0*0.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 8; ++i) { 
stepfunc_0e7a44d2846eecdd003c53f71aa00aba_0d4a29b0f7ee9e714a5883286267b5df(p);}
}
void stepfunc_24be0169e8f0ecea76b2ec9f22705bdf_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-20.0*(
1.0
)
));  p->lastBulletSpeed = (
(
1.1+1.0*0.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_92013eed75b7ad4f93ae6fba40b368b4_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
146.0*(
1.0
)
));  p->lastBulletSpeed = (
(
1.1+1.0*0.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 8; ++i) { 
stepfunc_24be0169e8f0ecea76b2ec9f22705bdf_0d4a29b0f7ee9e714a5883286267b5df(p);}
}
void stepfunc_b1ec2157d01ea1c74d1c3b04e576096d_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
126.0*(
1.0
)
));  p->lastBulletSpeed = (
(
1.1+1.0*0.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7f6157def46079d63e37a99fe3c4fcce_0d4a29b0f7ee9e714a5883286267b5df); 
  }
}
}
void stepfunc_1ce47ef0b98b914b05c4d94a6025c28b_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-126.0*(
1.0
)
));  p->lastBulletSpeed = (
(
1.1+1.0*0.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7f6157def46079d63e37a99fe3c4fcce_0d4a29b0f7ee9e714a5883286267b5df); 
  }
}
}
void stepfunc_be16bf0af59475cb27c7188323dceff4_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
p->wait = static_cast<u16>(
6.0
); 
}
void stepfunc_56a74d93a7af0038df1bf24a5aee1e67_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
1.0
);  FixedPointNum speed = FixedPointNum(
0.0
 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
(-60.0+80.0)*(
1.0
)
));  p->lastBulletSpeed = (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7f6157def46079d63e37a99fe3c4fcce_0d4a29b0f7ee9e714a5883286267b5df); 
  }
}
}
void stepfunc_ac8d5893a2e49607f48a5d93ddc80f1d_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
180.0
));  p->lastBulletSpeed = (
8.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d1ae2445f6728a509e721f9b07131ee8_0d4a29b0f7ee9e714a5883286267b5df); 
  }
}
p->wait = static_cast<u16>(
6.0
); 
}
void stepfunc_12b4b897dbc7ad9187df80724c494298_0d4a29b0f7ee9e714a5883286267b5df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
(-60.0+80.0)*(
-1.0
)
));  p->lastBulletSpeed = (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7f6157def46079d63e37a99fe3c4fcce_0d4a29b0f7ee9e714a5883286267b5df); 
  }
}
}


BulletInfo *genBulletFunc_0d4a29b0f7ee9e714a5883286267b5df(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_1a0a8ca90d40daaf020c093ddaba04c1_0d4a29b0f7ee9e714a5883286267b5df); 
  }
return bi;}


