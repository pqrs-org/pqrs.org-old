// XXX uniqID XXX 4eef6c4fb2708799d225ec12c376fd76 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "daiouzyou/round_4_boss_2.hpp" 

extern const BulletStepFunc bullet_813b2ce8ab1acd90c122b8b1a8bd7eb2_4eef6c4fb2708799d225ec12c376fd76[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_e4547dce74c2f31cf07f256255486988_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_fb5b10007541b09b1d972d7fcf95c3fe_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_fb5b10007541b09b1d972d7fcf95c3fe_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_fb5b10007541b09b1d972d7fcf95c3fe_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_fb5b10007541b09b1d972d7fcf95c3fe_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_fb5b10007541b09b1d972d7fcf95c3fe_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4eef6c4fb2708799d225ec12c376fd76,
NULL}; 
extern const BulletStepFunc bullet_632f2ef0f1a8e092f13bcde32eb6e64d_4eef6c4fb2708799d225ec12c376fd76[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_e4547dce74c2f31cf07f256255486988_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4eef6c4fb2708799d225ec12c376fd76,
NULL}; 
extern const BulletStepFunc bullet_7fdde7361e57dfc33343d81bccf4ccd6_4eef6c4fb2708799d225ec12c376fd76[] = { 
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4eef6c4fb2708799d225ec12c376fd76,
NULL}; 
extern const BulletStepFunc bullet_def35c082b8cb0d362cde06b39dd659b_4eef6c4fb2708799d225ec12c376fd76[] = { 
stepfunc_4e79b9198e04a784f6485ae51ed4ec4c_4eef6c4fb2708799d225ec12c376fd76,
stepfunc_9595f9f23d4ae3d3a05837ea79a3f2cf_4eef6c4fb2708799d225ec12c376fd76,
NULL}; 
void stepfunc_721169995ff19f0b94372886eb3e12c4_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
0.0
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.08+1.0*0.08
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_6767f1178e4f8996446d82091d0d9147_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
15.0
));  p->lastBulletSpeed = (
 1.3
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_721169995ff19f0b94372886eb3e12c4_4eef6c4fb2708799d225ec12c376fd76(p);}
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_fb5b10007541b09b1d972d7fcf95c3fe_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-7.0*(
 FixedPointNum::random()*3.0+1.0*2.0
)-7.0
));  p->lastBulletSpeed = 1;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7fdde7361e57dfc33343d81bccf4ccd6_4eef6c4fb2708799d225ec12c376fd76); 
  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_6767f1178e4f8996446d82091d0d9147_4eef6c4fb2708799d225ec12c376fd76(p);}
p->wait = static_cast<u16>(
 40.0
); 
}
void stepfunc_5aa98bab57516922045abb7f2c427635_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_e4547dce74c2f31cf07f256255486988_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
 1.0
);  FixedPointNum speed = FixedPointNum(
 0.0
 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_5e697210a06c352d91a2379f809e9b76_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
10.0
));  p->lastBulletSpeed = (
 1.4
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_962d76d1520f16fa17f2019e53622e29_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
95.0
));  p->lastBulletSpeed = (
 1.4
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_5e697210a06c352d91a2379f809e9b76_4eef6c4fb2708799d225ec12c376fd76(p);}
}
void stepfunc_5ab6854c9ea21aeb675b858037b64b8f_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
p->wait = (
 10.0-1.0*4.0+FixedPointNum::random()
).toInt(); 
}
void stepfunc_7c8657e597e68d2e88e7b737a172f573_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
for (u32 i = 0; i < 3; ++i) { 
stepfunc_962d76d1520f16fa17f2019e53622e29_4eef6c4fb2708799d225ec12c376fd76(p);}
}
void stepfunc_4e79b9198e04a784f6485ae51ed4ec4c_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
120.0
));  p->lastBulletSpeed = (
 3.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_632f2ef0f1a8e092f13bcde32eb6e64d_4eef6c4fb2708799d225ec12c376fd76); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-120.0
));  p->lastBulletSpeed = (
 3.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_813b2ce8ab1acd90c122b8b1a8bd7eb2_4eef6c4fb2708799d225ec12c376fd76); 
  }
}
p->wait = static_cast<u16>(
 200.0
); 
}
void stepfunc_9595f9f23d4ae3d3a05837ea79a3f2cf_4eef6c4fb2708799d225ec12c376fd76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-120.0
));  p->lastBulletSpeed = (
 3.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_632f2ef0f1a8e092f13bcde32eb6e64d_4eef6c4fb2708799d225ec12c376fd76); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
120.0
));  p->lastBulletSpeed = (
 3.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_813b2ce8ab1acd90c122b8b1a8bd7eb2_4eef6c4fb2708799d225ec12c376fd76); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_4eef6c4fb2708799d225ec12c376fd76(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_def35c082b8cb0d362cde06b39dd659b_4eef6c4fb2708799d225ec12c376fd76); 
  }
return bi;}


