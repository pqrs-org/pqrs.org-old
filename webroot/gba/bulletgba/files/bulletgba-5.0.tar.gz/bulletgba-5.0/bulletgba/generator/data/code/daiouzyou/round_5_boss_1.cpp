// XXX uniqID XXX 8c7560caedea979a773b43ae014fdd1f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "daiouzyou/round_5_boss_1.hpp" 

extern const BulletStepFunc bullet_4129788d7ffd90471b595c3149f5805e_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_e4547dce74c2f31cf07f256255486988_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_30d1fcb73d64de386ad3ef4f7549c0b4_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_e4547dce74c2f31cf07f256255486988_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_e71bfc96bd2151f33266142929ca4342_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_e4547dce74c2f31cf07f256255486988_8c7560caedea979a773b43ae014fdd1f,
stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f,
stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f,
stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f,
stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f,
stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f,
stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f,
stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_f5f46e56b48d5397826b1b6ebb0beab4_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_e4547dce74c2f31cf07f256255486988_8c7560caedea979a773b43ae014fdd1f,
stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_1d404cbbf7efc4bbd397fef636b03970_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_e4547dce74c2f31cf07f256255486988_8c7560caedea979a773b43ae014fdd1f,
stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f,
stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f,
stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f,
stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f,
stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f,
stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f,
stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_cc7a336361d9512c63b44ccfbc448051_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_e4547dce74c2f31cf07f256255486988_8c7560caedea979a773b43ae014fdd1f,
stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_c1955563583d6963e59462feb2cad011_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d50652de94ced4c4917b7086a044ddc7_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_6f89fd409a16b5f196a2ac096564dcb7_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f,
stepfunc_e787d4bc0008bf9b0a422d985f844b12_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_578bec0dcbfce8fa48d77466d2db022b_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_430b2185b31ee80f5810393682c32c77_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f,
stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f,
stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
extern const BulletStepFunc bullet_11595537ce108dd8f0b126568c65eef6_8c7560caedea979a773b43ae014fdd1f[] = { 
stepfunc_6cbb87578b3fe8822508f2f0c84b6bd6_8c7560caedea979a773b43ae014fdd1f,
stepfunc_2df3c492b576ac872b4fb48ab337bde9_8c7560caedea979a773b43ae014fdd1f,
NULL}; 
void stepfunc_97abb3de8c2cd43fb30716a4e75a505c_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 10.0
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_1ad3c3cb1f784ece061f4ee1da55142f_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 180.0
)-(
 5.0
)*3.0
));  p->lastBulletSpeed = (
 (
 1.1
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_97abb3de8c2cd43fb30716a4e75a505c_8c7560caedea979a773b43ae014fdd1f(p);}
p->wait = static_cast<u16>(
 420.0/(3.0+1.0*4.0)
); 
}
void stepfunc_5aa98bab57516922045abb7f2c427635_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_e4547dce74c2f31cf07f256255486988_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
 1.0
);  FixedPointNum speed = FixedPointNum(
 0.0
 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_1459d0d28a77975539b7f7288f0f8cb6_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 180.0
)-(
 8.0
)*3.0
));  p->lastBulletSpeed = (
 (
 1.1
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_97abb3de8c2cd43fb30716a4e75a505c_8c7560caedea979a773b43ae014fdd1f(p);}
p->wait = static_cast<u16>(
 420.0/(3.0+1.0*4.0)
); 
}
void stepfunc_beb0dd9deb3b5b7af07a6c3313257c38_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 156.0
)-(
 8.0
)*3.0
));  p->lastBulletSpeed = (
 (
 1.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_97abb3de8c2cd43fb30716a4e75a505c_8c7560caedea979a773b43ae014fdd1f(p);}
p->wait = static_cast<u16>(
 420.0/(3.0+1.0*4.0)
); 
}
void stepfunc_f52edc3cad533ff5057559e043ddfdc8_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 -164.0
)-(
 8.0
)*3.0
));  p->lastBulletSpeed = (
 (
 1.2
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_97abb3de8c2cd43fb30716a4e75a505c_8c7560caedea979a773b43ae014fdd1f(p);}
p->wait = static_cast<u16>(
 420.0/(3.0+1.0*4.0)
); 
}
void stepfunc_a778a35de0944b15931acb59291718c0_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 135.0
)-(
 10.0
)*3.0
));  p->lastBulletSpeed = (
 (
 1.3
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_97abb3de8c2cd43fb30716a4e75a505c_8c7560caedea979a773b43ae014fdd1f(p);}
p->wait = static_cast<u16>(
 420.0/(3.0+1.0*4.0)
); 
}
void stepfunc_48fde915180b8384ead7019062ec3bd2_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 -135.0
)-(
 10.0
)*3.0
));  p->lastBulletSpeed = (
 (
 1.3
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_97abb3de8c2cd43fb30716a4e75a505c_8c7560caedea979a773b43ae014fdd1f(p);}
p->wait = static_cast<u16>(
 420.0/(3.0+1.0*4.0)
); 
}
void stepfunc_fdc92017dd1e661c7b91ae505d8f4414_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
p->wait = static_cast<u16>(
 3.0
); 
}
void stepfunc_d8a712e7f4f22d20f4a8abe4b5631cf2_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
0.0
));  p->lastBulletSpeed = (
 1.5
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_4b05ca995e99ac96d49834e32aea73d8_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-3.0+FixedPointNum::random()*6.0
));  p->lastBulletSpeed = (
 1.5
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_0723e0936842d86db9380f94cc7c7af6_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
p->wait = static_cast<u16>(
 54.0-1.0*9.0
); 
}
void stepfunc_d50652de94ced4c4917b7086a044ddc7_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (
 0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_430b2185b31ee80f5810393682c32c77_8c7560caedea979a773b43ae014fdd1f); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_002b3f7ab8a252c009c146183ffdd02c_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 30.0
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_ca2409024d49d2df664b5267acec00a1_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
-60.0
));  p->lastBulletSpeed = (
 1.5
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_002b3f7ab8a252c009c146183ffdd02c_8c7560caedea979a773b43ae014fdd1f(p);}
}
void stepfunc_b585ea4260dfb3b84ff1987d9edd4b6c_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-33.0+FixedPointNum::random()*6.0
));  p->lastBulletSpeed = (
 1.5
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_002b3f7ab8a252c009c146183ffdd02c_8c7560caedea979a773b43ae014fdd1f(p);}
}
void stepfunc_e787d4bc0008bf9b0a422d985f844b12_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (
 0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_578bec0dcbfce8fa48d77466d2db022b_8c7560caedea979a773b43ae014fdd1f); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_6cbb87578b3fe8822508f2f0c84b6bd6_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
110.0
));  p->lastBulletSpeed = (
 4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6f89fd409a16b5f196a2ac096564dcb7_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-110.0
));  p->lastBulletSpeed = (
 4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6f89fd409a16b5f196a2ac096564dcb7_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
125.0
));  p->lastBulletSpeed = (
 5.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c1955563583d6963e59462feb2cad011_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-125.0
));  p->lastBulletSpeed = (
 5.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c1955563583d6963e59462feb2cad011_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
150.0
));  p->lastBulletSpeed = (
 7.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c1955563583d6963e59462feb2cad011_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-150.0
));  p->lastBulletSpeed = (
 7.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c1955563583d6963e59462feb2cad011_8c7560caedea979a773b43ae014fdd1f); 
  }
}
p->wait = static_cast<u16>(
 10.0
); 
}
void stepfunc_2df3c492b576ac872b4fb48ab337bde9_8c7560caedea979a773b43ae014fdd1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
90.0
));  p->lastBulletSpeed = (
 6.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_cc7a336361d9512c63b44ccfbc448051_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-90.0
));  p->lastBulletSpeed = (
 6.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1d404cbbf7efc4bbd397fef636b03970_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
110.0
));  p->lastBulletSpeed = (
 4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f5f46e56b48d5397826b1b6ebb0beab4_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-110.0
));  p->lastBulletSpeed = (
 4.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e71bfc96bd2151f33266142929ca4342_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
130.0
));  p->lastBulletSpeed = (
 2.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_30d1fcb73d64de386ad3ef4f7549c0b4_8c7560caedea979a773b43ae014fdd1f); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
-130.0
));  p->lastBulletSpeed = (
 2.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4129788d7ffd90471b595c3149f5805e_8c7560caedea979a773b43ae014fdd1f); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_8c7560caedea979a773b43ae014fdd1f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_11595537ce108dd8f0b126568c65eef6_8c7560caedea979a773b43ae014fdd1f); 
  }
return bi;}


