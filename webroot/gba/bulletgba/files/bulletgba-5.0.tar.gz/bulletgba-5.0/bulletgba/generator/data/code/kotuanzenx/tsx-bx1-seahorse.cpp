// XXX uniqID XXX 518406dbcb2bfc9ca5f9cf79816fa404 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx-bx1-seahorse.hpp" 

extern const BulletStepFunc bullet_7922268b7ced305096ba0607eefaf65c_518406dbcb2bfc9ca5f9cf79816fa404[] = { 
stepfunc_a72b35d03087fa0a4bec1c0ae2788558_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_2d8d20189622e956f048cb5da553d994_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_e07136b898aab6bdd129d97a38b40240_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_2d8d20189622e956f048cb5da553d994_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_a72b35d03087fa0a4bec1c0ae2788558_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_518406dbcb2bfc9ca5f9cf79816fa404,
NULL}; 
void stepfunc_5c751f9adc2466c644bf7b3830bec63d_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(45.0*(1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_4ebbb3b8e5d83fc7528869a697d4837a_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(48.0*(1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_5c751f9adc2466c644bf7b3830bec63d_518406dbcb2bfc9ca5f9cf79816fa404(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_9ea574d5cc99fb98c44468122abddefe_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(45.0*(-1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_1a6627dd384f7df6facdd665028ba70b_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(48.0*(-1.0)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_9ea574d5cc99fb98c44468122abddefe_518406dbcb2bfc9ca5f9cf79816fa404(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_a72b35d03087fa0a4bec1c0ae2788558_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-45.0*FixedPointNum::random()*90.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_5c751f9adc2466c644bf7b3830bec63d_518406dbcb2bfc9ca5f9cf79816fa404(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_2d8d20189622e956f048cb5da553d994_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
p->wait = static_cast<u16>(60.0-1.0*30.0); 
}
void stepfunc_e07136b898aab6bdd129d97a38b40240_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(-45.0*FixedPointNum::random()*90.0));  p->lastBulletSpeed = (1.0+1.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_9ea574d5cc99fb98c44468122abddefe_518406dbcb2bfc9ca5f9cf79816fa404(p);}
p->wait = static_cast<u16>(3.0); 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_518406dbcb2bfc9ca5f9cf79816fa404(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_518406dbcb2bfc9ca5f9cf79816fa404(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_7922268b7ced305096ba0607eefaf65c_518406dbcb2bfc9ca5f9cf79816fa404); 
  }
return bi;}


