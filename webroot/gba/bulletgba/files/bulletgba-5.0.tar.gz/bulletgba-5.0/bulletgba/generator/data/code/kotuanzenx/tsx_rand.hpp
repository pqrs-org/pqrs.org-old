#ifndef GENERATED_76eb81c20cfd5643c48283333e009a49_HPP 
#define GENERATED_76eb81c20cfd5643c48283333e009a49_HPP 

#include "bullet.hpp" 

void stepfunc_1b8bdd1b387f031dcace534466273b71_43ce1400d9175d733d3d38f51328b0e6(BulletInfo *p); 
void stepfunc_f637d86d748499e50e7804aacdfc43db_43ce1400d9175d733d3d38f51328b0e6(BulletInfo *p); 
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_43ce1400d9175d733d3d38f51328b0e6(BulletInfo *p); 


extern const BulletStepFunc bullet_c3a2ebcf83f5af5172d3836c1c6de6ed_43ce1400d9175d733d3d38f51328b0e6[]; 
const unsigned int bullet_c3a2ebcf83f5af5172d3836c1c6de6ed_43ce1400d9175d733d3d38f51328b0e6_size = 242; 


#endif 

