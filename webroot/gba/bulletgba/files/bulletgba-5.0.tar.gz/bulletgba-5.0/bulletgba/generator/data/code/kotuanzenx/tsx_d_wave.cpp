// XXX uniqID XXX c6f591636ff777755f479010df3beaeb XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "kotuanzenx/tsx_d_wave.hpp" 

extern const BulletStepFunc bullet_02de661f4d95953f2b4ba8c311bbd94c_c6f591636ff777755f479010df3beaeb[] = { 
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb,
NULL}; 
extern const BulletStepFunc bullet_3842d13a1206f33cbcc9742c325ff0cf_c6f591636ff777755f479010df3beaeb[] = { 
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb,
NULL}; 
extern const BulletStepFunc bullet_b1fd93a05a08863af72128e1467a0efd_c6f591636ff777755f479010df3beaeb[] = { 
stepfunc_c4469a6e33afc62b016ebdace4ddfc17_c6f591636ff777755f479010df3beaeb,
NULL}; 
extern const BulletStepFunc bullet_09b3484c9ca325cc0f7f85b2d2ea1226_c6f591636ff777755f479010df3beaeb[] = { 
stepfunc_685d53f75ed59e9fd5864ca69b0216a6_c6f591636ff777755f479010df3beaeb,
NULL}; 
void stepfunc_1416b5473ba63e42b2265ecb93832804_c6f591636ff777755f479010df3beaeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(-1.0));  p->lastBulletSpeed = p->getSpeed() + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_c4469a6e33afc62b016ebdace4ddfc17_c6f591636ff777755f479010df3beaeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(11.0));  p->lastBulletSpeed = p->getSpeed() + (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 22; ++i) { 
stepfunc_1416b5473ba63e42b2265ecb93832804_c6f591636ff777755f479010df3beaeb(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_104ce18d0af0c1f198d5f35bf1d8d7ed_c6f591636ff777755f479010df3beaeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(45.0));  p->lastBulletSpeed = ((1.0+1.0*0.5));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b1fd93a05a08863af72128e1467a0efd_c6f591636ff777755f479010df3beaeb); 
  }
}
}
void stepfunc_17cd853e98116607da6fbe2228903026_c6f591636ff777755f479010df3beaeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((0.0)));  p->lastBulletSpeed = ((1.0+1.0*0.5));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b1fd93a05a08863af72128e1467a0efd_c6f591636ff777755f479010df3beaeb); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_104ce18d0af0c1f198d5f35bf1d8d7ed_c6f591636ff777755f479010df3beaeb(p);}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_d39ec9430cfdd074ad7468a5a30bd82a_c6f591636ff777755f479010df3beaeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(45.0));  p->lastBulletSpeed = ((1.5+1.0*0.5));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b1fd93a05a08863af72128e1467a0efd_c6f591636ff777755f479010df3beaeb); 
  }
}
}
void stepfunc_de5ec161ffbec7ea13bb1d3234607c0b_c6f591636ff777755f479010df3beaeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle((22.5)));  p->lastBulletSpeed = ((1.5+1.0*0.5));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b1fd93a05a08863af72128e1467a0efd_c6f591636ff777755f479010df3beaeb); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_d39ec9430cfdd074ad7468a5a30bd82a_c6f591636ff777755f479010df3beaeb(p);}
p->wait = static_cast<u16>(30.0); 
}
void stepfunc_685d53f75ed59e9fd5864ca69b0216a6_c6f591636ff777755f479010df3beaeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_3842d13a1206f33cbcc9742c325ff0cf_c6f591636ff777755f479010df3beaeb); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (SelfPos::getAngle(p));  p->lastBulletSpeed = (0.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_02de661f4d95953f2b4ba8c311bbd94c_c6f591636ff777755f479010df3beaeb); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_c6f591636ff777755f479010df3beaeb(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_09b3484c9ca325cc0f7f85b2d2ea1226_c6f591636ff777755f479010df3beaeb); 
  }
return bi;}


