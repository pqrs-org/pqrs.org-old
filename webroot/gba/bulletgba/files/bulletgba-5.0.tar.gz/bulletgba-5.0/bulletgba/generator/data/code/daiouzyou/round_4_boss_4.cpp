// XXX uniqID XXX 4260b08f1d975e2ecf6d7b53b433e45f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "daiouzyou/round_4_boss_4.hpp" 

extern const BulletStepFunc bullet_480bd6332974751c856ec1268a15404b_4260b08f1d975e2ecf6d7b53b433e45f[] = { 
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4260b08f1d975e2ecf6d7b53b433e45f,
NULL}; 
extern const BulletStepFunc bullet_12b5cfd021af2562cc2e3be1332900bf_4260b08f1d975e2ecf6d7b53b433e45f[] = { 
stepfunc_5b17b63344c3e6f3cfa90d0c9509a0bb_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_5539e47df23923efb8c12f34568bd25a_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_771b6085dabe9b86b414279653a1d5f2_4260b08f1d975e2ecf6d7b53b433e45f,
NULL}; 
extern const BulletStepFunc bullet_87c13070d917756a860edff91cb59231_4260b08f1d975e2ecf6d7b53b433e45f[] = { 
stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_bed6acdf02c7a9af2db12880fd8f87e7_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_bed6acdf02c7a9af2db12880fd8f87e7_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4260b08f1d975e2ecf6d7b53b433e45f,
NULL}; 
extern const BulletStepFunc bullet_5511a66c6717db3d202682ed6d3d3567_4260b08f1d975e2ecf6d7b53b433e45f[] = { 
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_f038105d41c6e3b83567b2b86671dba5_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_bb000653de685bd2d6116ed006ee0417_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4260b08f1d975e2ecf6d7b53b433e45f,
NULL}; 
extern const BulletStepFunc bullet_e17f1dcc6ed77870a290efc0d87a7ff0_4260b08f1d975e2ecf6d7b53b433e45f[] = { 
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_8cd0d8beb41e5829cbb912972cdfd369_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_7ceeab2ea436bb22a544d66c29ca4a6a_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_7ceeab2ea436bb22a544d66c29ca4a6a_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_7ceeab2ea436bb22a544d66c29ca4a6a_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_7ceeab2ea436bb22a544d66c29ca4a6a_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_7ceeab2ea436bb22a544d66c29ca4a6a_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_7ceeab2ea436bb22a544d66c29ca4a6a_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_c9da35c301d3f57dc75c37845a54d426_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_cf67ce2cff3216c391e4ffece646fc13_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_cf67ce2cff3216c391e4ffece646fc13_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_cf67ce2cff3216c391e4ffece646fc13_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_cf67ce2cff3216c391e4ffece646fc13_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_cf67ce2cff3216c391e4ffece646fc13_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_cf67ce2cff3216c391e4ffece646fc13_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4260b08f1d975e2ecf6d7b53b433e45f,
NULL}; 
extern const BulletStepFunc bullet_db099352a7e1ed2977f8090bc0484bcc_4260b08f1d975e2ecf6d7b53b433e45f[] = { 
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_7563ea281d9cbbde980d0334910d0c6d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_b40460895461c87ae7a4d84cbfcfa871_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4260b08f1d975e2ecf6d7b53b433e45f,
NULL}; 
void stepfunc_5b17b63344c3e6f3cfa90d0c9509a0bb_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
p->wait = (
 10.0*FixedPointNum::random()
).toInt(); 
}
void stepfunc_5539e47df23923efb8c12f34568bd25a_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
 1.0
);  FixedPointNum speed = FixedPointNum(
 0.0
 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = static_cast<u16>(
 60.0 
); 
}
void stepfunc_771b6085dabe9b86b414279653a1d5f2_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
 1.0
);  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
0.0
)) - p->getAngle(), life);p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(
 1.0
);  FixedPointNum speed = FixedPointNum(
 2.4
 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_73eb9ffce271fd3d3ee6dacaf6ca3248_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
 FixedPointNum::random()*360.0
));  p->lastBulletSpeed = (
 2.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_12b5cfd021af2562cc2e3be1332900bf_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
}
p->wait = static_cast<u16>(
 3.0
); 
}
void stepfunc_bed6acdf02c7a9af2db12880fd8f87e7_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
p->wait = static_cast<u16>(
 60.0-1.0*60.0
); 
}
void stepfunc_63b4654334aeda3a0ad7530b7a3c4e1e_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
p->wait = static_cast<u16>(
 20.0
); 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_93da82071f528c1d964dc5617712b11e_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 (
 -5.0
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_a1e7fd188d9b07fd61c780c543e57b27_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
p->wait = static_cast<u16>(
 30.0
); 
}
void stepfunc_9af08c77d42138ec652d7166f33e207c_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 42.5
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_93da82071f528c1d964dc5617712b11e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_fa8bbb7f05b2a586643c7da3a5dc083e_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 (
 5.0
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_01b3e0ce2abd9f5df9b81640c88bec9d_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 -42.5
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_fa8bbb7f05b2a586643c7da3a5dc083e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_f038105d41c6e3b83567b2b86671dba5_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 160.0
)
));  p->lastBulletSpeed = (
 1.2+1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_480bd6332974751c856ec1268a15404b_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_fa8bbb7f05b2a586643c7da3a5dc083e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_bb000653de685bd2d6116ed006ee0417_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 210.0
)
));  p->lastBulletSpeed = (
 1.2+1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_480bd6332974751c856ec1268a15404b_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_93da82071f528c1d964dc5617712b11e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_ebb86c3b1b7b3dbd2fa36544be326391_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 (
 -2.5
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_cf67ce2cff3216c391e4ffece646fc13_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 22.5
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_ebb86c3b1b7b3dbd2fa36544be326391_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_815732f96d13434e7c69b5871f5ed43e_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 (
 (
 2.5
)
)
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
(
 0.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_7ceeab2ea436bb22a544d66c29ca4a6a_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
(
 -22.5
)
));  p->lastBulletSpeed = p->lastBulletSpeed + (
0.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_815732f96d13434e7c69b5871f5ed43e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_8cd0d8beb41e5829cbb912972cdfd369_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 200.0
)
));  p->lastBulletSpeed = (
 1.2+1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_480bd6332974751c856ec1268a15404b_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_815732f96d13434e7c69b5871f5ed43e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_c9da35c301d3f57dc75c37845a54d426_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 170.0
)
));  p->lastBulletSpeed = (
 1.2+1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_480bd6332974751c856ec1268a15404b_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_ebb86c3b1b7b3dbd2fa36544be326391_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_7563ea281d9cbbde980d0334910d0c6d_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 220.0
)
));  p->lastBulletSpeed = (
 1.2+1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_480bd6332974751c856ec1268a15404b_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_fa8bbb7f05b2a586643c7da3a5dc083e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}
void stepfunc_b40460895461c87ae7a4d84cbfcfa871_4260b08f1d975e2ecf6d7b53b433e45f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
 150.0
)
));  p->lastBulletSpeed = (
 1.2+1.0
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_480bd6332974751c856ec1268a15404b_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_93da82071f528c1d964dc5617712b11e_4260b08f1d975e2ecf6d7b53b433e45f(p);}
}


BulletInfo *genBulletFunc_4260b08f1d975e2ecf6d7b53b433e45f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_db099352a7e1ed2977f8090bc0484bcc_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_e17f1dcc6ed77870a290efc0d87a7ff0_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_5511a66c6717db3d202682ed6d3d3567_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_87c13070d917756a860edff91cb59231_4260b08f1d975e2ecf6d7b53b433e45f); 
  }
return bi;}


