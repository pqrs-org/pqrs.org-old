// XXX uniqID XXX 5bf4e31b9c8f3c8dc39e076d5d928638 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "__system/easy-aim-line.hpp" 

extern const BulletStepFunc bullet_9cf311e5418c3f3eecaf2234e7775c73_5bf4e31b9c8f3c8dc39e076d5d928638[] = { 
stepfunc_b9f3746024faf71a948d02a3f58cba12_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_c2db9f05d4f182941e7e9906f14f63c0_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_5bf4e31b9c8f3c8dc39e076d5d928638,
NULL}; 
extern const BulletStepFunc bullet_fb611d1e73ffbff511c19a1f920e721f_5bf4e31b9c8f3c8dc39e076d5d928638[] = { 
stepfunc_b9f3746024faf71a948d02a3f58cba12_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_c2db9f05d4f182941e7e9906f14f63c0_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_5bf4e31b9c8f3c8dc39e076d5d928638,
NULL}; 
extern const BulletStepFunc bullet_16abb71f30d9599731bd7b95008edb99_5bf4e31b9c8f3c8dc39e076d5d928638[] = { 
stepfunc_5cc3b1375e1600c1b49c6771d2e4803c_5bf4e31b9c8f3c8dc39e076d5d928638,
NULL}; 
extern const BulletStepFunc bullet_99ed8bdf428a9508da71aa2dc0b9d2af_5bf4e31b9c8f3c8dc39e076d5d928638[] = { 
stepfunc_9ff5a94f9101e71a425feab490936dd8_5bf4e31b9c8f3c8dc39e076d5d928638,
NULL}; 
extern const BulletStepFunc bullet_5f8a48284cdb08692e6145fa5e836f8f_5bf4e31b9c8f3c8dc39e076d5d928638[] = { 
stepfunc_393d27a9ecfd7edca5992dfbc421eca2_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_5bf4e31b9c8f3c8dc39e076d5d928638,
NULL}; 
void stepfunc_7a3f13ea9cbdc8ae8d58ee734bc8da3d_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_9ff5a94f9101e71a425feab490936dd8_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = ((1.0));  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 10; ++i) { 
stepfunc_7a3f13ea9cbdc8ae8d58ee734bc8da3d_5bf4e31b9c8f3c8dc39e076d5d928638(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_5cc3b1375e1600c1b49c6771d2e4803c_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_99ed8bdf428a9508da71aa2dc0b9d2af_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(2.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_99ed8bdf428a9508da71aa2dc0b9d2af_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(-2.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_99ed8bdf428a9508da71aa2dc0b9d2af_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(4.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_99ed8bdf428a9508da71aa2dc0b9d2af_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (FixedPointNum::degree2angle(-4.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_99ed8bdf428a9508da71aa2dc0b9d2af_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_24fb152841d1f29e9cd8b20f8cec8164_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_16abb71f30d9599731bd7b95008edb99_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
p->wait = static_cast<u16>(90.0); 
}
void stepfunc_493aee2ccd504a0a901204a0e71cbb72_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0+20.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_16abb71f30d9599731bd7b95008edb99_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
p->wait = static_cast<u16>(90.0); 
}
void stepfunc_b9f3746024faf71a948d02a3f58cba12_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
p->wait = static_cast<u16>(10.0); 
}
void stepfunc_c2db9f05d4f182941e7e9906f14f63c0_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1.0);  FixedPointNum speed = 0.0 - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_b1fc3ecc201599a83914641075ca994e_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(180.0-20.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_16abb71f30d9599731bd7b95008edb99_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
p->wait = static_cast<u16>(90.0); 
}
void stepfunc_393d27a9ecfd7edca5992dfbc421eca2_5bf4e31b9c8f3c8dc39e076d5d928638(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb611d1e73ffbff511c19a1f920e721f_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(270.0));  p->lastBulletSpeed = (4.0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9cf311e5418c3f3eecaf2234e7775c73_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
}
}


BulletInfo *genBulletFunc_5bf4e31b9c8f3c8dc39e076d5d928638(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_5f8a48284cdb08692e6145fa5e836f8f_5bf4e31b9c8f3c8dc39e076d5d928638); 
  }
return bi;}


