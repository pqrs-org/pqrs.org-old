// XXX uniqID XXX 797b9c7b21326eb9fd4e634c5e67b93a XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "bulletsmorph/aba_4.hpp" 

extern const BulletStepFunc bullet_c5ac8f1d131e76060340b585e410611c_797b9c7b21326eb9fd4e634c5e67b93a[] = { 
stepfunc_4ef44b166c4d984f7c75b5ba04b814dd_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_413664ef93031bdc378092a1c8aa41dd_797b9c7b21326eb9fd4e634c5e67b93a,
NULL}; 
extern const BulletStepFunc bullet_529988a3b24e2c60a6c52f01c70f62ac_797b9c7b21326eb9fd4e634c5e67b93a[] = { 
stepfunc_1491bb7a1e6f9c904ebd546984e68758_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_797b9c7b21326eb9fd4e634c5e67b93a,
NULL}; 
void stepfunc_4ef44b166c4d984f7c75b5ba04b814dd_797b9c7b21326eb9fd4e634c5e67b93a(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(300.0);  FixedPointNum speed = FixedPointNum(p->getSpeed() + 4.0, life);p->setAccel(speed, life);}
p->wait = static_cast<u16>(45.0); 
}
void stepfunc_413664ef93031bdc378092a1c8aa41dd_797b9c7b21326eb9fd4e634c5e67b93a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (1.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(90.0));  p->lastBulletSpeed = (1.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(-90.0));  p->lastBulletSpeed = (1.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (1.3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_a91b9f4f2890ea2b4e9b1698fa318167_797b9c7b21326eb9fd4e634c5e67b93a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = p->lastBulletSpeed + (0.04);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c5ac8f1d131e76060340b585e410611c_797b9c7b21326eb9fd4e634c5e67b93a); 
  }
}
p->wait = static_cast<u16>(20.0 - 10.0 * 1.0); 
}
void stepfunc_1491bb7a1e6f9c904ebd546984e68758_797b9c7b21326eb9fd4e634c5e67b93a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(0.0));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c5ac8f1d131e76060340b585e410611c_797b9c7b21326eb9fd4e634c5e67b93a); 
  }
}
p->wait = static_cast<u16>(5.0); 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_797b9c7b21326eb9fd4e634c5e67b93a(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_797b9c7b21326eb9fd4e634c5e67b93a(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_529988a3b24e2c60a6c52f01c70f62ac_797b9c7b21326eb9fd4e634c5e67b93a); 
  }
return bi;}


