// XXX uniqID XXX 9ef048954db14033ff500b595acd6671 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "g-wange/round_trip_bit.hpp" 

extern const BulletStepFunc bullet_d301d012bc0fb5aa0bb9ef2eaf3dff50_9ef048954db14033ff500b595acd6671[] = { 
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_f69edb6f1fba652b471058567add1f26_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_b40448ebf4e07e20019cb97877d48303_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_f69edb6f1fba652b471058567add1f26_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_b40448ebf4e07e20019cb97877d48303_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_f69edb6f1fba652b471058567add1f26_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_b40448ebf4e07e20019cb97877d48303_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_f69edb6f1fba652b471058567add1f26_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_b40448ebf4e07e20019cb97877d48303_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_f69edb6f1fba652b471058567add1f26_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_b40448ebf4e07e20019cb97877d48303_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
NULL}; 
extern const BulletStepFunc bullet_2d3ccd2bdf2452a5bab0b5cdaec83e3d_9ef048954db14033ff500b595acd6671[] = { 
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_fbf89d3b795d1e8e0fe26528a0f70493_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_e89b3febfe16af5224720edda7529ccd_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_fbf89d3b795d1e8e0fe26528a0f70493_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_e89b3febfe16af5224720edda7529ccd_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_fbf89d3b795d1e8e0fe26528a0f70493_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_e89b3febfe16af5224720edda7529ccd_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_fbf89d3b795d1e8e0fe26528a0f70493_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_e89b3febfe16af5224720edda7529ccd_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_fbf89d3b795d1e8e0fe26528a0f70493_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
stepfunc_e89b3febfe16af5224720edda7529ccd_9ef048954db14033ff500b595acd6671,
stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671,
NULL}; 
extern const BulletStepFunc bullet_2627f87116f969720a5d30219c57263e_9ef048954db14033ff500b595acd6671[] = { 
stepfunc_376596af767c6f62df4ee05f0bbbdb2c_9ef048954db14033ff500b595acd6671,
NULL}; 
void stepfunc_536434ad20316a67e230e88ba0d16b07_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum::degree2angle(
5.0+1.0*5.0
));  p->lastBulletSpeed = (
1.6
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_dcb533d851c747a6fba521bff30e299e_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
30.0
);  FixedPointNum speed = FixedPointNum(
0.01
 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-(5.0+1.0*5.0)*((
3.0
)-1.0)-4.0+FixedPointNum::random()*8.0
));  p->lastBulletSpeed = (
1.6
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_536434ad20316a67e230e88ba0d16b07_9ef048954db14033ff500b595acd6671(p);}
p->wait = static_cast<u16>(
15.0
); 
}
void stepfunc_c6f9197c635b66b1c3488abaa8dd60f0_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-(5.0+1.0*5.0)*((
5.0
)-1.0)-4.0+FixedPointNum::random()*8.0
));  p->lastBulletSpeed = (
1.6
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_536434ad20316a67e230e88ba0d16b07_9ef048954db14033ff500b595acd6671(p);}
p->wait = static_cast<u16>(
15.0
); 
}
void stepfunc_f69edb6f1fba652b471058567add1f26_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
1.0
);  FixedPointNum speed = FixedPointNum((FixedPointNum::degree2angle(
-(
-91.0
)
)) - p->getAngle(), life);p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(
30.0
);  FixedPointNum speed = FixedPointNum(
(
4.0
)
 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-(5.0+1.0*5.0)*((
3.0
)-1.0)-4.0+FixedPointNum::random()*8.0
));  p->lastBulletSpeed = (
1.6
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_536434ad20316a67e230e88ba0d16b07_9ef048954db14033ff500b595acd6671(p);}
p->wait = static_cast<u16>(
15.0
); 
}
void stepfunc_b40448ebf4e07e20019cb97877d48303_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
1.0
);  FixedPointNum speed = FixedPointNum((FixedPointNum::degree2angle(
(
-91.0
)
)) - p->getAngle(), life);p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(
30.0
);  FixedPointNum speed = FixedPointNum(
(
4.0
)
 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-(5.0+1.0*5.0)*((
3.0
)-1.0)-4.0+FixedPointNum::random()*8.0
));  p->lastBulletSpeed = (
1.6
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_536434ad20316a67e230e88ba0d16b07_9ef048954db14033ff500b595acd6671(p);}
p->wait = static_cast<u16>(
15.0
); 
}
void stepfunc_fbf89d3b795d1e8e0fe26528a0f70493_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
1.0
);  FixedPointNum speed = FixedPointNum((FixedPointNum::degree2angle(
-(
91.0
)
)) - p->getAngle(), life);p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(
30.0
);  FixedPointNum speed = FixedPointNum(
(
5.0
)
 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-(5.0+1.0*5.0)*((
3.0
)-1.0)-4.0+FixedPointNum::random()*8.0
));  p->lastBulletSpeed = (
1.6
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_536434ad20316a67e230e88ba0d16b07_9ef048954db14033ff500b595acd6671(p);}
p->wait = static_cast<u16>(
15.0
); 
}
void stepfunc_e89b3febfe16af5224720edda7529ccd_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(
1.0
);  FixedPointNum speed = FixedPointNum((FixedPointNum::degree2angle(
(
91.0
)
)) - p->getAngle(), life);p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(
30.0
);  FixedPointNum speed = FixedPointNum(
(
5.0
)
 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::degree2angle(
-(5.0+1.0*5.0)*((
3.0
)-1.0)-4.0+FixedPointNum::random()*8.0
));  p->lastBulletSpeed = (
1.6
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_536434ad20316a67e230e88ba0d16b07_9ef048954db14033ff500b595acd6671(p);}
p->wait = static_cast<u16>(
15.0
); 
}
void stepfunc_376596af767c6f62df4ee05f0bbbdb2c_9ef048954db14033ff500b595acd6671(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
91.0
)
));  p->lastBulletSpeed = (
(
5.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_2d3ccd2bdf2452a5bab0b5cdaec83e3d_9ef048954db14033ff500b595acd6671); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (FixedPointNum::degree2angle(
(
-91.0
)
));  p->lastBulletSpeed = (
(
4.0
)
);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(p->getType() << 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d301d012bc0fb5aa0bb9ef2eaf3dff50_9ef048954db14033ff500b595acd6671); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_9ef048954db14033ff500b595acd6671(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_2627f87116f969720a5d30219c57263e_9ef048954db14033ff500b595acd6671); 
  }
return bi;}


