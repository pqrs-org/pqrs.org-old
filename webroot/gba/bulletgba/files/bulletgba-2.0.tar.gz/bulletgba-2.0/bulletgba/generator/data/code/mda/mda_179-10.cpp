// XXX uniqID XXX 0025924d7de957bd5fad4aa4d983379b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/mda_179-10.hpp" 

extern const BulletStepFunc bullet_926313e5e3675bf0ee9245cb8cddd1a7_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_0d131920c4c47491adc1a0221a93b284_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_52b93e776c5de5f4c231f9365cda2394_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_a9c7baaae68c6f73ca39cc75b8acf004_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_aa4f73437224459c1ba1cfb120e45b63_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_2a1767e4a12eed670b6d56d99868dc30_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_bdc6daa39bf82eddfeac4a3432fda84e_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_5487efa73c5e6213f1be8473e1944c1f_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_645dd13cc470d95db15c02d94e523540_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_9de52f30be9c4926b144e4671e32da73_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_0d4e6225fba5feba71fcba82f537abb9_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_ddbfa4980073608874cdfa61b21488fc_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_c599935ea8d81f4eda9be76361af2651_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_14bd2c3d6ea7e77f5d62ad9be773faf9_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_5d6f38fa8117c186b5e0836ed82ba03e_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_b8d11b532b7e8bc03e43663d50a6dbaf_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_95df0c3c4e5853115b3fd9722af33772_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_4a43b1085c1de97126c2e1845ea4e581_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_496b1ed911b2acdee210a8753d650f1f_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_e4915bc12951ca61f54e9539ae397232_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_91a0fe6689eaafea19e2a1156148f432_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_fff3edcad1a70e4559f221ef1f9b1459_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_c56a093675659d36baeb5b13c1fc6fc9_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_c7154b3ad32477a583e212fafa9a6203_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_de29a2fe76fb908d13c968a19f145ee4_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_5cf0edffdb357278c608454350162fb9_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_a894452b281f86a8ef106629147f47d8_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_96b47f4565ecc4ab654ba6c4cca0610a_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_f44a4b2ca9ee366400baca2f38bbd1c3_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_be47b5c77b0cf478a5e59cd30b6c5c23_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_efa16ebe397f5bc425d5a2e194996228_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_56d1ea871588d2693fe21bbea75acbbb_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_8c7a1a899f6554b66ec671ec76992012_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_6d7fc36327d4f432550d8bfbecddaad0_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_81c4e21bbe9ea2f6f3163c1542ebfb83_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_4a91081db5f1018f3d0ea22f82315b02_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_128c2f3834f462c0f2372efa0cc2c8d0_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_8c53e2d35fdc0cf4c5bc75d69bfde9b8_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_66317d269fdcfade9ed868492d8af9bf_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b,
stepfunc_cf2720e0c9405fcc6274d3a293376864_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
extern const BulletStepFunc bullet_eda70dcab7b46f8ab59cf0d4f3e47fa5_0025924d7de957bd5fad4aa4d983379b[] = { 
stepfunc_a66f8304766f2926974b130ecb2d194d_0025924d7de957bd5fad4aa4d983379b,
stepfunc_56269e8bcafd645c04184650d67c577b_0025924d7de957bd5fad4aa4d983379b,
stepfunc_db13a8c997ab10b2fbab567581e91f4e_0025924d7de957bd5fad4aa4d983379b,
NULL}; 
void stepfunc_b6b69e12e8029e011df31946bab3914a_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
p->wait = 5; 
}
void stepfunc_2a1767e4a12eed670b6d56d99868dc30_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-12226, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_5487efa73c5e6213f1be8473e1944c1f_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-11507, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_9de52f30be9c4926b144e4671e32da73_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-10787, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_ddbfa4980073608874cdfa61b21488fc_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-10068, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_14bd2c3d6ea7e77f5d62ad9be773faf9_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-9349, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_b8d11b532b7e8bc03e43663d50a6dbaf_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-8630, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_4a43b1085c1de97126c2e1845ea4e581_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-7911, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_e4915bc12951ca61f54e9539ae397232_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-7191, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_fff3edcad1a70e4559f221ef1f9b1459_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-6472, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_c7154b3ad32477a583e212fafa9a6203_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-5753, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_5cf0edffdb357278c608454350162fb9_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-5034, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_96b47f4565ecc4ab654ba6c4cca0610a_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4315, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_be47b5c77b0cf478a5e59cd30b6c5c23_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3595, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_56d1ea871588d2693fe21bbea75acbbb_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2876, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_6d7fc36327d4f432550d8bfbecddaad0_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2157, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_4a91081db5f1018f3d0ea22f82315b02_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1438, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_8c53e2d35fdc0cf4c5bc75d69bfde9b8_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-719, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_cf2720e0c9405fcc6274d3a293376864_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(1))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_62fb0666eafb5dfee6144f886bbe627d_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_66317d269fdcfade9ed868492d8af9bf_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_128c2f3834f462c0f2372efa0cc2c8d0_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2022, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_81c4e21bbe9ea2f6f3163c1542ebfb83_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3034, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8c7a1a899f6554b66ec671ec76992012_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4045, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_efa16ebe397f5bc425d5a2e194996228_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5056, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f44a4b2ca9ee366400baca2f38bbd1c3_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6068, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a894452b281f86a8ef106629147f47d8_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7079, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_de29a2fe76fb908d13c968a19f145ee4_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8090, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c56a093675659d36baeb5b13c1fc6fc9_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9102, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_91a0fe6689eaafea19e2a1156148f432_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10113, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_496b1ed911b2acdee210a8753d650f1f_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11124, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_95df0c3c4e5853115b3fd9722af33772_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12136, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5d6f38fa8117c186b5e0836ed82ba03e_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13147, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c599935ea8d81f4eda9be76361af2651_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14159, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0d4e6225fba5feba71fcba82f537abb9_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15170, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_645dd13cc470d95db15c02d94e523540_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16181, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bdc6daa39bf82eddfeac4a3432fda84e_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17193, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_aa4f73437224459c1ba1cfb120e45b63_0025924d7de957bd5fad4aa4d983379b;  }
}
p->wait = 18; 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (64);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
void stepfunc_0b3ec0c7c7773aa76e3b343c07fd9fdc_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1635, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a9c7baaae68c6f73ca39cc75b8acf004_0025924d7de957bd5fad4aa4d983379b;  }
}
p->wait = 1; 
}
void stepfunc_52b93e776c5de5f4c231f9365cda2394_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(1635, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a9c7baaae68c6f73ca39cc75b8acf004_0025924d7de957bd5fad4aa4d983379b;  }
}
p->wait = 1; 
}
void stepfunc_a66f8304766f2926974b130ecb2d194d_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (128) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 15; 
}
void stepfunc_56269e8bcafd645c04184650d67c577b_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
void stepfunc_db13a8c997ab10b2fbab567581e91f4e_0025924d7de957bd5fad4aa4d983379b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0d131920c4c47491adc1a0221a93b284_0025924d7de957bd5fad4aa4d983379b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_926313e5e3675bf0ee9245cb8cddd1a7_0025924d7de957bd5fad4aa4d983379b;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_0025924d7de957bd5fad4aa4d983379b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_eda70dcab7b46f8ab59cf0d4f3e47fa5_0025924d7de957bd5fad4aa4d983379b; }}


