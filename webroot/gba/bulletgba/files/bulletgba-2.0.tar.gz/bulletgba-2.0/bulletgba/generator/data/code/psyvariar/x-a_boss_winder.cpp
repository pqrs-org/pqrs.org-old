// XXX uniqID XXX 442ab43dc019e08224faee2a5eea1d4f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "psyvariar/x-a_boss_winder.hpp" 

extern const BulletStepFunc bullet_da96227acf90344776c8ab48e4c4ee93_442ab43dc019e08224faee2a5eea1d4f[] = { 
stepfunc_1ddf85bcc8190140fbb3332be4a151f1_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_442ab43dc019e08224faee2a5eea1d4f,
NULL}; 
extern const BulletStepFunc bullet_86a1a30c9e22cca02cea481456a98db2_442ab43dc019e08224faee2a5eea1d4f[] = { 
stepfunc_aa049bb77ff2bc907d90d6a444e681e9_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_442ab43dc019e08224faee2a5eea1d4f,
NULL}; 
void stepfunc_a4b4d1e9f500be02a90f488efc4d28bb_442ab43dc019e08224faee2a5eea1d4f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2133, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
void stepfunc_146291a0935a78bf8367cf489786bb54_442ab43dc019e08224faee2a5eea1d4f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2133, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb_442ab43dc019e08224faee2a5eea1d4f(p);}
p->wait = 5; 
}
void stepfunc_2d271dd39970d604a2d68941a3e72123_442ab43dc019e08224faee2a5eea1d4f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2062, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb_442ab43dc019e08224faee2a5eea1d4f(p);}
p->wait = 5; 
}
void stepfunc_1ddf85bcc8190140fbb3332be4a151f1_442ab43dc019e08224faee2a5eea1d4f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-142, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_442ab43dc019e08224faee2a5eea1d4f(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_52a37301c841597ea6205a7e6e264652_442ab43dc019e08224faee2a5eea1d4f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2204, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb_442ab43dc019e08224faee2a5eea1d4f(p);}
p->wait = 5; 
}
void stepfunc_aa049bb77ff2bc907d90d6a444e681e9_442ab43dc019e08224faee2a5eea1d4f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(142, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}


void genBulletFunc_442ab43dc019e08224faee2a5eea1d4f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_86a1a30c9e22cca02cea481456a98db2_442ab43dc019e08224faee2a5eea1d4f; }  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_da96227acf90344776c8ab48e4c4ee93_442ab43dc019e08224faee2a5eea1d4f; }}


