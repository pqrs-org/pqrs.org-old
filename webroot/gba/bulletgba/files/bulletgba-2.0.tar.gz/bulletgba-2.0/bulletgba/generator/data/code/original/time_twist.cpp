// XXX uniqID XXX 989ff2b8b35015e96861a32f95d1584b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "original/time_twist.hpp" 

extern const BulletStepFunc bullet_cb7d381644e3b6e794cb9b40d8ed2410_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_f4323c2faff95e5d43596ceb701f1f8c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_1406dbc0e95d0e28d136d83b6fb7b91a_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca_989ff2b8b35015e96861a32f95d1584b,
stepfunc_cd4f9bab503495252b0ec1eb13e12889_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_6ecf7b3dda1da346dbf0d8325eb2ce09_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e8dc0db58e1159e94b4f3477982a2bab_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_741e163a03d1f5e53bbdcc674430341c_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_95874c360a4c89e01fddd0381e0669e0_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e1acda78f881a62084d282e03cce0673_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_97fb555f92edd1cb46607d6f0be04444_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_95874c360a4c89e01fddd0381e0669e0_989ff2b8b35015e96861a32f95d1584b,
stepfunc_142b983889f08346cc7f29996da6f2b3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_406031d4b5a7af0ee35e5ddd48c685e5_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_95874c360a4c89e01fddd0381e0669e0_989ff2b8b35015e96861a32f95d1584b,
stepfunc_17171781cbd716ace724cf7344b39fba_989ff2b8b35015e96861a32f95d1584b,
stepfunc_2f624a9685000b947084015ec2e794ef_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b,
stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_c8bb8f5504d03fea3f7087d8213e4167_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_7f0a30884d50a3b8ba8fe845e184b11d_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_5e17a0886bec8cdeb8139050eb310e44_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_9f9b673a4b97f3d3cfb6add98a7ed662_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_4d53aa09b725f4025ae7debc40f943dd_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca_989ff2b8b35015e96861a32f95d1584b,
stepfunc_35dfb82b81f9ca721a64c8f07177ffb6_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_b5b9d1de8d7570d801a74ab70c409622_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca_989ff2b8b35015e96861a32f95d1584b,
stepfunc_150d8c9baf034133bfa1984cc5b334f1_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
extern const BulletStepFunc bullet_7f5a31426df12cb28589b1eecfdbe2fb_989ff2b8b35015e96861a32f95d1584b[] = { 
stepfunc_25871b8d66b56a2248fbce52e2ea169f_989ff2b8b35015e96861a32f95d1584b,
stepfunc_3961d19aeeed7c75d079962a874152ba_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b,
stepfunc_b4db4a15e9d73afe83dd865209d7269e_989ff2b8b35015e96861a32f95d1584b,
stepfunc_92f8f1148b643f6f285e58f1164c6378_989ff2b8b35015e96861a32f95d1584b,
stepfunc_995ac8a72bc3098372a05553d1e41ad3_989ff2b8b35015e96861a32f95d1584b,
NULL}; 
void stepfunc_d0b16b98f2c9e7394fa3442969567303_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128) * FixedPointNum::random()) * FixedPointNum(71, 100));    p->lastBulletSpeed = ((
      (FixedPointNum(80, 100) + FixedPointNum(110, 100)*(FixedPointNum(180) * FixedPointNum::random())*(FixedPointNum(180)-(FixedPointNum(180) * FixedPointNum::random()))/FixedPointNum(8100)) * (FixedPointNum(50, 100)+FixedPointNum(50, 100)*FixedPointNum::random()) * FixedPointNum(1)
    ));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128) * FixedPointNum::random()) * (-FixedPointNum(71, 100)));    p->lastBulletSpeed = ((
      (FixedPointNum(80, 100) + FixedPointNum(110, 100)*(FixedPointNum(180) * FixedPointNum::random())*(FixedPointNum(180)-(FixedPointNum(180) * FixedPointNum::random()))/FixedPointNum(8100)) * (FixedPointNum(50, 100)+FixedPointNum(50, 100)*FixedPointNum::random()) * FixedPointNum(1)
    ));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
void stepfunc_c7d3bb89a2f48689092bf7b478d3e52f_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 5; 
}
void stepfunc_f4323c2faff95e5d43596ceb701f1f8c_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(FixedPointNum(110, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_1406dbc0e95d0e28d136d83b6fb7b91a_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
p->wait = 60; 
}
void stepfunc_cd4f9bab503495252b0ec1eb13e12889_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
for (u32 i = 0; i < 300; ++i) { 
stepfunc_d0b16b98f2c9e7394fa3442969567303_989ff2b8b35015e96861a32f95d1584b(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_35dfb82b81f9ca721a64c8f07177ffb6_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-64);    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_150d8c9baf034133bfa1984cc5b334f1_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_729db3863fc14565017f8697a934bf30_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5b9d1de8d7570d801a74ab70c409622_989ff2b8b35015e96861a32f95d1584b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4d53aa09b725f4025ae7debc40f943dd_989ff2b8b35015e96861a32f95d1584b;  }
}
p->wait = 2; 
}
void stepfunc_e8dc0db58e1159e94b4f3477982a2bab_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_9f9b673a4b97f3d3cfb6add98a7ed662_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(((FixedPointNum(11377, 100) + FixedPointNum(2844, 100) * FixedPointNum::random())) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 300;  FixedPointNum speed = FixedPointNum(3 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_a3ba8a4541d4388bca06754a094dff87_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((-FixedPointNum(32) + FixedPointNum(64) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5e17a0886bec8cdeb8139050eb310e44_989ff2b8b35015e96861a32f95d1584b;  }
}
p->wait = 3; 
}
void stepfunc_7f0a30884d50a3b8ba8fe845e184b11d_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(((FixedPointNum(11377, 100) + FixedPointNum(2844, 100) * FixedPointNum::random())) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 30; 
}
void stepfunc_e6437b806c78f1802565b058564622c3_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((-FixedPointNum(32) + FixedPointNum(64) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c8bb8f5504d03fea3f7087d8213e4167_989ff2b8b35015e96861a32f95d1584b;  }
}
p->wait = 6; 
}
void stepfunc_6616569ffc4b15d198bedc782c5aa499_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (32);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
void stepfunc_d1bd02a5b42bf28a515664b6d6302b08_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-32);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
void stepfunc_7f0075d67c1f721c4f48a329150948a7_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4266, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
void stepfunc_95874c360a4c89e01fddd0381e0669e0_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
p->wait = 30; 
}
void stepfunc_17171781cbd716ace724cf7344b39fba_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(8533, 100)) - p->getAngle();p->setRound(speed, life);}
p->wait = 5; 
}
void stepfunc_2f624a9685000b947084015ec2e794ef_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
void stepfunc_76590f9d1cfe1481f1d66e71c46b105c_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_406031d4b5a7af0ee35e5ddd48c685e5_989ff2b8b35015e96861a32f95d1584b;  }
}
}
void stepfunc_e1acda78f881a62084d282e03cce0673_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_406031d4b5a7af0ee35e5ddd48c685e5_989ff2b8b35015e96861a32f95d1584b;  }
}
}
void stepfunc_9614c45ae3acafc62e3820bf3fa17b06_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
void stepfunc_142b983889f08346cc7f29996da6f2b3_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
void stepfunc_25871b8d66b56a2248fbce52e2ea169f_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97fb555f92edd1cb46607d6f0be04444_989ff2b8b35015e96861a32f95d1584b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-64);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97fb555f92edd1cb46607d6f0be04444_989ff2b8b35015e96861a32f95d1584b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97fb555f92edd1cb46607d6f0be04444_989ff2b8b35015e96861a32f95d1584b;  }
}
p->wait = 20; 
}
void stepfunc_3961d19aeeed7c75d079962a874152ba_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_741e163a03d1f5e53bbdcc674430341c_989ff2b8b35015e96861a32f95d1584b;  }
}
p->wait = 20; 
}
void stepfunc_b4db4a15e9d73afe83dd865209d7269e_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
p->wait = 20; 
}
void stepfunc_92f8f1148b643f6f285e58f1164c6378_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6ecf7b3dda1da346dbf0d8325eb2ce09_989ff2b8b35015e96861a32f95d1584b;  }
}
p->wait = 20; 
}
void stepfunc_995ac8a72bc3098372a05553d1e41ad3_989ff2b8b35015e96861a32f95d1584b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb7d381644e3b6e794cb9b40d8ed2410_989ff2b8b35015e96861a32f95d1584b;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_989ff2b8b35015e96861a32f95d1584b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_7f5a31426df12cb28589b1eecfdbe2fb_989ff2b8b35015e96861a32f95d1584b; }}


