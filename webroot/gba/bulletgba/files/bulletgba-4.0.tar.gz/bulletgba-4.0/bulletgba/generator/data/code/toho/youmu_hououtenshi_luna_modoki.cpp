// XXX uniqID XXX b861b3aa367b0e8842df43a2feddbebc XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "toho/youmu_hououtenshi_luna_modoki.hpp" 

extern const BulletStepFunc bullet_4d72effc8322bb4ec20d2da286fdd8e1_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_2ba1bc811dfe9a2516cb9ef97488da42_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_ad81ffe5cebc6a9c03b25ebf88eb22f9_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_3bd986d2c05190d5632c7fe668aae2aa_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_2ba1bc811dfe9a2516cb9ef97488da42_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_d84e9ad1e34f67b79eb1179da83c034c_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_3844d4c04d348a46bcf42d057e954a7a_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_8177e270122b5d2f93ef6690a2d5400a_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_acc036fea3ceb004422a59769fe8e94b_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_f2d23c6784413b9f1d6f133b25ac9362_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_b30d4bca6da00e66cf52844f8dad0c76_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_c83e7499ee15aa1d85af4a09f56884bc_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_b1815b4145cd4016015a26f209c8c769_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_7e43bdac08d71788d0b3605848d4a101_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_a3aec0b3ad70b05aa2c4b539b36bf56c_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_b09be07c469186e9ccf76ac73d0bf974_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_fcbb9cab38312c404636ddf729ffa79a_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_7b2c4beb9b7ad2994727f21d2c162da8_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
extern const BulletStepFunc bullet_f2b8c2b05f43ee6818e6ec7cf07f6aa3_b861b3aa367b0e8842df43a2feddbebc[] = { 
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_b861b3aa367b0e8842df43a2feddbebc,
NULL}; 
void stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(1, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 60; 
}
void stepfunc_7b2c4beb9b7ad2994727f21d2c162da8_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-3539, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(80, 100) - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_d5c62833270b0bc08244d4f1e3784668_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fcbb9cab38312c404636ddf729ffa79a_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
}
void stepfunc_b09be07c469186e9ccf76ac73d0bf974_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-3792, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(75, 100) - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_d31c0e66f25528d9d339af1450497058_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a3aec0b3ad70b05aa2c4b539b36bf56c_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
}
void stepfunc_7e43bdac08d71788d0b3605848d4a101_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4045, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(70, 100) - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_1de81cb60122b1ccf99fe3bd5b250330_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b1815b4145cd4016015a26f209c8c769_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
}
void stepfunc_c83e7499ee15aa1d85af4a09f56884bc_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4298, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(65, 100) - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_2457986c60d2ef7ce5df9bb3b336a024_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b30d4bca6da00e66cf52844f8dad0c76_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
}
void stepfunc_f2d23c6784413b9f1d6f133b25ac9362_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4551, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(60, 100) - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_d050b2a0217080616ee3841967e9fd8b_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1285, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_acc036fea3ceb004422a59769fe8e94b_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
}
void stepfunc_2ba1bc811dfe9a2516cb9ef97488da42_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
p->wait = ((FixedPointNum::random()*FixedPointNum(30))).toInt(); 
}
void stepfunc_ad81ffe5cebc6a9c03b25ebf88eb22f9_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 2; 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_fa5adbdbbe9de633d382e95cbe1d3136_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-252, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_8177e270122b5d2f93ef6690a2d5400a_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(4551, 100));    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_fa5adbdbbe9de633d382e95cbe1d3136_b861b3aa367b0e8842df43a2feddbebc(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_379a7a25f4afe9d19ddaf1e2cd24e386_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_3844d4c04d348a46bcf42d057e954a7a_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
}
void stepfunc_d84e9ad1e34f67b79eb1179da83c034c_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_fc66c59b1c4102d6e9e8b5e4dc3eeeac_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum::random()*FixedPointNum(17066, 100))+FixedPointNum(4266, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_3bd986d2c05190d5632c7fe668aae2aa_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
p->wait = 20; 
}
void stepfunc_2b476569bfd19462355303810672262d_b861b3aa367b0e8842df43a2feddbebc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum::random()*FixedPointNum(17066, 100))+FixedPointNum(4266, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4d72effc8322bb4ec20d2da286fdd8e1_b861b3aa367b0e8842df43a2feddbebc); 
  }
}
p->wait = 60; 
}


BulletInfo *genBulletFunc_b861b3aa367b0e8842df43a2feddbebc(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_f2b8c2b05f43ee6818e6ec7cf07f6aa3_b861b3aa367b0e8842df43a2feddbebc); 
  }
return bi;}


