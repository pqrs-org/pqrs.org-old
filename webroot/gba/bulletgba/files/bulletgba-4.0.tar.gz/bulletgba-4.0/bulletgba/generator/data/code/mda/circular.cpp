// XXX uniqID XXX 66a6105556800f2952d4f34a118d29d3 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/circular.hpp" 

extern const BulletStepFunc bullet_24167139d83657a189725bdf6c9a3586_66a6105556800f2952d4f34a118d29d3[] = { 
stepfunc_c24fa0261d7a22f141a706463b79408c_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_66a6105556800f2952d4f34a118d29d3,
NULL}; 
extern const BulletStepFunc bullet_6155b2a835d2317e373376df552fe954_66a6105556800f2952d4f34a118d29d3[] = { 
stepfunc_8f4cdae05ba0f92d45e02550a5a064c5_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_66a6105556800f2952d4f34a118d29d3,
NULL}; 
extern const BulletStepFunc bullet_92b5b581a86e32ba3419124f5e83a26a_66a6105556800f2952d4f34a118d29d3[] = { 
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_66a6105556800f2952d4f34a118d29d3,
NULL}; 
void stepfunc_4c3855109bee87480d88ba302480fcd5_66a6105556800f2952d4f34a118d29d3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 20; 
}
void stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd_66a6105556800f2952d4f34a118d29d3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(355, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = ((FixedPointNum(4)+FixedPointNum::random()*FixedPointNum(8))).toInt(); 
}
void stepfunc_c24fa0261d7a22f141a706463b79408c_66a6105556800f2952d4f34a118d29d3(BulletInfo *p) { 
{
  u16 life = 9999;  FixedPointNum speed = FixedPointNum(25457, 100);p->setRound(speed, life);}
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_66a6105556800f2952d4f34a118d29d3(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_1c11037c651b8c192888e0327f487cf0_66a6105556800f2952d4f34a118d29d3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(25244, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = ((FixedPointNum(4)+FixedPointNum::random()*FixedPointNum(8))).toInt(); 
}
void stepfunc_8f4cdae05ba0f92d45e02550a5a064c5_66a6105556800f2952d4f34a118d29d3(BulletInfo *p) { 
{
  u16 life = 9999;  FixedPointNum speed = FixedPointNum(142, 100);p->setRound(speed, life);}
}
void stepfunc_1da5c0fb24f617ef84972191b8eb43ad_66a6105556800f2952d4f34a118d29d3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6155b2a835d2317e373376df552fe954_66a6105556800f2952d4f34a118d29d3); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (192);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_24167139d83657a189725bdf6c9a3586_66a6105556800f2952d4f34a118d29d3); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 20; 
}


BulletInfo *genBulletFunc_66a6105556800f2952d4f34a118d29d3(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_92b5b581a86e32ba3419124f5e83a26a_66a6105556800f2952d4f34a118d29d3); 
  }
return bi;}


