// XXX uniqID XXX 7f9a567c3018d52c28ddc4637deab280 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "misc/border_down_6a_boss_x_explosion.hpp" 

extern const BulletStepFunc bullet_260850096b40658c55c70ac4bac9222d_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_faeb9ac81b7a64ffed123259883c3994_7f9a567c3018d52c28ddc4637deab280,
stepfunc_4fc39e92360478aed68777bd40eda960_7f9a567c3018d52c28ddc4637deab280,
stepfunc_c643dd46bc429e99869b1b84bf10ac23_7f9a567c3018d52c28ddc4637deab280,
stepfunc_c643dd46bc429e99869b1b84bf10ac23_7f9a567c3018d52c28ddc4637deab280,
stepfunc_c643dd46bc429e99869b1b84bf10ac23_7f9a567c3018d52c28ddc4637deab280,
stepfunc_c643dd46bc429e99869b1b84bf10ac23_7f9a567c3018d52c28ddc4637deab280,
stepfunc_c643dd46bc429e99869b1b84bf10ac23_7f9a567c3018d52c28ddc4637deab280,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_e7133ec0a11dc9bc4201ccacb101e2b1_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_4e1882c6d575977071f0893527d2e423_7f9a567c3018d52c28ddc4637deab280,
stepfunc_f828d6ab286193b69f72fd2f3ec374a6_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_4e1882c6d575977071f0893527d2e423_7f9a567c3018d52c28ddc4637deab280,
stepfunc_f463ff547edafe86798b1ff5eebdae91_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_03b61c237d9c4aab48f6446965da203b_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_faeb9ac81b7a64ffed123259883c3994_7f9a567c3018d52c28ddc4637deab280,
stepfunc_4fc39e92360478aed68777bd40eda960_7f9a567c3018d52c28ddc4637deab280,
stepfunc_c35e4c59880b88f616e718d53aefa09c_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_242d6e467401858a6ff804507a7f7940_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_faeb9ac81b7a64ffed123259883c3994_7f9a567c3018d52c28ddc4637deab280,
stepfunc_4fc39e92360478aed68777bd40eda960_7f9a567c3018d52c28ddc4637deab280,
stepfunc_0f7a98451a17b3965f7a61b5ebfae70e_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_8f37a007abf77651d530db19ffb105bf_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_657d6ce3f368a15a9f9d42acfe682ab8_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_8ec939d8e104b996cb8f91649df46b5f_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_a4531213a24e321c64e01f39fc74f19b_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_ed3bee4794279bbdefe0950fc171ec6e_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_aafac0a49d07e9c8f9da617438c03920_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_5c20fb5badc22808975d1dcb29774297_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_64b931bb07c0a0dee1653344f0f24b26_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_98c4764e923841002973150ed17f357f_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_08fed69f5e8af05627036554b914ba34_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_227e5166cbf5d1b8559c77b536638e78_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_1bea5d99c60a486ddc9720036f47764e_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_c2732b2a9762b5151a25ee29661daa23_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_0c1d8794ce02fd8cb42f25deacf44578_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_d35744f1d636a6c2aab8efdb7bd80686_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_9d6677843bfbd8707ee2ad4ebabfd123_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_41724f36beda16dfe3de9d485d0b980f_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_c0966141963b38107e80728482fdb026_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_3ae8cb7e35d64598f1e227711370b83c_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_c14f89d102faf722e713ce3a3cb95aeb_7f9a567c3018d52c28ddc4637deab280,
stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_82d83c5e4ac015159745c2cc2c3cd041_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_c20ec2e3a5fc5550fe75109f34903d64_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
extern const BulletStepFunc bullet_1ec72429bf551d9ce6f372829184ba0c_7f9a567c3018d52c28ddc4637deab280[] = { 
stepfunc_b23944b7daff01a089d0f1b1bb917c2a_7f9a567c3018d52c28ddc4637deab280,
stepfunc_48d1a71a6626782b04f3c43dfdee27d5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_00629d3728872f376c02f03f20af7e0e_7f9a567c3018d52c28ddc4637deab280,
stepfunc_b40260f46a2231f7116ada461a577f91_7f9a567c3018d52c28ddc4637deab280,
stepfunc_aeb1c7b0afdaf96936625cf374cd0fd3_7f9a567c3018d52c28ddc4637deab280,
stepfunc_42e5833f57add1048d34abf6b1ccdca2_7f9a567c3018d52c28ddc4637deab280,
stepfunc_5b502751f1728a011324a94f95d35d7d_7f9a567c3018d52c28ddc4637deab280,
stepfunc_382ba6be7e5acac245f83f756f1cf930_7f9a567c3018d52c28ddc4637deab280,
stepfunc_b23944b7daff01a089d0f1b1bb917c2a_7f9a567c3018d52c28ddc4637deab280,
stepfunc_48d1a71a6626782b04f3c43dfdee27d5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_00629d3728872f376c02f03f20af7e0e_7f9a567c3018d52c28ddc4637deab280,
stepfunc_b40260f46a2231f7116ada461a577f91_7f9a567c3018d52c28ddc4637deab280,
stepfunc_aeb1c7b0afdaf96936625cf374cd0fd3_7f9a567c3018d52c28ddc4637deab280,
stepfunc_42e5833f57add1048d34abf6b1ccdca2_7f9a567c3018d52c28ddc4637deab280,
stepfunc_5b502751f1728a011324a94f95d35d7d_7f9a567c3018d52c28ddc4637deab280,
stepfunc_382ba6be7e5acac245f83f756f1cf930_7f9a567c3018d52c28ddc4637deab280,
stepfunc_b23944b7daff01a089d0f1b1bb917c2a_7f9a567c3018d52c28ddc4637deab280,
stepfunc_48d1a71a6626782b04f3c43dfdee27d5_7f9a567c3018d52c28ddc4637deab280,
stepfunc_00629d3728872f376c02f03f20af7e0e_7f9a567c3018d52c28ddc4637deab280,
stepfunc_b40260f46a2231f7116ada461a577f91_7f9a567c3018d52c28ddc4637deab280,
stepfunc_aeb1c7b0afdaf96936625cf374cd0fd3_7f9a567c3018d52c28ddc4637deab280,
stepfunc_42e5833f57add1048d34abf6b1ccdca2_7f9a567c3018d52c28ddc4637deab280,
stepfunc_5b502751f1728a011324a94f95d35d7d_7f9a567c3018d52c28ddc4637deab280,
stepfunc_382ba6be7e5acac245f83f756f1cf930_7f9a567c3018d52c28ddc4637deab280,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_7f9a567c3018d52c28ddc4637deab280,
NULL}; 
void stepfunc_5b502751f1728a011324a94f95d35d7d_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 60; 
}
void stepfunc_382ba6be7e5acac245f83f756f1cf930_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 200; 
}
void stepfunc_c20ec2e3a5fc5550fe75109f34903d64_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (0) - p->getAngle();p->setRound(speed, life);}
}
void stepfunc_657d6ce3f368a15a9f9d42acfe682ab8_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 60; 
}
void stepfunc_692650418a003028c093cde2dad67c68_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (32);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_82d83c5e4ac015159745c2cc2c3cd041_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_82d83c5e4ac015159745c2cc2c3cd041_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_82d83c5e4ac015159745c2cc2c3cd041_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (224);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_82d83c5e4ac015159745c2cc2c3cd041_7f9a567c3018d52c28ddc4637deab280); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_a4531213a24e321c64e01f39fc74f19b_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 65; 
}
void stepfunc_aafac0a49d07e9c8f9da617438c03920_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 70; 
}
void stepfunc_64b931bb07c0a0dee1653344f0f24b26_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 75; 
}
void stepfunc_08fed69f5e8af05627036554b914ba34_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 80; 
}
void stepfunc_1bea5d99c60a486ddc9720036f47764e_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 85; 
}
void stepfunc_0c1d8794ce02fd8cb42f25deacf44578_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 90; 
}
void stepfunc_9d6677843bfbd8707ee2ad4ebabfd123_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 95; 
}
void stepfunc_c0966141963b38107e80728482fdb026_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 100; 
}
void stepfunc_c14f89d102faf722e713ce3a3cb95aeb_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 105; 
}
void stepfunc_faeb9ac81b7a64ffed123259883c3994_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 20; 
}
void stepfunc_4fc39e92360478aed68777bd40eda960_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{
  u16 life = 9;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 15; 
}
void stepfunc_0f7a98451a17b3965f7a61b5ebfae70e_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(9, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_3ae8cb7e35d64598f1e227711370b83c_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(38, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_41724f36beda16dfe3de9d485d0b980f_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(67, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d35744f1d636a6c2aab8efdb7bd80686_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(96, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c2732b2a9762b5151a25ee29661daa23_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(125, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_227e5166cbf5d1b8559c77b536638e78_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(154, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_98c4764e923841002973150ed17f357f_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(183, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5c20fb5badc22808975d1dcb29774297_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ed3bee4794279bbdefe0950fc171ec6e_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(241, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8ec939d8e104b996cb8f91649df46b5f_7f9a567c3018d52c28ddc4637deab280); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8f37a007abf77651d530db19ffb105bf_7f9a567c3018d52c28ddc4637deab280); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_42e5833f57add1048d34abf6b1ccdca2_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(24604, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_242d6e467401858a6ff804507a7f7940_7f9a567c3018d52c28ddc4637deab280); 
  }
}
}
void stepfunc_aeb1c7b0afdaf96936625cf374cd0fd3_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15502, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_242d6e467401858a6ff804507a7f7940_7f9a567c3018d52c28ddc4637deab280); 
  }
}
}
void stepfunc_c35e4c59880b88f616e718d53aefa09c_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_b40260f46a2231f7116ada461a577f91_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(24604, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_03b61c237d9c4aab48f6446965da203b_7f9a567c3018d52c28ddc4637deab280); 
  }
}
}
void stepfunc_00629d3728872f376c02f03f20af7e0e_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15502, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_03b61c237d9c4aab48f6446965da203b_7f9a567c3018d52c28ddc4637deab280); 
  }
}
}
void stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{
  u16 life = 4;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 2; 
}
void stepfunc_4e1882c6d575977071f0893527d2e423_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
p->wait = 1; 
}
void stepfunc_f463ff547edafe86798b1ff5eebdae91_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(390, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_f828d6ab286193b69f72fd2f3ec374a6_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(FixedPointNum(10, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_c643dd46bc429e99869b1b84bf10ac23_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (1);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_e7133ec0a11dc9bc4201ccacb101e2b1_7f9a567c3018d52c28ddc4637deab280); 
  }
}
p->wait = 2; 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_48d1a71a6626782b04f3c43dfdee27d5_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(24604, 100));    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_260850096b40658c55c70ac4bac9222d_7f9a567c3018d52c28ddc4637deab280); 
  }
}
}
void stepfunc_b23944b7daff01a089d0f1b1bb917c2a_7f9a567c3018d52c28ddc4637deab280(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15502, 100));    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_260850096b40658c55c70ac4bac9222d_7f9a567c3018d52c28ddc4637deab280); 
  }
}
}


BulletInfo *genBulletFunc_7f9a567c3018d52c28ddc4637deab280(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_1ec72429bf551d9ce6f372829184ba0c_7f9a567c3018d52c28ddc4637deab280); 
  }
return bi;}


