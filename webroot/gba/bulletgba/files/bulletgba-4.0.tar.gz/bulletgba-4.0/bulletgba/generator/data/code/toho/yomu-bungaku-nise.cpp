// XXX uniqID XXX e0424b07b788197d9ebd2cce2c829cbf XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "toho/yomu-bungaku-nise.hpp" 

extern const BulletStepFunc bullet_bf2192c5d6a8e016f34448bf45c72fcc_e0424b07b788197d9ebd2cce2c829cbf[] = { 
stepfunc_d7428c9dcd26fea74995c38e49dc4220_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_ac3c21f7927f9d59636ee642c8e9eaa7_e0424b07b788197d9ebd2cce2c829cbf,
NULL}; 
extern const BulletStepFunc bullet_af6643e92a02886f3a9ee99e98ea80d5_e0424b07b788197d9ebd2cce2c829cbf[] = { 
stepfunc_d7428c9dcd26fea74995c38e49dc4220_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e0424b07b788197d9ebd2cce2c829cbf,
NULL}; 
extern const BulletStepFunc bullet_09d2cb688e52a2dbb833cc32817d2208_e0424b07b788197d9ebd2cce2c829cbf[] = { 
stepfunc_d7428c9dcd26fea74995c38e49dc4220_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_8631a39b6ec919035ed6cc6436fc8e50_e0424b07b788197d9ebd2cce2c829cbf,
NULL}; 
extern const BulletStepFunc bullet_838c3f0482ef12e097a6c644f7df8e21_e0424b07b788197d9ebd2cce2c829cbf[] = { 
stepfunc_25f1f9a3d29d94f7108ab0443601f25e_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e0424b07b788197d9ebd2cce2c829cbf,
NULL}; 
extern const BulletStepFunc bullet_147ee9fca65e1cf6537ed363aea5d01f_e0424b07b788197d9ebd2cce2c829cbf[] = { 
stepfunc_d7428c9dcd26fea74995c38e49dc4220_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_b87d75df22df3e3ad09b396f4e9e4641_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e0424b07b788197d9ebd2cce2c829cbf,
NULL}; 
extern const BulletStepFunc bullet_4a62294ce88e0cddbab752a6f9de8aa9_e0424b07b788197d9ebd2cce2c829cbf[] = { 
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e0424b07b788197d9ebd2cce2c829cbf,
NULL}; 
void stepfunc_68981b23bdc95d6eec6064ad55684fad_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 2; 
}
void stepfunc_d7428c9dcd26fea74995c38e49dc4220_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
p->wait = 30; 
}
void stepfunc_b87d75df22df3e3ad09b396f4e9e4641_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(11377, 100)+FixedPointNum::random()*FixedPointNum(2844, 100)));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 2; 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_ac3c21f7927f9d59636ee642c8e9eaa7_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_147ee9fca65e1cf6537ed363aea5d01f_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_25f1f9a3d29d94f7108ab0443601f25e_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
p->wait = 9999; 
}
void stepfunc_a75fc1fcc77fe73ba6bc93acf764730c_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum::random()*FixedPointNum(256)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(40, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_838c3f0482ef12e097a6c644f7df8e21_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
}
void stepfunc_6f3d1c0109f3d3f74d58174ae9766028_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_8631a39b6ec919035ed6cc6436fc8e50_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(7822, 100)+FixedPointNum::random()*FixedPointNum(9955, 100)));    p->lastBulletSpeed = (FixedPointNum(70, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_6f3d1c0109f3d3f74d58174ae9766028_e0424b07b788197d9ebd2cce2c829cbf(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_5fefb041a39dab9bf92178c3fadbf6be_e0424b07b788197d9ebd2cce2c829cbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_09d2cb688e52a2dbb833cc32817d2208_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_09d2cb688e52a2dbb833cc32817d2208_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_09d2cb688e52a2dbb833cc32817d2208_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_af6643e92a02886f3a9ee99e98ea80d5_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_af6643e92a02886f3a9ee99e98ea80d5_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_bf2192c5d6a8e016f34448bf45c72fcc_e0424b07b788197d9ebd2cce2c829cbf); 
  }
}
}


BulletInfo *genBulletFunc_e0424b07b788197d9ebd2cce2c829cbf(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_4a62294ce88e0cddbab752a6f9de8aa9_e0424b07b788197d9ebd2cce2c829cbf); 
  }
return bi;}


