#ifndef GENERATED_eb403b922aee26a247eeed1e1091be3f_HPP 
#define GENERATED_eb403b922aee26a247eeed1e1091be3f_HPP 

#include "bullet.hpp" 

void stepfunc_2061cf67c3c71f8fb0d3a7b3fe1bda6b_951c5d1879a87b53001ffd802aa370d8(BulletInfo *p); 
void stepfunc_d9c4489c7fda37a9b643d059c322ffef_951c5d1879a87b53001ffd802aa370d8(BulletInfo *p); 
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_951c5d1879a87b53001ffd802aa370d8(BulletInfo *p); 


extern const BulletStepFunc bullet_a6ec85ca2874e2b13a2b28575b8e7bb0_951c5d1879a87b53001ffd802aa370d8[]; 
const unsigned int bullet_a6ec85ca2874e2b13a2b28575b8e7bb0_951c5d1879a87b53001ffd802aa370d8_size = 502; 


#endif 

