#!/bin/sh

targetromsize="8M"
targetromname=bulletgba.rom.gba
filename=bulletgba.gba

dd if=/dev/zero of=$targetromname bs=$targetromsize count=1 >& /dev/null
dd if=$filename of=$targetromname conv=notrunc >& /dev/null

if [ $(ls -S -1 $filename $targetromname | head -n 1) != 'bulletgba.rom.gba' ]; then
    echo "[ERROR] Too small target ROM size. Please edit makerom.sh"
    exit 1
fi

