// XXX uniqID XXX a0af817c2ad1ad48948b272adbc1cffe XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p); 
static void stepfunc_1f509d9e337cefb20f0deb65f40517e0(BulletInfo *p); 
static void stepfunc_9e29da4393fb8e5c1fbfb884ffe808dd(BulletInfo *p); 
static void stepfunc_05e85b13e1a428f1e68914c48e98b3ed(BulletInfo *p); 
static void stepfunc_76912d638ab7bbda42700714f00c866e(BulletInfo *p); 
static void stepfunc_6221f084c322d873ba692921ca9239ee(BulletInfo *p); 
static void stepfunc_75e06c0e2993730ab6b9f823cdb6256e(BulletInfo *p); 
static void stepfunc_59df6bc84d116812fd0d1a66df618c2d(BulletInfo *p); 
static void stepfunc_af330b19a308c929101b3aba631f7eba(BulletInfo *p); 
static void stepfunc_524cc0e71a82855f8bcd6269da148388(BulletInfo *p); 
static void stepfunc_26cd6aad42bc18684e4228dfc0920498(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_8daca8d0067177d98d07e7cd8d0dbccf(BulletInfo *p); 
static void stepfunc_c56a14ac55e934d090dd3e20b50c0e1b(BulletInfo *p); 
static void stepfunc_311804e965752a2f273d2c7549548fe5(BulletInfo *p); 
static void stepfunc_5db36a9216ebd24ac3b00b2fa58706ee(BulletInfo *p); 
static void stepfunc_214d37592603f133a7676a98777b3215(BulletInfo *p); 
static void stepfunc_8f3efda0228914af56b994af31e851e7(BulletInfo *p); 
static void stepfunc_36b47136b4225b9964a324e2208db4aa(BulletInfo *p); 
static void stepfunc_168981166aad44406fc4f080e7a30cfe(BulletInfo *p); 
static void stepfunc_b7b01c1b0d932bce5ca77a71b33e43f2(BulletInfo *p); 
static void stepfunc_07c2b6548e5700779c66b1024c7c00d1(BulletInfo *p); 
static void stepfunc_911b785d1e9b5217237cd7d9df4a58d2(BulletInfo *p); 
static void stepfunc_0be0c17df8b357e920c24c6f3ff453ab(BulletInfo *p); 
static void stepfunc_b5b6b256455cedef4629c8817be6232b(BulletInfo *p); 
static void stepfunc_3bd91d9561ac863936243dfcd79bd82c(BulletInfo *p); 
static void stepfunc_13632bf303a649da73e3f3c198688063(BulletInfo *p); 
static void stepfunc_28c3288c19e45823e6611c9c41f36713(BulletInfo *p); 
static void stepfunc_4f90a02dada1ee4c22c095fd6bd3cd4e(BulletInfo *p); 
static void stepfunc_9642378ea29f76f11e9ac5e123e5f40b(BulletInfo *p); 
static void stepfunc_7091d71d99f6d19c91c73fe734f11333(BulletInfo *p); 
static void stepfunc_fa318acac8021bddcb7e01c86d7bce16(BulletInfo *p); 
static void stepfunc_3471e5443b2cf7ce56814782ca2e3d23(BulletInfo *p); 
static void stepfunc_d820d45f2c0207ff4d16122d0cab5a3b(BulletInfo *p); 
static void stepfunc_5ae3cf3807f12c9651cb12735a6617c6(BulletInfo *p); 
static void stepfunc_6aec718fd97f1cf3a22284a80c0f6992(BulletInfo *p); 
static void stepfunc_ee142cbcba988d5361e01e5161b3732c(BulletInfo *p); 
static void stepfunc_768935c456c1157d031af6fecb054eb3(BulletInfo *p); 
static void stepfunc_9d8091b6daea1b150a5a4649bee3938d(BulletInfo *p); 
static void stepfunc_8d141f509cee8d73b4f1b2804f99c276(BulletInfo *p); 
static void stepfunc_4ad90d9e41020122d7b1220cc03b022f(BulletInfo *p); 
static void stepfunc_f3f70ebcd792d71d55540b0c00eb1f81(BulletInfo *p); 
static void stepfunc_5cd0e35dc36ce5f84337477caf0f798c(BulletInfo *p); 
static void stepfunc_09b441c1a2bd3ea99b0594ba88159008(BulletInfo *p); 
static void stepfunc_26184f758b610b8200bdf703b3ee88f0(BulletInfo *p); 
static void stepfunc_fca63bdfbb6c50b5617fd837eac94473(BulletInfo *p); 


static const BulletStepFunc bullet_991c81a2a07303c34b2bd1442ecf83cd[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_1f509d9e337cefb20f0deb65f40517e0,
stepfunc_9e29da4393fb8e5c1fbfb884ffe808dd,
stepfunc_05e85b13e1a428f1e68914c48e98b3ed,
stepfunc_05e85b13e1a428f1e68914c48e98b3ed,
stepfunc_05e85b13e1a428f1e68914c48e98b3ed,
stepfunc_05e85b13e1a428f1e68914c48e98b3ed,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_6221f084c322d873ba692921ca9239ee,
stepfunc_75e06c0e2993730ab6b9f823cdb6256e,
stepfunc_75e06c0e2993730ab6b9f823cdb6256e,
stepfunc_75e06c0e2993730ab6b9f823cdb6256e,
stepfunc_75e06c0e2993730ab6b9f823cdb6256e,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_59df6bc84d116812fd0d1a66df618c2d,
stepfunc_af330b19a308c929101b3aba631f7eba,
stepfunc_af330b19a308c929101b3aba631f7eba,
stepfunc_af330b19a308c929101b3aba631f7eba,
stepfunc_af330b19a308c929101b3aba631f7eba,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_524cc0e71a82855f8bcd6269da148388,
stepfunc_26cd6aad42bc18684e4228dfc0920498,
stepfunc_26cd6aad42bc18684e4228dfc0920498,
stepfunc_26cd6aad42bc18684e4228dfc0920498,
stepfunc_26cd6aad42bc18684e4228dfc0920498,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_a3f3c3f956f43427190d738fad0154b5[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_1f509d9e337cefb20f0deb65f40517e0,
stepfunc_8daca8d0067177d98d07e7cd8d0dbccf,
stepfunc_c56a14ac55e934d090dd3e20b50c0e1b,
stepfunc_c56a14ac55e934d090dd3e20b50c0e1b,
stepfunc_c56a14ac55e934d090dd3e20b50c0e1b,
stepfunc_c56a14ac55e934d090dd3e20b50c0e1b,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_311804e965752a2f273d2c7549548fe5,
stepfunc_5db36a9216ebd24ac3b00b2fa58706ee,
stepfunc_5db36a9216ebd24ac3b00b2fa58706ee,
stepfunc_5db36a9216ebd24ac3b00b2fa58706ee,
stepfunc_5db36a9216ebd24ac3b00b2fa58706ee,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_214d37592603f133a7676a98777b3215,
stepfunc_8f3efda0228914af56b994af31e851e7,
stepfunc_8f3efda0228914af56b994af31e851e7,
stepfunc_8f3efda0228914af56b994af31e851e7,
stepfunc_8f3efda0228914af56b994af31e851e7,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_36b47136b4225b9964a324e2208db4aa,
stepfunc_168981166aad44406fc4f080e7a30cfe,
stepfunc_168981166aad44406fc4f080e7a30cfe,
stepfunc_168981166aad44406fc4f080e7a30cfe,
stepfunc_168981166aad44406fc4f080e7a30cfe,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_5120b634b24792a8f5de199100640652[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_1f509d9e337cefb20f0deb65f40517e0,
stepfunc_b7b01c1b0d932bce5ca77a71b33e43f2,
stepfunc_07c2b6548e5700779c66b1024c7c00d1,
stepfunc_07c2b6548e5700779c66b1024c7c00d1,
stepfunc_07c2b6548e5700779c66b1024c7c00d1,
stepfunc_07c2b6548e5700779c66b1024c7c00d1,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_911b785d1e9b5217237cd7d9df4a58d2,
stepfunc_0be0c17df8b357e920c24c6f3ff453ab,
stepfunc_0be0c17df8b357e920c24c6f3ff453ab,
stepfunc_0be0c17df8b357e920c24c6f3ff453ab,
stepfunc_0be0c17df8b357e920c24c6f3ff453ab,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_b5b6b256455cedef4629c8817be6232b,
stepfunc_3bd91d9561ac863936243dfcd79bd82c,
stepfunc_3bd91d9561ac863936243dfcd79bd82c,
stepfunc_3bd91d9561ac863936243dfcd79bd82c,
stepfunc_3bd91d9561ac863936243dfcd79bd82c,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_13632bf303a649da73e3f3c198688063,
stepfunc_28c3288c19e45823e6611c9c41f36713,
stepfunc_28c3288c19e45823e6611c9c41f36713,
stepfunc_28c3288c19e45823e6611c9c41f36713,
stepfunc_28c3288c19e45823e6611c9c41f36713,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_8ebf4ac357f0633aaa920819a6550179[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_1f509d9e337cefb20f0deb65f40517e0,
stepfunc_4f90a02dada1ee4c22c095fd6bd3cd4e,
stepfunc_9642378ea29f76f11e9ac5e123e5f40b,
stepfunc_9642378ea29f76f11e9ac5e123e5f40b,
stepfunc_9642378ea29f76f11e9ac5e123e5f40b,
stepfunc_9642378ea29f76f11e9ac5e123e5f40b,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_7091d71d99f6d19c91c73fe734f11333,
stepfunc_fa318acac8021bddcb7e01c86d7bce16,
stepfunc_fa318acac8021bddcb7e01c86d7bce16,
stepfunc_fa318acac8021bddcb7e01c86d7bce16,
stepfunc_fa318acac8021bddcb7e01c86d7bce16,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_3471e5443b2cf7ce56814782ca2e3d23,
stepfunc_d820d45f2c0207ff4d16122d0cab5a3b,
stepfunc_d820d45f2c0207ff4d16122d0cab5a3b,
stepfunc_d820d45f2c0207ff4d16122d0cab5a3b,
stepfunc_d820d45f2c0207ff4d16122d0cab5a3b,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_5ae3cf3807f12c9651cb12735a6617c6,
stepfunc_6aec718fd97f1cf3a22284a80c0f6992,
stepfunc_6aec718fd97f1cf3a22284a80c0f6992,
stepfunc_6aec718fd97f1cf3a22284a80c0f6992,
stepfunc_6aec718fd97f1cf3a22284a80c0f6992,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_251c9dee7aaf0f21e9ee3bd3affeaf1b[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_1f509d9e337cefb20f0deb65f40517e0,
stepfunc_ee142cbcba988d5361e01e5161b3732c,
stepfunc_768935c456c1157d031af6fecb054eb3,
stepfunc_768935c456c1157d031af6fecb054eb3,
stepfunc_768935c456c1157d031af6fecb054eb3,
stepfunc_768935c456c1157d031af6fecb054eb3,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_9d8091b6daea1b150a5a4649bee3938d,
stepfunc_8d141f509cee8d73b4f1b2804f99c276,
stepfunc_8d141f509cee8d73b4f1b2804f99c276,
stepfunc_8d141f509cee8d73b4f1b2804f99c276,
stepfunc_8d141f509cee8d73b4f1b2804f99c276,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_4ad90d9e41020122d7b1220cc03b022f,
stepfunc_f3f70ebcd792d71d55540b0c00eb1f81,
stepfunc_f3f70ebcd792d71d55540b0c00eb1f81,
stepfunc_f3f70ebcd792d71d55540b0c00eb1f81,
stepfunc_f3f70ebcd792d71d55540b0c00eb1f81,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_5cd0e35dc36ce5f84337477caf0f798c,
stepfunc_09b441c1a2bd3ea99b0594ba88159008,
stepfunc_09b441c1a2bd3ea99b0594ba88159008,
stepfunc_09b441c1a2bd3ea99b0594ba88159008,
stepfunc_09b441c1a2bd3ea99b0594ba88159008,
stepfunc_76912d638ab7bbda42700714f00c866e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_f1dcf869a02b475e036d5a7d0d842e5b[] = {
stepfunc_26184f758b610b8200bdf703b3ee88f0,
stepfunc_fca63bdfbb6c50b5617fd837eac94473,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_26cd6aad42bc18684e4228dfc0920498(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_af330b19a308c929101b3aba631f7eba(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_75e06c0e2993730ab6b9f823cdb6256e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_05e85b13e1a428f1e68914c48e98b3ed(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_1f509d9e337cefb20f0deb65f40517e0(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_9e29da4393fb8e5c1fbfb884ffe808dd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_76912d638ab7bbda42700714f00c866e(BulletInfo *p) { 
p->wait = 4; 
}
static void stepfunc_6221f084c322d873ba692921ca9239ee(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_59df6bc84d116812fd0d1a66df618c2d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_524cc0e71a82855f8bcd6269da148388(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_168981166aad44406fc4f080e7a30cfe(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1328, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_8f3efda0228914af56b994af31e851e7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1829, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_5db36a9216ebd24ac3b00b2fa58706ee(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2125, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_c56a14ac55e934d090dd3e20b50c0e1b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2833, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_8daca8d0067177d98d07e7cd8d0dbccf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2833, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_311804e965752a2f273d2c7549548fe5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2125, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_214d37592603f133a7676a98777b3215(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1829, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_36b47136b4225b9964a324e2208db4aa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1328, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_28c3288c19e45823e6611c9c41f36713(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1328, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_3bd91d9561ac863936243dfcd79bd82c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1829, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_0be0c17df8b357e920c24c6f3ff453ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2125, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_07c2b6548e5700779c66b1024c7c00d1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2833, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_b7b01c1b0d932bce5ca77a71b33e43f2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2833, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_911b785d1e9b5217237cd7d9df4a58d2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_b5b6b256455cedef4629c8817be6232b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1829, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_13632bf303a649da73e3f3c198688063(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1328, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_6aec718fd97f1cf3a22284a80c0f6992(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1992, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_d820d45f2c0207ff4d16122d0cab5a3b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2744, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_fa318acac8021bddcb7e01c86d7bce16(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_9642378ea29f76f11e9ac5e123e5f40b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-4250, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_4f90a02dada1ee4c22c095fd6bd3cd4e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-4250, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_7091d71d99f6d19c91c73fe734f11333(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_3471e5443b2cf7ce56814782ca2e3d23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2744, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_5ae3cf3807f12c9651cb12735a6617c6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1992, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_09b441c1a2bd3ea99b0594ba88159008(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1992, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_f3f70ebcd792d71d55540b0c00eb1f81(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2744, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_8d141f509cee8d73b4f1b2804f99c276(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3187, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_768935c456c1157d031af6fecb054eb3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4250, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(24, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_ee142cbcba988d5361e01e5161b3732c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_9d8091b6daea1b150a5a4649bee3938d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3187, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_4ad90d9e41020122d7b1220cc03b022f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2744, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_5cd0e35dc36ce5f84337477caf0f798c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1992, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_26184f758b610b8200bdf703b3ee88f0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_251c9dee7aaf0f21e9ee3bd3affeaf1b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ebf4ac357f0633aaa920819a6550179;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_991c81a2a07303c34b2bd1442ecf83cd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_251c9dee7aaf0f21e9ee3bd3affeaf1b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ebf4ac357f0633aaa920819a6550179;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_991c81a2a07303c34b2bd1442ecf83cd;  }
}
p->wait = 110; 
}
static void stepfunc_fca63bdfbb6c50b5617fd837eac94473(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5120b634b24792a8f5de199100640652;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a3f3c3f956f43427190d738fad0154b5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_991c81a2a07303c34b2bd1442ecf83cd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5120b634b24792a8f5de199100640652;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a3f3c3f956f43427190d738fad0154b5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_991c81a2a07303c34b2bd1442ecf83cd;  }
}
p->wait = 110; 
}


void genBulletFunc_a0af817c2ad1ad48948b272adbc1cffe(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_f1dcf869a02b475e036d5a7d0d842e5b; }}


