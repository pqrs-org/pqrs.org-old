// XXX uniqID XXX 9775f4d4d5f6a787fe0fa3496459b059 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_bc520f48bf863fa909eed342ae6a63c7(BulletInfo *p); 
static void stepfunc_1970fe9cce5aec03eb9be7257981350f(BulletInfo *p); 
static void stepfunc_7d26b7bb30928548b0a435d8c676b1f9(BulletInfo *p); 
static void stepfunc_bc80be0b59787d3aa2591478ea506ee5(BulletInfo *p); 
static void stepfunc_4b233616af0231a3800dfce5ec63fb05(BulletInfo *p); 
static void stepfunc_5aaee11fc944f943c12afeacda085279(BulletInfo *p); 
static void stepfunc_a87f23aa0a4a339241fe48321ec16d54(BulletInfo *p); 
static void stepfunc_c3123531b07f52249cc6e069e587acc1(BulletInfo *p); 
static void stepfunc_3d26a7b5d00ca4785a006f2e5ebc3451(BulletInfo *p); 
static void stepfunc_b4d162c9ffb9e2f0b111ff74da48e415(BulletInfo *p); 
static void stepfunc_0b97877c641d9fa01a3504d5c9703f77(BulletInfo *p); 
static void stepfunc_d066250da19dd3edc35073d6b6f9a268(BulletInfo *p); 
static void stepfunc_acdeefae6cbe8c350f5457454de6f03e(BulletInfo *p); 
static void stepfunc_f454a97a761723b72a5e94c9ee6ff32a(BulletInfo *p); 
static void stepfunc_3823f0855f2c6a595e28abd3b30c61d5(BulletInfo *p); 
static void stepfunc_99ff65d1e5eb4da99d11a3d3c252adee(BulletInfo *p); 
static void stepfunc_38b6d0cc52c3fdc379a55e15e5701d41(BulletInfo *p); 
static void stepfunc_8790f8af6785aa277b0a2290ffe5fdf1(BulletInfo *p); 
static void stepfunc_e22859a4cc131683004d0a78976e4fc5(BulletInfo *p); 
static void stepfunc_7ca7e1521bedbd83d54439791a47bebd(BulletInfo *p); 
static void stepfunc_40ab88d371b53afe02485e95d1c060c9(BulletInfo *p); 
static void stepfunc_3a69de561c8b13cabd973dd623f9ef4a(BulletInfo *p); 
static void stepfunc_a48b3623122679a20251452186680aa2(BulletInfo *p); 
static void stepfunc_de3b29a52320375d306dda68b1dc58bb(BulletInfo *p); 
static void stepfunc_0db2c6b3bf8bd5309f3689000d968c4d(BulletInfo *p); 
static void stepfunc_d604d96bcea71a957f0754efd155c939(BulletInfo *p); 
static void stepfunc_34a73673a18c1c8bb6ae6893fbe0fa58(BulletInfo *p); 
static void stepfunc_b777e1a9822e4b4d3e05e1be6b315869(BulletInfo *p); 
static void stepfunc_9d61e226751abd2725c82462cbc9c32e(BulletInfo *p); 
static void stepfunc_d1fee59d10dfe5dbf5d355ae75626b2f(BulletInfo *p); 
static void stepfunc_4589f292cb1aa238d2a5d30402466c1c(BulletInfo *p); 
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_5b9b04c4bc09b75c755069ffa39e4aa6[] = {
stepfunc_bc520f48bf863fa909eed342ae6a63c7,
stepfunc_1970fe9cce5aec03eb9be7257981350f,
#if 0
stepfunc_7d26b7bb30928548b0a435d8c676b1f9,
#endif
stepfunc_1970fe9cce5aec03eb9be7257981350f,
#if 0
stepfunc_bc80be0b59787d3aa2591478ea506ee5,
#endif
stepfunc_1970fe9cce5aec03eb9be7257981350f,
#if 0
stepfunc_4b233616af0231a3800dfce5ec63fb05,
#endif
stepfunc_1970fe9cce5aec03eb9be7257981350f,
#if 0
stepfunc_5aaee11fc944f943c12afeacda085279,
#endif
stepfunc_1970fe9cce5aec03eb9be7257981350f,
#if 0
stepfunc_a87f23aa0a4a339241fe48321ec16d54,
#endif
stepfunc_bc520f48bf863fa909eed342ae6a63c7,
stepfunc_c3123531b07f52249cc6e069e587acc1,
#if 0
stepfunc_3d26a7b5d00ca4785a006f2e5ebc3451,
#endif
stepfunc_c3123531b07f52249cc6e069e587acc1,
#if 0
stepfunc_b4d162c9ffb9e2f0b111ff74da48e415,
#endif
stepfunc_c3123531b07f52249cc6e069e587acc1,
#if 0
stepfunc_0b97877c641d9fa01a3504d5c9703f77,
#endif
stepfunc_c3123531b07f52249cc6e069e587acc1,
#if 0
stepfunc_d066250da19dd3edc35073d6b6f9a268,
#endif
stepfunc_c3123531b07f52249cc6e069e587acc1,
#if 0
stepfunc_acdeefae6cbe8c350f5457454de6f03e,
#endif
stepfunc_bc520f48bf863fa909eed342ae6a63c7,
stepfunc_f454a97a761723b72a5e94c9ee6ff32a,
#if 0
stepfunc_3823f0855f2c6a595e28abd3b30c61d5,
#endif
stepfunc_f454a97a761723b72a5e94c9ee6ff32a,
#if 0
stepfunc_99ff65d1e5eb4da99d11a3d3c252adee,
#endif
stepfunc_f454a97a761723b72a5e94c9ee6ff32a,
#if 0
stepfunc_38b6d0cc52c3fdc379a55e15e5701d41,
#endif
stepfunc_f454a97a761723b72a5e94c9ee6ff32a,
#if 0
stepfunc_8790f8af6785aa277b0a2290ffe5fdf1,
#endif
stepfunc_f454a97a761723b72a5e94c9ee6ff32a,
#if 0
stepfunc_e22859a4cc131683004d0a78976e4fc5,
#endif
stepfunc_bc520f48bf863fa909eed342ae6a63c7,
stepfunc_7ca7e1521bedbd83d54439791a47bebd,
#if 0
stepfunc_40ab88d371b53afe02485e95d1c060c9,
#endif
stepfunc_7ca7e1521bedbd83d54439791a47bebd,
#if 0
stepfunc_3a69de561c8b13cabd973dd623f9ef4a,
#endif
stepfunc_7ca7e1521bedbd83d54439791a47bebd,
#if 0
stepfunc_a48b3623122679a20251452186680aa2,
#endif
stepfunc_7ca7e1521bedbd83d54439791a47bebd,
#if 0
stepfunc_de3b29a52320375d306dda68b1dc58bb,
#endif
stepfunc_7ca7e1521bedbd83d54439791a47bebd,
#if 0
stepfunc_0db2c6b3bf8bd5309f3689000d968c4d,
#endif
stepfunc_bc520f48bf863fa909eed342ae6a63c7,
stepfunc_d604d96bcea71a957f0754efd155c939,
#if 0
stepfunc_34a73673a18c1c8bb6ae6893fbe0fa58,
#endif
stepfunc_d604d96bcea71a957f0754efd155c939,
#if 0
stepfunc_b777e1a9822e4b4d3e05e1be6b315869,
#endif
stepfunc_d604d96bcea71a957f0754efd155c939,
#if 0
stepfunc_9d61e226751abd2725c82462cbc9c32e,
#endif
stepfunc_d604d96bcea71a957f0754efd155c939,
#if 0
stepfunc_d1fee59d10dfe5dbf5d355ae75626b2f,
#endif
stepfunc_d604d96bcea71a957f0754efd155c939,
#if 0
stepfunc_4589f292cb1aa238d2a5d30402466c1c,
#endif
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_4589f292cb1aa238d2a5d30402466c1c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d1fee59d10dfe5dbf5d355ae75626b2f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9d61e226751abd2725c82462cbc9c32e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b777e1a9822e4b4d3e05e1be6b315869(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_34a73673a18c1c8bb6ae6893fbe0fa58(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_0db2c6b3bf8bd5309f3689000d968c4d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_de3b29a52320375d306dda68b1dc58bb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a48b3623122679a20251452186680aa2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_3a69de561c8b13cabd973dd623f9ef4a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_40ab88d371b53afe02485e95d1c060c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e22859a4cc131683004d0a78976e4fc5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_8790f8af6785aa277b0a2290ffe5fdf1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_38b6d0cc52c3fdc379a55e15e5701d41(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_99ff65d1e5eb4da99d11a3d3c252adee(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_3823f0855f2c6a595e28abd3b30c61d5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_acdeefae6cbe8c350f5457454de6f03e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d066250da19dd3edc35073d6b6f9a268(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_0b97877c641d9fa01a3504d5c9703f77(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b4d162c9ffb9e2f0b111ff74da48e415(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_3d26a7b5d00ca4785a006f2e5ebc3451(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a87f23aa0a4a339241fe48321ec16d54(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_5aaee11fc944f943c12afeacda085279(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4b233616af0231a3800dfce5ec63fb05(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_bc80be0b59787d3aa2591478ea506ee5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_7d26b7bb30928548b0a435d8c676b1f9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_bc520f48bf863fa909eed342ae6a63c7(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum::random()*FixedPointNum(255)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_1970fe9cce5aec03eb9be7257981350f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_7d26b7bb30928548b0a435d8c676b1f9(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_bc80be0b59787d3aa2591478ea506ee5(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_4b233616af0231a3800dfce5ec63fb05(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_5aaee11fc944f943c12afeacda085279(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(70, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(70, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_a87f23aa0a4a339241fe48321ec16d54(p);}
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_c3123531b07f52249cc6e069e587acc1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_3d26a7b5d00ca4785a006f2e5ebc3451(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_b4d162c9ffb9e2f0b111ff74da48e415(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_0b97877c641d9fa01a3504d5c9703f77(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_d066250da19dd3edc35073d6b6f9a268(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(141, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(141, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_acdeefae6cbe8c350f5457454de6f03e(p);}
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_f454a97a761723b72a5e94c9ee6ff32a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_3823f0855f2c6a595e28abd3b30c61d5(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_99ff65d1e5eb4da99d11a3d3c252adee(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_38b6d0cc52c3fdc379a55e15e5701d41(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_8790f8af6785aa277b0a2290ffe5fdf1(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(212, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(212, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_e22859a4cc131683004d0a78976e4fc5(p);}
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_7ca7e1521bedbd83d54439791a47bebd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_40ab88d371b53afe02485e95d1c060c9(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_3a69de561c8b13cabd973dd623f9ef4a(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_a48b3623122679a20251452186680aa2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_de3b29a52320375d306dda68b1dc58bb(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(283, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(283, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_0db2c6b3bf8bd5309f3689000d968c4d(p);}
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_d604d96bcea71a957f0754efd155c939(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2125, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_34a73673a18c1c8bb6ae6893fbe0fa58(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1062, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_b777e1a9822e4b4d3e05e1be6b315869(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_9d61e226751abd2725c82462cbc9c32e(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_d1fee59d10dfe5dbf5d355ae75626b2f(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+(FixedPointNum(354, 100))*FixedPointNum::random()*FixedPointNum(141, 100)-(FixedPointNum(354, 100)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_4589f292cb1aa238d2a5d30402466c1c(p);}
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_9775f4d4d5f6a787fe0fa3496459b059(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_5b9b04c4bc09b75c755069ffa39e4aa6; }}


