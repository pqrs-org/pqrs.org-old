// XXX uniqID XXX 82ab405be2a9c242c7f32fbaf0801b2e XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_05ac849ba5e342e9151c3848856367c1(BulletInfo *p); 
static void stepfunc_fba06d87a7c758daf0040d97d0b99f20(BulletInfo *p); 
static void stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc(BulletInfo *p); 
static void stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12(BulletInfo *p); 
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_b1beab28421ae895c102a6c2264f53a6(BulletInfo *p); 
static void stepfunc_a834e0ca56bd0ee9c92c048759082476(BulletInfo *p); 
static void stepfunc_169b1fbdf7228568f7b6eb0d84eee8f9(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_1ad443738ef1849e4c814b4d3d4c0d8b[] = {
stepfunc_05ac849ba5e342e9151c3848856367c1,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_b1beab28421ae895c102a6c2264f53a6,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc,
stepfunc_a834e0ca56bd0ee9c92c048759082476,
#if 0
stepfunc_fba06d87a7c758daf0040d97d0b99f20,
#endif
stepfunc_169b1fbdf7228568f7b6eb0d84eee8f9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_fba06d87a7c758daf0040d97d0b99f20(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(566, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4bc00bcb18e59efb41fde6cce3c0d1cc(BulletInfo *p) { 
p->wait = 2; 
}
static void stepfunc_a834e0ca56bd0ee9c92c048759082476(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-11262, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-4, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_fba06d87a7c758daf0040d97d0b99f20(p);}
}
static void stepfunc_76a2a6ffdab7385db6d4ad0a4932eb12(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-11404, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-4, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_fba06d87a7c758daf0040d97d0b99f20(p);}
}
static void stepfunc_05ac849ba5e342e9151c3848856367c1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-5666, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_fba06d87a7c758daf0040d97d0b99f20(p);}
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_b1beab28421ae895c102a6c2264f53a6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-5666, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 20; ++i) { 
stepfunc_fba06d87a7c758daf0040d97d0b99f20(p);}
}
static void stepfunc_169b1fbdf7228568f7b6eb0d84eee8f9(BulletInfo *p) { 
p->wait = 150; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_82ab405be2a9c242c7f32fbaf0801b2e(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_1ad443738ef1849e4c814b4d3d4c0d8b; }}


