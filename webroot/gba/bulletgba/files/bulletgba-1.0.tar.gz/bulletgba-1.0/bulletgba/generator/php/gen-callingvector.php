#!/usr/bin/env php
<?php //-*- Mode: php; indent-tabs-mode: nil; Coding: utf-8; -*-

define('MAX_REPEAT_TIMES', 20000);

require_once sprintf('%s/libcommon.php', dirname(__FILE__));
require_once sprintf('%s/libgenerate.php', dirname(__FILE__));

class GenCallingVector
{
  var $document;
  var $listDefinition;

  function GenCallingVector($doc) {
    $this->document = $doc;

    $this->listDefinition = array();
  }

  function doConv() {
    $this->parseStepFuncDef();
    $this->outputCallingVector();
  }

  function parseStepFuncDef() {
    foreach ($this->document->getElementsByTagName('stepfuncDef') as $elem) {
      $label = $elem->getAttribute('label');
      $this->listDefinition[$label] = $elem;
    }
  }

  function outputCallingVector() {
    foreach ($this->document->getElementsByTagName('bulletDef') as $elem) {
      $label = $elem->getAttribute('label');
      print "static const BulletStepFunc ${label}[] = {\n";

      $list = $elem->getElementsByTagName('stepfuncCall');
      if ($list->length == 0) {
        Common::error("No stepfuncCall in bulletDef");
      }
      foreach ($list as $e) {
        $label = $e->getAttribute('label');
        $this->getStepFuncCallingVector($label);
      }
      print "NULL}; \n";
    }
  }

  function getStepFuncCallingVector($label) {
    $elem = $this->listDefinition[$label];

    if (! $elem->hasChildNodes()) {
      Common::error("Empty StepFunc");
    }

    $list = $elem->getElementsByTagName('repeat');
    if ($list->length == 0) {
      printf("%s,\n", $elem->getAttribute('label'));
      return;
    }

    foreach ($list as $e) {
      $repeat = new Repeat($e);

      if ($repeat->nowait) {
        printf("%s,\n", $elem->getAttribute('label'));
        print "#if 0\n";
        foreach ($repeat->listStepFuncCall as $call) {
          $label = $call->getAttribute('label');
          $this->getStepFuncCallingVector($label);
        }
        print "#endif\n";

      } else {
        if ($repeat->times > MAX_REPEAT_TIMES) {
          Common::error("Too many Repeat count!");
        }
        for ($i = 0; $i < $repeat->times; ++$i) {
          foreach ($repeat->listStepFuncCall as $call) {
            $label = $call->getAttribute('label');
            $this->getStepFuncCallingVector($label);
          }
        }
      }
    }
  }
}


if (realpath($argv[0]) == __FILE__) {
  $xmlfile = Common::getArg1();

  $doc = new DOMDocument;
  $doc->preserveWhiteSpace = false;
  $doc->load($xmlfile, LIBXML_NSCLEAN);

  $gen = new GenCallingVector($doc);
  $gen->doConv();
}

?>
