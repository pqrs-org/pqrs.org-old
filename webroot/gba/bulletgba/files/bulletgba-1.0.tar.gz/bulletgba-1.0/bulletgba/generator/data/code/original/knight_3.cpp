// XXX uniqID XXX 166534cf168e8b836ac3e870ea6569b4 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 
static void stepfunc_c6e1ad918411d01268618a4b56367ac3(BulletInfo *p); 
static void stepfunc_4de207021375b38f0dae5c67c1e1612f(BulletInfo *p); 
static void stepfunc_a55b6202afe2af5b7f5fcbfe3e64a23a(BulletInfo *p); 
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p); 
static void stepfunc_193ba79b8472241384238dd0cfa6607a(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_fa4d28a6968977bce8db4fc5226bf892(BulletInfo *p); 
static void stepfunc_2db022ad4e8f6b172fd862ba5e5c6718(BulletInfo *p); 
static void stepfunc_8c2be1a8bfb56a21afe28d443fa94338(BulletInfo *p); 
static void stepfunc_8b8b805bbd39c11377805bca90f400b8(BulletInfo *p); 


static const BulletStepFunc bullet_800c2dfcc0245616af60f7fb86a311ab[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_c6e1ad918411d01268618a4b56367ac3,
stepfunc_4de207021375b38f0dae5c67c1e1612f,
stepfunc_a55b6202afe2af5b7f5fcbfe3e64a23a,
NULL}; 
static const BulletStepFunc bullet_f22f00a1f6478b90f719f4b223d2bb53[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_193ba79b8472241384238dd0cfa6607a,
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_193ba79b8472241384238dd0cfa6607a,
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_193ba79b8472241384238dd0cfa6607a,
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_193ba79b8472241384238dd0cfa6607a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_38bd626e5165e3e629640d17dc668171[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_fa4d28a6968977bce8db4fc5226bf892,
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_fa4d28a6968977bce8db4fc5226bf892,
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_fa4d28a6968977bce8db4fc5226bf892,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_a2dea87bc6eac2f44454be983be00bed[] = {
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_2db022ad4e8f6b172fd862ba5e5c6718,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d0277a690c812594747ec1a621e66604[] = {
stepfunc_8b8b805bbd39c11377805bca90f400b8,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_8c2be1a8bfb56a21afe28d443fa94338(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_2db022ad4e8f6b172fd862ba5e5c6718(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-FixedPointNum(708, 100) + FixedPointNum(1416, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
p->wait = 2; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_193ba79b8472241384238dd0cfa6607a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7791, 100) + FixedPointNum(1416, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a2dea87bc6eac2f44454be983be00bed;  }
}
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_fa4d28a6968977bce8db4fc5226bf892(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(16291, 100) + FixedPointNum(1416, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a2dea87bc6eac2f44454be983be00bed;  }
}
}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_c6e1ad918411d01268618a4b56367ac3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 2; 
}
static void stepfunc_4de207021375b38f0dae5c67c1e1612f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_38bd626e5165e3e629640d17dc668171;  }
}
p->wait = 30; 
}
static void stepfunc_a55b6202afe2af5b7f5fcbfe3e64a23a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14875, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f22f00a1f6478b90f719f4b223d2bb53;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8b8b805bbd39c11377805bca90f400b8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4250, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_800c2dfcc0245616af60f7fb86a311ab;  }
}
p->wait = 300; 
}


void genBulletFunc_166534cf168e8b836ac3e870ea6569b4(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_d0277a690c812594747ec1a621e66604; }}


