// XXX uniqID XXX 5a76b37d6b348138e2d4fbb082933562 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p); 
static void stepfunc_335203fb678266e1601218bb1f76f232(BulletInfo *p); 
static void stepfunc_4e9c85b792f1a8f999f76a1ca70e538c(BulletInfo *p); 
static void stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798(BulletInfo *p); 
static void stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03(BulletInfo *p); 
static void stepfunc_33381006f67f0b2a6227e555c2039d06(BulletInfo *p); 
static void stepfunc_0eec21fa66dcbdfe4a80555b66c50849(BulletInfo *p); 
static void stepfunc_7eb793fae76eaa7c6761063a3c912245(BulletInfo *p); 
static void stepfunc_8a375cb7b2af80a8717be020427ef507(BulletInfo *p); 
static void stepfunc_158de86fae4036e1340a7bce3989f7d9(BulletInfo *p); 
static void stepfunc_58e19432a33338365afa335e177a71d5(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_92cf143159417f1c9277b64caf363991[] = {
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_335203fb678266e1601218bb1f76f232,
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
stepfunc_4e9c85b792f1a8f999f76a1ca70e538c,
#if 0
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798,
#endif
NULL}; 
static const BulletStepFunc bullet_e0e3882d41a134cb66ee354e1e1bebbc[] = {
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_335203fb678266e1601218bb1f76f232,
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03,
#if 0
stepfunc_33381006f67f0b2a6227e555c2039d06,
#endif
NULL}; 
static const BulletStepFunc bullet_7c3974019788564f69e867cc7a32ff71[] = {
stepfunc_0eec21fa66dcbdfe4a80555b66c50849,
NULL}; 
static const BulletStepFunc bullet_5d4205404db7632b6f593cc6fa25e966[] = {
stepfunc_7eb793fae76eaa7c6761063a3c912245,
stepfunc_8a375cb7b2af80a8717be020427ef507,
stepfunc_158de86fae4036e1340a7bce3989f7d9,
stepfunc_58e19432a33338365afa335e177a71d5,
stepfunc_7eb793fae76eaa7c6761063a3c912245,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_33381006f67f0b2a6227e555c2039d06(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(501, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_0eec21fa66dcbdfe4a80555b66c50849(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(4 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_9d6b62b0d3ebe3a89fbb9da1e029dd03(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7c3974019788564f69e867cc7a32ff71;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10034, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_33381006f67f0b2a6227e555c2039d06(p);}
p->wait = 6; 
}
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_335203fb678266e1601218bb1f76f232(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 3 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
}
static void stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-501, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4e9c85b792f1a8f999f76a1ca70e538c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7c3974019788564f69e867cc7a32ff71;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-10034, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_d49a5c2a24f89e3f6c9f53ab8ae06798(p);}
p->wait = 6; 
}
static void stepfunc_7eb793fae76eaa7c6761063a3c912245(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7776, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e0e3882d41a134cb66ee354e1e1bebbc;  }
}
p->wait = 120; 
}
static void stepfunc_8a375cb7b2af80a8717be020427ef507(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-7776, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_92cf143159417f1c9277b64caf363991;  }
}
p->wait = 100; 
}
static void stepfunc_158de86fae4036e1340a7bce3989f7d9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7776, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e0e3882d41a134cb66ee354e1e1bebbc;  }
}
p->wait = 80; 
}
static void stepfunc_58e19432a33338365afa335e177a71d5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-7776, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_92cf143159417f1c9277b64caf363991;  }
}
p->wait = 60; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_5a76b37d6b348138e2d4fbb082933562(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_5d4205404db7632b6f593cc6fa25e966; }}


