// XXX uniqID XXX 740492a6569d251c4550519af137ad67 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_537d74a50aa0fe92205c760565ef3180(BulletInfo *p); 
static void stepfunc_aad0635cd3c4d5b29144956be35a1069(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_177f380cbfd5bdc1fa410372284211b3(BulletInfo *p); 
static void stepfunc_eccda7d9ab7e7a6fdd59d49c525b34bd(BulletInfo *p); 
static void stepfunc_e5d3ae1029ab8339b767843ab1067784(BulletInfo *p); 
static void stepfunc_d9d705592913553e723b653a9e67bb54(BulletInfo *p); 
static void stepfunc_732523da8530f2e355e895effb3d15fe(BulletInfo *p); 
static void stepfunc_ca201efabfcf2ccdc4751c1d4f600d04(BulletInfo *p); 


static const BulletStepFunc bullet_26195d671c22eea4dbf15b43fe4b10e2[] = {
stepfunc_537d74a50aa0fe92205c760565ef3180,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_aad0635cd3c4d5b29144956be35a1069,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_0a7a21a6b8b306761b0a88cd75c786eb[] = {
stepfunc_177f380cbfd5bdc1fa410372284211b3,
stepfunc_eccda7d9ab7e7a6fdd59d49c525b34bd,
#if 0
stepfunc_e5d3ae1029ab8339b767843ab1067784,
#endif
stepfunc_eccda7d9ab7e7a6fdd59d49c525b34bd,
#if 0
stepfunc_d9d705592913553e723b653a9e67bb54,
#endif
stepfunc_eccda7d9ab7e7a6fdd59d49c525b34bd,
#if 0
stepfunc_732523da8530f2e355e895effb3d15fe,
#endif
NULL}; 
static const BulletStepFunc bullet_e6ca8784fdaeeb3d190222c6951db36a[] = {
stepfunc_ca201efabfcf2ccdc4751c1d4f600d04,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_732523da8530f2e355e895effb3d15fe(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100)+FixedPointNum(2125, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(80, 100)+FixedPointNum(FixedPointNum(1))+FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d9d705592913553e723b653a9e67bb54(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(3187, 100)+FixedPointNum(2125, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(80, 100)+FixedPointNum(FixedPointNum(1))+FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e5d3ae1029ab8339b767843ab1067784(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(1062, 100)+FixedPointNum(2125, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(80, 100)+FixedPointNum(FixedPointNum(1))+FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_177f380cbfd5bdc1fa410372284211b3(BulletInfo *p) { 
p->wait = 3; 
}
static void stepfunc_eccda7d9ab7e7a6fdd59d49c525b34bd(BulletInfo *p) { 
for (u32 i = 0; i < 2; ++i) { 
stepfunc_e5d3ae1029ab8339b767843ab1067784(p);}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_d9d705592913553e723b653a9e67bb54(p);}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_732523da8530f2e355e895effb3d15fe(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_aad0635cd3c4d5b29144956be35a1069(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0a7a21a6b8b306761b0a88cd75c786eb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0a7a21a6b8b306761b0a88cd75c786eb;  }
}
p->wait = 20; 
}
static void stepfunc_537d74a50aa0fe92205c760565ef3180(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_ca201efabfcf2ccdc4751c1d4f600d04(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_26195d671c22eea4dbf15b43fe4b10e2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_26195d671c22eea4dbf15b43fe4b10e2;  }
}
p->wait = 200; 
}


void genBulletFunc_740492a6569d251c4550519af137ad67(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_e6ca8784fdaeeb3d190222c6951db36a; }}


