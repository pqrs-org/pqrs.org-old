// XXX uniqID XXX b69210483397768b79d4babf9ed15c7f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_956b60c558b7df21f2b22c8a035848ad(BulletInfo *p); 
static void stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(BulletInfo *p); 
static void stepfunc_453a3522e15978f2600bc9de5e6fab19(BulletInfo *p); 
static void stepfunc_5446612bf24b21fc74d7710c88fa39b7(BulletInfo *p); 
static void stepfunc_99a7499d8b7fc20af1292913912de134(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_dbd9b28bbbb6394b5dd7f31f0445c245[] = {
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_99a7499d8b7fc20af1292913912de134,
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_99a7499d8b7fc20af1292913912de134,
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_99a7499d8b7fc20af1292913912de134,
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_99a7499d8b7fc20af1292913912de134,
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_956b60c558b7df21f2b22c8a035848ad,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_5446612bf24b21fc74d7710c88fa39b7,
#if 0
stepfunc_453a3522e15978f2600bc9de5e6fab19,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
#endif
stepfunc_99a7499d8b7fc20af1292913912de134,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(212, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_453a3522e15978f2600bc9de5e6fab19(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(850, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(p);}
}
static void stepfunc_5446612bf24b21fc74d7710c88fa39b7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-15087, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(p);}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_453a3522e15978f2600bc9de5e6fab19(p);}
p->wait = 10; 
}
static void stepfunc_956b60c558b7df21f2b22c8a035848ad(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum(255)*FixedPointNum::random()) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(50, 100)*FixedPointNum::random()+FixedPointNum(50, 100) - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(p);}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_453a3522e15978f2600bc9de5e6fab19(p);}
p->wait = 10; 
}
static void stepfunc_99a7499d8b7fc20af1292913912de134(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 50; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_b69210483397768b79d4babf9ed15c7f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_dbd9b28bbbb6394b5dd7f31f0445c245; }}


