// XXX uniqID XXX a138b8adb748c0a01f4cfb4316cb6de0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_47320a1d1b1c41d97a9c0099b26e95ac(BulletInfo *p); 
static void stepfunc_e61597d5a37c290fdec8359f26dcb290(BulletInfo *p); 
static void stepfunc_ae7e5a65f9a9ad17901ca488bd6c6c9d(BulletInfo *p); 
static void stepfunc_f1dc0d04b3ca570f373163b7234d9827(BulletInfo *p); 
static void stepfunc_0593c0781095fca3d925d2349d644796(BulletInfo *p); 
static void stepfunc_b9672f5cb356335d9bf972bfd6ec7320(BulletInfo *p); 
static void stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929(BulletInfo *p); 
static void stepfunc_8153201aebd4ac7c91a4bb12b57d3118(BulletInfo *p); 
static void stepfunc_54561a13ebe4ff4c4fa43653c4002c76(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_5bf46dcc795cffaa2576434e099ea16c[] = {
stepfunc_47320a1d1b1c41d97a9c0099b26e95ac,
stepfunc_e61597d5a37c290fdec8359f26dcb290,
stepfunc_ae7e5a65f9a9ad17901ca488bd6c6c9d,
stepfunc_f1dc0d04b3ca570f373163b7234d9827,
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_0593c0781095fca3d925d2349d644796,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
stepfunc_8153201aebd4ac7c91a4bb12b57d3118,
#if 0
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929,
#if 0
stepfunc_b9672f5cb356335d9bf972bfd6ec7320,
#endif
#endif
stepfunc_54561a13ebe4ff4c4fa43653c4002c76,
stepfunc_e61597d5a37c290fdec8359f26dcb290,
stepfunc_ae7e5a65f9a9ad17901ca488bd6c6c9d,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_b9672f5cb356335d9bf972bfd6ec7320(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = (FixedPointNum(220, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(220, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_b9672f5cb356335d9bf972bfd6ec7320(p);}
}
static void stepfunc_0593c0781095fca3d925d2349d644796(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(220, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_b9672f5cb356335d9bf972bfd6ec7320(p);}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929(p);}
p->wait = 13; 
}
static void stepfunc_8153201aebd4ac7c91a4bb12b57d3118(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(220, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_b9672f5cb356335d9bf972bfd6ec7320(p);}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_175c1fc53cbe42f0ebb7cb6b0e529929(p);}
p->wait = 13; 
}
static void stepfunc_47320a1d1b1c41d97a9c0099b26e95ac(BulletInfo *p) { 
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum((FixedPointNum(12750, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 6; 
}
static void stepfunc_e61597d5a37c290fdec8359f26dcb290(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(1 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 55; 
}
static void stepfunc_ae7e5a65f9a9ad17901ca488bd6c6c9d(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 55; 
}
static void stepfunc_f1dc0d04b3ca570f373163b7234d9827(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum::random()*FixedPointNum(255)) - p->getAngle();p->setRound(speed, life);}
p->wait = 5; 
}
static void stepfunc_54561a13ebe4ff4c4fa43653c4002c76(BulletInfo *p) { 
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum((0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 6; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_a138b8adb748c0a01f4cfb4316cb6de0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_5bf46dcc795cffaa2576434e099ea16c; }}


