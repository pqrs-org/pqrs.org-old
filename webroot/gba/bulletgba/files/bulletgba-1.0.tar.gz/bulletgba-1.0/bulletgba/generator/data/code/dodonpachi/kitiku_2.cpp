// XXX uniqID XXX 0dba329100a592341092c52b8cccaa1a XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_af96e564d993e9b248ed8c0ebbf2769e(BulletInfo *p); 
static void stepfunc_2b9b7b8ad2619e31bc9043d73ab884e8(BulletInfo *p); 
static void stepfunc_5c656f0c99663ebd3c0d4ff33845f443(BulletInfo *p); 
static void stepfunc_e150453a0c38f25ec6daf4f2d53c84a2(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_eff2fbcce9bc12c3fb3ac93a97604849(BulletInfo *p); 
static void stepfunc_e023f8d281ff9152939f327c7a88a160(BulletInfo *p); 


static const BulletStepFunc bullet_bd155482fbd2ec4d9e8e9340a2ec61fe[] = {
stepfunc_af96e564d993e9b248ed8c0ebbf2769e,
stepfunc_2b9b7b8ad2619e31bc9043d73ab884e8,
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_5c656f0c99663ebd3c0d4ff33845f443,
#if 0
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3dd93423e7fd8a39ed06741148e3c47b[] = {
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_1e3179f11a51e011648b7391e83075a9[] = {
stepfunc_eff2fbcce9bc12c3fb3ac93a97604849,
stepfunc_e023f8d281ff9152939f327c7a88a160,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_e150453a0c38f25ec6daf4f2d53c84a2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(212, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(15, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_5c656f0c99663ebd3c0d4ff33845f443(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-646, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_e150453a0c38f25ec6daf4f2d53c84a2(p);}
p->wait = 4; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_af96e564d993e9b248ed8c0ebbf2769e(BulletInfo *p) { 
p->wait = 6; 
}
static void stepfunc_2b9b7b8ad2619e31bc9043d73ab884e8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_eff2fbcce9bc12c3fb3ac93a97604849(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd155482fbd2ec4d9e8e9340a2ec61fe;  }
}
p->wait = 1; 
}
static void stepfunc_e023f8d281ff9152939f327c7a88a160(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd155482fbd2ec4d9e8e9340a2ec61fe;  }
}
p->wait = 430; 
}


void genBulletFunc_0dba329100a592341092c52b8cccaa1a(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_1e3179f11a51e011648b7391e83075a9; }}


