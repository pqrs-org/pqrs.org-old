// XXX uniqID XXX 439c1fd102aafc34114001e70cc098e4 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b5f39e54521a3eaf20616a06af3538d0(BulletInfo *p); 
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p); 
static void stepfunc_36c0ec94022ed9b27c52f111b83c27ab(BulletInfo *p); 
static void stepfunc_9fbe45bf0d16232591ff0efc0f13249e(BulletInfo *p); 
static void stepfunc_24e3939b5f750d7a8253086a02664737(BulletInfo *p); 
static void stepfunc_5262c7b33909953a5834230763674d3e(BulletInfo *p); 
static void stepfunc_1fd45aa94ace3cc5a3b8667e55281593(BulletInfo *p); 
static void stepfunc_72f044d58ccfb4d5b2b84dbe3f00df2f(BulletInfo *p); 


static const BulletStepFunc bullet_52bcdb65085774bec5a52f3ed07a4526[] = {
stepfunc_b5f39e54521a3eaf20616a06af3538d0,
stepfunc_769bdefb02579aa79348dd03cdd26c8a,
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_36c0ec94022ed9b27c52f111b83c27ab,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_24e3939b5f750d7a8253086a02664737,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_1fd45aa94ace3cc5a3b8667e55281593,
stepfunc_72f044d58ccfb4d5b2b84dbe3f00df2f,
NULL}; 
static void stepfunc_5262c7b33909953a5834230763674d3e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(425, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9fbe45bf0d16232591ff0efc0f13249e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(425, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_36c0ec94022ed9b27c52f111b83c27ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 59; ++i) { 
stepfunc_9fbe45bf0d16232591ff0efc0f13249e(p);}
p->wait = 10; 
}
static void stepfunc_24e3939b5f750d7a8253086a02664737(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(637, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 59; ++i) { 
stepfunc_5262c7b33909953a5834230763674d3e(p);}
p->wait = 10; 
}
static void stepfunc_b5f39e54521a3eaf20616a06af3538d0(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 25; 
}
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_1fd45aa94ace3cc5a3b8667e55281593(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 25; 
}
static void stepfunc_72f044d58ccfb4d5b2b84dbe3f00df2f(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_439c1fd102aafc34114001e70cc098e4(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_52bcdb65085774bec5a52f3ed07a4526; }}


