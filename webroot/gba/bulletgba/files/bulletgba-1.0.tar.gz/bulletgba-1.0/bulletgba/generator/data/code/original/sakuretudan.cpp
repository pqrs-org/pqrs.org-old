// XXX uniqID XXX 678552a9c843e4bbefa5595ee3896ade XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_05efe524a5f88491de5258485203ee4c(BulletInfo *p); 
static void stepfunc_084085cf2be9b236b01018cc4e853805(BulletInfo *p); 
static void stepfunc_6a44bb20f393a4c1d9283abe159a2ec3(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_49e32a245b3ce304698f09c90723d206(BulletInfo *p); 
static void stepfunc_2fe772edb4d0682aba49104294ea1e24(BulletInfo *p); 
static void stepfunc_f3cfc088f994f0bd43365f99dc939675(BulletInfo *p); 
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p); 


static const BulletStepFunc bullet_98b102972e4c7776b6ec11f73d4a83e8[] = {
stepfunc_05efe524a5f88491de5258485203ee4c,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_084085cf2be9b236b01018cc4e853805,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_2be9844f85d27940f013c6d3b3398fda[] = {
stepfunc_49e32a245b3ce304698f09c90723d206,
stepfunc_2fe772edb4d0682aba49104294ea1e24,
NULL}; 
static const BulletStepFunc bullet_8c3fbdc27ee6e8335b9396ec4e9ff8f1[] = {
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_f3cfc088f994f0bd43365f99dc939675,
stepfunc_97e8979d1a7c719f55deab0bdea20675,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_49e32a245b3ce304698f09c90723d206(BulletInfo *p) { 
p->wait = FixedPointNum::random()*FixedPointNum(5); 
}
static void stepfunc_2fe772edb4d0682aba49104294ea1e24(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (FixedPointNum::random()*FixedPointNum(4)+FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_084085cf2be9b236b01018cc4e853805(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2be9844f85d27940f013c6d3b3398fda;  }
}
}
static void stepfunc_6a44bb20f393a4c1d9283abe159a2ec3(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_05efe524a5f88491de5258485203ee4c(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 60; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_f3cfc088f994f0bd43365f99dc939675(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::random()*FixedPointNum(255));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98b102972e4c7776b6ec11f73d4a83e8;  }
}
p->wait = 60; 
}
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p) { 
p->wait = 100; 
}


void genBulletFunc_678552a9c843e4bbefa5595ee3896ade(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_8c3fbdc27ee6e8335b9396ec4e9ff8f1; }}


