// XXX uniqID XXX d35b47229547a2b018558227dc6a025c XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 
static void stepfunc_9b5a426fc16fbeff6cb19aed9e879d14(BulletInfo *p); 
static void stepfunc_bbc91d6ae5ccdbfdab65447a1ceccb7a(BulletInfo *p); 
static void stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d(BulletInfo *p); 
static void stepfunc_25d2caf7735439d95145c38a571ff6b0(BulletInfo *p); 
static void stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c(BulletInfo *p); 
static void stepfunc_254c7c101aaaf5b6c6a3f39ae53cf7eb(BulletInfo *p); 
static void stepfunc_ea3887b57b81c87f104a6eefdbc88790(BulletInfo *p); 
static void stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6(BulletInfo *p); 
static void stepfunc_cff48349f549a0cd84bae436ddfa65b0(BulletInfo *p); 
static void stepfunc_8f27081bbb52d187de2b4fc2bf96a6c5(BulletInfo *p); 
static void stepfunc_7743cefcdfdff09096f21527cc19bf2d(BulletInfo *p); 
static void stepfunc_9738a8b90ab73b2ce2359dedadaa36e1(BulletInfo *p); 
static void stepfunc_cbc947c03fb1ab17a8b2c85daff6de5c(BulletInfo *p); 
static void stepfunc_5a5c466f9f70409558250c9d5200e84f(BulletInfo *p); 
static void stepfunc_95ff95a32dcd6386e5b5a3ab3d1fb24a(BulletInfo *p); 
static void stepfunc_49a52ab1a032295cc2f6062c4825eda2(BulletInfo *p); 
static void stepfunc_4ed5c9cb488a5d16a0def08f46cca4ee(BulletInfo *p); 
static void stepfunc_ababdf75224220c29cd67939d009e498(BulletInfo *p); 
static void stepfunc_66f76cc4aa5edcf500caabdbaa4485be(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_3706e2b0017376f253eff8d36bf261cd[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_9b5a426fc16fbeff6cb19aed9e879d14,
stepfunc_bbc91d6ae5ccdbfdab65447a1ceccb7a,
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_254c7c101aaaf5b6c6a3f39ae53cf7eb,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_254c7c101aaaf5b6c6a3f39ae53cf7eb,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_254c7c101aaaf5b6c6a3f39ae53cf7eb,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_254c7c101aaaf5b6c6a3f39ae53cf7eb,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_254c7c101aaaf5b6c6a3f39ae53cf7eb,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d,
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_25d2caf7735439d95145c38a571ff6b0,
#if 0
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c,
#endif
stepfunc_ea3887b57b81c87f104a6eefdbc88790,
stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6,
#if 0
stepfunc_cff48349f549a0cd84bae436ddfa65b0,
#endif
stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6,
#if 0
stepfunc_8f27081bbb52d187de2b4fc2bf96a6c5,
#endif
stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6,
#if 0
stepfunc_7743cefcdfdff09096f21527cc19bf2d,
#endif
stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6,
#if 0
stepfunc_9738a8b90ab73b2ce2359dedadaa36e1,
#endif
stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6,
#if 0
stepfunc_cbc947c03fb1ab17a8b2c85daff6de5c,
#endif
stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6,
#if 0
stepfunc_5a5c466f9f70409558250c9d5200e84f,
#endif
stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6,
#if 0
stepfunc_95ff95a32dcd6386e5b5a3ab3d1fb24a,
#endif
stepfunc_49a52ab1a032295cc2f6062c4825eda2,
stepfunc_4ed5c9cb488a5d16a0def08f46cca4ee,
#if 0
stepfunc_ababdf75224220c29cd67939d009e498,
#endif
NULL}; 
static const BulletStepFunc bullet_d700c3b36aa4dd6eb044c463f673c8ff[] = {
stepfunc_66f76cc4aa5edcf500caabdbaa4485be,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_ababdf75224220c29cd67939d009e498(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(283, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(283, 100));    p->lastBulletSpeed = (FixedPointNum(90, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = (FixedPointNum(70, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_95ff95a32dcd6386e5b5a3ab3d1fb24a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_5a5c466f9f70409558250c9d5200e84f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(708, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_cbc947c03fb1ab17a8b2c85daff6de5c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(354, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9738a8b90ab73b2ce2359dedadaa36e1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_7743cefcdfdff09096f21527cc19bf2d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-354, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_8f27081bbb52d187de2b4fc2bf96a6c5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-708, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_cff48349f549a0cd84bae436ddfa65b0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1062, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-FixedPointNum(2125, 100)+FixedPointNum::random()*FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_25d2caf7735439d95145c38a571ff6b0(BulletInfo *p) { 
for (u32 i = 0; i < 4; ++i) { 
stepfunc_595c13f0d87c2e9ac555a1d8ce8a164c(p);}
p->wait = 8; 
}
static void stepfunc_4fe35fb7d9dd9cc5166c11aac7b9166d(BulletInfo *p) { 
{
  u16 life = 24;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-3187, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_254c7c101aaaf5b6c6a3f39ae53cf7eb(BulletInfo *p) { 
{
  u16 life = 48;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(6375, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_9b5a426fc16fbeff6cb19aed9e879d14(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_bbc91d6ae5ccdbfdab65447a1ceccb7a(BulletInfo *p) { 
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum((FixedPointNum(12750, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 10; 
}
static void stepfunc_ea3887b57b81c87f104a6eefdbc88790(BulletInfo *p) { 
p->wait = 400; 
}
static void stepfunc_a76a3f41c13cef5d8b2e146563e8f5a6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1062, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_cff48349f549a0cd84bae436ddfa65b0(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-708, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_8f27081bbb52d187de2b4fc2bf96a6c5(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_7743cefcdfdff09096f21527cc19bf2d(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_9738a8b90ab73b2ce2359dedadaa36e1(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_cbc947c03fb1ab17a8b2c85daff6de5c(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(708, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_5a5c466f9f70409558250c9d5200e84f(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_95ff95a32dcd6386e5b5a3ab3d1fb24a(p);}
p->wait = 175; 
}
static void stepfunc_49a52ab1a032295cc2f6062c4825eda2(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(1)+FixedPointNum::random() - p->getSpeed();p->setAccel(speed, life);}
p->wait = FixedPointNum(10)+FixedPointNum::random()*FixedPointNum(65); 
}
static void stepfunc_4ed5c9cb488a5d16a0def08f46cca4ee(BulletInfo *p) { 
for (u32 i = 0; i < 30; ++i) { 
stepfunc_ababdf75224220c29cd67939d009e498(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_66f76cc4aa5edcf500caabdbaa4485be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (85);    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3706e2b0017376f253eff8d36bf261cd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-85);    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3706e2b0017376f253eff8d36bf261cd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3706e2b0017376f253eff8d36bf261cd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-3187, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3706e2b0017376f253eff8d36bf261cd;  }
}
p->wait = 1300; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_d35b47229547a2b018558227dc6a025c(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_d700c3b36aa4dd6eb044c463f673c8ff; }}


