// XXX uniqID XXX a8d45d83cd82ff7b58b026289f02ec31 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_5e3191f65c4ce8cd90fcb6ebfe3e5099(BulletInfo *p); 
static void stepfunc_c33a225e8c1ff0c722cc860114ef262e(BulletInfo *p); 
static void stepfunc_9bfce65253260c8faba148a15f6552f0(BulletInfo *p); 
static void stepfunc_e19963b7a95ef9850c37f5edae1623dd(BulletInfo *p); 
static void stepfunc_79854b301627169cdb17562bcfca9659(BulletInfo *p); 
static void stepfunc_d5f005c356592947b360316cbcf47b0e(BulletInfo *p); 
static void stepfunc_a6571855d4729cad0a5a93202bfd6c72(BulletInfo *p); 
static void stepfunc_266cd10a2dff19f76bdf9a619079235d(BulletInfo *p); 
static void stepfunc_df2c9190217fb2692dc1c619bda2790d(BulletInfo *p); 
static void stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7(BulletInfo *p); 
static void stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda(BulletInfo *p); 
static void stepfunc_0cae7d1a1472137b1170db4ada69d9b7(BulletInfo *p); 
static void stepfunc_546effe802eba63060e92d5a2746aef0(BulletInfo *p); 
static void stepfunc_55afc9a9845503e026794d7263e6ab12(BulletInfo *p); 
static void stepfunc_e8ee77598bc7fc6731419d9a35945f6d(BulletInfo *p); 
static void stepfunc_286e709ba40e036ad889c9c0a9435ac9(BulletInfo *p); 
static void stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b(BulletInfo *p); 
static void stepfunc_8f74f93622160bd7549e0b32f7caf9eb(BulletInfo *p); 
static void stepfunc_d665045807944747a6eb6eaced0ac2f1(BulletInfo *p); 
static void stepfunc_e4bcc471a07d78a81bb6b156167f0ac0(BulletInfo *p); 
static void stepfunc_e9c8d19dfcdb947abf729be00eafd9d5(BulletInfo *p); 
static void stepfunc_03eb57551430dc2c52213197e6262fdb(BulletInfo *p); 
static void stepfunc_1a3c310aca4bd8324e09c4a95f3db72e(BulletInfo *p); 
static void stepfunc_cbd37eebf314e221cfc9216b89297421(BulletInfo *p); 
static void stepfunc_4b5c613e7198f3aabae5a1721fb63c91(BulletInfo *p); 
static void stepfunc_9fa11ac749a104c17050ed4aa9022e6b(BulletInfo *p); 
static void stepfunc_42d57dfd06872f8db9d744eb5ac88a1b(BulletInfo *p); 
static void stepfunc_5e90ee36e2c906bad509482fe0cb02b0(BulletInfo *p); 
static void stepfunc_0ff43229045c6e34798d258519747481(BulletInfo *p); 
static void stepfunc_5bd1bd7d19eb3a5c6762290c4011c6fa(BulletInfo *p); 
static void stepfunc_4354a52e298354b908f0591c9e4b0b23(BulletInfo *p); 
static void stepfunc_2f15f6aaf8afc9a32108aa89234a9e95(BulletInfo *p); 
static void stepfunc_fbfad99abb951138cb72579d1ac34be4(BulletInfo *p); 
static void stepfunc_dba19baa29757440f7b476b3e3d99253(BulletInfo *p); 
static void stepfunc_0b1fecc4e4b809247caf5cb62719e10a(BulletInfo *p); 
static void stepfunc_16476e20df93eaeca194f5c83c82a56c(BulletInfo *p); 
static void stepfunc_b8148ddbcd63929e90e976ae2f1f25af(BulletInfo *p); 
static void stepfunc_a70d940ced19da807e57cdb24666897d(BulletInfo *p); 
static void stepfunc_6d8fd32fc8754f0d1b5af2c59333b710(BulletInfo *p); 
static void stepfunc_bfe4656ff42615ac74d657590dee609a(BulletInfo *p); 
static void stepfunc_821a992fea5f53550256e090e17806b1(BulletInfo *p); 
static void stepfunc_0e777bd54fe3761f5ecdad6ba496267c(BulletInfo *p); 
static void stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833(BulletInfo *p); 
static void stepfunc_172a2e43fef4ae5d31c992db50c4fca3(BulletInfo *p); 
static void stepfunc_c4b8b8a321b55f06fa571426b1284107(BulletInfo *p); 
static void stepfunc_fb01137074be10bf76984403d335504f(BulletInfo *p); 
static void stepfunc_c7efeef5681a4bdfa6f696044697bf1c(BulletInfo *p); 
static void stepfunc_2efd606ebc6e84377394cf8da2b34631(BulletInfo *p); 
static void stepfunc_b0fd8ac8430eb94dd071a1daa45b0376(BulletInfo *p); 
static void stepfunc_94e3baf71d6d7a20109f4f5dbb138540(BulletInfo *p); 
static void stepfunc_a0be0384ebc4474206d087f56232e0be(BulletInfo *p); 
static void stepfunc_304f4e0df22ba3d7cd12b706090bc980(BulletInfo *p); 
static void stepfunc_72ee7364900882a8f2f7445fdce97d3e(BulletInfo *p); 
static void stepfunc_37fa9c7bb59eaf32261d05c419cfa89e(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_6648e2af7661e8d2a2b886ea17a65ab7[] = {
stepfunc_5e3191f65c4ce8cd90fcb6ebfe3e5099,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_9bfce65253260c8faba148a15f6552f0,
stepfunc_e19963b7a95ef9850c37f5edae1623dd,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_d5f005c356592947b360316cbcf47b0e,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_a6571855d4729cad0a5a93202bfd6c72,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_266cd10a2dff19f76bdf9a619079235d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_df2c9190217fb2692dc1c619bda2790d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_266cd10a2dff19f76bdf9a619079235d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_a6571855d4729cad0a5a93202bfd6c72,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_d5f005c356592947b360316cbcf47b0e,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_e19963b7a95ef9850c37f5edae1623dd,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_0cae7d1a1472137b1170db4ada69d9b7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_546effe802eba63060e92d5a2746aef0,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_0cae7d1a1472137b1170db4ada69d9b7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_e19963b7a95ef9850c37f5edae1623dd,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_d5f005c356592947b360316cbcf47b0e,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_a6571855d4729cad0a5a93202bfd6c72,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_266cd10a2dff19f76bdf9a619079235d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_df2c9190217fb2692dc1c619bda2790d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_266cd10a2dff19f76bdf9a619079235d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_a6571855d4729cad0a5a93202bfd6c72,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_d5f005c356592947b360316cbcf47b0e,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_e19963b7a95ef9850c37f5edae1623dd,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_0cae7d1a1472137b1170db4ada69d9b7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_546effe802eba63060e92d5a2746aef0,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_0cae7d1a1472137b1170db4ada69d9b7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_e19963b7a95ef9850c37f5edae1623dd,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_d5f005c356592947b360316cbcf47b0e,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_a6571855d4729cad0a5a93202bfd6c72,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_266cd10a2dff19f76bdf9a619079235d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_df2c9190217fb2692dc1c619bda2790d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_266cd10a2dff19f76bdf9a619079235d,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_a6571855d4729cad0a5a93202bfd6c72,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_d5f005c356592947b360316cbcf47b0e,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_e19963b7a95ef9850c37f5edae1623dd,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_0cae7d1a1472137b1170db4ada69d9b7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_546effe802eba63060e92d5a2746aef0,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_0cae7d1a1472137b1170db4ada69d9b7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7,
#if 0
stepfunc_79854b301627169cdb17562bcfca9659,
#endif
stepfunc_55afc9a9845503e026794d7263e6ab12,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_5e3191f65c4ce8cd90fcb6ebfe3e5099,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_9bfce65253260c8faba148a15f6552f0,
stepfunc_e8ee77598bc7fc6731419d9a35945f6d,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_8f74f93622160bd7549e0b32f7caf9eb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d665045807944747a6eb6eaced0ac2f1,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e4bcc471a07d78a81bb6b156167f0ac0,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d665045807944747a6eb6eaced0ac2f1,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_8f74f93622160bd7549e0b32f7caf9eb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e8ee77598bc7fc6731419d9a35945f6d,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e9c8d19dfcdb947abf729be00eafd9d5,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_03eb57551430dc2c52213197e6262fdb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_1a3c310aca4bd8324e09c4a95f3db72e,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_cbd37eebf314e221cfc9216b89297421,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_1a3c310aca4bd8324e09c4a95f3db72e,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_03eb57551430dc2c52213197e6262fdb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e9c8d19dfcdb947abf729be00eafd9d5,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e8ee77598bc7fc6731419d9a35945f6d,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_8f74f93622160bd7549e0b32f7caf9eb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d665045807944747a6eb6eaced0ac2f1,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e4bcc471a07d78a81bb6b156167f0ac0,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d665045807944747a6eb6eaced0ac2f1,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_8f74f93622160bd7549e0b32f7caf9eb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e8ee77598bc7fc6731419d9a35945f6d,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e9c8d19dfcdb947abf729be00eafd9d5,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_03eb57551430dc2c52213197e6262fdb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_1a3c310aca4bd8324e09c4a95f3db72e,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_cbd37eebf314e221cfc9216b89297421,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_1a3c310aca4bd8324e09c4a95f3db72e,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_03eb57551430dc2c52213197e6262fdb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e9c8d19dfcdb947abf729be00eafd9d5,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e8ee77598bc7fc6731419d9a35945f6d,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_8f74f93622160bd7549e0b32f7caf9eb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d665045807944747a6eb6eaced0ac2f1,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e4bcc471a07d78a81bb6b156167f0ac0,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d665045807944747a6eb6eaced0ac2f1,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_8f74f93622160bd7549e0b32f7caf9eb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e8ee77598bc7fc6731419d9a35945f6d,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e9c8d19dfcdb947abf729be00eafd9d5,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_03eb57551430dc2c52213197e6262fdb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_1a3c310aca4bd8324e09c4a95f3db72e,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_cbd37eebf314e221cfc9216b89297421,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_1a3c310aca4bd8324e09c4a95f3db72e,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_03eb57551430dc2c52213197e6262fdb,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_e9c8d19dfcdb947abf729be00eafd9d5,
#if 0
stepfunc_286e709ba40e036ad889c9c0a9435ac9,
#endif
stepfunc_55afc9a9845503e026794d7263e6ab12,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_5e3191f65c4ce8cd90fcb6ebfe3e5099,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_9bfce65253260c8faba148a15f6552f0,
stepfunc_4b5c613e7198f3aabae5a1721fb63c91,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_42d57dfd06872f8db9d744eb5ac88a1b,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5e90ee36e2c906bad509482fe0cb02b0,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_0ff43229045c6e34798d258519747481,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5bd1bd7d19eb3a5c6762290c4011c6fa,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_0ff43229045c6e34798d258519747481,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5e90ee36e2c906bad509482fe0cb02b0,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_42d57dfd06872f8db9d744eb5ac88a1b,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4b5c613e7198f3aabae5a1721fb63c91,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4354a52e298354b908f0591c9e4b0b23,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_2f15f6aaf8afc9a32108aa89234a9e95,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_fbfad99abb951138cb72579d1ac34be4,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_dba19baa29757440f7b476b3e3d99253,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_fbfad99abb951138cb72579d1ac34be4,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_2f15f6aaf8afc9a32108aa89234a9e95,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4354a52e298354b908f0591c9e4b0b23,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4b5c613e7198f3aabae5a1721fb63c91,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_42d57dfd06872f8db9d744eb5ac88a1b,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5e90ee36e2c906bad509482fe0cb02b0,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_0ff43229045c6e34798d258519747481,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5bd1bd7d19eb3a5c6762290c4011c6fa,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_0ff43229045c6e34798d258519747481,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5e90ee36e2c906bad509482fe0cb02b0,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_42d57dfd06872f8db9d744eb5ac88a1b,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4b5c613e7198f3aabae5a1721fb63c91,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4354a52e298354b908f0591c9e4b0b23,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_2f15f6aaf8afc9a32108aa89234a9e95,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_fbfad99abb951138cb72579d1ac34be4,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_dba19baa29757440f7b476b3e3d99253,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_fbfad99abb951138cb72579d1ac34be4,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_2f15f6aaf8afc9a32108aa89234a9e95,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4354a52e298354b908f0591c9e4b0b23,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4b5c613e7198f3aabae5a1721fb63c91,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_42d57dfd06872f8db9d744eb5ac88a1b,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5e90ee36e2c906bad509482fe0cb02b0,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_0ff43229045c6e34798d258519747481,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5bd1bd7d19eb3a5c6762290c4011c6fa,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_0ff43229045c6e34798d258519747481,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_5e90ee36e2c906bad509482fe0cb02b0,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_42d57dfd06872f8db9d744eb5ac88a1b,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4b5c613e7198f3aabae5a1721fb63c91,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4354a52e298354b908f0591c9e4b0b23,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_2f15f6aaf8afc9a32108aa89234a9e95,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_fbfad99abb951138cb72579d1ac34be4,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_dba19baa29757440f7b476b3e3d99253,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_fbfad99abb951138cb72579d1ac34be4,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_2f15f6aaf8afc9a32108aa89234a9e95,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_4354a52e298354b908f0591c9e4b0b23,
#if 0
stepfunc_9fa11ac749a104c17050ed4aa9022e6b,
#endif
stepfunc_55afc9a9845503e026794d7263e6ab12,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_5e3191f65c4ce8cd90fcb6ebfe3e5099,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_9bfce65253260c8faba148a15f6552f0,
stepfunc_0b1fecc4e4b809247caf5cb62719e10a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_b8148ddbcd63929e90e976ae2f1f25af,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_a70d940ced19da807e57cdb24666897d,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_6d8fd32fc8754f0d1b5af2c59333b710,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_bfe4656ff42615ac74d657590dee609a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_6d8fd32fc8754f0d1b5af2c59333b710,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_a70d940ced19da807e57cdb24666897d,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_b8148ddbcd63929e90e976ae2f1f25af,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0b1fecc4e4b809247caf5cb62719e10a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_821a992fea5f53550256e090e17806b1,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0e777bd54fe3761f5ecdad6ba496267c,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_172a2e43fef4ae5d31c992db50c4fca3,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0e777bd54fe3761f5ecdad6ba496267c,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_821a992fea5f53550256e090e17806b1,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0b1fecc4e4b809247caf5cb62719e10a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_b8148ddbcd63929e90e976ae2f1f25af,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_a70d940ced19da807e57cdb24666897d,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_6d8fd32fc8754f0d1b5af2c59333b710,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_bfe4656ff42615ac74d657590dee609a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_6d8fd32fc8754f0d1b5af2c59333b710,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_a70d940ced19da807e57cdb24666897d,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_b8148ddbcd63929e90e976ae2f1f25af,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0b1fecc4e4b809247caf5cb62719e10a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_821a992fea5f53550256e090e17806b1,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0e777bd54fe3761f5ecdad6ba496267c,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_172a2e43fef4ae5d31c992db50c4fca3,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0e777bd54fe3761f5ecdad6ba496267c,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_821a992fea5f53550256e090e17806b1,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0b1fecc4e4b809247caf5cb62719e10a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_b8148ddbcd63929e90e976ae2f1f25af,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_a70d940ced19da807e57cdb24666897d,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_6d8fd32fc8754f0d1b5af2c59333b710,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_bfe4656ff42615ac74d657590dee609a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_6d8fd32fc8754f0d1b5af2c59333b710,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_a70d940ced19da807e57cdb24666897d,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_b8148ddbcd63929e90e976ae2f1f25af,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0b1fecc4e4b809247caf5cb62719e10a,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_821a992fea5f53550256e090e17806b1,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0e777bd54fe3761f5ecdad6ba496267c,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_172a2e43fef4ae5d31c992db50c4fca3,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_0e777bd54fe3761f5ecdad6ba496267c,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_821a992fea5f53550256e090e17806b1,
#if 0
stepfunc_16476e20df93eaeca194f5c83c82a56c,
#endif
stepfunc_55afc9a9845503e026794d7263e6ab12,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_5e3191f65c4ce8cd90fcb6ebfe3e5099,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_9bfce65253260c8faba148a15f6552f0,
stepfunc_c4b8b8a321b55f06fa571426b1284107,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c7efeef5681a4bdfa6f696044697bf1c,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_2efd606ebc6e84377394cf8da2b34631,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_b0fd8ac8430eb94dd071a1daa45b0376,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_94e3baf71d6d7a20109f4f5dbb138540,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_b0fd8ac8430eb94dd071a1daa45b0376,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_2efd606ebc6e84377394cf8da2b34631,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c7efeef5681a4bdfa6f696044697bf1c,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c4b8b8a321b55f06fa571426b1284107,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_a0be0384ebc4474206d087f56232e0be,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_304f4e0df22ba3d7cd12b706090bc980,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_72ee7364900882a8f2f7445fdce97d3e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_37fa9c7bb59eaf32261d05c419cfa89e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_72ee7364900882a8f2f7445fdce97d3e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_304f4e0df22ba3d7cd12b706090bc980,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_a0be0384ebc4474206d087f56232e0be,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c4b8b8a321b55f06fa571426b1284107,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c7efeef5681a4bdfa6f696044697bf1c,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_2efd606ebc6e84377394cf8da2b34631,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_b0fd8ac8430eb94dd071a1daa45b0376,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_94e3baf71d6d7a20109f4f5dbb138540,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_b0fd8ac8430eb94dd071a1daa45b0376,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_2efd606ebc6e84377394cf8da2b34631,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c7efeef5681a4bdfa6f696044697bf1c,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c4b8b8a321b55f06fa571426b1284107,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_a0be0384ebc4474206d087f56232e0be,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_304f4e0df22ba3d7cd12b706090bc980,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_72ee7364900882a8f2f7445fdce97d3e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_37fa9c7bb59eaf32261d05c419cfa89e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_72ee7364900882a8f2f7445fdce97d3e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_304f4e0df22ba3d7cd12b706090bc980,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_a0be0384ebc4474206d087f56232e0be,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c4b8b8a321b55f06fa571426b1284107,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c7efeef5681a4bdfa6f696044697bf1c,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_2efd606ebc6e84377394cf8da2b34631,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_b0fd8ac8430eb94dd071a1daa45b0376,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_94e3baf71d6d7a20109f4f5dbb138540,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_b0fd8ac8430eb94dd071a1daa45b0376,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_2efd606ebc6e84377394cf8da2b34631,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c7efeef5681a4bdfa6f696044697bf1c,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_c4b8b8a321b55f06fa571426b1284107,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_a0be0384ebc4474206d087f56232e0be,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_304f4e0df22ba3d7cd12b706090bc980,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_72ee7364900882a8f2f7445fdce97d3e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_37fa9c7bb59eaf32261d05c419cfa89e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_72ee7364900882a8f2f7445fdce97d3e,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_304f4e0df22ba3d7cd12b706090bc980,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_a0be0384ebc4474206d087f56232e0be,
#if 0
stepfunc_fb01137074be10bf76984403d335504f,
#endif
stepfunc_55afc9a9845503e026794d7263e6ab12,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_fb01137074be10bf76984403d335504f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (12);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_c4b8b8a321b55f06fa571426b1284107(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_c7efeef5681a4bdfa6f696044697bf1c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_2efd606ebc6e84377394cf8da2b34631(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_b0fd8ac8430eb94dd071a1daa45b0376(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_94e3baf71d6d7a20109f4f5dbb138540(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_a0be0384ebc4474206d087f56232e0be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_304f4e0df22ba3d7cd12b706090bc980(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_72ee7364900882a8f2f7445fdce97d3e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_37fa9c7bb59eaf32261d05c419cfa89e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_fb01137074be10bf76984403d335504f(p);}
p->wait = 2; 
}
static void stepfunc_16476e20df93eaeca194f5c83c82a56c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1440, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_0b1fecc4e4b809247caf5cb62719e10a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_b8148ddbcd63929e90e976ae2f1f25af(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_a70d940ced19da807e57cdb24666897d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_6d8fd32fc8754f0d1b5af2c59333b710(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_bfe4656ff42615ac74d657590dee609a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_821a992fea5f53550256e090e17806b1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_0e777bd54fe3761f5ecdad6ba496267c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_2e7c12c4c8033bab19d61e7ac7ae3833(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_172a2e43fef4ae5d31c992db50c4fca3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 24; ++i) { 
stepfunc_16476e20df93eaeca194f5c83c82a56c(p);}
p->wait = 2; 
}
static void stepfunc_9fa11ac749a104c17050ed4aa9022e6b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (18);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4b5c613e7198f3aabae5a1721fb63c91(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_42d57dfd06872f8db9d744eb5ac88a1b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_5e90ee36e2c906bad509482fe0cb02b0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_0ff43229045c6e34798d258519747481(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_5bd1bd7d19eb3a5c6762290c4011c6fa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_4354a52e298354b908f0591c9e4b0b23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_2f15f6aaf8afc9a32108aa89234a9e95(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_fbfad99abb951138cb72579d1ac34be4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_dba19baa29757440f7b476b3e3d99253(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_9fa11ac749a104c17050ed4aa9022e6b(p);}
p->wait = 2; 
}
static void stepfunc_286e709ba40e036ad889c9c0a9435ac9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (24);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e8ee77598bc7fc6731419d9a35945f6d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_d5b98aa2f7b77c4d2f83ebc3500e616b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_8f74f93622160bd7549e0b32f7caf9eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_d665045807944747a6eb6eaced0ac2f1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_e4bcc471a07d78a81bb6b156167f0ac0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_e9c8d19dfcdb947abf729be00eafd9d5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_03eb57551430dc2c52213197e6262fdb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_1a3c310aca4bd8324e09c4a95f3db72e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_cbd37eebf314e221cfc9216b89297421(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 14; ++i) { 
stepfunc_286e709ba40e036ad889c9c0a9435ac9(p);}
p->wait = 2; 
}
static void stepfunc_79854b301627169cdb17562bcfca9659(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (36);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e19963b7a95ef9850c37f5edae1623dd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_d5f005c356592947b360316cbcf47b0e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_a6571855d4729cad0a5a93202bfd6c72(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_266cd10a2dff19f76bdf9a619079235d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_df2c9190217fb2692dc1c619bda2790d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_1e63a48f71c22f0f3cc7e1700cf69fa7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-212, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_26ac1ed40d76417ebb5ea5f1f06ecfda(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_0cae7d1a1472137b1170db4ada69d9b7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-425, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_546effe802eba63060e92d5a2746aef0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-460, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 9; ++i) { 
stepfunc_79854b301627169cdb17562bcfca9659(p);}
p->wait = 2; 
}
static void stepfunc_5e3191f65c4ce8cd90fcb6ebfe3e5099(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = ((FixedPointNum(7083, 100)+(FixedPointNum::random())*FixedPointNum(11333, 100))) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = ((FixedPointNum::random()))*FixedPointNum(6)+FixedPointNum(FixedPointNum(1))*FixedPointNum(6) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_c33a225e8c1ff0c722cc860114ef262e(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_9bfce65253260c8faba148a15f6552f0(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum::random()*FixedPointNum(255)) - p->getAngle();p->setRound(speed, life);}
p->wait = 1; 
}
static void stepfunc_55afc9a9845503e026794d7263e6ab12(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (((FixedPointNum(7083, 100)+(FixedPointNum::random())*FixedPointNum(11333, 100))+FixedPointNum(12750, 100))) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = ((FixedPointNum::random()))*FixedPointNum(6)+FixedPointNum(FixedPointNum(1))*FixedPointNum(6) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_a8d45d83cd82ff7b58b026289f02ec31(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_6648e2af7661e8d2a2b886ea17a65ab7; }}


