// XXX uniqID XXX e457e3280b609a4bb8ab59c27fdbecb0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p); 
static void stepfunc_11bbb43cf6060a0959aa2b542110cc78(BulletInfo *p); 
static void stepfunc_419b82479d5ec703ea22ebd50c9ec566(BulletInfo *p); 
static void stepfunc_50a41ff9c682dad15ce5e83805da2d68(BulletInfo *p); 
static void stepfunc_d59236f36c50eef669b9755f0a4319de(BulletInfo *p); 
static void stepfunc_95f0210c75673253733dca5ea9381ef5(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_b551ef41fdc0e2016e0128d2ece99e8e(BulletInfo *p); 


static const BulletStepFunc bullet_70883a28372592b99dffebeacb8e7202[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_11bbb43cf6060a0959aa2b542110cc78,
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_419b82479d5ec703ea22ebd50c9ec566,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_95f0210c75673253733dca5ea9381ef5,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_d59236f36c50eef669b9755f0a4319de,
#if 0
stepfunc_50a41ff9c682dad15ce5e83805da2d68,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3dd93423e7fd8a39ed06741148e3c47b[] = {
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_64b69f3ac687bed805dd3c1fcff91245[] = {
stepfunc_b551ef41fdc0e2016e0128d2ece99e8e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_50a41ff9c682dad15ce5e83805da2d68(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1770, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d59236f36c50eef669b9755f0a4319de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-6933, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_50a41ff9c682dad15ce5e83805da2d68(p);}
p->wait = 2; 
}
static void stepfunc_95f0210c75673253733dca5ea9381ef5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-7232, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_50a41ff9c682dad15ce5e83805da2d68(p);}
p->wait = 2; 
}
static void stepfunc_419b82479d5ec703ea22ebd50c9ec566(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-7083, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_50a41ff9c682dad15ce5e83805da2d68(p);}
p->wait = 2; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_11bbb43cf6060a0959aa2b542110cc78(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(16291, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
}
static void stepfunc_b551ef41fdc0e2016e0128d2ece99e8e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9562, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_70883a28372592b99dffebeacb8e7202;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15937, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_70883a28372592b99dffebeacb8e7202;  }
}
p->wait = 220; 
}


void genBulletFunc_e457e3280b609a4bb8ab59c27fdbecb0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_64b69f3ac687bed805dd3c1fcff91245; }}


