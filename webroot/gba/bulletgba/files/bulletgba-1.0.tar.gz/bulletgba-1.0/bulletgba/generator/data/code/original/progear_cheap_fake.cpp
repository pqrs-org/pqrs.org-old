// XXX uniqID XXX 6ccd7c3646ac0a28d28cff4ff6d6663a XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_3efc47c9ff9608d8b8679627ca2dbeba(BulletInfo *p); 
static void stepfunc_e1bb12f56d3a739d843fc11714f7bf77(BulletInfo *p); 
static void stepfunc_d7270068df0ea6208f56ba00e5be5f92(BulletInfo *p); 
static void stepfunc_e4171c858f03d42f9cc4cedf10561eb8(BulletInfo *p); 
static void stepfunc_9a115327112f9fb77f2f126f94e8e6cf(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_1287a571291ea12c24ea78fa563666be[] = {
stepfunc_3efc47c9ff9608d8b8679627ca2dbeba,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_d7270068df0ea6208f56ba00e5be5f92,
stepfunc_3efc47c9ff9608d8b8679627ca2dbeba,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_d7270068df0ea6208f56ba00e5be5f92,
stepfunc_3efc47c9ff9608d8b8679627ca2dbeba,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_e1bb12f56d3a739d843fc11714f7bf77,
stepfunc_d7270068df0ea6208f56ba00e5be5f92,
stepfunc_3efc47c9ff9608d8b8679627ca2dbeba,
NULL}; 
static const BulletStepFunc bullet_17f6b5a39fe68b719526f289d0892ac1[] = {
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_e4171c858f03d42f9cc4cedf10561eb8,
stepfunc_9a115327112f9fb77f2f126f94e8e6cf,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_e1bb12f56d3a739d843fc11714f7bf77(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_3efc47c9ff9608d8b8679627ca2dbeba(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(FixedPointNum(150, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_d7270068df0ea6208f56ba00e5be5f92(BulletInfo *p) { 
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (FixedPointNum(4250, 100)-FixedPointNum(85)*FixedPointNum::random()) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(FixedPointNum(10, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_e4171c858f03d42f9cc4cedf10561eb8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1287a571291ea12c24ea78fa563666be;  }
}
p->wait = 30; 
}
static void stepfunc_9a115327112f9fb77f2f126f94e8e6cf(BulletInfo *p) { 
p->wait = 180; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_6ccd7c3646ac0a28d28cff4ff6d6663a(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_17f6b5a39fe68b719526f289d0892ac1; }}


