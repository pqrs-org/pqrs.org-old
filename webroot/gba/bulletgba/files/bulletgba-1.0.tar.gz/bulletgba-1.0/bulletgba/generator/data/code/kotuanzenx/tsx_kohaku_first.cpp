// XXX uniqID XXX 8bfbaf6f4daa2384b76feb27d8615282 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_b933d83e3aeaa286da0cc9abc84997d9(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_4e9d082a8cdf315cc09e5117473f4aed(BulletInfo *p); 
static void stepfunc_6793cb48748fb690ab08be463778bf84(BulletInfo *p); 
static void stepfunc_ae72ab3a38cf5a7b54f5387b022734bc(BulletInfo *p); 
static void stepfunc_d015bfb36207eb8a130c8425966e5116(BulletInfo *p); 
static void stepfunc_76f7c0bd4e2461e011ddd3fa50d95203(BulletInfo *p); 
static void stepfunc_b54c77a3891eb81da56b9c73de37adab(BulletInfo *p); 
static void stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248(BulletInfo *p); 
static void stepfunc_8598e7d9bdf00234c6c2cbe6290a8650(BulletInfo *p); 


static const BulletStepFunc bullet_cde5ea0a0f77ba04c53c3b7e03e62db4[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_b933d83e3aeaa286da0cc9abc84997d9,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_8da1956cb5a702267c57a1f5268dff3e[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_4e9d082a8cdf315cc09e5117473f4aed,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_4b1163bfb5696dd2be6576a41374b5de[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_6793cb48748fb690ab08be463778bf84,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_6473287c01612f44f96e3a5f1d7b9f2b[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae72ab3a38cf5a7b54f5387b022734bc,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_0f2a65fc8b8ea52692d07affd6e7e99d[] = {
stepfunc_d015bfb36207eb8a130c8425966e5116,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_76f7c0bd4e2461e011ddd3fa50d95203,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_43c09588717f8a1b0b1afa4cf121a036[] = {
stepfunc_d015bfb36207eb8a130c8425966e5116,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_b54c77a3891eb81da56b9c73de37adab,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_9e556444f091821401e66d4a098487b2[] = {
stepfunc_d015bfb36207eb8a130c8425966e5116,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_1e838f6e26ce0b42fc0d13a9d33b77b9[] = {
stepfunc_8598e7d9bdf00234c6c2cbe6290a8650,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_b54c77a3891eb81da56b9c73de37adab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(7, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_d015bfb36207eb8a130c8425966e5116(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_85c3fabdf75ac7eb5ef6adb30bbda248(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-7, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_b933d83e3aeaa286da0cc9abc84997d9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(85)+FixedPointNum::random()*FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e556444f091821401e66d4a098487b2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100)+FixedPointNum::random()*FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_43c09588717f8a1b0b1afa4cf121a036;  }
}
p->wait = 30; 
}
static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p) { 
p->wait = 9; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_76f7c0bd4e2461e011ddd3fa50d95203(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_4e9d082a8cdf315cc09e5117473f4aed(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f2a65fc8b8ea52692d07affd6e7e99d;  }
}
p->wait = 30; 
}
static void stepfunc_6793cb48748fb690ab08be463778bf84(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-70, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 20; 
}
static void stepfunc_ae72ab3a38cf5a7b54f5387b022734bc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 20; 
}
static void stepfunc_8598e7d9bdf00234c6c2cbe6290a8650(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6473287c01612f44f96e3a5f1d7b9f2b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6473287c01612f44f96e3a5f1d7b9f2b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (-2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4b1163bfb5696dd2be6576a41374b5de;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (-4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4b1163bfb5696dd2be6576a41374b5de;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8da1956cb5a702267c57a1f5268dff3e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cde5ea0a0f77ba04c53c3b7e03e62db4;  }
}
p->wait = 610; 
}


void genBulletFunc_8bfbaf6f4daa2384b76feb27d8615282(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_1e838f6e26ce0b42fc0d13a9d33b77b9; }}


