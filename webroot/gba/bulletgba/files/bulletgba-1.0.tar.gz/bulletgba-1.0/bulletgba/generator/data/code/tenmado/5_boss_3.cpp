// XXX uniqID XXX 1b7e354019aaae1c0f5fd693c17983f9 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_14cf48d4bc6c9ebdef74ad42261498db(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_8f71731518f20e1ee5010870e21629a8(BulletInfo *p); 
static void stepfunc_8c554813f3f6324de2f0eb210e99d94f(BulletInfo *p); 
static void stepfunc_db1dc82a75e93992c5f990e3c6064fe5(BulletInfo *p); 
static void stepfunc_6d655116d903bedce9dfbe201241fa16(BulletInfo *p); 
static void stepfunc_1b0146a62156279fecf3d1f202c5e09c(BulletInfo *p); 
static void stepfunc_2e36386e499e2ddfa6480f53c8c1ee0a(BulletInfo *p); 
static void stepfunc_c331f55821db04c5de7a760069b883ea(BulletInfo *p); 
static void stepfunc_110b7e5f1ca336e75421676e6fee9c5b(BulletInfo *p); 
static void stepfunc_e9e83aa7fb6924d4331a110399ee2185(BulletInfo *p); 
static void stepfunc_88391e0adc41732413c3ddfe4e42df46(BulletInfo *p); 
static void stepfunc_23eab824a5a91d78983183f6c7c7cd33(BulletInfo *p); 
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 


static const BulletStepFunc bullet_6562486e7c6f98dbec32538bc83aea66[] = {
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_14cf48d4bc6c9ebdef74ad42261498db,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_6acc78a820a4155b3e0938cef7f09cfc[] = {
stepfunc_8f71731518f20e1ee5010870e21629a8,
stepfunc_8c554813f3f6324de2f0eb210e99d94f,
NULL}; 
static const BulletStepFunc bullet_b7ba2b24c944452ca3e73a0ddf7add80[] = {
stepfunc_db1dc82a75e93992c5f990e3c6064fe5,
stepfunc_6d655116d903bedce9dfbe201241fa16,
NULL}; 
static const BulletStepFunc bullet_277d95f75d3dd5c8e066fc85dff16a92[] = {
stepfunc_1b0146a62156279fecf3d1f202c5e09c,
stepfunc_8c554813f3f6324de2f0eb210e99d94f,
NULL}; 
static const BulletStepFunc bullet_54a3863a3b35d667fbfa0963b64e20cc[] = {
stepfunc_2e36386e499e2ddfa6480f53c8c1ee0a,
stepfunc_6d655116d903bedce9dfbe201241fa16,
NULL}; 
static const BulletStepFunc bullet_7dcba6545dc97e7c5fcd9b1563c3a054[] = {
stepfunc_c331f55821db04c5de7a760069b883ea,
NULL}; 
static const BulletStepFunc bullet_e17f7e1e688efee29dcf5b9316fae41d[] = {
stepfunc_110b7e5f1ca336e75421676e6fee9c5b,
NULL}; 
static const BulletStepFunc bullet_5089f789229eed6b718904b227182163[] = {
stepfunc_e9e83aa7fb6924d4331a110399ee2185,
NULL}; 
static const BulletStepFunc bullet_3d9a7fe83027e0332cb19d6ac2bfcbc4[] = {
stepfunc_88391e0adc41732413c3ddfe4e42df46,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_23eab824a5a91d78983183f6c7c7cd33,
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_c331f55821db04c5de7a760069b883ea(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(210, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_110b7e5f1ca336e75421676e6fee9c5b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(204, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_e9e83aa7fb6924d4331a110399ee2185(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_23eab824a5a91d78983183f6c7c7cd33(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5089f789229eed6b718904b227182163;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e17f7e1e688efee29dcf5b9316fae41d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7dcba6545dc97e7c5fcd9b1563c3a054;  }
}
p->wait = 10; 
}
static void stepfunc_8f71731518f20e1ee5010870e21629a8(BulletInfo *p) { 
p->wait = 84; 
}
static void stepfunc_8c554813f3f6324de2f0eb210e99d94f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (85);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10625, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14875, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (170);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(21250, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(23375, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_db1dc82a75e93992c5f990e3c6064fe5(BulletInfo *p) { 
p->wait = 76; 
}
static void stepfunc_6d655116d903bedce9dfbe201241fa16(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (85);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10625, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14875, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (170);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(21250, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(23375, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1b0146a62156279fecf3d1f202c5e09c(BulletInfo *p) { 
p->wait = 68; 
}
static void stepfunc_2e36386e499e2ddfa6480f53c8c1ee0a(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_14cf48d4bc6c9ebdef74ad42261498db(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9562, 100) + FixedPointNum(6375, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(30, 100) + FixedPointNum(170, 100) * FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_54a3863a3b35d667fbfa0963b64e20cc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9562, 100) + FixedPointNum(6375, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(30, 100) + FixedPointNum(170, 100) * FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_277d95f75d3dd5c8e066fc85dff16a92;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9562, 100) + FixedPointNum(6375, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(30, 100) + FixedPointNum(170, 100) * FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b7ba2b24c944452ca3e73a0ddf7add80;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9562, 100) + FixedPointNum(6375, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(30, 100) + FixedPointNum(170, 100) * FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6acc78a820a4155b3e0938cef7f09cfc;  }
}
p->wait = 32; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_88391e0adc41732413c3ddfe4e42df46(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6562486e7c6f98dbec32538bc83aea66;  }
}
p->wait = 120; 
}
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}


void genBulletFunc_1b7e354019aaae1c0f5fd693c17983f9(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_3d9a7fe83027e0332cb19d6ac2bfcbc4; }}


