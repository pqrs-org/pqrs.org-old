// XXX uniqID XXX ef1c2457cc64cfc80b9fd485342c5471 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_0ec2eda5337bd8653c4a07c6b1214a11(BulletInfo *p); 
static void stepfunc_11842a85f1de40db0d740aad7d33658f(BulletInfo *p); 
static void stepfunc_1d8b21d766293687e49c5e663600e829(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_70cdc7ce6eff2d255282bdecc4329ed8(BulletInfo *p); 


static const BulletStepFunc bullet_624cc90af51c172a62ed66b40fd47f2d[] = {
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_0ec2eda5337bd8653c4a07c6b1214a11,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_1d8b21d766293687e49c5e663600e829,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_a1781696364271efe003c20a2bd3f9ec[] = {
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_70cdc7ce6eff2d255282bdecc4329ed8,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_1d8b21d766293687e49c5e663600e829,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_11842a85f1de40db0d740aad7d33658f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_0ec2eda5337bd8653c4a07c6b1214a11(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_11842a85f1de40db0d740aad7d33658f(p);}
p->wait = 2; 
}
static void stepfunc_1d8b21d766293687e49c5e663600e829(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_70cdc7ce6eff2d255282bdecc4329ed8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(283, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_11842a85f1de40db0d740aad7d33658f(p);}
p->wait = 2; 
}


void genBulletFunc_ef1c2457cc64cfc80b9fd485342c5471(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_a1781696364271efe003c20a2bd3f9ec; }  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_624cc90af51c172a62ed66b40fd47f2d; }}


