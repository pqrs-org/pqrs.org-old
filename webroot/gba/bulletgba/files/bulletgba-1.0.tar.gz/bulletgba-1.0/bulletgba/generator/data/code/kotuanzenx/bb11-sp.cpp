// XXX uniqID XXX 143001ba37f72942b5dfaabc2b2afafb XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p); 
static void stepfunc_0ef30cf0a3b34c9f0171b4f4595a2dcf(BulletInfo *p); 
static void stepfunc_add55792f35151edb0ee5a3ea25c9b30(BulletInfo *p); 
static void stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_30eb5b90fec1634e5c736eded3426405(BulletInfo *p); 
static void stepfunc_bab48ada24a57da8221830c2aab4b6a0(BulletInfo *p); 
static void stepfunc_f895a9f1935ac0d14ca3cfd52455561c(BulletInfo *p); 
static void stepfunc_102953b021eb5d9371e75dcc6ce9a061(BulletInfo *p); 
static void stepfunc_c68a4e2b0374717a0a6962a782f2cf64(BulletInfo *p); 
static void stepfunc_e709dac2a1f7bfc385ea047a30cf0082(BulletInfo *p); 
static void stepfunc_db1b2163180881e9931deca7b44e2bfe(BulletInfo *p); 


static const BulletStepFunc bullet_6745134511b8734516f3be0cbc4530e7[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_0ef30cf0a3b34c9f0171b4f4595a2dcf,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_add55792f35151edb0ee5a3ea25c9b30,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_4a58b9b711305bb9083cf5e27cd915c5[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_bab48ada24a57da8221830c2aab4b6a0,
stepfunc_f895a9f1935ac0d14ca3cfd52455561c,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_102953b021eb5d9371e75dcc6ce9a061,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_276e3a833736a883387ec90ecfa5f0ff[] = {
stepfunc_c68a4e2b0374717a0a6962a782f2cf64,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_e709dac2a1f7bfc385ea047a30cf0082,
stepfunc_db1b2163180881e9931deca7b44e2bfe,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_102953b021eb5d9371e75dcc6ce9a061(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_30eb5b90fec1634e5c736eded3426405(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_bab48ada24a57da8221830c2aab4b6a0(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_f895a9f1935ac0d14ca3cfd52455561c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(2125, 100)+FixedPointNum::random()*FixedPointNum(4250, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_e709dac2a1f7bfc385ea047a30cf0082(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum::random()*FixedPointNum(255));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a58b9b711305bb9083cf5e27cd915c5;  }
}
p->wait = 10; 
}
static void stepfunc_5e881cd4dd3911d2c86eb83249dbbfa5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-283, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 6; 
}
static void stepfunc_add55792f35151edb0ee5a3ea25c9b30(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(283, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 6; 
}
static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_0ef30cf0a3b34c9f0171b4f4595a2dcf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 6; 
}
static void stepfunc_c68a4e2b0374717a0a6962a782f2cf64(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6745134511b8734516f3be0cbc4530e7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6745134511b8734516f3be0cbc4530e7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (-2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6745134511b8734516f3be0cbc4530e7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (-4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6745134511b8734516f3be0cbc4530e7;  }
}
p->wait = 60; 
}
static void stepfunc_db1b2163180881e9931deca7b44e2bfe(BulletInfo *p) { 
p->wait = 120; 
}


void genBulletFunc_143001ba37f72942b5dfaabc2b2afafb(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_276e3a833736a883387ec90ecfa5f0ff; }}


