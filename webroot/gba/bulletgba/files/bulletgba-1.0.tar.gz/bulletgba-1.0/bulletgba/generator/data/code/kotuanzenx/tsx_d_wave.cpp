// XXX uniqID XXX 9af899c5b076bb7e647cbf738a6cc70f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_453f28457e53efee416f87dac69b3445(BulletInfo *p); 
static void stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575(BulletInfo *p); 
static void stepfunc_7543937edc007b1a7b28f28904bc1589(BulletInfo *p); 
static void stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60(BulletInfo *p); 
static void stepfunc_1b8a83447a223cdc11ebd05822f1d043(BulletInfo *p); 
static void stepfunc_1416b5473ba63e42b2265ecb93832804(BulletInfo *p); 
static void stepfunc_04365d416e82e69e86bb94aab7aa5163(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_00c2ce75bdfc018e50eb8fab18703b21[] = {
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
NULL}; 
static const BulletStepFunc bullet_7b0be5e9f72a6fc8078cae2c1399811f[] = {
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
NULL}; 
static const BulletStepFunc bullet_1dbd0677911ededa8c69ea68f0966c4d[] = {
stepfunc_1b8a83447a223cdc11ebd05822f1d043,
#if 0
stepfunc_1416b5473ba63e42b2265ecb93832804,
#endif
NULL}; 
static const BulletStepFunc bullet_9a85cca1b3779329091276445b1c34c8[] = {
stepfunc_04365d416e82e69e86bb94aab7aa5163,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_1416b5473ba63e42b2265ecb93832804(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-70, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1b8a83447a223cdc11ebd05822f1d043(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(779, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 22; ++i) { 
stepfunc_1416b5473ba63e42b2265ecb93832804(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(3187, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
}
static void stepfunc_453f28457e53efee416f87dac69b3445(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575(p);}
p->wait = 30; 
}
static void stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(3187, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
}
static void stepfunc_7543937edc007b1a7b28f28904bc1589(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1593, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60(p);}
p->wait = 30; 
}
static void stepfunc_04365d416e82e69e86bb94aab7aa5163(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7b0be5e9f72a6fc8078cae2c1399811f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_00c2ce75bdfc018e50eb8fab18703b21;  }
}
p->wait = 600; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_9af899c5b076bb7e647cbf738a6cc70f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_9a85cca1b3779329091276445b1c34c8; }}


