// XXX uniqID XXX 3ce4bdcec1f779d04c6aa53122d8cabd XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_5e5be720b9233e3ac703ba5a7370fe34(BulletInfo *p); 
static void stepfunc_442ee3b294c5f52e2b281b905e106824(BulletInfo *p); 
static void stepfunc_a6c6002295be5ddbf497e18dd5ed566f(BulletInfo *p); 
static void stepfunc_8b3ff76e381808bfa211f3d80b40bdbe(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_d334dc06f67dad8a309714d061321aa5(BulletInfo *p); 
static void stepfunc_716bea930d5f53d10b3f6c26b7ea2a0d(BulletInfo *p); 
static void stepfunc_7f61185e680d3b6e7f2672cef8416450(BulletInfo *p); 
static void stepfunc_8ee3ce6c08b737e07a381a3efd8db916(BulletInfo *p); 
static void stepfunc_bec3c8d337e84267e5f3f5dcfe214e77(BulletInfo *p); 
static void stepfunc_23005c2ef2ac22473df0605e0f341346(BulletInfo *p); 
static void stepfunc_4b29cbb66dc6d5cbdcff4459f4aadd44(BulletInfo *p); 
static void stepfunc_a150e275f4f674212b553495bbbf9e54(BulletInfo *p); 
static void stepfunc_b3ad252fc851e5495a316a6413dce327(BulletInfo *p); 
static void stepfunc_943b30ae3d22cce3b057e23b5a35fe6d(BulletInfo *p); 
static void stepfunc_5d990e00e3b3aa04b771e4181c3412f6(BulletInfo *p); 
static void stepfunc_b1834ec77a279a94aa7d6b5a66727ade(BulletInfo *p); 
static void stepfunc_8774a97184370e8a42ffce9f8eb5e417(BulletInfo *p); 
static void stepfunc_3b3877e7994bf780f2b10454bcda7a55(BulletInfo *p); 
static void stepfunc_ecda1b2c1ebabc55a434c11e422c3aa3(BulletInfo *p); 
static void stepfunc_f9b173cadf118c82c9dfee0abec6e26b(BulletInfo *p); 
static void stepfunc_d2479a26f8ba638ad765ebe80fe1170c(BulletInfo *p); 
static void stepfunc_2990cc657da7929f898230e9fd374bd2(BulletInfo *p); 
static void stepfunc_2498afe6aaad43782548c9cceaedace2(BulletInfo *p); 
static void stepfunc_73c52fc0d6d9f4d9f5c2e725f205ec70(BulletInfo *p); 
static void stepfunc_fb0cb730bcb6887d074c8e8d242f9e97(BulletInfo *p); 
static void stepfunc_920ec785b857ed07d0dc57fce664ffee(BulletInfo *p); 
static void stepfunc_30d6d885454cdf969c31bfd4a3fd5286(BulletInfo *p); 
static void stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7(BulletInfo *p); 
static void stepfunc_937335c3c54dc8d8b99005f67001a056(BulletInfo *p); 
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 


static const BulletStepFunc bullet_7946618881eff1fa563509b269f89522[] = {
stepfunc_5e5be720b9233e3ac703ba5a7370fe34,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_6cf51623973a0906126ff4ca5a656c5e[] = {
stepfunc_d334dc06f67dad8a309714d061321aa5,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9e7a3a16afdf509a9883c031e4772c86[] = {
stepfunc_716bea930d5f53d10b3f6c26b7ea2a0d,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_a95378dea5438927573c887ce37cf283[] = {
stepfunc_7f61185e680d3b6e7f2672cef8416450,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_2c6d13bb0ea5cbedfc96262975398380[] = {
stepfunc_8ee3ce6c08b737e07a381a3efd8db916,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_a283d7c6e845e8da45678672801e2e33[] = {
stepfunc_bec3c8d337e84267e5f3f5dcfe214e77,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_ac6b5e1d7f81433c8d6042029f991446[] = {
stepfunc_23005c2ef2ac22473df0605e0f341346,
stepfunc_4b29cbb66dc6d5cbdcff4459f4aadd44,
stepfunc_a150e275f4f674212b553495bbbf9e54,
stepfunc_b3ad252fc851e5495a316a6413dce327,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b8251256c5180c9f78a01442a2b64c13[] = {
stepfunc_943b30ae3d22cce3b057e23b5a35fe6d,
stepfunc_4b29cbb66dc6d5cbdcff4459f4aadd44,
stepfunc_a150e275f4f674212b553495bbbf9e54,
stepfunc_b3ad252fc851e5495a316a6413dce327,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_8567f0bf2a86073798aef8e53a8c929f[] = {
stepfunc_5d990e00e3b3aa04b771e4181c3412f6,
stepfunc_4b29cbb66dc6d5cbdcff4459f4aadd44,
stepfunc_a150e275f4f674212b553495bbbf9e54,
stepfunc_b3ad252fc851e5495a316a6413dce327,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d10585bfb1e9c80e232fc1e85341adad[] = {
stepfunc_b1834ec77a279a94aa7d6b5a66727ade,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_634f1d7831e09883c536c20aa4440263[] = {
stepfunc_8774a97184370e8a42ffce9f8eb5e417,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_f32c2c1ba60fbfe1e4007fb810ec133c[] = {
stepfunc_3b3877e7994bf780f2b10454bcda7a55,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_adf1e3717d5f0164b2b27be098f0fa76[] = {
stepfunc_ecda1b2c1ebabc55a434c11e422c3aa3,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_98ef25d53ac55f43eb7741cb7fe18bb8[] = {
stepfunc_f9b173cadf118c82c9dfee0abec6e26b,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_115df81537fb6f3d1ee7c9ca988a315a[] = {
stepfunc_d2479a26f8ba638ad765ebe80fe1170c,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_212907cfa693f7af3f78243afc5d735a[] = {
stepfunc_2990cc657da7929f898230e9fd374bd2,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_686e08e5c8e0cfd3b23b29c0b3de88bd[] = {
stepfunc_2498afe6aaad43782548c9cceaedace2,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3dee8e2bae3eb8eac1510c6aee2814de[] = {
stepfunc_73c52fc0d6d9f4d9f5c2e725f205ec70,
stepfunc_442ee3b294c5f52e2b281b905e106824,
stepfunc_a6c6002295be5ddbf497e18dd5ed566f,
stepfunc_8b3ff76e381808bfa211f3d80b40bdbe,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_dee6d36885edfaa7d58059ce8bdbe595[] = {
stepfunc_fb0cb730bcb6887d074c8e8d242f9e97,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_4eb34db3cdba32d0def0104f5b5519f2[] = {
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_920ec785b857ed07d0dc57fce664ffee,
stepfunc_30d6d885454cdf969c31bfd4a3fd5286,
stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7,
stepfunc_937335c3c54dc8d8b99005f67001a056,
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_5e5be720b9233e3ac703ba5a7370fe34(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(23375, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_442ee3b294c5f52e2b281b905e106824(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(212, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-425, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_a6c6002295be5ddbf497e18dd5ed566f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(637, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-850, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_8b3ff76e381808bfa211f3d80b40bdbe(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1275, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_d334dc06f67dad8a309714d061321aa5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_716bea930d5f53d10b3f6c26b7ea2a0d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14875, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_7f61185e680d3b6e7f2672cef8416450(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10625, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_8ee3ce6c08b737e07a381a3efd8db916(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_bec3c8d337e84267e5f3f5dcfe214e77(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_fb0cb730bcb6887d074c8e8d242f9e97(BulletInfo *p) { 
p->wait = 1000; 
}
static void stepfunc_23005c2ef2ac22473df0605e0f341346(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1275, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
p->wait = 3; 
}
static void stepfunc_4b29cbb66dc6d5cbdcff4459f4aadd44(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(212, 100));    p->lastBulletSpeed = (FixedPointNum(176, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-425, 100));    p->lastBulletSpeed = (FixedPointNum(176, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
p->wait = 3; 
}
static void stepfunc_a150e275f4f674212b553495bbbf9e54(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(637, 100));    p->lastBulletSpeed = (FixedPointNum(193, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-850, 100));    p->lastBulletSpeed = (FixedPointNum(193, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
p->wait = 3; 
}
static void stepfunc_b3ad252fc851e5495a316a6413dce327(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1275, 100));    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
p->wait = 3; 
}
static void stepfunc_943b30ae3d22cce3b057e23b5a35fe6d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1275, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
p->wait = 3; 
}
static void stepfunc_5d990e00e3b3aa04b771e4181c3412f6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dee6d36885edfaa7d58059ce8bdbe595;  }
}
p->wait = 3; 
}
static void stepfunc_b1834ec77a279a94aa7d6b5a66727ade(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(21250, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_8774a97184370e8a42ffce9f8eb5e417(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (170);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_3b3877e7994bf780f2b10454bcda7a55(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_ecda1b2c1ebabc55a434c11e422c3aa3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (85);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_f9b173cadf118c82c9dfee0abec6e26b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_d2479a26f8ba638ad765ebe80fe1170c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_2990cc657da7929f898230e9fd374bd2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1275, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_2498afe6aaad43782548c9cceaedace2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1275, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_73c52fc0d6d9f4d9f5c2e725f205ec70(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_920ec785b857ed07d0dc57fce664ffee(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dee8e2bae3eb8eac1510c6aee2814de;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_686e08e5c8e0cfd3b23b29c0b3de88bd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_212907cfa693f7af3f78243afc5d735a;  }
}
p->wait = 7; 
}
static void stepfunc_30d6d885454cdf969c31bfd4a3fd5286(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_115df81537fb6f3d1ee7c9ca988a315a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98ef25d53ac55f43eb7741cb7fe18bb8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_adf1e3717d5f0164b2b27be098f0fa76;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f32c2c1ba60fbfe1e4007fb810ec133c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_634f1d7831e09883c536c20aa4440263;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d10585bfb1e9c80e232fc1e85341adad;  }
}
p->wait = 7; 
}
static void stepfunc_e329cb26b10e3d8e7a5fae3593bd2ff7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8567f0bf2a86073798aef8e53a8c929f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b8251256c5180c9f78a01442a2b64c13;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ac6b5e1d7f81433c8d6042029f991446;  }
}
p->wait = 7; 
}
static void stepfunc_937335c3c54dc8d8b99005f67001a056(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a283d7c6e845e8da45678672801e2e33;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2c6d13bb0ea5cbedfc96262975398380;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a95378dea5438927573c887ce37cf283;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e7a3a16afdf509a9883c031e4772c86;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6cf51623973a0906126ff4ca5a656c5e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7946618881eff1fa563509b269f89522;  }
}
p->wait = 7; 
}
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}


void genBulletFunc_3ce4bdcec1f779d04c6aa53122d8cabd(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_4eb34db3cdba32d0def0104f5b5519f2; }}


