// XXX uniqID XXX 6c91af4c9dee2a3d569c4993b91e9d96 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_77e73728a95622ab704cbd60911e3f30(BulletInfo *p); 
static void stepfunc_16155e36d389a093f140fef61a6c2bec(BulletInfo *p); 
static void stepfunc_f5fc13a2664df660aaad46fd70ab4ab5(BulletInfo *p); 
static void stepfunc_f054541877a2006b8d2edc5e9afe66d8(BulletInfo *p); 
static void stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6(BulletInfo *p); 
static void stepfunc_23933e8362d4e8674f5b124788f82a8c(BulletInfo *p); 
static void stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2(BulletInfo *p); 
static void stepfunc_ba2c82e86daa693475584c354b717e96(BulletInfo *p); 
static void stepfunc_fc9203b63fa6220c67186a3553b16c1a(BulletInfo *p); 
static void stepfunc_be701408fefcdc7d946cb025cbde3fca(BulletInfo *p); 
static void stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089(BulletInfo *p); 
static void stepfunc_00002b9b002c88aa92c95be36f5f2170(BulletInfo *p); 
static void stepfunc_2200cfdd0e9287b4e1130022873ee613(BulletInfo *p); 
static void stepfunc_0b62c0a239af9d95f8255a48dda545d2(BulletInfo *p); 
static void stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca(BulletInfo *p); 
static void stepfunc_e7514eb040f84f9bba3fd53f5a7c383c(BulletInfo *p); 
static void stepfunc_aab71df843284029ac901e43f6ec0479(BulletInfo *p); 
static void stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de(BulletInfo *p); 
static void stepfunc_63221470cce7c7f48183340e90cea943(BulletInfo *p); 
static void stepfunc_71f0a3c108e5a819adbf0a9867ad9340(BulletInfo *p); 
static void stepfunc_ab05b8e537f4a9d9619d173f4b125e5d(BulletInfo *p); 
static void stepfunc_2f319d6bebbd9542f014b0d4db3a31ca(BulletInfo *p); 
static void stepfunc_b5ebcaed895c6d9e9815a182985c8e45(BulletInfo *p); 
static void stepfunc_a4e5c6aca9165b46e914e685d8056c82(BulletInfo *p); 
static void stepfunc_35447e2974d87e423df1f9cb2029456d(BulletInfo *p); 
static void stepfunc_fdd5788c6a399d9cb36af80327bc669d(BulletInfo *p); 
static void stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6(BulletInfo *p); 
static void stepfunc_cc548300db279a4d09dc4fb634971fe8(BulletInfo *p); 
static void stepfunc_8dee0231088d78a3fb65f90e08bd065d(BulletInfo *p); 
static void stepfunc_79ff498cfbff39b1c28e076c8c043683(BulletInfo *p); 
static void stepfunc_618788dd4486c022033182238d4bfb71(BulletInfo *p); 
static void stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97(BulletInfo *p); 
static void stepfunc_c894a1c80ea3afa258b73d38dc01897b(BulletInfo *p); 
static void stepfunc_f82f2db623f6e589c70a130388e91ce4(BulletInfo *p); 
static void stepfunc_27f9158a25d40a435a345a9496135f23(BulletInfo *p); 
static void stepfunc_de007f369b73bc94fa4133858a5d4bc8(BulletInfo *p); 
static void stepfunc_ffc02ee559cbb1c9432d3475398c219f(BulletInfo *p); 
static void stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4(BulletInfo *p); 
static void stepfunc_e8f6001cd9a308b8598888b21c7a2cb5(BulletInfo *p); 
static void stepfunc_05648ba8614520bcfe8b652c74c2a990(BulletInfo *p); 
static void stepfunc_5830b616100ea0b4e0d564f8ae8718be(BulletInfo *p); 
static void stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364(BulletInfo *p); 
static void stepfunc_2f0f89791fefcc70e5525a441ee734e9(BulletInfo *p); 
static void stepfunc_ca145210014513dc1d2b35c98f7f71c4(BulletInfo *p); 
static void stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df(BulletInfo *p); 
static void stepfunc_e45fdb38ec3753dd229c0589db5ba0cd(BulletInfo *p); 
static void stepfunc_7d42ae88829a4f48318a9a95d51e311c(BulletInfo *p); 
static void stepfunc_c284ac9c71bdf8ca675bb55f07c09846(BulletInfo *p); 
static void stepfunc_6609b686e81e3c59a11de5538b7aa2a4(BulletInfo *p); 
static void stepfunc_88e1b4a7217945b3f92ad1ff510f3653(BulletInfo *p); 
static void stepfunc_319e606fe5d045bbd2f5176d49ab32fb(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_e21b79873fe7a00b6f7d517e1df1a611(BulletInfo *p); 
static void stepfunc_da8e710bb0fe0683fe26f273c194c803(BulletInfo *p); 
static void stepfunc_e5590bd7ea6cf8fa83b21e1419a854c3(BulletInfo *p); 
static void stepfunc_4bb7972a3d9cb26cdef633ccdc2e3705(BulletInfo *p); 
static void stepfunc_fae6c7bc112a867078dc33dd3f893fc4(BulletInfo *p); 
static void stepfunc_b843f84b80a0414fc3d16c3ba9fb5954(BulletInfo *p); 
static void stepfunc_a989866c58f33ba270d0df8e7db03c9b(BulletInfo *p); 
static void stepfunc_f868cbd31b11efe75bbfa35f335c68a6(BulletInfo *p); 
static void stepfunc_9275b5a1b86b49ac7e0aba7cd0d3de08(BulletInfo *p); 
static void stepfunc_f5a66b23ded0f25ffe786931ff9ec5de(BulletInfo *p); 
static void stepfunc_2aaf66bb23f330299140d82cbb25005c(BulletInfo *p); 
static void stepfunc_e969897bb657b1a4a1972ef131146180(BulletInfo *p); 
static void stepfunc_bcdaf2d5a65cb75138bbe8626cca6270(BulletInfo *p); 
static void stepfunc_4f3fff48e3956f6e76af16a84dc0c27a(BulletInfo *p); 
static void stepfunc_4e8158703fbbc43894ce583e3ee76011(BulletInfo *p); 
static void stepfunc_0c6f7946d5e40c058b1252c019ea77ae(BulletInfo *p); 
static void stepfunc_a521c35168d487bfe0c8da0ee089a0f5(BulletInfo *p); 
static void stepfunc_d04766bd97eed1af0d2d329a8f4e2d83(BulletInfo *p); 
static void stepfunc_d0228e89703652967591faa34e244b81(BulletInfo *p); 
static void stepfunc_14879c92d0380c7a958f21c5faeba1f8(BulletInfo *p); 
static void stepfunc_aff4530e510a3fce952402d92059ce3f(BulletInfo *p); 
static void stepfunc_8af311b269614dd7c150da53869dc275(BulletInfo *p); 
static void stepfunc_3fbc69c17bf881898b3b3107aab94098(BulletInfo *p); 
static void stepfunc_afab56063701f74857cc5dd70072a052(BulletInfo *p); 
static void stepfunc_db63a7012f2e611c5c5edeaf5f1f95f7(BulletInfo *p); 
static void stepfunc_215624a57ae6982e445b30157a6f468c(BulletInfo *p); 
static void stepfunc_9f6b77f4d85a9258d295e1be6fc61d61(BulletInfo *p); 
static void stepfunc_5f98d2b45974198380010b3f06d699ca(BulletInfo *p); 
static void stepfunc_12b80cf5453cd90cbba3dd3bcc92d259(BulletInfo *p); 
static void stepfunc_393246da2db9e04107986facb78b9b32(BulletInfo *p); 
static void stepfunc_33ef2d357f66a2b942411de89328dbaa(BulletInfo *p); 
static void stepfunc_5aba040520537860a412e77836ce893e(BulletInfo *p); 
static void stepfunc_e68124f911bbbca9b9a06b21ab649260(BulletInfo *p); 
static void stepfunc_448f5d56b575fc670f18f390d8c3e0d3(BulletInfo *p); 
static void stepfunc_f8d04b4573d2c0bcd2e1d885ef7524bb(BulletInfo *p); 
static void stepfunc_84c84e785ce1b575dfbd72bbb2d4c16b(BulletInfo *p); 
static void stepfunc_bca741a7467eae1037e8f46fe273809e(BulletInfo *p); 
static void stepfunc_8645af25feeb6946aa5a1db0faea6a4d(BulletInfo *p); 
static void stepfunc_6180b1c6912eba9f741b97e9d24afab0(BulletInfo *p); 
static void stepfunc_14e652cb8212673144b3c3d2c7011ead(BulletInfo *p); 
static void stepfunc_c23c664d2ac375a0707f374b22893618(BulletInfo *p); 
static void stepfunc_008fdf2f750c850c4aa78a856d932cb6(BulletInfo *p); 
static void stepfunc_4285d2d82a65d433685be02e220a87af(BulletInfo *p); 
static void stepfunc_d619bbbdbcb14e6d271fd0d509844153(BulletInfo *p); 
static void stepfunc_6166e424e8da832870a082411ab03a0a(BulletInfo *p); 
static void stepfunc_17c4a7a98351c288574e026812245bb9(BulletInfo *p); 
static void stepfunc_d520eec51ad1042fbf0cc2d58412e682(BulletInfo *p); 
static void stepfunc_4cd0c1050a3293029416ce0a961b0902(BulletInfo *p); 
static void stepfunc_972d7e481cb6403eea2d0a5f424ef8b0(BulletInfo *p); 
static void stepfunc_073710ad94e5f992dd844832143f48c3(BulletInfo *p); 
static void stepfunc_89a3723e31a10471756fde6241bf49c8(BulletInfo *p); 
static void stepfunc_8cd782da7a9415a800aac62a4fca1a6c(BulletInfo *p); 


static const BulletStepFunc bullet_4e64f3d35e335c498e6e079fb6565461[] = {
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_fdd5788c6a399d9cb36af80327bc669d,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_fdd5788c6a399d9cb36af80327bc669d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_bd6a676026420d00600d0809c54ea3e7[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_da8e710bb0fe0683fe26f273c194c803,
NULL}; 
static const BulletStepFunc bullet_d84e3cca4a6740f8e025011d630373c9[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_e5590bd7ea6cf8fa83b21e1419a854c3,
NULL}; 
static const BulletStepFunc bullet_3a8b2c22b3624917462e720c412d197f[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_4bb7972a3d9cb26cdef633ccdc2e3705,
NULL}; 
static const BulletStepFunc bullet_f18cac7afc1723133c8bbff7745a8fd8[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_fae6c7bc112a867078dc33dd3f893fc4,
NULL}; 
static const BulletStepFunc bullet_b7d7888d71a4bff40c97cebc76a238ab[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_b843f84b80a0414fc3d16c3ba9fb5954,
NULL}; 
static const BulletStepFunc bullet_e0d365dc25466211f789ea75b5da7656[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_a989866c58f33ba270d0df8e7db03c9b,
NULL}; 
static const BulletStepFunc bullet_7f548cb49a29d47740896f6e162b5caa[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_f868cbd31b11efe75bbfa35f335c68a6,
NULL}; 
static const BulletStepFunc bullet_e28e6ef20ed52ce80a17750828c043dd[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_9275b5a1b86b49ac7e0aba7cd0d3de08,
NULL}; 
static const BulletStepFunc bullet_e4a0abdad02716d5400c075f5a01db50[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_f5a66b23ded0f25ffe786931ff9ec5de,
NULL}; 
static const BulletStepFunc bullet_5083d8627c9ca54c1afa182fa1f127f7[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_2aaf66bb23f330299140d82cbb25005c,
NULL}; 
static const BulletStepFunc bullet_fd1bd4993f84294e4cc8030746483371[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_e969897bb657b1a4a1972ef131146180,
NULL}; 
static const BulletStepFunc bullet_c8639521e6dcdcbbdbb0fc047730a6b7[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_bcdaf2d5a65cb75138bbe8626cca6270,
NULL}; 
static const BulletStepFunc bullet_f5e14e260e4c2df61575eab719a63086[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_4f3fff48e3956f6e76af16a84dc0c27a,
NULL}; 
static const BulletStepFunc bullet_d33c6d332e5002df8688fa4ac99aba8e[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_4e8158703fbbc43894ce583e3ee76011,
NULL}; 
static const BulletStepFunc bullet_896ee5cbf2523e0acd5e0a5cf9325413[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_0c6f7946d5e40c058b1252c019ea77ae,
NULL}; 
static const BulletStepFunc bullet_69c7fc2cb233eeebcc69d74db0df232e[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_a521c35168d487bfe0c8da0ee089a0f5,
NULL}; 
static const BulletStepFunc bullet_c22580966bc66836a7778c4d75b399fb[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_d04766bd97eed1af0d2d329a8f4e2d83,
NULL}; 
static const BulletStepFunc bullet_0e8799c743eca36ea81e4bf1de8880a2[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_d0228e89703652967591faa34e244b81,
NULL}; 
static const BulletStepFunc bullet_496a057f1be452288fd2fbea673c9c72[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_14879c92d0380c7a958f21c5faeba1f8,
NULL}; 
static const BulletStepFunc bullet_35c4efd3ace91f5e9af45167dd372f49[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_aff4530e510a3fce952402d92059ce3f,
NULL}; 
static const BulletStepFunc bullet_b5c0fbc40d7a4c7d10135f13b296e9d6[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_8af311b269614dd7c150da53869dc275,
NULL}; 
static const BulletStepFunc bullet_f4bb4dae4e324a987c7b3bd26b40f61c[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_3fbc69c17bf881898b3b3107aab94098,
NULL}; 
static const BulletStepFunc bullet_71396d4097aee35fd62b2067d13fcbf9[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_afab56063701f74857cc5dd70072a052,
NULL}; 
static const BulletStepFunc bullet_7b22f87bc45f7957969536d13cbb8775[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_db63a7012f2e611c5c5edeaf5f1f95f7,
NULL}; 
static const BulletStepFunc bullet_ca8fe1d201e451980bd38ee84f40eb61[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_215624a57ae6982e445b30157a6f468c,
NULL}; 
static const BulletStepFunc bullet_7d62aead69efff4e83b5d774d8ba822b[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_9f6b77f4d85a9258d295e1be6fc61d61,
NULL}; 
static const BulletStepFunc bullet_fcc58744a1f8c8add953cd3f741d6404[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_5f98d2b45974198380010b3f06d699ca,
NULL}; 
static const BulletStepFunc bullet_9134b85e4e1cb56c206c0d4d96d1a6c5[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_12b80cf5453cd90cbba3dd3bcc92d259,
NULL}; 
static const BulletStepFunc bullet_5994893c8c622d0ddef3e9e850bab2fd[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_393246da2db9e04107986facb78b9b32,
NULL}; 
static const BulletStepFunc bullet_790c704bdd4e44cf3d4efa3e901a1cc1[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_33ef2d357f66a2b942411de89328dbaa,
NULL}; 
static const BulletStepFunc bullet_c874166532718f38dc392e31ef841bdd[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_5aba040520537860a412e77836ce893e,
NULL}; 
static const BulletStepFunc bullet_0bad718483cd091229473aeeceab2733[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_e68124f911bbbca9b9a06b21ab649260,
NULL}; 
static const BulletStepFunc bullet_18d46f9801875086046e65743baf7071[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_448f5d56b575fc670f18f390d8c3e0d3,
NULL}; 
static const BulletStepFunc bullet_acaa2affd75b85aa952edbe5dae4e452[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_f8d04b4573d2c0bcd2e1d885ef7524bb,
NULL}; 
static const BulletStepFunc bullet_d2f0b514bf0b28f508dfcb85ad4fbb75[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_84c84e785ce1b575dfbd72bbb2d4c16b,
NULL}; 
static const BulletStepFunc bullet_434bc37d668d21e269060217872dbe37[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_bca741a7467eae1037e8f46fe273809e,
NULL}; 
static const BulletStepFunc bullet_73e8eae1a47b271997b6b9c42955adbf[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_8645af25feeb6946aa5a1db0faea6a4d,
NULL}; 
static const BulletStepFunc bullet_ab1c6f9ea750d2e03821054dd859d8f2[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_6180b1c6912eba9f741b97e9d24afab0,
NULL}; 
static const BulletStepFunc bullet_e6cc313276c924fa6804b91ba949cf15[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_14e652cb8212673144b3c3d2c7011ead,
NULL}; 
static const BulletStepFunc bullet_67a2b2dc566fdb6e28c23a1f425b3ee9[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_c23c664d2ac375a0707f374b22893618,
NULL}; 
static const BulletStepFunc bullet_d8fc3e509ac99cde4ef25035cd3ef327[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_008fdf2f750c850c4aa78a856d932cb6,
NULL}; 
static const BulletStepFunc bullet_e85559fdfde3f50581ff461cc453c2f1[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_4285d2d82a65d433685be02e220a87af,
NULL}; 
static const BulletStepFunc bullet_2171fa86568ab5352456bb80b2438b74[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_d619bbbdbcb14e6d271fd0d509844153,
NULL}; 
static const BulletStepFunc bullet_ccf4915dfb69679559708c032c20c9e8[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_6166e424e8da832870a082411ab03a0a,
NULL}; 
static const BulletStepFunc bullet_3b169696c7c7c2ae4563d30d9dbd7976[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_17c4a7a98351c288574e026812245bb9,
NULL}; 
static const BulletStepFunc bullet_f61f42e44f3c84cdaa2a052b16f1b105[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_d520eec51ad1042fbf0cc2d58412e682,
NULL}; 
static const BulletStepFunc bullet_28c17a4310d3b487bf27a2640eae146b[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_4cd0c1050a3293029416ce0a961b0902,
NULL}; 
static const BulletStepFunc bullet_692adc3e7ca9c5dbd37aabf3d7ddfd37[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_972d7e481cb6403eea2d0a5f424ef8b0,
NULL}; 
static const BulletStepFunc bullet_d5a6166ac64d5eb74561ecd56a67f0ef[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_073710ad94e5f992dd844832143f48c3,
NULL}; 
static const BulletStepFunc bullet_b8ad4ed10256222e8119261b30f5695e[] = {
stepfunc_e21b79873fe7a00b6f7d517e1df1a611,
stepfunc_89a3723e31a10471756fde6241bf49c8,
NULL}; 
static const BulletStepFunc bullet_51714fd97c877ca72b50e7eec7080944[] = {
stepfunc_8cd782da7a9415a800aac62a4fca1a6c,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_cc548300db279a4d09dc4fb634971fe8,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_8dee0231088d78a3fb65f90e08bd065d,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_79ff498cfbff39b1c28e076c8c043683,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_618788dd4486c022033182238d4bfb71,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_c894a1c80ea3afa258b73d38dc01897b,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_f82f2db623f6e589c70a130388e91ce4,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_27f9158a25d40a435a345a9496135f23,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_de007f369b73bc94fa4133858a5d4bc8,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_ffc02ee559cbb1c9432d3475398c219f,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_e8f6001cd9a308b8598888b21c7a2cb5,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_05648ba8614520bcfe8b652c74c2a990,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_5830b616100ea0b4e0d564f8ae8718be,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_2f0f89791fefcc70e5525a441ee734e9,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_ca145210014513dc1d2b35c98f7f71c4,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_e45fdb38ec3753dd229c0589db5ba0cd,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_7d42ae88829a4f48318a9a95d51e311c,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_c284ac9c71bdf8ca675bb55f07c09846,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_6609b686e81e3c59a11de5538b7aa2a4,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_88e1b4a7217945b3f92ad1ff510f3653,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_319e606fe5d045bbd2f5176d49ab32fb,
stepfunc_fdd5788c6a399d9cb36af80327bc669d,
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_77e73728a95622ab704cbd60911e3f30,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_16155e36d389a093f140fef61a6c2bec,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f5fc13a2664df660aaad46fd70ab4ab5,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_f054541877a2006b8d2edc5e9afe66d8,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_23933e8362d4e8674f5b124788f82a8c,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_ba2c82e86daa693475584c354b717e96,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_fc9203b63fa6220c67186a3553b16c1a,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_be701408fefcdc7d946cb025cbde3fca,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_00002b9b002c88aa92c95be36f5f2170,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_2200cfdd0e9287b4e1130022873ee613,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_0b62c0a239af9d95f8255a48dda545d2,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_e7514eb040f84f9bba3fd53f5a7c383c,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_aab71df843284029ac901e43f6ec0479,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_63221470cce7c7f48183340e90cea943,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_71f0a3c108e5a819adbf0a9867ad9340,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_ab05b8e537f4a9d9619d173f4b125e5d,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_2f319d6bebbd9542f014b0d4db3a31ca,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_b5ebcaed895c6d9e9815a182985c8e45,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_a4e5c6aca9165b46e914e685d8056c82,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_35447e2974d87e423df1f9cb2029456d,
stepfunc_fdd5788c6a399d9cb36af80327bc669d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_e21b79873fe7a00b6f7d517e1df1a611(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(1, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 50; 
}
static void stepfunc_89a3723e31a10471756fde6241bf49c8(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11758, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_35447e2974d87e423df1f9cb2029456d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b8ad4ed10256222e8119261b30f5695e;  }
}
}
static void stepfunc_073710ad94e5f992dd844832143f48c3(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11687, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_a4e5c6aca9165b46e914e685d8056c82(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(387, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d5a6166ac64d5eb74561ecd56a67f0ef;  }
}
}
static void stepfunc_972d7e481cb6403eea2d0a5f424ef8b0(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11616, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_b5ebcaed895c6d9e9815a182985c8e45(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(362, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_692adc3e7ca9c5dbd37aabf3d7ddfd37;  }
}
}
static void stepfunc_4cd0c1050a3293029416ce0a961b0902(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11538, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_2f319d6bebbd9542f014b0d4db3a31ca(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(337, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_28c17a4310d3b487bf27a2640eae146b;  }
}
}
static void stepfunc_d520eec51ad1042fbf0cc2d58412e682(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11411, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_ab05b8e537f4a9d9619d173f4b125e5d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(312, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f61f42e44f3c84cdaa2a052b16f1b105;  }
}
}
static void stepfunc_17c4a7a98351c288574e026812245bb9(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11326, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_71f0a3c108e5a819adbf0a9867ad9340(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(287, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3b169696c7c7c2ae4563d30d9dbd7976;  }
}
}
static void stepfunc_6166e424e8da832870a082411ab03a0a(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11184, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_63221470cce7c7f48183340e90cea943(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(262, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ccf4915dfb69679559708c032c20c9e8;  }
}
}
static void stepfunc_d619bbbdbcb14e6d271fd0d509844153(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10979, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_82d1ac9e507d40b6dd1d38e72f38a9de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(237, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2171fa86568ab5352456bb80b2438b74;  }
}
}
static void stepfunc_4285d2d82a65d433685be02e220a87af(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10695, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_aab71df843284029ac901e43f6ec0479(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e85559fdfde3f50581ff461cc453c2f1;  }
}
}
static void stepfunc_008fdf2f750c850c4aa78a856d932cb6(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10483, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_e7514eb040f84f9bba3fd53f5a7c383c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(187, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d8fc3e509ac99cde4ef25035cd3ef327;  }
}
}
static void stepfunc_c23c664d2ac375a0707f374b22893618(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10058, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_8e9c51c2ff03b755cf5f69ab96b52dca(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(162, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_67a2b2dc566fdb6e28c23a1f425b3ee9;  }
}
}
static void stepfunc_14e652cb8212673144b3c3d2c7011ead(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-9491, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_0b62c0a239af9d95f8255a48dda545d2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(137, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e6cc313276c924fa6804b91ba949cf15;  }
}
}
static void stepfunc_6180b1c6912eba9f741b97e9d24afab0(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-8358, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_2200cfdd0e9287b4e1130022873ee613(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(112, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ab1c6f9ea750d2e03821054dd859d8f2;  }
}
}
static void stepfunc_8645af25feeb6946aa5a1db0faea6a4d(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11652, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_00002b9b002c88aa92c95be36f5f2170(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(375, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_73e8eae1a47b271997b6b9c42955adbf;  }
}
}
static void stepfunc_bca741a7467eae1037e8f46fe273809e(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11475, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_5b2a5d1173ac27b4dce0bdc3ef32f089(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(325, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_434bc37d668d21e269060217872dbe37;  }
}
}
static void stepfunc_84c84e785ce1b575dfbd72bbb2d4c16b(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11262, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_be701408fefcdc7d946cb025cbde3fca(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(275, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d2f0b514bf0b28f508dfcb85ad4fbb75;  }
}
}
static void stepfunc_f8d04b4573d2c0bcd2e1d885ef7524bb(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10872, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_fc9203b63fa6220c67186a3553b16c1a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_acaa2affd75b85aa952edbe5dae4e452;  }
}
}
static void stepfunc_448f5d56b575fc670f18f390d8c3e0d3(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10270, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_ba2c82e86daa693475584c354b717e96(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(175, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_18d46f9801875086046e65743baf7071;  }
}
}
static void stepfunc_e68124f911bbbca9b9a06b21ab649260(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-8995, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_a39381c6b33943bac3bfb7cbe7a1c9a2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(125, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0bad718483cd091229473aeeceab2733;  }
}
}
static void stepfunc_5aba040520537860a412e77836ce893e(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-6375, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_23933e8362d4e8674f5b124788f82a8c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c874166532718f38dc392e31ef841bdd;  }
}
}
static void stepfunc_33ef2d357f66a2b942411de89328dbaa(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-9775, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_b5a680ea7da3a36b9bc0b5d9e43937d6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_790c704bdd4e44cf3d4efa3e901a1cc1;  }
}
}
static void stepfunc_393246da2db9e04107986facb78b9b32(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10625, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_f054541877a2006b8d2edc5e9afe66d8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5994893c8c622d0ddef3e9e850bab2fd;  }
}
}
static void stepfunc_12b80cf5453cd90cbba3dd3bcc92d259(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11050, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_f5fc13a2664df660aaad46fd70ab4ab5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9134b85e4e1cb56c206c0d4d96d1a6c5;  }
}
}
static void stepfunc_5f98d2b45974198380010b3f06d699ca(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11404, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_16155e36d389a093f140fef61a6c2bec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fcc58744a1f8c8add953cd3f741d6404;  }
}
}
static void stepfunc_9f6b77f4d85a9258d295e1be6fc61d61(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-11545, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_77e73728a95622ab704cbd60911e3f30(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7d62aead69efff4e83b5d774d8ba822b;  }
}
}
static void stepfunc_215624a57ae6982e445b30157a6f468c(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11758, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_319e606fe5d045bbd2f5176d49ab32fb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ca8fe1d201e451980bd38ee84f40eb61;  }
}
}
static void stepfunc_db63a7012f2e611c5c5edeaf5f1f95f7(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11687, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_88e1b4a7217945b3f92ad1ff510f3653(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(387, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7b22f87bc45f7957969536d13cbb8775;  }
}
}
static void stepfunc_afab56063701f74857cc5dd70072a052(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11616, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_6609b686e81e3c59a11de5538b7aa2a4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(362, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_71396d4097aee35fd62b2067d13fcbf9;  }
}
}
static void stepfunc_3fbc69c17bf881898b3b3107aab94098(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11538, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_c284ac9c71bdf8ca675bb55f07c09846(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(337, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f4bb4dae4e324a987c7b3bd26b40f61c;  }
}
}
static void stepfunc_8af311b269614dd7c150da53869dc275(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11411, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_7d42ae88829a4f48318a9a95d51e311c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(312, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5c0fbc40d7a4c7d10135f13b296e9d6;  }
}
}
static void stepfunc_aff4530e510a3fce952402d92059ce3f(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11326, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_e45fdb38ec3753dd229c0589db5ba0cd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(287, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_35c4efd3ace91f5e9af45167dd372f49;  }
}
}
static void stepfunc_14879c92d0380c7a958f21c5faeba1f8(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11184, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_eca301f5c8bee1e92e3e5a9b9d1c04df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(262, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_496a057f1be452288fd2fbea673c9c72;  }
}
}
static void stepfunc_d0228e89703652967591faa34e244b81(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10979, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_ca145210014513dc1d2b35c98f7f71c4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(237, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e8799c743eca36ea81e4bf1de8880a2;  }
}
}
static void stepfunc_d04766bd97eed1af0d2d329a8f4e2d83(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10695, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_2f0f89791fefcc70e5525a441ee734e9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c22580966bc66836a7778c4d75b399fb;  }
}
}
static void stepfunc_a521c35168d487bfe0c8da0ee089a0f5(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10483, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_7d2db44a5f0f0d2f74ce7d450fb2d364(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(187, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_69c7fc2cb233eeebcc69d74db0df232e;  }
}
}
static void stepfunc_0c6f7946d5e40c058b1252c019ea77ae(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10058, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_5830b616100ea0b4e0d564f8ae8718be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(162, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_896ee5cbf2523e0acd5e0a5cf9325413;  }
}
}
static void stepfunc_4e8158703fbbc43894ce583e3ee76011(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(9491, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_05648ba8614520bcfe8b652c74c2a990(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(137, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d33c6d332e5002df8688fa4ac99aba8e;  }
}
}
static void stepfunc_4f3fff48e3956f6e76af16a84dc0c27a(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(8358, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_e8f6001cd9a308b8598888b21c7a2cb5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(112, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f5e14e260e4c2df61575eab719a63086;  }
}
}
static void stepfunc_bcdaf2d5a65cb75138bbe8626cca6270(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11652, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_588e13341fc6e0e9e6c19ee2e3f359c4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(375, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c8639521e6dcdcbbdbb0fc047730a6b7;  }
}
}
static void stepfunc_e969897bb657b1a4a1972ef131146180(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11475, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_ffc02ee559cbb1c9432d3475398c219f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(325, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fd1bd4993f84294e4cc8030746483371;  }
}
}
static void stepfunc_2aaf66bb23f330299140d82cbb25005c(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11262, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_de007f369b73bc94fa4133858a5d4bc8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(275, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5083d8627c9ca54c1afa182fa1f127f7;  }
}
}
static void stepfunc_f5a66b23ded0f25ffe786931ff9ec5de(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10872, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_27f9158a25d40a435a345a9496135f23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e4a0abdad02716d5400c075f5a01db50;  }
}
}
static void stepfunc_9275b5a1b86b49ac7e0aba7cd0d3de08(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10270, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_f82f2db623f6e589c70a130388e91ce4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(175, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e28e6ef20ed52ce80a17750828c043dd;  }
}
}
static void stepfunc_f868cbd31b11efe75bbfa35f335c68a6(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(8995, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_c894a1c80ea3afa258b73d38dc01897b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(125, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7f548cb49a29d47740896f6e162b5caa;  }
}
}
static void stepfunc_a989866c58f33ba270d0df8e7db03c9b(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(6375, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_28045ea15873cc3b7c5dd0aa63ad0f97(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e0d365dc25466211f789ea75b5da7656;  }
}
}
static void stepfunc_b843f84b80a0414fc3d16c3ba9fb5954(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(9775, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_618788dd4486c022033182238d4bfb71(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b7d7888d71a4bff40c97cebc76a238ab;  }
}
}
static void stepfunc_fae6c7bc112a867078dc33dd3f893fc4(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10625, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_79ff498cfbff39b1c28e076c8c043683(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f18cac7afc1723133c8bbff7745a8fd8;  }
}
}
static void stepfunc_4bb7972a3d9cb26cdef633ccdc2e3705(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11050, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_8dee0231088d78a3fb65f90e08bd065d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3a8b2c22b3624917462e720c412d197f;  }
}
}
static void stepfunc_e5590bd7ea6cf8fa83b21e1419a854c3(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11404, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_cc548300db279a4d09dc4fb634971fe8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d84e3cca4a6740f8e025011d630373c9;  }
}
}
static void stepfunc_da8e710bb0fe0683fe26f273c194c803(BulletInfo *p) { 
{
  u16 life = 80;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(11545, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_ecb9371b2ead4f2efb5b2b54d43b52f6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd6a676026420d00600d0809c54ea3e7;  }
}
}
static void stepfunc_fdd5788c6a399d9cb36af80327bc669d(BulletInfo *p) { 
p->wait = 300; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_8cd782da7a9415a800aac62a4fca1a6c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4e64f3d35e335c498e6e079fb6565461;  }
}
}


void genBulletFunc_6c91af4c9dee2a3d569c4993b91e9d96(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_51714fd97c877ca72b50e7eec7080944; }}


