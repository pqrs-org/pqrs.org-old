// XXX uniqID XXX 3caa604825bdbe6232d3b649682cbb4b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_1d2c56ced80a2bbd82e717c585123998(BulletInfo *p); 
static void stepfunc_75c355dee851c491cee2a221ab2178ed(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_bd1acfd57641250d5902b60afec1b2d1(BulletInfo *p); 
static void stepfunc_bfce8be6f947dd75a66c3c73b50c41be(BulletInfo *p); 
static void stepfunc_f6a7fbfcb2de90e78f485a340130a0e3(BulletInfo *p); 
static void stepfunc_1e60668d33d4f5d852908e63c1660105(BulletInfo *p); 
static void stepfunc_ae63a49be7462e6be61032ce07d47f0a(BulletInfo *p); 
static void stepfunc_a2a772ad4d43bf6bf17d69d9537f0004(BulletInfo *p); 
static void stepfunc_1b2cb270cd79cf3f1b7a41af0edbac4d(BulletInfo *p); 
static void stepfunc_91ce4046ab85d5f79c5a00450ca9340e(BulletInfo *p); 
static void stepfunc_299dc98add48e87764ed09846b932565(BulletInfo *p); 
static void stepfunc_eb58471cc4e146c0605a272031e5f249(BulletInfo *p); 
static void stepfunc_b8996d58eb0fd3069957a86a5f81efc2(BulletInfo *p); 
static void stepfunc_b2e6a5b468695b5b5c04d91c2fa16daa(BulletInfo *p); 
static void stepfunc_db2e2fada96a1397e5009ee33f6abb78(BulletInfo *p); 
static void stepfunc_f3f008883d7abe2389a856a83a47cf56(BulletInfo *p); 
static void stepfunc_14ad36e129488fd4f1e6799d784d5497(BulletInfo *p); 
static void stepfunc_dbf5406bd76c8ebd9f2aff357389b67c(BulletInfo *p); 
static void stepfunc_3cdf87018c604386ca32450fc42dde6e(BulletInfo *p); 
static void stepfunc_bf3e09916b06a5e87a85453c728838ba(BulletInfo *p); 
static void stepfunc_323a449a82c170193b6da9488c844139(BulletInfo *p); 
static void stepfunc_5ca4db18abc9253f2ae2cb334dfbe1af(BulletInfo *p); 
static void stepfunc_fb4b7ccdf825137dcc88e993f361e2ed(BulletInfo *p); 
static void stepfunc_f3d4d53dd576b72876c5d2600c9229d1(BulletInfo *p); 
static void stepfunc_07840e59f3c5aa63cb2fde6e3e29648c(BulletInfo *p); 
static void stepfunc_68c7a50dd2cb7798de7e717230b93804(BulletInfo *p); 
static void stepfunc_11062a8758655f51f8aa791b838117de(BulletInfo *p); 
static void stepfunc_c3d099ca4c85a4357cd3d70cf03ced85(BulletInfo *p); 
static void stepfunc_2b0a43f4f7c53df9e44f68c9596fe757(BulletInfo *p); 
static void stepfunc_7f1c0ba6fd0480004534f7ec8bcb72db(BulletInfo *p); 
static void stepfunc_30eb5b90fec1634e5c736eded3426405(BulletInfo *p); 
static void stepfunc_89e9a8ed4c0757339f7691768f37c1c9(BulletInfo *p); 
static void stepfunc_a10b5a2714854b005f6667ca45fd47f1(BulletInfo *p); 
static void stepfunc_29afa0aaf28fe7d0cd3d08f7feb5b1f8(BulletInfo *p); 
static void stepfunc_d460d8644f3b2a77c043b52af4169760(BulletInfo *p); 
static void stepfunc_3f8edb6fb802919d795e3cb83f1898a5(BulletInfo *p); 
static void stepfunc_03af63b3888268e22b6d5c25667be5fa(BulletInfo *p); 
static void stepfunc_c040e6721b40cb41a51a9ce75a95e3da(BulletInfo *p); 
static void stepfunc_8fd34a4f72286ebd587c44494ca2946d(BulletInfo *p); 
static void stepfunc_b76405ee06e016670cf0aaa658f082b2(BulletInfo *p); 
static void stepfunc_0f863f24681035da82638a50ee0a832e(BulletInfo *p); 
static void stepfunc_5fbdf7b9ecbb64dcff66a02afe185e1e(BulletInfo *p); 
static void stepfunc_2ff2174e0f1a9ab33def6d8fa7c4b62f(BulletInfo *p); 
static void stepfunc_cabe2d18dc1bb986ab5ca0008c93c0d6(BulletInfo *p); 
static void stepfunc_c3ba8ab18b8f1ff74b6ce997aff46136(BulletInfo *p); 
static void stepfunc_498364d667f1cf7ce3ef3237618b15c7(BulletInfo *p); 
static void stepfunc_778823b3be118f44a06dbff588b77d17(BulletInfo *p); 
static void stepfunc_33506dba189bb9737dce2b30fb86a990(BulletInfo *p); 
static void stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba(BulletInfo *p); 
static void stepfunc_0bc38fc39f80d3a8a47372889274a7f3(BulletInfo *p); 
static void stepfunc_e7de1423c7f4291eaaca324d7edb7c82(BulletInfo *p); 
static void stepfunc_14e00c1b908af28277a0a2281b2e4b59(BulletInfo *p); 
static void stepfunc_8632b0aa71fb87e14a086801ba38c0e4(BulletInfo *p); 
static void stepfunc_664aa74cfb6bf306b0bd5f2d418d3f9a(BulletInfo *p); 
static void stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5(BulletInfo *p); 
static void stepfunc_3735135cc031d3fc1cad3936e5a02f6c(BulletInfo *p); 
static void stepfunc_b18f7b586d2995a0d0847f5a32be4d0b(BulletInfo *p); 
static void stepfunc_735e5c75860967bfc890a4a9d2b7d584(BulletInfo *p); 
static void stepfunc_82abe7438182703e36d06c4c9ad98ed2(BulletInfo *p); 
static void stepfunc_f81e44ab696d66806a10d8d6f75225bf(BulletInfo *p); 
static void stepfunc_43a67d3b960a428a22460ccd6d8d0d85(BulletInfo *p); 
static void stepfunc_c124eec9c9e0b9f7f319f60b94deda9f(BulletInfo *p); 
static void stepfunc_5a5f9a5d09716079f935a7cd46060d11(BulletInfo *p); 
static void stepfunc_f0638846263c14a44a6cdd7c4c51237b(BulletInfo *p); 
static void stepfunc_77aa54d8089ab5aff3f23bfab07b3b44(BulletInfo *p); 
static void stepfunc_ec3698f23e38bf3a9a79f4c85f5ff1f3(BulletInfo *p); 
static void stepfunc_9db6193d85fa6bd90a1cf1356854ca76(BulletInfo *p); 
static void stepfunc_f53df03ac0247d0ed44c24d2554186c4(BulletInfo *p); 


static const BulletStepFunc bullet_cdb8c0e1f8bbf5a60f87882fbca5bd3c[] = {
stepfunc_1d2c56ced80a2bbd82e717c585123998,
stepfunc_75c355dee851c491cee2a221ab2178ed,
stepfunc_75c355dee851c491cee2a221ab2178ed,
stepfunc_75c355dee851c491cee2a221ab2178ed,
stepfunc_75c355dee851c491cee2a221ab2178ed,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_7c9351b868719e129fa96acb530d0a04[] = {
stepfunc_bd1acfd57641250d5902b60afec1b2d1,
stepfunc_bfce8be6f947dd75a66c3c73b50c41be,
stepfunc_bfce8be6f947dd75a66c3c73b50c41be,
stepfunc_bfce8be6f947dd75a66c3c73b50c41be,
stepfunc_bfce8be6f947dd75a66c3c73b50c41be,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_84ef39ce154eaeb640c59c053ab1990e[] = {
stepfunc_f6a7fbfcb2de90e78f485a340130a0e3,
stepfunc_1e60668d33d4f5d852908e63c1660105,
stepfunc_1e60668d33d4f5d852908e63c1660105,
stepfunc_1e60668d33d4f5d852908e63c1660105,
stepfunc_1e60668d33d4f5d852908e63c1660105,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_f8bf8d079f50e1181ad40aa492e19201[] = {
stepfunc_ae63a49be7462e6be61032ce07d47f0a,
stepfunc_a2a772ad4d43bf6bf17d69d9537f0004,
stepfunc_a2a772ad4d43bf6bf17d69d9537f0004,
stepfunc_a2a772ad4d43bf6bf17d69d9537f0004,
stepfunc_a2a772ad4d43bf6bf17d69d9537f0004,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_cbc73e6cae578f165f2c754ff15ba5c3[] = {
stepfunc_1b2cb270cd79cf3f1b7a41af0edbac4d,
stepfunc_91ce4046ab85d5f79c5a00450ca9340e,
stepfunc_91ce4046ab85d5f79c5a00450ca9340e,
stepfunc_91ce4046ab85d5f79c5a00450ca9340e,
stepfunc_91ce4046ab85d5f79c5a00450ca9340e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_af2f2d4f8cab13e861e07b54b796db2c[] = {
stepfunc_299dc98add48e87764ed09846b932565,
stepfunc_eb58471cc4e146c0605a272031e5f249,
stepfunc_eb58471cc4e146c0605a272031e5f249,
stepfunc_eb58471cc4e146c0605a272031e5f249,
stepfunc_eb58471cc4e146c0605a272031e5f249,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_1850cb077056a903e1fd78ffa1642d37[] = {
stepfunc_b8996d58eb0fd3069957a86a5f81efc2,
stepfunc_b2e6a5b468695b5b5c04d91c2fa16daa,
stepfunc_b2e6a5b468695b5b5c04d91c2fa16daa,
stepfunc_b2e6a5b468695b5b5c04d91c2fa16daa,
stepfunc_b2e6a5b468695b5b5c04d91c2fa16daa,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_64e03e1ed5896dc8684012bf3479dd04[] = {
stepfunc_db2e2fada96a1397e5009ee33f6abb78,
stepfunc_f3f008883d7abe2389a856a83a47cf56,
stepfunc_f3f008883d7abe2389a856a83a47cf56,
stepfunc_f3f008883d7abe2389a856a83a47cf56,
stepfunc_f3f008883d7abe2389a856a83a47cf56,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_61f9f7b5438464abdb5de0ea546ee1b7[] = {
stepfunc_14ad36e129488fd4f1e6799d784d5497,
stepfunc_dbf5406bd76c8ebd9f2aff357389b67c,
stepfunc_dbf5406bd76c8ebd9f2aff357389b67c,
stepfunc_dbf5406bd76c8ebd9f2aff357389b67c,
stepfunc_dbf5406bd76c8ebd9f2aff357389b67c,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_3a5e6670d36b257b9f99b90725039219[] = {
stepfunc_3cdf87018c604386ca32450fc42dde6e,
stepfunc_bf3e09916b06a5e87a85453c728838ba,
stepfunc_bf3e09916b06a5e87a85453c728838ba,
stepfunc_bf3e09916b06a5e87a85453c728838ba,
stepfunc_bf3e09916b06a5e87a85453c728838ba,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_ced1b775b2e66e63b334dedf1112827e[] = {
stepfunc_323a449a82c170193b6da9488c844139,
stepfunc_5ca4db18abc9253f2ae2cb334dfbe1af,
stepfunc_5ca4db18abc9253f2ae2cb334dfbe1af,
stepfunc_5ca4db18abc9253f2ae2cb334dfbe1af,
stepfunc_5ca4db18abc9253f2ae2cb334dfbe1af,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_d8c1c7f8a2495a1fe39c92e6acdc80e4[] = {
stepfunc_fb4b7ccdf825137dcc88e993f361e2ed,
stepfunc_f3d4d53dd576b72876c5d2600c9229d1,
stepfunc_f3d4d53dd576b72876c5d2600c9229d1,
stepfunc_f3d4d53dd576b72876c5d2600c9229d1,
stepfunc_f3d4d53dd576b72876c5d2600c9229d1,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_50489f47f89103ec384ef225840c1c6f[] = {
stepfunc_07840e59f3c5aa63cb2fde6e3e29648c,
stepfunc_68c7a50dd2cb7798de7e717230b93804,
stepfunc_68c7a50dd2cb7798de7e717230b93804,
stepfunc_68c7a50dd2cb7798de7e717230b93804,
stepfunc_68c7a50dd2cb7798de7e717230b93804,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_fe55636a3283b9baf64fe1da6224f5d1[] = {
stepfunc_11062a8758655f51f8aa791b838117de,
stepfunc_c3d099ca4c85a4357cd3d70cf03ced85,
stepfunc_c3d099ca4c85a4357cd3d70cf03ced85,
stepfunc_c3d099ca4c85a4357cd3d70cf03ced85,
stepfunc_c3d099ca4c85a4357cd3d70cf03ced85,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_e0fe3fd541fdb5b94e529761012b6c88[] = {
stepfunc_2b0a43f4f7c53df9e44f68c9596fe757,
stepfunc_7f1c0ba6fd0480004534f7ec8bcb72db,
stepfunc_7f1c0ba6fd0480004534f7ec8bcb72db,
stepfunc_7f1c0ba6fd0480004534f7ec8bcb72db,
stepfunc_7f1c0ba6fd0480004534f7ec8bcb72db,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_a69ae562df951ad515d389d226d6f4df[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_89e9a8ed4c0757339f7691768f37c1c9,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_0b7a80f0ce03395225bf319d000cc6c5[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_29afa0aaf28fe7d0cd3d08f7feb5b1f8,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_f234a7ece8ce88a124304cfa783a719e[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_d460d8644f3b2a77c043b52af4169760,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_0e256f3d2a67c43db45ea17ecf336099[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_3f8edb6fb802919d795e3cb83f1898a5,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_774f303b1be272a85c3bf3193855dc57[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_03af63b3888268e22b6d5c25667be5fa,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_b1ee11701560fae7d51381ebee34adf9[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_c040e6721b40cb41a51a9ce75a95e3da,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_0d6bc27e652c30c5c4d193a5c644531f[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_8fd34a4f72286ebd587c44494ca2946d,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_40e069eac1b1dedf9f2c41039d958a9f[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_b76405ee06e016670cf0aaa658f082b2,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_c981c900f7f7ef4911e5bedec5d43a0b[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_0f863f24681035da82638a50ee0a832e,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_c11d1af693a039b7531cf77ca48c10f5[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_5fbdf7b9ecbb64dcff66a02afe185e1e,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_178445f5a15134c050567d4aed09cc7e[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_2ff2174e0f1a9ab33def6d8fa7c4b62f,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_fb7764ae9ad93faa1f8ecd36985b08d1[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_cabe2d18dc1bb986ab5ca0008c93c0d6,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_7e532195f81fda5b7daedfa86da8d4fc[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_c3ba8ab18b8f1ff74b6ce997aff46136,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_931e7263f531115a6700621128c2f541[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_498364d667f1cf7ce3ef3237618b15c7,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_e0d6a9acfffe3708a8ef1acf6723a53c[] = {
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_778823b3be118f44a06dbff588b77d17,
stepfunc_a10b5a2714854b005f6667ca45fd47f1,
NULL}; 
static const BulletStepFunc bullet_e6b11ab56a789d65bc1a61493fba0579[] = {
stepfunc_33506dba189bb9737dce2b30fb86a990,
stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba,
stepfunc_0bc38fc39f80d3a8a47372889274a7f3,
stepfunc_e7de1423c7f4291eaaca324d7edb7c82,
stepfunc_14e00c1b908af28277a0a2281b2e4b59,
stepfunc_8632b0aa71fb87e14a086801ba38c0e4,
stepfunc_664aa74cfb6bf306b0bd5f2d418d3f9a,
stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba,
stepfunc_0bc38fc39f80d3a8a47372889274a7f3,
stepfunc_e7de1423c7f4291eaaca324d7edb7c82,
stepfunc_14e00c1b908af28277a0a2281b2e4b59,
stepfunc_8632b0aa71fb87e14a086801ba38c0e4,
stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5,
stepfunc_3735135cc031d3fc1cad3936e5a02f6c,
stepfunc_b18f7b586d2995a0d0847f5a32be4d0b,
stepfunc_735e5c75860967bfc890a4a9d2b7d584,
stepfunc_82abe7438182703e36d06c4c9ad98ed2,
stepfunc_f81e44ab696d66806a10d8d6f75225bf,
stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba,
stepfunc_0bc38fc39f80d3a8a47372889274a7f3,
stepfunc_e7de1423c7f4291eaaca324d7edb7c82,
stepfunc_14e00c1b908af28277a0a2281b2e4b59,
stepfunc_8632b0aa71fb87e14a086801ba38c0e4,
stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5,
stepfunc_3735135cc031d3fc1cad3936e5a02f6c,
stepfunc_b18f7b586d2995a0d0847f5a32be4d0b,
stepfunc_735e5c75860967bfc890a4a9d2b7d584,
stepfunc_82abe7438182703e36d06c4c9ad98ed2,
stepfunc_43a67d3b960a428a22460ccd6d8d0d85,
stepfunc_c124eec9c9e0b9f7f319f60b94deda9f,
stepfunc_5a5f9a5d09716079f935a7cd46060d11,
stepfunc_f0638846263c14a44a6cdd7c4c51237b,
stepfunc_77aa54d8089ab5aff3f23bfab07b3b44,
stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba,
stepfunc_0bc38fc39f80d3a8a47372889274a7f3,
stepfunc_e7de1423c7f4291eaaca324d7edb7c82,
stepfunc_14e00c1b908af28277a0a2281b2e4b59,
stepfunc_8632b0aa71fb87e14a086801ba38c0e4,
stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5,
stepfunc_3735135cc031d3fc1cad3936e5a02f6c,
stepfunc_b18f7b586d2995a0d0847f5a32be4d0b,
stepfunc_735e5c75860967bfc890a4a9d2b7d584,
stepfunc_82abe7438182703e36d06c4c9ad98ed2,
stepfunc_43a67d3b960a428a22460ccd6d8d0d85,
stepfunc_c124eec9c9e0b9f7f319f60b94deda9f,
stepfunc_5a5f9a5d09716079f935a7cd46060d11,
stepfunc_f0638846263c14a44a6cdd7c4c51237b,
stepfunc_77aa54d8089ab5aff3f23bfab07b3b44,
stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba,
stepfunc_0bc38fc39f80d3a8a47372889274a7f3,
stepfunc_e7de1423c7f4291eaaca324d7edb7c82,
stepfunc_14e00c1b908af28277a0a2281b2e4b59,
stepfunc_8632b0aa71fb87e14a086801ba38c0e4,
stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5,
stepfunc_3735135cc031d3fc1cad3936e5a02f6c,
stepfunc_b18f7b586d2995a0d0847f5a32be4d0b,
stepfunc_735e5c75860967bfc890a4a9d2b7d584,
stepfunc_82abe7438182703e36d06c4c9ad98ed2,
stepfunc_43a67d3b960a428a22460ccd6d8d0d85,
stepfunc_c124eec9c9e0b9f7f319f60b94deda9f,
stepfunc_5a5f9a5d09716079f935a7cd46060d11,
stepfunc_f0638846263c14a44a6cdd7c4c51237b,
stepfunc_77aa54d8089ab5aff3f23bfab07b3b44,
stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba,
stepfunc_0bc38fc39f80d3a8a47372889274a7f3,
stepfunc_e7de1423c7f4291eaaca324d7edb7c82,
stepfunc_14e00c1b908af28277a0a2281b2e4b59,
stepfunc_8632b0aa71fb87e14a086801ba38c0e4,
stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5,
stepfunc_3735135cc031d3fc1cad3936e5a02f6c,
stepfunc_b18f7b586d2995a0d0847f5a32be4d0b,
stepfunc_735e5c75860967bfc890a4a9d2b7d584,
stepfunc_82abe7438182703e36d06c4c9ad98ed2,
stepfunc_43a67d3b960a428a22460ccd6d8d0d85,
stepfunc_c124eec9c9e0b9f7f319f60b94deda9f,
stepfunc_5a5f9a5d09716079f935a7cd46060d11,
stepfunc_f0638846263c14a44a6cdd7c4c51237b,
stepfunc_77aa54d8089ab5aff3f23bfab07b3b44,
stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba,
stepfunc_0bc38fc39f80d3a8a47372889274a7f3,
stepfunc_e7de1423c7f4291eaaca324d7edb7c82,
stepfunc_14e00c1b908af28277a0a2281b2e4b59,
stepfunc_8632b0aa71fb87e14a086801ba38c0e4,
stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5,
stepfunc_3735135cc031d3fc1cad3936e5a02f6c,
stepfunc_b18f7b586d2995a0d0847f5a32be4d0b,
stepfunc_735e5c75860967bfc890a4a9d2b7d584,
stepfunc_82abe7438182703e36d06c4c9ad98ed2,
stepfunc_43a67d3b960a428a22460ccd6d8d0d85,
stepfunc_c124eec9c9e0b9f7f319f60b94deda9f,
stepfunc_5a5f9a5d09716079f935a7cd46060d11,
stepfunc_f0638846263c14a44a6cdd7c4c51237b,
stepfunc_77aa54d8089ab5aff3f23bfab07b3b44,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_ba6167f34978e06321b3366a5b6be81a[] = {
stepfunc_ec3698f23e38bf3a9a79f4c85f5ff1f3,
stepfunc_9db6193d85fa6bd90a1cf1356854ca76,
stepfunc_f53df03ac0247d0ed44c24d2554186c4,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_30eb5b90fec1634e5c736eded3426405(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_778823b3be118f44a06dbff588b77d17(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 44; 
}
static void stepfunc_a10b5a2714854b005f6667ca45fd47f1(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(3 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_1e60668d33d4f5d852908e63c1660105(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e0d6a9acfffe3708a8ef1acf6723a53c;  }
}
}
static void stepfunc_f6a7fbfcb2de90e78f485a340130a0e3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e0d6a9acfffe3708a8ef1acf6723a53c;  }
}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_498364d667f1cf7ce3ef3237618b15c7(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 43; 
}
static void stepfunc_a2a772ad4d43bf6bf17d69d9537f0004(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_931e7263f531115a6700621128c2f541;  }
}
}
static void stepfunc_ae63a49be7462e6be61032ce07d47f0a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_931e7263f531115a6700621128c2f541;  }
}
}
static void stepfunc_c3ba8ab18b8f1ff74b6ce997aff46136(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 42; 
}
static void stepfunc_91ce4046ab85d5f79c5a00450ca9340e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7e532195f81fda5b7daedfa86da8d4fc;  }
}
}
static void stepfunc_1b2cb270cd79cf3f1b7a41af0edbac4d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7e532195f81fda5b7daedfa86da8d4fc;  }
}
}
static void stepfunc_cabe2d18dc1bb986ab5ca0008c93c0d6(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 41; 
}
static void stepfunc_eb58471cc4e146c0605a272031e5f249(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fb7764ae9ad93faa1f8ecd36985b08d1;  }
}
}
static void stepfunc_299dc98add48e87764ed09846b932565(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fb7764ae9ad93faa1f8ecd36985b08d1;  }
}
}
static void stepfunc_2ff2174e0f1a9ab33def6d8fa7c4b62f(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 40; 
}
static void stepfunc_75c355dee851c491cee2a221ab2178ed(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_178445f5a15134c050567d4aed09cc7e;  }
}
}
static void stepfunc_1d2c56ced80a2bbd82e717c585123998(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_178445f5a15134c050567d4aed09cc7e;  }
}
}
static void stepfunc_5fbdf7b9ecbb64dcff66a02afe185e1e(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 39; 
}
static void stepfunc_b2e6a5b468695b5b5c04d91c2fa16daa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c11d1af693a039b7531cf77ca48c10f5;  }
}
}
static void stepfunc_b8996d58eb0fd3069957a86a5f81efc2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c11d1af693a039b7531cf77ca48c10f5;  }
}
}
static void stepfunc_0f863f24681035da82638a50ee0a832e(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 38; 
}
static void stepfunc_f3f008883d7abe2389a856a83a47cf56(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c981c900f7f7ef4911e5bedec5d43a0b;  }
}
}
static void stepfunc_db2e2fada96a1397e5009ee33f6abb78(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c981c900f7f7ef4911e5bedec5d43a0b;  }
}
}
static void stepfunc_b76405ee06e016670cf0aaa658f082b2(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 37; 
}
static void stepfunc_dbf5406bd76c8ebd9f2aff357389b67c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_40e069eac1b1dedf9f2c41039d958a9f;  }
}
}
static void stepfunc_14ad36e129488fd4f1e6799d784d5497(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_40e069eac1b1dedf9f2c41039d958a9f;  }
}
}
static void stepfunc_8fd34a4f72286ebd587c44494ca2946d(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 36; 
}
static void stepfunc_bf3e09916b06a5e87a85453c728838ba(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0d6bc27e652c30c5c4d193a5c644531f;  }
}
}
static void stepfunc_3cdf87018c604386ca32450fc42dde6e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0d6bc27e652c30c5c4d193a5c644531f;  }
}
}
static void stepfunc_c040e6721b40cb41a51a9ce75a95e3da(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 35; 
}
static void stepfunc_bfce8be6f947dd75a66c3c73b50c41be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b1ee11701560fae7d51381ebee34adf9;  }
}
}
static void stepfunc_bd1acfd57641250d5902b60afec1b2d1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b1ee11701560fae7d51381ebee34adf9;  }
}
}
static void stepfunc_03af63b3888268e22b6d5c25667be5fa(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 34; 
}
static void stepfunc_5ca4db18abc9253f2ae2cb334dfbe1af(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_774f303b1be272a85c3bf3193855dc57;  }
}
}
static void stepfunc_323a449a82c170193b6da9488c844139(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_774f303b1be272a85c3bf3193855dc57;  }
}
}
static void stepfunc_3f8edb6fb802919d795e3cb83f1898a5(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 33; 
}
static void stepfunc_f3d4d53dd576b72876c5d2600c9229d1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e256f3d2a67c43db45ea17ecf336099;  }
}
}
static void stepfunc_fb4b7ccdf825137dcc88e993f361e2ed(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e256f3d2a67c43db45ea17ecf336099;  }
}
}
static void stepfunc_d460d8644f3b2a77c043b52af4169760(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 32; 
}
static void stepfunc_68c7a50dd2cb7798de7e717230b93804(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f234a7ece8ce88a124304cfa783a719e;  }
}
}
static void stepfunc_07840e59f3c5aa63cb2fde6e3e29648c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f234a7ece8ce88a124304cfa783a719e;  }
}
}
static void stepfunc_29afa0aaf28fe7d0cd3d08f7feb5b1f8(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 31; 
}
static void stepfunc_c3d099ca4c85a4357cd3d70cf03ced85(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0b7a80f0ce03395225bf319d000cc6c5;  }
}
}
static void stepfunc_11062a8758655f51f8aa791b838117de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0b7a80f0ce03395225bf319d000cc6c5;  }
}
}
static void stepfunc_89e9a8ed4c0757339f7691768f37c1c9(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_7f1c0ba6fd0480004534f7ec8bcb72db(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1593, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a69ae562df951ad515d389d226d6f4df;  }
}
}
static void stepfunc_2b0a43f4f7c53df9e44f68c9596fe757(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3187, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a69ae562df951ad515d389d226d6f4df;  }
}
}
static void stepfunc_43dc93a1b00157cc13a48b2f7e7fd2ba(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e0fe3fd541fdb5b94e529761012b6c88;  }
}
p->wait = 2; 
}
static void stepfunc_0bc38fc39f80d3a8a47372889274a7f3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fe55636a3283b9baf64fe1da6224f5d1;  }
}
p->wait = 2; 
}
static void stepfunc_e7de1423c7f4291eaaca324d7edb7c82(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_50489f47f89103ec384ef225840c1c6f;  }
}
p->wait = 2; 
}
static void stepfunc_14e00c1b908af28277a0a2281b2e4b59(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d8c1c7f8a2495a1fe39c92e6acdc80e4;  }
}
p->wait = 2; 
}
static void stepfunc_8632b0aa71fb87e14a086801ba38c0e4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ced1b775b2e66e63b334dedf1112827e;  }
}
p->wait = 2; 
}
static void stepfunc_5af7dab9b479a3e94f7f63db7c74b1f5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7c9351b868719e129fa96acb530d0a04;  }
}
p->wait = 2; 
}
static void stepfunc_3735135cc031d3fc1cad3936e5a02f6c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3a5e6670d36b257b9f99b90725039219;  }
}
p->wait = 2; 
}
static void stepfunc_b18f7b586d2995a0d0847f5a32be4d0b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_61f9f7b5438464abdb5de0ea546ee1b7;  }
}
p->wait = 2; 
}
static void stepfunc_735e5c75860967bfc890a4a9d2b7d584(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_64e03e1ed5896dc8684012bf3479dd04;  }
}
p->wait = 2; 
}
static void stepfunc_82abe7438182703e36d06c4c9ad98ed2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1850cb077056a903e1fd78ffa1642d37;  }
}
p->wait = 2; 
}
static void stepfunc_43a67d3b960a428a22460ccd6d8d0d85(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cdb8c0e1f8bbf5a60f87882fbca5bd3c;  }
}
p->wait = 2; 
}
static void stepfunc_c124eec9c9e0b9f7f319f60b94deda9f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_af2f2d4f8cab13e861e07b54b796db2c;  }
}
p->wait = 2; 
}
static void stepfunc_5a5f9a5d09716079f935a7cd46060d11(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cbc73e6cae578f165f2c754ff15ba5c3;  }
}
p->wait = 2; 
}
static void stepfunc_f0638846263c14a44a6cdd7c4c51237b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f8bf8d079f50e1181ad40aa492e19201;  }
}
p->wait = 2; 
}
static void stepfunc_77aa54d8089ab5aff3f23bfab07b3b44(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_84ef39ce154eaeb640c59c053ab1990e;  }
}
p->wait = 20; 
}
static void stepfunc_33506dba189bb9737dce2b30fb86a990(BulletInfo *p) { 
p->wait = FixedPointNum(20)+FixedPointNum::random()*FixedPointNum(10); 
}
static void stepfunc_664aa74cfb6bf306b0bd5f2d418d3f9a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7c9351b868719e129fa96acb530d0a04;  }
}
p->wait = 30; 
}
static void stepfunc_f81e44ab696d66806a10d8d6f75225bf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cdb8c0e1f8bbf5a60f87882fbca5bd3c;  }
}
p->wait = 25; 
}
static void stepfunc_ec3698f23e38bf3a9a79f4c85f5ff1f3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(85)+FixedPointNum::random()*FixedPointNum(1416, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum(FixedPointNum(120, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_9db6193d85fa6bd90a1cf1356854ca76(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(354, 100);p->setRound(speed, life);}
p->wait = 120; 
}
static void stepfunc_f53df03ac0247d0ed44c24d2554186c4(BulletInfo *p) { 
{
  u16 life = 250;  FixedPointNum speed = FixedPointNum(-354, 100);p->setRound(speed, life);}
p->wait = 250; 
}


void genBulletFunc_3caa604825bdbe6232d3b649682cbb4b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_ba6167f34978e06321b3366a5b6be81a; }  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_e6b11ab56a789d65bc1a61493fba0579; }}


