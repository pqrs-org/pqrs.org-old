// XXX uniqID XXX 3dffec8f6a5e3f9f9c7ddd8a7aa025d0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 
static void stepfunc_9b5a426fc16fbeff6cb19aed9e879d14(BulletInfo *p); 
static void stepfunc_bbc91d6ae5ccdbfdab65447a1ceccb7a(BulletInfo *p); 
static void stepfunc_08a05b21d884c8300aab3f92f30a5e7c(BulletInfo *p); 
static void stepfunc_70bfd4b2f151d78397412ec51a0d4727(BulletInfo *p); 
static void stepfunc_18af53bc83dc0030a04a1f27ac437943(BulletInfo *p); 
static void stepfunc_874d2e5e90fe09b6f38462d1832d30d1(BulletInfo *p); 
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p); 
static void stepfunc_d097c937c08b1c5c6019e5e53c868b18(BulletInfo *p); 
static void stepfunc_f4ec38dcbaa24d3811bebeecddf0e02c(BulletInfo *p); 
static void stepfunc_59b36b64911d10a09634be3628165ed2(BulletInfo *p); 
static void stepfunc_131fd1eeb21f89a2c735ac5f20e2993b(BulletInfo *p); 
static void stepfunc_a7c04e39d930d7552e190d8e0ade80e3(BulletInfo *p); 
static void stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb(BulletInfo *p); 
static void stepfunc_f99b4ab03da25d3db9fb7f354edf95a0(BulletInfo *p); 
static void stepfunc_28e5fd26b14def0c8f85da61274089fa(BulletInfo *p); 
static void stepfunc_49a52ab1a032295cc2f6062c4825eda2(BulletInfo *p); 
static void stepfunc_b9935259e5a98ee157b22387e6cb4ecf(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_b29cebfac2f19abeac4b7b53f6b48124(BulletInfo *p); 
static void stepfunc_099de5a0f09778650c2bc144b0392411(BulletInfo *p); 
static void stepfunc_28701d515eba20086d93340ba33fde6d(BulletInfo *p); 
static void stepfunc_39fb1026339bd14e494b828e17246818(BulletInfo *p); 
static void stepfunc_c2779d963337fc1c28ce2cbd0c260ea5(BulletInfo *p); 
static void stepfunc_36c278ec6ad9b8630d60ee74e4d849b3(BulletInfo *p); 


static const BulletStepFunc bullet_a8f4e4611ee7aee9ad7aba4f71aa0e5d[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_9b5a426fc16fbeff6cb19aed9e879d14,
stepfunc_bbc91d6ae5ccdbfdab65447a1ceccb7a,
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_874d2e5e90fe09b6f38462d1832d30d1,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_874d2e5e90fe09b6f38462d1832d30d1,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_874d2e5e90fe09b6f38462d1832d30d1,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_874d2e5e90fe09b6f38462d1832d30d1,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_874d2e5e90fe09b6f38462d1832d30d1,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_874d2e5e90fe09b6f38462d1832d30d1,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_08a05b21d884c8300aab3f92f30a5e7c,
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_70bfd4b2f151d78397412ec51a0d4727,
#if 0
stepfunc_18af53bc83dc0030a04a1f27ac437943,
#endif
stepfunc_97e8979d1a7c719f55deab0bdea20675,
stepfunc_d097c937c08b1c5c6019e5e53c868b18,
stepfunc_f4ec38dcbaa24d3811bebeecddf0e02c,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_131fd1eeb21f89a2c735ac5f20e2993b,
#if 0
stepfunc_59b36b64911d10a09634be3628165ed2,
#endif
stepfunc_a7c04e39d930d7552e190d8e0ade80e3,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_f99b4ab03da25d3db9fb7f354edf95a0,
#if 0
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb,
#endif
stepfunc_28e5fd26b14def0c8f85da61274089fa,
stepfunc_49a52ab1a032295cc2f6062c4825eda2,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_b9935259e5a98ee157b22387e6cb4ecf,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_ed55ff3526923817b0c282f93aa890be[] = {
stepfunc_b29cebfac2f19abeac4b7b53f6b48124,
stepfunc_099de5a0f09778650c2bc144b0392411,
NULL}; 
static const BulletStepFunc bullet_6f787d461890683d33c039579309a2e3[] = {
stepfunc_b29cebfac2f19abeac4b7b53f6b48124,
stepfunc_28701d515eba20086d93340ba33fde6d,
NULL}; 
static const BulletStepFunc bullet_9887f015fca9f93774b8b4b6a8150e8d[] = {
stepfunc_b29cebfac2f19abeac4b7b53f6b48124,
stepfunc_39fb1026339bd14e494b828e17246818,
NULL}; 
static const BulletStepFunc bullet_c81ad302a516ad4bcb1416d3c98ca39a[] = {
stepfunc_b29cebfac2f19abeac4b7b53f6b48124,
stepfunc_c2779d963337fc1c28ce2cbd0c260ea5,
NULL}; 
static const BulletStepFunc bullet_32aabb7fc5c16e652563b6f08998bfb6[] = {
stepfunc_36c278ec6ad9b8630d60ee74e4d849b3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_b29cebfac2f19abeac4b7b53f6b48124(BulletInfo *p) { 
p->wait = 50; 
}
static void stepfunc_099de5a0f09778650c2bc144b0392411(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(90, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_28701d515eba20086d93340ba33fde6d(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(110, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_39fb1026339bd14e494b828e17246818(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(130, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_c2779d963337fc1c28ce2cbd0c260ea5(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(150, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_b9935259e5a98ee157b22387e6cb4ecf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c81ad302a516ad4bcb1416d3c98ca39a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9887f015fca9f93774b8b4b6a8150e8d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6f787d461890683d33c039579309a2e3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ed55ff3526923817b0c282f93aa890be;  }
}
}
static void stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-354, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_f99b4ab03da25d3db9fb7f354edf95a0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb(p);}
p->wait = 1; 
}
static void stepfunc_59b36b64911d10a09634be3628165ed2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-708, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_131fd1eeb21f89a2c735ac5f20e2993b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_59b36b64911d10a09634be3628165ed2(p);}
p->wait = 1; 
}
static void stepfunc_18af53bc83dc0030a04a1f27ac437943(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(708, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_70bfd4b2f151d78397412ec51a0d4727(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-FixedPointNum(1416, 100)+FixedPointNum::random()*FixedPointNum(1416, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_18af53bc83dc0030a04a1f27ac437943(p);}
p->wait = 4; 
}
static void stepfunc_08a05b21d884c8300aab3f92f30a5e7c(BulletInfo *p) { 
{
  u16 life = 16;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-3187, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_874d2e5e90fe09b6f38462d1832d30d1(BulletInfo *p) { 
{
  u16 life = 32;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(6375, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_9b5a426fc16fbeff6cb19aed9e879d14(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_bbc91d6ae5ccdbfdab65447a1ceccb7a(BulletInfo *p) { 
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum((FixedPointNum(12750, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 10; 
}
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p) { 
p->wait = 100; 
}
static void stepfunc_d097c937c08b1c5c6019e5e53c868b18(BulletInfo *p) { 
p->wait = 0; 
}
static void stepfunc_f4ec38dcbaa24d3811bebeecddf0e02c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_59b36b64911d10a09634be3628165ed2(p);}
p->wait = 1; 
}
static void stepfunc_a7c04e39d930d7552e190d8e0ade80e3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(320, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_5992a6b0264bfa9260ee7b11ab4a96fb(p);}
p->wait = 1; 
}
static void stepfunc_28e5fd26b14def0c8f85da61274089fa(BulletInfo *p) { 
p->wait = 175; 
}
static void stepfunc_49a52ab1a032295cc2f6062c4825eda2(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(1)+FixedPointNum::random() - p->getSpeed();p->setAccel(speed, life);}
p->wait = FixedPointNum(10)+FixedPointNum::random()*FixedPointNum(65); 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_36c278ec6ad9b8630d60ee74e4d849b3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (85);    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a8f4e4611ee7aee9ad7aba4f71aa0e5d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-85);    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a8f4e4611ee7aee9ad7aba4f71aa0e5d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a8f4e4611ee7aee9ad7aba4f71aa0e5d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-3187, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a8f4e4611ee7aee9ad7aba4f71aa0e5d;  }
}
p->wait = 1100; 
}


void genBulletFunc_3dffec8f6a5e3f9f9c7ddd8a7aa025d0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_32aabb7fc5c16e652563b6f08998bfb6; }}


