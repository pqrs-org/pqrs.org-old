// XXX uniqID XXX b99a295bf9a1ad70f9d77289ef618984 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_7a9969ce1f9fdb08f35eb453dde24d07(BulletInfo *p); 
static void stepfunc_f4fcfcc6edfb3a00c767f5a9b870d9cc(BulletInfo *p); 
static void stepfunc_e095e4f62919950dfa542811a9540c82(BulletInfo *p); 
static void stepfunc_594ebe06c22777045bf4f9531198b4bc(BulletInfo *p); 
static void stepfunc_430225019f10afbeb4369b08c9e8d688(BulletInfo *p); 
static void stepfunc_98eb86aef303b5cfbb77aaa330c93c39(BulletInfo *p); 
static void stepfunc_00763f8398a7d746131d414b31b58380(BulletInfo *p); 
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 
static void stepfunc_ff155358f8160f6b50609fc40369a02e(BulletInfo *p); 
static void stepfunc_1cdbfb1f3d68437e5e48192ad40cb897(BulletInfo *p); 
static void stepfunc_f1818f2e6340c6b80c91b1fad39c3e79(BulletInfo *p); 
static void stepfunc_ac58a9ac83886509de09fd68c5b8cf35(BulletInfo *p); 
static void stepfunc_3496dc0cbc731810bb2e3c15f8d93189(BulletInfo *p); 
static void stepfunc_74a62f05b6190639860b15634a062287(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_994e80318ff382d4c85218e9fd6c768f(BulletInfo *p); 
static void stepfunc_529aea9ad903537181da28c1ccb67841(BulletInfo *p); 
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p); 
static void stepfunc_1adeaa69e3bfa2efca75b68f487f1035(BulletInfo *p); 
static void stepfunc_c966b55df10b03540af48d4785c14e30(BulletInfo *p); 
static void stepfunc_74dc3e573ff30bbf56c99ca4050543ac(BulletInfo *p); 
static void stepfunc_d0da532853068bb277025ed5a91e2771(BulletInfo *p); 
static void stepfunc_921e98da4f803f34be9eff39872dcd63(BulletInfo *p); 
static void stepfunc_dcdad126a9d18deca407691cc43fdea4(BulletInfo *p); 
static void stepfunc_b745512bf4437e834235dfcd259c6241(BulletInfo *p); 


static const BulletStepFunc bullet_e9f79f982cc8e0976461f46cef80992e[] = {
stepfunc_7a9969ce1f9fdb08f35eb453dde24d07,
stepfunc_f4fcfcc6edfb3a00c767f5a9b870d9cc,
stepfunc_e095e4f62919950dfa542811a9540c82,
stepfunc_594ebe06c22777045bf4f9531198b4bc,
NULL}; 
static const BulletStepFunc bullet_87f9f854065c3b2fd186c2b683c9d4c3[] = {
stepfunc_430225019f10afbeb4369b08c9e8d688,
stepfunc_f4fcfcc6edfb3a00c767f5a9b870d9cc,
stepfunc_e095e4f62919950dfa542811a9540c82,
stepfunc_594ebe06c22777045bf4f9531198b4bc,
NULL}; 
static const BulletStepFunc bullet_2ad14c5f945b31a5d3f03f54c111eba9[] = {
stepfunc_98eb86aef303b5cfbb77aaa330c93c39,
stepfunc_00763f8398a7d746131d414b31b58380,
stepfunc_e095e4f62919950dfa542811a9540c82,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_ff155358f8160f6b50609fc40369a02e,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_f1818f2e6340c6b80c91b1fad39c3e79,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_3496dc0cbc731810bb2e3c15f8d93189,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b7e02e90b2030467acfe583925899681[] = {
stepfunc_994e80318ff382d4c85218e9fd6c768f,
stepfunc_529aea9ad903537181da28c1ccb67841,
stepfunc_e095e4f62919950dfa542811a9540c82,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_ff155358f8160f6b50609fc40369a02e,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_1cdbfb1f3d68437e5e48192ad40cb897,
stepfunc_f1818f2e6340c6b80c91b1fad39c3e79,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_ac58a9ac83886509de09fd68c5b8cf35,
stepfunc_3496dc0cbc731810bb2e3c15f8d93189,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_74a62f05b6190639860b15634a062287,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_ab44d5af2cdb5784e166b9e8d5df56b6[] = {
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_1adeaa69e3bfa2efca75b68f487f1035,
stepfunc_c966b55df10b03540af48d4785c14e30,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
stepfunc_74dc3e573ff30bbf56c99ca4050543ac,
NULL}; 
static const BulletStepFunc bullet_5e13eccae1f9a4957ce656fbb44e3710[] = {
stepfunc_d0da532853068bb277025ed5a91e2771,
stepfunc_921e98da4f803f34be9eff39872dcd63,
stepfunc_e095e4f62919950dfa542811a9540c82,
stepfunc_dcdad126a9d18deca407691cc43fdea4,
stepfunc_b745512bf4437e834235dfcd259c6241,
stepfunc_921e98da4f803f34be9eff39872dcd63,
stepfunc_e095e4f62919950dfa542811a9540c82,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_74a62f05b6190639860b15634a062287(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100)-FixedPointNum::random()*FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(1)+FixedPointNum::random()*FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 20; 
}
static void stepfunc_74dc3e573ff30bbf56c99ca4050543ac(BulletInfo *p) { 
{
  u16 life = 8;  FixedPointNum speed = FixedPointNum(FixedPointNum(10, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 8; 
}
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_1adeaa69e3bfa2efca75b68f487f1035(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 750; 
}
static void stepfunc_c966b55df10b03540af48d4785c14e30(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (FixedPointNum(283, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 10; 
}
static void stepfunc_ac58a9ac83886509de09fd68c5b8cf35(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-708, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ab44d5af2cdb5784e166b9e8d5df56b6;  }
}
}
static void stepfunc_1cdbfb1f3d68437e5e48192ad40cb897(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(708, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ab44d5af2cdb5784e166b9e8d5df56b6;  }
}
}
static void stepfunc_98eb86aef303b5cfbb77aaa330c93c39(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum((FixedPointNum(12750, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 12; 
}
static void stepfunc_00763f8398a7d746131d414b31b58380(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(3 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 55; 
}
static void stepfunc_e095e4f62919950dfa542811a9540c82(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 55; 
}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_ff155358f8160f6b50609fc40369a02e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(708, 100));    p->lastBulletSpeed = (FixedPointNum(35, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ab44d5af2cdb5784e166b9e8d5df56b6;  }
}
}
static void stepfunc_f1818f2e6340c6b80c91b1fad39c3e79(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-708, 100));    p->lastBulletSpeed = (FixedPointNum(35, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ab44d5af2cdb5784e166b9e8d5df56b6;  }
}
}
static void stepfunc_3496dc0cbc731810bb2e3c15f8d93189(BulletInfo *p) { 
p->wait = 200; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_994e80318ff382d4c85218e9fd6c768f(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum((0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 12; 
}
static void stepfunc_529aea9ad903537181da28c1ccb67841(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(90, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 55; 
}
static void stepfunc_7a9969ce1f9fdb08f35eb453dde24d07(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum((FixedPointNum(-6375, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 12; 
}
static void stepfunc_f4fcfcc6edfb3a00c767f5a9b870d9cc(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(150, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 55; 
}
static void stepfunc_594ebe06c22777045bf4f9531198b4bc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b7e02e90b2030467acfe583925899681;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2ad14c5f945b31a5d3f03f54c111eba9;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_430225019f10afbeb4369b08c9e8d688(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum((FixedPointNum(6375, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 12; 
}
static void stepfunc_d0da532853068bb277025ed5a91e2771(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87f9f854065c3b2fd186c2b683c9d4c3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e9f79f982cc8e0976461f46cef80992e;  }
}
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum((0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 12; 
}
static void stepfunc_921e98da4f803f34be9eff39872dcd63(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(90, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 55; 
}
static void stepfunc_dcdad126a9d18deca407691cc43fdea4(BulletInfo *p) { 
p->wait = 950; 
}
static void stepfunc_b745512bf4437e834235dfcd259c6241(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum((FixedPointNum(12750, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 12; 
}


void genBulletFunc_b99a295bf9a1ad70f9d77289ef618984(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_5e13eccae1f9a4957ce656fbb44e3710; }}


