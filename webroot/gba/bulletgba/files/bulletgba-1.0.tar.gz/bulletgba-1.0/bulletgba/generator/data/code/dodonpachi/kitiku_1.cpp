// XXX uniqID XXX 53a7fc7f1c0bb27346bd81c88435868d XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_119eb5b5fac0589b908907a90795cf64(BulletInfo *p); 
static void stepfunc_6b7fc025c69b94fd8dcb853e09483fa8(BulletInfo *p); 
static void stepfunc_af96e564d993e9b248ed8c0ebbf2769e(BulletInfo *p); 
static void stepfunc_9b5a426fc16fbeff6cb19aed9e879d14(BulletInfo *p); 
static void stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc(BulletInfo *p); 
static void stepfunc_11842a85f1de40db0d740aad7d33658f(BulletInfo *p); 
static void stepfunc_ed7e9879b72ba2682ca4a13ad611ca27(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p); 
static void stepfunc_117ee21c07f97779c38652408f8d4a2b(BulletInfo *p); 
static void stepfunc_6fc15bc853a7df9dfa097b7452a20a2c(BulletInfo *p); 
static void stepfunc_a46b45667a13916f1cb8c22d277be8ec(BulletInfo *p); 
static void stepfunc_29845e24a57575d5620d240c05cf778c(BulletInfo *p); 
static void stepfunc_810f4a15cbf820d7e3f6d7c22bbf5dc4(BulletInfo *p); 
static void stepfunc_ad8818fd9ff790aab67c39d0fb74741d(BulletInfo *p); 


static const BulletStepFunc bullet_97696b3b11357d7f661eaa719682dd75[] = {
stepfunc_119eb5b5fac0589b908907a90795cf64,
NULL}; 
static const BulletStepFunc bullet_306e6393bbfe5de590a2d3f19210bad9[] = {
stepfunc_6b7fc025c69b94fd8dcb853e09483fa8,
NULL}; 
static const BulletStepFunc bullet_168cfd1e5b6a7e992120ad6a3b8e8514[] = {
stepfunc_af96e564d993e9b248ed8c0ebbf2769e,
stepfunc_9b5a426fc16fbeff6cb19aed9e879d14,
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc,
#if 0
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3541422580eb552563f4a2ef400e7c0b[] = {
stepfunc_af96e564d993e9b248ed8c0ebbf2769e,
stepfunc_769bdefb02579aa79348dd03cdd26c8a,
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_117ee21c07f97779c38652408f8d4a2b,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_c08660e25c9b1c92d06bf8bfb27e0787[] = {
stepfunc_af96e564d993e9b248ed8c0ebbf2769e,
stepfunc_769bdefb02579aa79348dd03cdd26c8a,
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_6fc15bc853a7df9dfa097b7452a20a2c,
#if 0
stepfunc_11842a85f1de40db0d740aad7d33658f,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_ea8cc6583f27921bea3ca4ce251dc31e[] = {
stepfunc_a46b45667a13916f1cb8c22d277be8ec,
stepfunc_29845e24a57575d5620d240c05cf778c,
stepfunc_810f4a15cbf820d7e3f6d7c22bbf5dc4,
stepfunc_ad8818fd9ff790aab67c39d0fb74741d,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_11842a85f1de40db0d740aad7d33658f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_6fc15bc853a7df9dfa097b7452a20a2c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-200, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_11842a85f1de40db0d740aad7d33658f(p);}
p->wait = FixedPointNum(8)-FixedPointNum(FixedPointNum(1))*FixedPointNum(4)+FixedPointNum::random(); 
}
static void stepfunc_af96e564d993e9b248ed8c0ebbf2769e(BulletInfo *p) { 
p->wait = 6; 
}
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_119eb5b5fac0589b908907a90795cf64(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10492, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c08660e25c9b1c92d06bf8bfb27e0787;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_117ee21c07f97779c38652408f8d4a2b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(200, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_11842a85f1de40db0d740aad7d33658f(p);}
p->wait = FixedPointNum(8)-FixedPointNum(FixedPointNum(1))*FixedPointNum(4)+FixedPointNum::random(); 
}
static void stepfunc_6b7fc025c69b94fd8dcb853e09483fa8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15007, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3541422580eb552563f4a2ef400e7c0b;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ed7e9879b72ba2682ca4a13ad611ca27(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_11842a85f1de40db0d740aad7d33658f(p);}
}
static void stepfunc_4de5d37ddbfe6f972bd556cf145b1dfc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (-FixedPointNum(779, 100)-FixedPointNum::random()*FixedPointNum(141, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_11842a85f1de40db0d740aad7d33658f(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_ed7e9879b72ba2682ca4a13ad611ca27(p);}
p->wait = 12; 
}
static void stepfunc_9b5a426fc16fbeff6cb19aed9e879d14(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_a46b45667a13916f1cb8c22d277be8ec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6020, 100));    p->lastBulletSpeed = (10);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_168cfd1e5b6a7e992120ad6a3b8e8514;  }
}
p->wait = 1; 
}
static void stepfunc_29845e24a57575d5620d240c05cf778c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6020, 100));    p->lastBulletSpeed = (10);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_168cfd1e5b6a7e992120ad6a3b8e8514;  }
}
p->wait = 1; 
}
static void stepfunc_810f4a15cbf820d7e3f6d7c22bbf5dc4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_306e6393bbfe5de590a2d3f19210bad9;  }
}
p->wait = 1; 
}
static void stepfunc_ad8818fd9ff790aab67c39d0fb74741d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97696b3b11357d7f661eaa719682dd75;  }
}
p->wait = 430; 
}


void genBulletFunc_53a7fc7f1c0bb27346bd81c88435868d(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_ea8cc6583f27921bea3ca4ce251dc31e; }}


