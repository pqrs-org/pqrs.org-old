// XXX uniqID XXX 8209009d12b99144cbb738942bdd2e92 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b5f39e54521a3eaf20616a06af3538d0(BulletInfo *p); 
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p); 
static void stepfunc_490ca55e5de6bb7c581deb7d2bc0eade(BulletInfo *p); 
static void stepfunc_5262c7b33909953a5834230763674d3e(BulletInfo *p); 
static void stepfunc_29e3d1931fb960f8609f4ae38f127208(BulletInfo *p); 
static void stepfunc_9fbe45bf0d16232591ff0efc0f13249e(BulletInfo *p); 
static void stepfunc_1fd45aa94ace3cc5a3b8667e55281593(BulletInfo *p); 
static void stepfunc_72f044d58ccfb4d5b2b84dbe3f00df2f(BulletInfo *p); 


static const BulletStepFunc bullet_d7d66e5aab213b2969fa5e49fa7df110[] = {
stepfunc_b5f39e54521a3eaf20616a06af3538d0,
stepfunc_769bdefb02579aa79348dd03cdd26c8a,
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_490ca55e5de6bb7c581deb7d2bc0eade,
#if 0
stepfunc_5262c7b33909953a5834230763674d3e,
#endif
stepfunc_29e3d1931fb960f8609f4ae38f127208,
#if 0
stepfunc_9fbe45bf0d16232591ff0efc0f13249e,
#endif
stepfunc_1fd45aa94ace3cc5a3b8667e55281593,
stepfunc_72f044d58ccfb4d5b2b84dbe3f00df2f,
NULL}; 
static void stepfunc_9fbe45bf0d16232591ff0efc0f13249e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(425, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_5262c7b33909953a5834230763674d3e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(425, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_490ca55e5de6bb7c581deb7d2bc0eade(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 59; ++i) { 
stepfunc_5262c7b33909953a5834230763674d3e(p);}
p->wait = 10; 
}
static void stepfunc_29e3d1931fb960f8609f4ae38f127208(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(637, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 59; ++i) { 
stepfunc_9fbe45bf0d16232591ff0efc0f13249e(p);}
p->wait = 10; 
}
static void stepfunc_b5f39e54521a3eaf20616a06af3538d0(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 25; 
}
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_1fd45aa94ace3cc5a3b8667e55281593(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 25; 
}
static void stepfunc_72f044d58ccfb4d5b2b84dbe3f00df2f(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_8209009d12b99144cbb738942bdd2e92(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_d7d66e5aab213b2969fa5e49fa7df110; }}


