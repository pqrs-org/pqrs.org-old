// XXX uniqID XXX ea5bbbc7ecc0578fd9a21f0a193735e1 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c(BulletInfo *p); 
static void stepfunc_bbc70ca389abeff5c0b95f1fd1104534(BulletInfo *p); 
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 
static void stepfunc_cdec139daa8e9dca41caa7b09947f0cb(BulletInfo *p); 
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_8ef3d84f4c73366792398724f8579ff8[] = {
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_cdec139daa8e9dca41caa7b09947f0cb,
#if 0
stepfunc_bbc70ca389abeff5c0b95f1fd1104534,
#endif
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_bbc70ca389abeff5c0b95f1fd1104534(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1345, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_cdec139daa8e9dca41caa7b09947f0cb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2904, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 10; ++i) { 
stepfunc_bbc70ca389abeff5c0b95f1fd1104534(p);}
p->wait = 1; 
}
static void stepfunc_c2bbd4f35e1fde0c44d28df4c24c579c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2904, 100));    p->lastBulletSpeed = (FixedPointNum(69, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 13; ++i) { 
stepfunc_bbc70ca389abeff5c0b95f1fd1104534(p);}
p->wait = 1; 
}
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_ea5bbbc7ecc0578fd9a21f0a193735e1(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_8ef3d84f4c73366792398724f8579ff8; }}


