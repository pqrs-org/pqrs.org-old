// XXX uniqID XXX 9873e665589d2e08a9528043de88928c XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_c24fa0261d7a22f141a706463b79408c(BulletInfo *p); 
static void stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_8f4cdae05ba0f92d45e02550a5a064c5(BulletInfo *p); 
static void stepfunc_1c11037c651b8c192888e0327f487cf0(BulletInfo *p); 
static void stepfunc_304c6696f4d3c31030a32cb06129eb78(BulletInfo *p); 
static void stepfunc_4c3855109bee87480d88ba302480fcd5(BulletInfo *p); 


static const BulletStepFunc bullet_38f168d1c577c9e6196b357ddc98f48a[] = {
stepfunc_c24fa0261d7a22f141a706463b79408c,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_eb2bde7ec80c2338b8ec89da0078bd61[] = {
stepfunc_8f4cdae05ba0f92d45e02550a5a064c5,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_1c11037c651b8c192888e0327f487cf0,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_4f09c7e80654b9295c3f6e316e2d3a8d[] = {
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_304c6696f4d3c31030a32cb06129eb78,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_4c3855109bee87480d88ba302480fcd5,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_4c3855109bee87480d88ba302480fcd5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 20; 
}
static void stepfunc_95d7e18b4a61f7f1fd26d3f7a00210fd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = FixedPointNum(4)+FixedPointNum::random()*FixedPointNum(8); 
}
static void stepfunc_c24fa0261d7a22f141a706463b79408c(BulletInfo *p) { 
{
  u16 life = 9999;  FixedPointNum speed = FixedPointNum(25358, 100);p->setRound(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_1c11037c651b8c192888e0327f487cf0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(25145, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = FixedPointNum(4)+FixedPointNum::random()*FixedPointNum(8); 
}
static void stepfunc_8f4cdae05ba0f92d45e02550a5a064c5(BulletInfo *p) { 
{
  u16 life = 9999;  FixedPointNum speed = FixedPointNum(141, 100);p->setRound(speed, life);}
}
static void stepfunc_304c6696f4d3c31030a32cb06129eb78(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_eb2bde7ec80c2338b8ec89da0078bd61;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_38f168d1c577c9e6196b357ddc98f48a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 20; 
}


void genBulletFunc_9873e665589d2e08a9528043de88928c(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_4f09c7e80654b9295c3f6e316e2d3a8d; }}


