// XXX uniqID XXX bdda80179c2aecc6b03ea1bfd7b21fe4 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_9604d530b79210bcb56507e3e9836fc6(BulletInfo *p); 
static void stepfunc_84bb4ec273da81ce0e132e20f32e7b82(BulletInfo *p); 
static void stepfunc_194cb427fb0df23698ec6a8436b3e5a8(BulletInfo *p); 
static void stepfunc_366e4b0ee262457534c3f28736f53d7c(BulletInfo *p); 
static void stepfunc_bcf79081a964bbe57d853458be8a11aa(BulletInfo *p); 
static void stepfunc_bed681fb6e22a6bad0a16d91a2a5c4e6(BulletInfo *p); 
static void stepfunc_78e161c5d18eb3350183233211f0d4a4(BulletInfo *p); 
static void stepfunc_9da55d8d7d0359a6be4bec5e22c03e3b(BulletInfo *p); 
static void stepfunc_73811469feb0e61ff23d24184e5d5c86(BulletInfo *p); 
static void stepfunc_d87e454e9098031f2fe83d3961eb612d(BulletInfo *p); 
static void stepfunc_20afff497fbb45dd41ca9c4e78e8d85f(BulletInfo *p); 
static void stepfunc_8b2e271550d50a5c89e8b385c6cf7f74(BulletInfo *p); 
static void stepfunc_b8258afdd1aa885a4a177e52bf7d0b75(BulletInfo *p); 
static void stepfunc_5acaeedc34a1e3c36067471740a2bf01(BulletInfo *p); 
static void stepfunc_8d7907a4bf3f665bbba78849815e5920(BulletInfo *p); 
static void stepfunc_834cd10c08355d7b41f2e499fc413331(BulletInfo *p); 
static void stepfunc_3b84a3d7c4cf994a5a6545c727656153(BulletInfo *p); 
static void stepfunc_e5cc138d9b0e6538c1a4581acbcd0af9(BulletInfo *p); 
static void stepfunc_e4385b313c4b03f218b4b704d20d44d8(BulletInfo *p); 
static void stepfunc_499d8543234e566de75a898ca83d8e80(BulletInfo *p); 
static void stepfunc_a8ad2960b6244b652910d1060148f11d(BulletInfo *p); 
static void stepfunc_69bb6acce0cbc569e620e96706326565(BulletInfo *p); 
static void stepfunc_b9721c371969df78327a4c6dd1f689c3(BulletInfo *p); 
static void stepfunc_a243a0291932645c3d9d80071f8946a4(BulletInfo *p); 
static void stepfunc_96095486a1547f9d6727fb168deb65f9(BulletInfo *p); 
static void stepfunc_be483536617b24109f45789d7c0edd56(BulletInfo *p); 
static void stepfunc_229bf47b3fac1d9abac5e1e7ef723bd1(BulletInfo *p); 
static void stepfunc_ae8ab415fb5fe74a507d4ea8b2627ac4(BulletInfo *p); 
static void stepfunc_d978c484da78744cd4186ec87bdb6573(BulletInfo *p); 
static void stepfunc_ab8e91ecce7d66fb07093f8b64477801(BulletInfo *p); 
static void stepfunc_c691417d81b66c33a7668382410790d6(BulletInfo *p); 
static void stepfunc_7458df2e26a47b582c06a40468c4ae2a(BulletInfo *p); 
static void stepfunc_ad30160506a39db8e8d00f75d559fedd(BulletInfo *p); 
static void stepfunc_ee27b29b49a3cd966fc22535807f627f(BulletInfo *p); 
static void stepfunc_e2c8186336043fcdbab4bd2e7bf4e2e2(BulletInfo *p); 
static void stepfunc_64e702562b46b13ddab2d5b03845cd2a(BulletInfo *p); 
static void stepfunc_0d60605728c8f650810c15c5051e6d1c(BulletInfo *p); 
static void stepfunc_9b4c89b6bb4901e6dd2889b8c25c5665(BulletInfo *p); 
static void stepfunc_2d929fdd40a08ab855582bf8d6b32d51(BulletInfo *p); 
static void stepfunc_2636b1fcca27958b2785beaaebca42b1(BulletInfo *p); 
static void stepfunc_c74bb5f3c58c34cfd794ffb9eb280491(BulletInfo *p); 
static void stepfunc_9605d0d50de5acebe0ae96d42b1e8f21(BulletInfo *p); 
static void stepfunc_91bdf0e7f31d98dfd4ecdd4beae81ca6(BulletInfo *p); 
static void stepfunc_a1c81250204a4cd38be0d1c22011f72a(BulletInfo *p); 
static void stepfunc_cebe500d21cf3810e1f036ec9af8d289(BulletInfo *p); 
static void stepfunc_83c93e5c01b018b5649aa7b2806cb335(BulletInfo *p); 
static void stepfunc_5e51c07bc8b80ef18e97ec1f68bb3f4c(BulletInfo *p); 
static void stepfunc_1698efda28274a98634454de4a7e2e8d(BulletInfo *p); 
static void stepfunc_909f9cce29f126dc4f11765406e39de9(BulletInfo *p); 
static void stepfunc_62f76c2f9fc68200b64adb2c1c05745f(BulletInfo *p); 
static void stepfunc_986717bdf5e72cbee99eb30d8c563a21(BulletInfo *p); 
static void stepfunc_b970856ffd05c2b09077b305e5e8de30(BulletInfo *p); 
static void stepfunc_904820e6d7723e9f9959122755ce11e9(BulletInfo *p); 
static void stepfunc_71bacfa6322daf4b0c6215df91b78fc0(BulletInfo *p); 
static void stepfunc_58def3b621d1ff1674c297b6c8fd1093(BulletInfo *p); 
static void stepfunc_0c409ec289b2815bdd343790517f10ac(BulletInfo *p); 
static void stepfunc_56e87fcdf463d7b8f584aa43b2b0542c(BulletInfo *p); 
static void stepfunc_5d5fe0663c48f820e0089d253ed1714e(BulletInfo *p); 
static void stepfunc_457fdfacc5a3c25dd85286cea1b4a5db(BulletInfo *p); 
static void stepfunc_ee5a5ec6a0aaa4ce9ca88e7f2d850c2a(BulletInfo *p); 
static void stepfunc_ce3ef138b9b68ce6cbd24bc0ac523197(BulletInfo *p); 
static void stepfunc_29bbfe77c50c4e306a98e24cb3231937(BulletInfo *p); 
static void stepfunc_e94c1a79b01b77036d1e10c5905226e7(BulletInfo *p); 
static void stepfunc_7bc68dd86074abbbadfb37b697aad9c3(BulletInfo *p); 
static void stepfunc_6c1bfba1552fd15a08b06b9629289fac(BulletInfo *p); 
static void stepfunc_a6337bb3f098dad7fceccaf1ffc6ef1d(BulletInfo *p); 
static void stepfunc_425eacbdab318574de4f7593e459ba20(BulletInfo *p); 
static void stepfunc_007b1015561fd31a0a79e53cee997f45(BulletInfo *p); 
static void stepfunc_b77b2419f41736162fe62ccd3e90d1e7(BulletInfo *p); 
static void stepfunc_facde89a0995adb70792b37150243d89(BulletInfo *p); 
static void stepfunc_f04ee87a787a0e183031aa90daecfe57(BulletInfo *p); 
static void stepfunc_8bc198a6066a4771196df5935a87a478(BulletInfo *p); 
static void stepfunc_6a0302a961bbb90e3b508982c1a9206a(BulletInfo *p); 
static void stepfunc_c1b7f1cb9c474daeb3a32d3e23b304f6(BulletInfo *p); 
static void stepfunc_493dab8b9fefa75701bb28cb83516eef(BulletInfo *p); 
static void stepfunc_f49f79704283e789198120ea420da20d(BulletInfo *p); 
static void stepfunc_df8edc9da2034626137eb463b200ff4b(BulletInfo *p); 
static void stepfunc_7aa08413a81dfe842ad4f2a45bad6d93(BulletInfo *p); 
static void stepfunc_dccbd9fb8575ca586b862742380b10a9(BulletInfo *p); 
static void stepfunc_45decafd61b16c532bf73e492de601aa(BulletInfo *p); 
static void stepfunc_1a6dc362e292fb8fd1b1edefff877ecd(BulletInfo *p); 
static void stepfunc_32901ce96151273bde4ff40af352a897(BulletInfo *p); 
static void stepfunc_2857a7965567687ed97d14a73cacef0c(BulletInfo *p); 
static void stepfunc_61693af9f33d79e049e7ee8bcb52de6d(BulletInfo *p); 
static void stepfunc_d66c08a50f32580900d95f00bf5b7fdc(BulletInfo *p); 
static void stepfunc_331fb430dfc3b793445f5b549f305fea(BulletInfo *p); 
static void stepfunc_60d6a12cabd9258c710ed17f4bdae259(BulletInfo *p); 
static void stepfunc_dc1279723eb597ad417310d7859fd88e(BulletInfo *p); 
static void stepfunc_d16e2d79134f84d647ed97d6b6b046b1(BulletInfo *p); 
static void stepfunc_543ea0b3e425efea35ca586204735bd7(BulletInfo *p); 
static void stepfunc_fce1ea6078ad5d2dde85608fd64ea1e9(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_b04800858852b94c3015e5818e89a025[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_84bb4ec273da81ce0e132e20f32e7b82,
NULL}; 
static const BulletStepFunc bullet_0656548e8559b0cd7d49bf962f8027c7[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_194cb427fb0df23698ec6a8436b3e5a8,
NULL}; 
static const BulletStepFunc bullet_cbbc5405f63932458b4526b7ece1d9cf[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_366e4b0ee262457534c3f28736f53d7c,
NULL}; 
static const BulletStepFunc bullet_4ea1cea3b6c62cc8372c8bac977414ab[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_bcf79081a964bbe57d853458be8a11aa,
NULL}; 
static const BulletStepFunc bullet_e25f994b0c135535493380e78d4973b3[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_bed681fb6e22a6bad0a16d91a2a5c4e6,
NULL}; 
static const BulletStepFunc bullet_5cb5341ed8931ebf3b07149e3f4819d7[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_78e161c5d18eb3350183233211f0d4a4,
NULL}; 
static const BulletStepFunc bullet_ff354c09e736d4d13ed402bd70b94265[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_9da55d8d7d0359a6be4bec5e22c03e3b,
NULL}; 
static const BulletStepFunc bullet_03460918e853b7381c9eb72296e0ab15[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_73811469feb0e61ff23d24184e5d5c86,
NULL}; 
static const BulletStepFunc bullet_b5412212e356097a81647102e36969c1[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_d87e454e9098031f2fe83d3961eb612d,
NULL}; 
static const BulletStepFunc bullet_e20ef2113278d292a0e87e23cef95802[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_20afff497fbb45dd41ca9c4e78e8d85f,
NULL}; 
static const BulletStepFunc bullet_5054931ebdc3b2548e1bf23b61b8c480[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8b2e271550d50a5c89e8b385c6cf7f74,
NULL}; 
static const BulletStepFunc bullet_98ab223d009bd1cce4bc437c60fb73a8[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_b8258afdd1aa885a4a177e52bf7d0b75,
NULL}; 
static const BulletStepFunc bullet_d11a9d5b5eb864be1643a0d851cf6b96[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_5acaeedc34a1e3c36067471740a2bf01,
NULL}; 
static const BulletStepFunc bullet_4ecb0695c5d1cc889bd130c7104b02bb[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8d7907a4bf3f665bbba78849815e5920,
NULL}; 
static const BulletStepFunc bullet_d7cbadd8f325e03d26123d43cd41c24b[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_834cd10c08355d7b41f2e499fc413331,
NULL}; 
static const BulletStepFunc bullet_87665eca1f83c33fd6121f92914e5f92[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_3b84a3d7c4cf994a5a6545c727656153,
NULL}; 
static const BulletStepFunc bullet_96bebef18ddea0755767ae124165b1fb[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_e5cc138d9b0e6538c1a4581acbcd0af9,
NULL}; 
static const BulletStepFunc bullet_65ae14773b51b49e7946eea09b4c14ef[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_e4385b313c4b03f218b4b704d20d44d8,
NULL}; 
static const BulletStepFunc bullet_ac6454234aa5930b350680220c8523a8[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_499d8543234e566de75a898ca83d8e80,
NULL}; 
static const BulletStepFunc bullet_69595ddbb0b9649fcc19e53df93d56cc[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_a8ad2960b6244b652910d1060148f11d,
NULL}; 
static const BulletStepFunc bullet_642c855093637562e59650732549680b[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_69bb6acce0cbc569e620e96706326565,
NULL}; 
static const BulletStepFunc bullet_89920dccafa82108e8d6f56abfa0155e[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_b9721c371969df78327a4c6dd1f689c3,
NULL}; 
static const BulletStepFunc bullet_59b4c56445fde754eb1b5be365d9f1c2[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_a243a0291932645c3d9d80071f8946a4,
NULL}; 
static const BulletStepFunc bullet_19e7278cd97d23574eb2ad48fd3c8775[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_96095486a1547f9d6727fb168deb65f9,
NULL}; 
static const BulletStepFunc bullet_93d28989a84fc77d28b53f3d9f8445d7[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_be483536617b24109f45789d7c0edd56,
NULL}; 
static const BulletStepFunc bullet_377de773f32748efb0346d188159e201[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_229bf47b3fac1d9abac5e1e7ef723bd1,
NULL}; 
static const BulletStepFunc bullet_327d1f00cd6107eba0ea19115dfcbeb8[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_ae8ab415fb5fe74a507d4ea8b2627ac4,
NULL}; 
static const BulletStepFunc bullet_16065322f7009081f345b8b2fe056570[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_d978c484da78744cd4186ec87bdb6573,
NULL}; 
static const BulletStepFunc bullet_d91b2cd679e94f74ea319e5893e364f3[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_ab8e91ecce7d66fb07093f8b64477801,
NULL}; 
static const BulletStepFunc bullet_b5ef496a4df69d5a67e0eca5366f2fd0[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_c691417d81b66c33a7668382410790d6,
NULL}; 
static const BulletStepFunc bullet_b3e6c91d1f9fef7be04142707c042a3c[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_7458df2e26a47b582c06a40468c4ae2a,
NULL}; 
static const BulletStepFunc bullet_450dbbb17f3d7eb754933066f5de5aeb[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_ad30160506a39db8e8d00f75d559fedd,
NULL}; 
static const BulletStepFunc bullet_485a87b143f565fa044d7c7712eec0d1[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_ee27b29b49a3cd966fc22535807f627f,
NULL}; 
static const BulletStepFunc bullet_8d33766d939b76e0c1abeb779ccf8b88[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_e2c8186336043fcdbab4bd2e7bf4e2e2,
NULL}; 
static const BulletStepFunc bullet_b8ec3c35d8532df566d0287b17e382e4[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_64e702562b46b13ddab2d5b03845cd2a,
NULL}; 
static const BulletStepFunc bullet_ed835b29c64a3e79808b385f7278d21e[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_0d60605728c8f650810c15c5051e6d1c,
NULL}; 
static const BulletStepFunc bullet_d3cb6c6dc9ba501808621427e2829d88[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_9b4c89b6bb4901e6dd2889b8c25c5665,
NULL}; 
static const BulletStepFunc bullet_dde13b10e5628c23afb4e16eece51267[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_2d929fdd40a08ab855582bf8d6b32d51,
NULL}; 
static const BulletStepFunc bullet_20e9c02600193882a300db77f6023df1[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_2636b1fcca27958b2785beaaebca42b1,
NULL}; 
static const BulletStepFunc bullet_d33f0fad2bdf44082324445c2e1b0387[] = {
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_c74bb5f3c58c34cfd794ffb9eb280491,
NULL}; 
static const BulletStepFunc bullet_62914a617f12628b7a84ab973f9db447[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_91bdf0e7f31d98dfd4ecdd4beae81ca6,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_1d8cf13e34f246ecb8f1f290111db1e0[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_cebe500d21cf3810e1f036ec9af8d289,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_9e113e98b4e7981423033b0bee2d0066[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_83c93e5c01b018b5649aa7b2806cb335,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_f6f6757158752b6e58d731658807296e[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_5e51c07bc8b80ef18e97ec1f68bb3f4c,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_f45ef13eb41e2a5c8aaeb9a154b2400d[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_1698efda28274a98634454de4a7e2e8d,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_76d0726bfde497a707811f7c796722fc[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_909f9cce29f126dc4f11765406e39de9,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_e5fbbe7d9f4de679afce2ab62e79b4fa[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_62f76c2f9fc68200b64adb2c1c05745f,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_380b84fb6b0c6573839150e40389af5e[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_986717bdf5e72cbee99eb30d8c563a21,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_464e70a99d742a97e1bd13c2658169f1[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_b970856ffd05c2b09077b305e5e8de30,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_d0cc9b7ca7f3a71f3f230ee0411cd06b[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_904820e6d7723e9f9959122755ce11e9,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_ce35631c524604138087e12b0403987c[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_71bacfa6322daf4b0c6215df91b78fc0,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_201d4a1c1d66d75af25fc9eb65c5bcdc[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_58def3b621d1ff1674c297b6c8fd1093,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_cc29dd867fd453d4c8710077329fca84[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_0c409ec289b2815bdd343790517f10ac,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_170c56f7e126a95c1deeec255f107fe9[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_56e87fcdf463d7b8f584aa43b2b0542c,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_5e3e00d2bda179d85654a48610db1ab3[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_5d5fe0663c48f820e0089d253ed1714e,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_8f1d63884590f5555fd84858e4ebefea[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_457fdfacc5a3c25dd85286cea1b4a5db,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_21a59bca1a65ef75faa70b6c92bf6b31[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_ee5a5ec6a0aaa4ce9ca88e7f2d850c2a,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_28d75cbf32649210060ef851c9fd7db1[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_ce3ef138b9b68ce6cbd24bc0ac523197,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_82bf9de363c4991e284a9eb1d7f98b15[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_29bbfe77c50c4e306a98e24cb3231937,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_07dd5b8feab49bd1531879868d1a47c8[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_e94c1a79b01b77036d1e10c5905226e7,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_aabca0cf9ec61437cac2071a4d84169d[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_7bc68dd86074abbbadfb37b697aad9c3,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_d08a2af9c57d3cc0df83f64ed6b0d57c[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_6c1bfba1552fd15a08b06b9629289fac,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_2debbde585c68cb8935788fe025b535a[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_a6337bb3f098dad7fceccaf1ffc6ef1d,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_28ccf5aca68fae1bc2d554e99c2d1f7c[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_425eacbdab318574de4f7593e459ba20,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_c4b1018f93f6fa3f84d17b922e767845[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_007b1015561fd31a0a79e53cee997f45,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_b6160858731b2684083e353197f9d49c[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_b77b2419f41736162fe62ccd3e90d1e7,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_9fe1bd2dee61b3704ff9802b632666e7[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_facde89a0995adb70792b37150243d89,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_ffee842bddd985fe7a418390d949635e[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_f04ee87a787a0e183031aa90daecfe57,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_8622faedf1da344ad38cb19f1e89a1e5[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_8bc198a6066a4771196df5935a87a478,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_1fa2e6e7cfcbb8668e3a57785aaba616[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_6a0302a961bbb90e3b508982c1a9206a,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_b2006fb6cb206fdff897022a44125608[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_c1b7f1cb9c474daeb3a32d3e23b304f6,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_bf4a5c85101b379e96888793df958cc8[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_493dab8b9fefa75701bb28cb83516eef,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_6e6cbb56b9f45255330f0369d632311e[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_f49f79704283e789198120ea420da20d,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_3c12a876bbfa9e0fae0c312db5f1be31[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_df8edc9da2034626137eb463b200ff4b,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_2a52617faf6ebe490dc0f50d4ddac367[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_7aa08413a81dfe842ad4f2a45bad6d93,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_536788a02cdfd94703cc1da37730f8ee[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_dccbd9fb8575ca586b862742380b10a9,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_7f41ac9e73686a2740667a3e19828c92[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_45decafd61b16c532bf73e492de601aa,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_d0e4b026d06241a41b13563d1ee7f2ab[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_1a6dc362e292fb8fd1b1edefff877ecd,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_448f4c2b677c05d552f998699e29351a[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_32901ce96151273bde4ff40af352a897,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_33b7418d2bf64c1781fb3f5a772b51e6[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_2857a7965567687ed97d14a73cacef0c,
#if 0
stepfunc_a1c81250204a4cd38be0d1c22011f72a,
#endif
NULL}; 
static const BulletStepFunc bullet_2a9b2ac594823d77ae56e3a32ba12f01[] = {
stepfunc_61693af9f33d79e049e7ee8bcb52de6d,
stepfunc_d66c08a50f32580900d95f00bf5b7fdc,
stepfunc_331fb430dfc3b793445f5b549f305fea,
stepfunc_60d6a12cabd9258c710ed17f4bdae259,
stepfunc_dc1279723eb597ad417310d7859fd88e,
stepfunc_d16e2d79134f84d647ed97d6b6b046b1,
stepfunc_543ea0b3e425efea35ca586204735bd7,
stepfunc_fce1ea6078ad5d2dde85608fd64ea1e9,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_a1c81250204a4cd38be0d1c22011f72a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (10);    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9605d0d50de5acebe0ae96d42b1e8f21(BulletInfo *p) { 
p->wait = 12; 
}
static void stepfunc_2857a7965567687ed97d14a73cacef0c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(20069, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9604d530b79210bcb56507e3e9836fc6(BulletInfo *p) { 
p->wait = 8; 
}
static void stepfunc_84bb4ec273da81ce0e132e20f32e7b82(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_33b7418d2bf64c1781fb3f5a772b51e6;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_32901ce96151273bde4ff40af352a897(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(18112, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(234, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_194cb427fb0df23698ec6a8436b3e5a8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(475, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_448f4c2b677c05d552f998699e29351a;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1a6dc362e292fb8fd1b1edefff877ecd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(16256, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(227, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_366e4b0ee262457534c3f28736f53d7c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(450, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d0e4b026d06241a41b13563d1ee7f2ab;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_45decafd61b16c532bf73e492de601aa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(14500, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(222, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_bcf79081a964bbe57d853458be8a11aa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(425, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7f41ac9e73686a2740667a3e19828c92;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_dccbd9fb8575ca586b862742380b10a9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(12844, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(216, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_bed681fb6e22a6bad0a16d91a2a5c4e6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_536788a02cdfd94703cc1da37730f8ee;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_7aa08413a81dfe842ad4f2a45bad6d93(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(11289, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_78e161c5d18eb3350183233211f0d4a4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(375, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2a52617faf6ebe490dc0f50d4ddac367;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_df8edc9da2034626137eb463b200ff4b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(9834, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(204, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9da55d8d7d0359a6be4bec5e22c03e3b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3c12a876bbfa9e0fae0c312db5f1be31;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f49f79704283e789198120ea420da20d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(8479, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(198, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_73811469feb0e61ff23d24184e5d5c86(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(325, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e6cbb56b9f45255330f0369d632311e;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_493dab8b9fefa75701bb28cb83516eef(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(7225, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(192, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d87e454e9098031f2fe83d3961eb612d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bf4a5c85101b379e96888793df958cc8;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c1b7f1cb9c474daeb3a32d3e23b304f6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(6071, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(186, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_20afff497fbb45dd41ca9c4e78e8d85f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(275, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b2006fb6cb206fdff897022a44125608;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_6a0302a961bbb90e3b508982c1a9206a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(5017, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8b2e271550d50a5c89e8b385c6cf7f74(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1fa2e6e7cfcbb8668e3a57785aaba616;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8bc198a6066a4771196df5935a87a478(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(4064, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(174, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b8258afdd1aa885a4a177e52bf7d0b75(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8622faedf1da344ad38cb19f1e89a1e5;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f04ee87a787a0e183031aa90daecfe57(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(3211, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(168, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5acaeedc34a1e3c36067471740a2bf01(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ffee842bddd985fe7a418390d949635e;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_facde89a0995adb70792b37150243d89(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(2458, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(162, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8d7907a4bf3f665bbba78849815e5920(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(175, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fe1bd2dee61b3704ff9802b632666e7;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b77b2419f41736162fe62ccd3e90d1e7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(1806, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(156, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_834cd10c08355d7b41f2e499fc413331(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b6160858731b2684083e353197f9d49c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_007b1015561fd31a0a79e53cee997f45(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(1254, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_3b84a3d7c4cf994a5a6545c727656153(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(125, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c4b1018f93f6fa3f84d17b922e767845;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_425eacbdab318574de4f7593e459ba20(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(802, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(144, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e5cc138d9b0e6538c1a4581acbcd0af9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_28ccf5aca68fae1bc2d554e99c2d1f7c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_a6337bb3f098dad7fceccaf1ffc6ef1d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(451, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(138, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e4385b313c4b03f218b4b704d20d44d8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2debbde585c68cb8935788fe025b535a;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_6c1bfba1552fd15a08b06b9629289fac(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(200, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(132, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_499d8543234e566de75a898ca83d8e80(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d08a2af9c57d3cc0df83f64ed6b0d57c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_7bc68dd86074abbbadfb37b697aad9c3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(70, 100))*(FixedPointNum(50, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(126, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_a8ad2960b6244b652910d1060148f11d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_aabca0cf9ec61437cac2071a4d84169d;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e94c1a79b01b77036d1e10c5905226e7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(20069, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_69bb6acce0cbc569e620e96706326565(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_07dd5b8feab49bd1531879868d1a47c8;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_29bbfe77c50c4e306a98e24cb3231937(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(18112, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(234, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b9721c371969df78327a4c6dd1f689c3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(475, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_82bf9de363c4991e284a9eb1d7f98b15;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ce3ef138b9b68ce6cbd24bc0ac523197(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(16256, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(227, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_a243a0291932645c3d9d80071f8946a4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(450, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_28d75cbf32649210060ef851c9fd7db1;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ee5a5ec6a0aaa4ce9ca88e7f2d850c2a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(14500, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(222, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_96095486a1547f9d6727fb168deb65f9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(425, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_21a59bca1a65ef75faa70b6c92bf6b31;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_457fdfacc5a3c25dd85286cea1b4a5db(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(12844, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(216, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_be483536617b24109f45789d7c0edd56(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8f1d63884590f5555fd84858e4ebefea;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5d5fe0663c48f820e0089d253ed1714e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(11289, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_229bf47b3fac1d9abac5e1e7ef723bd1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(375, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5e3e00d2bda179d85654a48610db1ab3;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_56e87fcdf463d7b8f584aa43b2b0542c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(9834, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(204, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ae8ab415fb5fe74a507d4ea8b2627ac4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_170c56f7e126a95c1deeec255f107fe9;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_0c409ec289b2815bdd343790517f10ac(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(8479, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(198, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d978c484da78744cd4186ec87bdb6573(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(325, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cc29dd867fd453d4c8710077329fca84;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_58def3b621d1ff1674c297b6c8fd1093(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(7225, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(192, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ab8e91ecce7d66fb07093f8b64477801(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_201d4a1c1d66d75af25fc9eb65c5bcdc;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_71bacfa6322daf4b0c6215df91b78fc0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(6071, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(186, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c691417d81b66c33a7668382410790d6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(275, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ce35631c524604138087e12b0403987c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_904820e6d7723e9f9959122755ce11e9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(5017, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_7458df2e26a47b582c06a40468c4ae2a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d0cc9b7ca7f3a71f3f230ee0411cd06b;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b970856ffd05c2b09077b305e5e8de30(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(4064, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(174, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ad30160506a39db8e8d00f75d559fedd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_464e70a99d742a97e1bd13c2658169f1;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_986717bdf5e72cbee99eb30d8c563a21(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(3211, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(168, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ee27b29b49a3cd966fc22535807f627f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_380b84fb6b0c6573839150e40389af5e;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_62f76c2f9fc68200b64adb2c1c05745f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(2458, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(162, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e2c8186336043fcdbab4bd2e7bf4e2e2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(175, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e5fbbe7d9f4de679afce2ab62e79b4fa;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_909f9cce29f126dc4f11765406e39de9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(1806, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(156, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_64e702562b46b13ddab2d5b03845cd2a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_76d0726bfde497a707811f7c796722fc;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1698efda28274a98634454de4a7e2e8d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(1254, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_0d60605728c8f650810c15c5051e6d1c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(125, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f45ef13eb41e2a5c8aaeb9a154b2400d;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5e51c07bc8b80ef18e97ec1f68bb3f4c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(802, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(144, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9b4c89b6bb4901e6dd2889b8c25c5665(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f6f6757158752b6e58d731658807296e;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_83c93e5c01b018b5649aa7b2806cb335(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(451, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(138, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2d929fdd40a08ab855582bf8d6b32d51(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e113e98b4e7981423033b0bee2d0066;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_cebe500d21cf3810e1f036ec9af8d289(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(200, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(132, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2636b1fcca27958b2785beaaebca42b1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1d8cf13e34f246ecb8f1f290111db1e0;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_91bdf0e7f31d98dfd4ecdd4beae81ca6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(-FixedPointNum(70, 100))*(FixedPointNum(50, 100))/(FixedPointNum(1416, 100))+(((FixedPointNum::random())))*FixedPointNum(255));    p->lastBulletSpeed = (FixedPointNum(126, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_a1c81250204a4cd38be0d1c22011f72a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c74bb5f3c58c34cfd794ffb9eb280491(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_62914a617f12628b7a84ab973f9db447;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_61693af9f33d79e049e7ee8bcb52de6d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_69595ddbb0b9649fcc19e53df93d56cc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ac6454234aa5930b350680220c8523a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_65ae14773b51b49e7946eea09b4c14ef;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_96bebef18ddea0755767ae124165b1fb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87665eca1f83c33fd6121f92914e5f92;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d7cbadd8f325e03d26123d43cd41c24b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ecb0695c5d1cc889bd130c7104b02bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d11a9d5b5eb864be1643a0d851cf6b96;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98ab223d009bd1cce4bc437c60fb73a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5054931ebdc3b2548e1bf23b61b8c480;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e20ef2113278d292a0e87e23cef95802;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5412212e356097a81647102e36969c1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_03460918e853b7381c9eb72296e0ab15;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ff354c09e736d4d13ed402bd70b94265;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5cb5341ed8931ebf3b07149e3f4819d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e25f994b0c135535493380e78d4973b3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ea1cea3b6c62cc8372c8bac977414ab;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cbbc5405f63932458b4526b7ece1d9cf;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0656548e8559b0cd7d49bf962f8027c7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b04800858852b94c3015e5818e89a025;  }
}
p->wait = 144; 
}
static void stepfunc_d66c08a50f32580900d95f00bf5b7fdc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d33f0fad2bdf44082324445c2e1b0387;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_20e9c02600193882a300db77f6023df1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dde13b10e5628c23afb4e16eece51267;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d3cb6c6dc9ba501808621427e2829d88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ed835b29c64a3e79808b385f7278d21e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b8ec3c35d8532df566d0287b17e382e4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d33766d939b76e0c1abeb779ccf8b88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_485a87b143f565fa044d7c7712eec0d1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_450dbbb17f3d7eb754933066f5de5aeb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b3e6c91d1f9fef7be04142707c042a3c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5ef496a4df69d5a67e0eca5366f2fd0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d91b2cd679e94f74ea319e5893e364f3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16065322f7009081f345b8b2fe056570;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_327d1f00cd6107eba0ea19115dfcbeb8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_377de773f32748efb0346d188159e201;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_93d28989a84fc77d28b53f3d9f8445d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_19e7278cd97d23574eb2ad48fd3c8775;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_59b4c56445fde754eb1b5be365d9f1c2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89920dccafa82108e8d6f56abfa0155e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_642c855093637562e59650732549680b;  }
}
p->wait = 120; 
}
static void stepfunc_331fb430dfc3b793445f5b549f305fea(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_69595ddbb0b9649fcc19e53df93d56cc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ac6454234aa5930b350680220c8523a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_65ae14773b51b49e7946eea09b4c14ef;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_96bebef18ddea0755767ae124165b1fb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87665eca1f83c33fd6121f92914e5f92;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d7cbadd8f325e03d26123d43cd41c24b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ecb0695c5d1cc889bd130c7104b02bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d11a9d5b5eb864be1643a0d851cf6b96;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98ab223d009bd1cce4bc437c60fb73a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5054931ebdc3b2548e1bf23b61b8c480;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e20ef2113278d292a0e87e23cef95802;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5412212e356097a81647102e36969c1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_03460918e853b7381c9eb72296e0ab15;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ff354c09e736d4d13ed402bd70b94265;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5cb5341ed8931ebf3b07149e3f4819d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e25f994b0c135535493380e78d4973b3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ea1cea3b6c62cc8372c8bac977414ab;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cbbc5405f63932458b4526b7ece1d9cf;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0656548e8559b0cd7d49bf962f8027c7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b04800858852b94c3015e5818e89a025;  }
}
p->wait = 96; 
}
static void stepfunc_60d6a12cabd9258c710ed17f4bdae259(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d33f0fad2bdf44082324445c2e1b0387;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_20e9c02600193882a300db77f6023df1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dde13b10e5628c23afb4e16eece51267;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d3cb6c6dc9ba501808621427e2829d88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ed835b29c64a3e79808b385f7278d21e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b8ec3c35d8532df566d0287b17e382e4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d33766d939b76e0c1abeb779ccf8b88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_485a87b143f565fa044d7c7712eec0d1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_450dbbb17f3d7eb754933066f5de5aeb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b3e6c91d1f9fef7be04142707c042a3c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5ef496a4df69d5a67e0eca5366f2fd0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d91b2cd679e94f74ea319e5893e364f3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16065322f7009081f345b8b2fe056570;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_327d1f00cd6107eba0ea19115dfcbeb8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_377de773f32748efb0346d188159e201;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_93d28989a84fc77d28b53f3d9f8445d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_19e7278cd97d23574eb2ad48fd3c8775;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_59b4c56445fde754eb1b5be365d9f1c2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89920dccafa82108e8d6f56abfa0155e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_642c855093637562e59650732549680b;  }
}
p->wait = 72; 
}
static void stepfunc_dc1279723eb597ad417310d7859fd88e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_69595ddbb0b9649fcc19e53df93d56cc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ac6454234aa5930b350680220c8523a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_65ae14773b51b49e7946eea09b4c14ef;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_96bebef18ddea0755767ae124165b1fb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87665eca1f83c33fd6121f92914e5f92;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d7cbadd8f325e03d26123d43cd41c24b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ecb0695c5d1cc889bd130c7104b02bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d11a9d5b5eb864be1643a0d851cf6b96;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98ab223d009bd1cce4bc437c60fb73a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5054931ebdc3b2548e1bf23b61b8c480;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e20ef2113278d292a0e87e23cef95802;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5412212e356097a81647102e36969c1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_03460918e853b7381c9eb72296e0ab15;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ff354c09e736d4d13ed402bd70b94265;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5cb5341ed8931ebf3b07149e3f4819d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e25f994b0c135535493380e78d4973b3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ea1cea3b6c62cc8372c8bac977414ab;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cbbc5405f63932458b4526b7ece1d9cf;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0656548e8559b0cd7d49bf962f8027c7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b04800858852b94c3015e5818e89a025;  }
}
p->wait = 48; 
}
static void stepfunc_d16e2d79134f84d647ed97d6b6b046b1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d33f0fad2bdf44082324445c2e1b0387;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_20e9c02600193882a300db77f6023df1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dde13b10e5628c23afb4e16eece51267;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d3cb6c6dc9ba501808621427e2829d88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ed835b29c64a3e79808b385f7278d21e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b8ec3c35d8532df566d0287b17e382e4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d33766d939b76e0c1abeb779ccf8b88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_485a87b143f565fa044d7c7712eec0d1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_450dbbb17f3d7eb754933066f5de5aeb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b3e6c91d1f9fef7be04142707c042a3c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5ef496a4df69d5a67e0eca5366f2fd0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d91b2cd679e94f74ea319e5893e364f3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16065322f7009081f345b8b2fe056570;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_327d1f00cd6107eba0ea19115dfcbeb8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_377de773f32748efb0346d188159e201;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_93d28989a84fc77d28b53f3d9f8445d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_19e7278cd97d23574eb2ad48fd3c8775;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_59b4c56445fde754eb1b5be365d9f1c2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89920dccafa82108e8d6f56abfa0155e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_642c855093637562e59650732549680b;  }
}
p->wait = 24; 
}
static void stepfunc_543ea0b3e425efea35ca586204735bd7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_69595ddbb0b9649fcc19e53df93d56cc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ac6454234aa5930b350680220c8523a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_65ae14773b51b49e7946eea09b4c14ef;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_96bebef18ddea0755767ae124165b1fb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87665eca1f83c33fd6121f92914e5f92;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d7cbadd8f325e03d26123d43cd41c24b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ecb0695c5d1cc889bd130c7104b02bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d11a9d5b5eb864be1643a0d851cf6b96;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98ab223d009bd1cce4bc437c60fb73a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5054931ebdc3b2548e1bf23b61b8c480;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e20ef2113278d292a0e87e23cef95802;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5412212e356097a81647102e36969c1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_03460918e853b7381c9eb72296e0ab15;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ff354c09e736d4d13ed402bd70b94265;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5cb5341ed8931ebf3b07149e3f4819d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e25f994b0c135535493380e78d4973b3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ea1cea3b6c62cc8372c8bac977414ab;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cbbc5405f63932458b4526b7ece1d9cf;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0656548e8559b0cd7d49bf962f8027c7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b04800858852b94c3015e5818e89a025;  }
}
p->wait = 192; 
}
static void stepfunc_fce1ea6078ad5d2dde85608fd64ea1e9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d33f0fad2bdf44082324445c2e1b0387;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_20e9c02600193882a300db77f6023df1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dde13b10e5628c23afb4e16eece51267;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d3cb6c6dc9ba501808621427e2829d88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ed835b29c64a3e79808b385f7278d21e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b8ec3c35d8532df566d0287b17e382e4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d33766d939b76e0c1abeb779ccf8b88;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_485a87b143f565fa044d7c7712eec0d1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_450dbbb17f3d7eb754933066f5de5aeb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b3e6c91d1f9fef7be04142707c042a3c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5ef496a4df69d5a67e0eca5366f2fd0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d91b2cd679e94f74ea319e5893e364f3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16065322f7009081f345b8b2fe056570;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_327d1f00cd6107eba0ea19115dfcbeb8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_377de773f32748efb0346d188159e201;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_93d28989a84fc77d28b53f3d9f8445d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_19e7278cd97d23574eb2ad48fd3c8775;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_59b4c56445fde754eb1b5be365d9f1c2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89920dccafa82108e8d6f56abfa0155e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_642c855093637562e59650732549680b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_69595ddbb0b9649fcc19e53df93d56cc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ac6454234aa5930b350680220c8523a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_65ae14773b51b49e7946eea09b4c14ef;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_96bebef18ddea0755767ae124165b1fb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87665eca1f83c33fd6121f92914e5f92;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d7cbadd8f325e03d26123d43cd41c24b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ecb0695c5d1cc889bd130c7104b02bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d11a9d5b5eb864be1643a0d851cf6b96;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98ab223d009bd1cce4bc437c60fb73a8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5054931ebdc3b2548e1bf23b61b8c480;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e20ef2113278d292a0e87e23cef95802;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b5412212e356097a81647102e36969c1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_03460918e853b7381c9eb72296e0ab15;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ff354c09e736d4d13ed402bd70b94265;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5cb5341ed8931ebf3b07149e3f4819d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e25f994b0c135535493380e78d4973b3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ea1cea3b6c62cc8372c8bac977414ab;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cbbc5405f63932458b4526b7ece1d9cf;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0656548e8559b0cd7d49bf962f8027c7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b04800858852b94c3015e5818e89a025;  }
}
p->wait = 200; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_bdda80179c2aecc6b03ea1bfd7b21fe4(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_2a9b2ac594823d77ae56e3a32ba12f01; }}


