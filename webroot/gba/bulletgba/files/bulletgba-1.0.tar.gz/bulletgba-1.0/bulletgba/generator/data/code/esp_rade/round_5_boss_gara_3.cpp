// XXX uniqID XXX 898960ac300c5959d4ae6bbb646b85e6 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b7fe01f70a80cf2d6355c2546368d73e(BulletInfo *p); 
static void stepfunc_c33a225e8c1ff0c722cc860114ef262e(BulletInfo *p); 
static void stepfunc_943495301369c22d3916f18d0ef54747(BulletInfo *p); 
static void stepfunc_b224021b17294e60ab21c8472b33382c(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_77d44b67e7cd4e27738a7a5be441cd25(BulletInfo *p); 
static void stepfunc_2d954ab574cd9220e46f4f19ece5d276(BulletInfo *p); 
static void stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030(BulletInfo *p); 
static void stepfunc_50222cb466874f5502b44750f9730b97(BulletInfo *p); 
static void stepfunc_842acf418acd48728fbacc571c51d3af(BulletInfo *p); 
static void stepfunc_6a0b276e37a5a5b5231d204001162fa5(BulletInfo *p); 
static void stepfunc_490e2542dd7fe393a757089f08bc9839(BulletInfo *p); 
static void stepfunc_489697b32650491e1d71673d6f4c30ab(BulletInfo *p); 
static void stepfunc_fabd84ece939141ba3587089dcd81b67(BulletInfo *p); 
static void stepfunc_4220d5dbcf0c0093b3f78216f6fe679c(BulletInfo *p); 
static void stepfunc_96f5b60f6258a4a0622108a3fefd8578(BulletInfo *p); 
static void stepfunc_dc7569e2e965da70ed308ac1c48ce6f4(BulletInfo *p); 
static void stepfunc_3a4e2a761f6702236dec5850fb7a7b30(BulletInfo *p); 
static void stepfunc_05d46a7fb2c6f3f6df51ee24512ef11f(BulletInfo *p); 
static void stepfunc_47a4968a162b222bfc23501b98ce5451(BulletInfo *p); 
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p); 
static void stepfunc_81618eae29ebdbc526aaa66a33beb7a4(BulletInfo *p); 
static void stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(BulletInfo *p); 
static void stepfunc_30d271b21bf1d1ecc03de43291853b7e(BulletInfo *p); 


static const BulletStepFunc bullet_d8c35253cd1c9958552bb774e134165d[] = {
stepfunc_b7fe01f70a80cf2d6355c2546368d73e,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_943495301369c22d3916f18d0ef54747,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_0f77776ccd7c2b5712edd8421dff6953[] = {
stepfunc_77d44b67e7cd4e27738a7a5be441cd25,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_2d954ab574cd9220e46f4f19ece5d276,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_aec9340d89ab4cc7092db94977c4872f[] = {
stepfunc_50222cb466874f5502b44750f9730b97,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_842acf418acd48728fbacc571c51d3af,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b13dfc136dee0f395f2877dabde88822[] = {
stepfunc_6a0b276e37a5a5b5231d204001162fa5,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_490e2542dd7fe393a757089f08bc9839,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b005b5dc3ca5b5826b467d0180314b9e[] = {
stepfunc_489697b32650491e1d71673d6f4c30ab,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_fabd84ece939141ba3587089dcd81b67,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_64c00a75cd00a342c3950e082fd6e879[] = {
stepfunc_4220d5dbcf0c0093b3f78216f6fe679c,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_96f5b60f6258a4a0622108a3fefd8578,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_4fd54031ed0892d7713c41042b6df623[] = {
stepfunc_dc7569e2e965da70ed308ac1c48ce6f4,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_3a4e2a761f6702236dec5850fb7a7b30,
#if 0
stepfunc_b224021b17294e60ab21c8472b33382c,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3f5ea55faffa8cb698dd8d8efc2091e1[] = {
stepfunc_05d46a7fb2c6f3f6df51ee24512ef11f,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_47a4968a162b222bfc23501b98ce5451,
#if 0
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3a3ac838ede32fcafbdc815c4c5a9e28[] = {
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_81618eae29ebdbc526aaa66a33beb7a4,
#if 0
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3dd93423e7fd8a39ed06741148e3c47b[] = {
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9c7fbe21beb3f25d7f8bd852402c60c8[] = {
stepfunc_30d271b21bf1d1ecc03de43291853b7e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_b224021b17294e60ab21c8472b33382c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(100, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_943495301369c22d3916f18d0ef54747(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(71, 100));    p->lastBulletSpeed = (FixedPointNum(90, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_b224021b17294e60ab21c8472b33382c(p);}
p->wait = 15; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_b7fe01f70a80cf2d6355c2546368d73e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-501, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_c33a225e8c1ff0c722cc860114ef262e(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-100, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_2d954ab574cd9220e46f4f19ece5d276(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-71, 100));    p->lastBulletSpeed = (FixedPointNum(90, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030(p);}
p->wait = 15; 
}
static void stepfunc_77d44b67e7cd4e27738a7a5be441cd25(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(501, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_842acf418acd48728fbacc571c51d3af(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_b224021b17294e60ab21c8472b33382c(p);}
p->wait = 15; 
}
static void stepfunc_50222cb466874f5502b44750f9730b97(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(1630, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_490e2542dd7fe393a757089f08bc9839(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-142, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030(p);}
p->wait = 15; 
}
static void stepfunc_6a0b276e37a5a5b5231d204001162fa5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1630, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_fabd84ece939141ba3587089dcd81b67(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(213, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_b224021b17294e60ab21c8472b33382c(p);}
p->wait = 15; 
}
static void stepfunc_489697b32650491e1d71673d6f4c30ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(3763, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_96f5b60f6258a4a0622108a3fefd8578(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-213, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030(p);}
p->wait = 15; 
}
static void stepfunc_4220d5dbcf0c0093b3f78216f6fe679c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3763, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_3a4e2a761f6702236dec5850fb7a7b30(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(284, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_b224021b17294e60ab21c8472b33382c(p);}
p->wait = 15; 
}
static void stepfunc_dc7569e2e965da70ed308ac1c48ce6f4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(5895, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_47a4968a162b222bfc23501b98ce5451(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-284, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_7eb3e0a5c5d44a794853d5b53ef1f030(p);}
p->wait = 15; 
}
static void stepfunc_05d46a7fb2c6f3f6df51ee24512ef11f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-5895, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
p->wait = 15; 
}
static void stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(212, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_81618eae29ebdbc526aaa66a33beb7a4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-212, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_c1982a1f7d17f8161d8d29002c76d6b5(p);}
p->wait = 20; 
}
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_30d271b21bf1d1ecc03de43291853b7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3a3ac838ede32fcafbdc815c4c5a9e28;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3a3ac838ede32fcafbdc815c4c5a9e28;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4958, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3a3ac838ede32fcafbdc815c4c5a9e28;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4958, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3a3ac838ede32fcafbdc815c4c5a9e28;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7083, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3f5ea55faffa8cb698dd8d8efc2091e1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-7083, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4fd54031ed0892d7713c41042b6df623;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_64c00a75cd00a342c3950e082fd6e879;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b005b5dc3ca5b5826b467d0180314b9e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6020, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b13dfc136dee0f395f2877dabde88822;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6020, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_aec9340d89ab4cc7092db94977c4872f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (51);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f77776ccd7c2b5712edd8421dff6953;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-51);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d8c35253cd1c9958552bb774e134165d;  }
}
p->wait = 700; 
}


void genBulletFunc_898960ac300c5959d4ae6bbb646b85e6(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_9c7fbe21beb3f25d7f8bd852402c60c8; }}


