// XXX uniqID XXX f170e3155d79ce84b0759075202141a9 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b6298100f05d8f9e6fb8327ec89fd415(BulletInfo *p); 
static void stepfunc_5c751f9adc2466c644bf7b3830bec63d(BulletInfo *p); 
static void stepfunc_3fc9ae448484aa68ef1df02e44811bc2(BulletInfo *p); 
static void stepfunc_2d8d20189622e956f048cb5da553d994(BulletInfo *p); 
static void stepfunc_c41ec3abe7cf4308216395b879728bae(BulletInfo *p); 
static void stepfunc_9ea574d5cc99fb98c44468122abddefe(BulletInfo *p); 
static void stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_18c229d339bfd72e57ae69ab576f7118[] = {
stepfunc_b6298100f05d8f9e6fb8327ec89fd415,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_2d8d20189622e956f048cb5da553d994,
stepfunc_c41ec3abe7cf4308216395b879728bae,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0,
#if 0
stepfunc_9ea574d5cc99fb98c44468122abddefe,
#endif
stepfunc_2d8d20189622e956f048cb5da553d994,
stepfunc_b6298100f05d8f9e6fb8327ec89fd415,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_3fc9ae448484aa68ef1df02e44811bc2,
#if 0
stepfunc_5c751f9adc2466c644bf7b3830bec63d,
#endif
stepfunc_2d8d20189622e956f048cb5da553d994,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_5c751f9adc2466c644bf7b3830bec63d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2257, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_3fc9ae448484aa68ef1df02e44811bc2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2408, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_5c751f9adc2466c644bf7b3830bec63d(p);}
p->wait = 3; 
}
static void stepfunc_9ea574d5cc99fb98c44468122abddefe(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-2257, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_294e75d28f4ca4ac4a7af49a333f8bb0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-2408, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_9ea574d5cc99fb98c44468122abddefe(p);}
p->wait = 3; 
}
static void stepfunc_b6298100f05d8f9e6fb8327ec89fd415(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(3187, 100)*FixedPointNum::random()*FixedPointNum(6375, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_5c751f9adc2466c644bf7b3830bec63d(p);}
p->wait = 3; 
}
static void stepfunc_2d8d20189622e956f048cb5da553d994(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_c41ec3abe7cf4308216395b879728bae(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(3187, 100)*FixedPointNum::random()*FixedPointNum(6375, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_9ea574d5cc99fb98c44468122abddefe(p);}
p->wait = 3; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_f170e3155d79ce84b0759075202141a9(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_18c229d339bfd72e57ae69ab576f7118; }}


