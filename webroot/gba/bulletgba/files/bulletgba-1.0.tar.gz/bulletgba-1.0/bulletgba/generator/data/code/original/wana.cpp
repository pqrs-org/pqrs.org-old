// XXX uniqID XXX ee86adac8dc14e80ab23623426f8977c XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p); 
static void stepfunc_8bc96aa659d3d724cd21077d533633eb(BulletInfo *p); 
static void stepfunc_454dc9b0f152908e6aec3a74c2182957(BulletInfo *p); 
static void stepfunc_35488f0f655d962cb6c90ab631a883b7(BulletInfo *p); 
static void stepfunc_330f4620962dde89d8964d912d186dff(BulletInfo *p); 
static void stepfunc_95d09293641486bf1fc264f563bc0c92(BulletInfo *p); 
static void stepfunc_412730fa4163223a08e0029060f86aae(BulletInfo *p); 
static void stepfunc_d25f041d1330fb684f74052f8cef8705(BulletInfo *p); 
static void stepfunc_48983d361fdfb220d270afbd809e5275(BulletInfo *p); 
static void stepfunc_b081cf93edacfa1fb04362d825956005(BulletInfo *p); 
static void stepfunc_0497b95ca0d0771fd4f03f764a46997c(BulletInfo *p); 
static void stepfunc_945c5227b7412f622246d61af4fe7ebe(BulletInfo *p); 


static const BulletStepFunc bullet_ea773b8ed549a8c7e2f6943b2dcfb8f4[] = {
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_ff07d8b33e24c3a70f76702923d058d6[] = {
stepfunc_8bc96aa659d3d724cd21077d533633eb,
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_454dc9b0f152908e6aec3a74c2182957,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_95d09293641486bf1fc264f563bc0c92,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_48983d361fdfb220d270afbd809e5275,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_148dc895b4849b3e11faf4f6587ba175[] = {
stepfunc_b081cf93edacfa1fb04362d825956005,
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_945c5227b7412f622246d61af4fe7ebe,
#if 0
stepfunc_d25f041d1330fb684f74052f8cef8705,
#if 0
stepfunc_412730fa4163223a08e0029060f86aae,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_0497b95ca0d0771fd4f03f764a46997c,
#if 0
stepfunc_330f4620962dde89d8964d912d186dff,
#if 0
stepfunc_35488f0f655d962cb6c90ab631a883b7,
#endif
#endif
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static void stepfunc_412730fa4163223a08e0029060f86aae(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(4, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d25f041d1330fb684f74052f8cef8705(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2550, 100));    p->lastBulletSpeed = (FixedPointNum(106, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_412730fa4163223a08e0029060f86aae(p);}
}
static void stepfunc_35488f0f655d962cb6c90ab631a883b7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-4, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_330f4620962dde89d8964d912d186dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2550, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_35488f0f655d962cb6c90ab631a883b7(p);}
}
static void stepfunc_48983d361fdfb220d270afbd809e5275(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2195, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_35488f0f655d962cb6c90ab631a883b7(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_330f4620962dde89d8964d912d186dff(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_d25f041d1330fb684f74052f8cef8705(p);}
p->wait = 15; 
}
static void stepfunc_95d09293641486bf1fc264f563bc0c92(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2195, 100));    p->lastBulletSpeed = (FixedPointNum(106, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_412730fa4163223a08e0029060f86aae(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_d25f041d1330fb684f74052f8cef8705(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_d25f041d1330fb684f74052f8cef8705(p);}
p->wait = 15; 
}
static void stepfunc_454dc9b0f152908e6aec3a74c2182957(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2195, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_35488f0f655d962cb6c90ab631a883b7(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_330f4620962dde89d8964d912d186dff(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_330f4620962dde89d8964d912d186dff(p);}
p->wait = 15; 
}
static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_8bc96aa659d3d724cd21077d533633eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15229, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea773b8ed549a8c7e2f6943b2dcfb8f4;  }
}
}
static void stepfunc_0497b95ca0d0771fd4f03f764a46997c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2904, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_35488f0f655d962cb6c90ab631a883b7(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_330f4620962dde89d8964d912d186dff(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_330f4620962dde89d8964d912d186dff(p);}
p->wait = 15; 
}
static void stepfunc_945c5227b7412f622246d61af4fe7ebe(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2904, 100));    p->lastBulletSpeed = (FixedPointNum(106, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_412730fa4163223a08e0029060f86aae(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_d25f041d1330fb684f74052f8cef8705(p);}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_d25f041d1330fb684f74052f8cef8705(p);}
p->wait = 15; 
}
static void stepfunc_b081cf93edacfa1fb04362d825956005(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-708, 100));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea773b8ed549a8c7e2f6943b2dcfb8f4;  }
}
}


void genBulletFunc_ee86adac8dc14e80ab23623426f8977c(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_148dc895b4849b3e11faf4f6587ba175; }  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_ff07d8b33e24c3a70f76702923d058d6; }}


