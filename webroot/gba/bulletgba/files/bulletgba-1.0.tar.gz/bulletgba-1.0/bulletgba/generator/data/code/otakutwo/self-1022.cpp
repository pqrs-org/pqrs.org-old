// XXX uniqID XXX a6d5bb33187ce8ba0fddeb84413586f2 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_1521831f906eb81bc08cc8a1452a3d1e(BulletInfo *p); 
static void stepfunc_f11562396d23ebc50620c6c03ec21f63(BulletInfo *p); 
static void stepfunc_52845df3630496f730a9bc9c5afcea0a(BulletInfo *p); 
static void stepfunc_e26af0ca2a64ea6d337ac3303c870813(BulletInfo *p); 
static void stepfunc_b4f24be965d7cd68a6661e2b8de5e31e(BulletInfo *p); 
static void stepfunc_08d8b17cab48acf64b7e7d517d608429(BulletInfo *p); 
static void stepfunc_71a16d9e5c44673763d1d2a52589d198(BulletInfo *p); 
static void stepfunc_de6d23ae5815166e296dbf12beaed99c(BulletInfo *p); 
static void stepfunc_d57336d65aeb2805e9688b97cf6897d5(BulletInfo *p); 
static void stepfunc_755c75a2c5d6ca3062bbd31e34867e9c(BulletInfo *p); 
static void stepfunc_2785447dfc2036e80c2f638852acd612(BulletInfo *p); 
static void stepfunc_063904ec73a0a5e55d6458668d3d8543(BulletInfo *p); 
static void stepfunc_7e5fa65c05198f9149faa63d0c0c4bef(BulletInfo *p); 
static void stepfunc_23801a476bad388367d9d0936281a0c8(BulletInfo *p); 
static void stepfunc_0948176b614f2ab5b15e415e1bda69f3(BulletInfo *p); 
static void stepfunc_0996ac81d1cbcde01932f1d922861811(BulletInfo *p); 
static void stepfunc_31c5f73fe1d22139cced932523a5262d(BulletInfo *p); 
static void stepfunc_d62d2a189dc961d7b68304b86c5b6c16(BulletInfo *p); 
static void stepfunc_6cede38f081578a6e288a73357750a5f(BulletInfo *p); 
static void stepfunc_b1d126eb8885f645e6772d7c5f63f698(BulletInfo *p); 
static void stepfunc_0d8b0f310b04f3b0ca1d2b0daa6ea01f(BulletInfo *p); 
static void stepfunc_03f7ea02a972947c8a2d469a7a51d13d(BulletInfo *p); 
static void stepfunc_8df7784b876fe561a230d040dce81647(BulletInfo *p); 
static void stepfunc_1a5c6cf86f999e213e6998610d66a53d(BulletInfo *p); 
static void stepfunc_f189a6de6c48ecc8ef124ae2b7b50c30(BulletInfo *p); 
static void stepfunc_2becca843689936b1138703d539e2a41(BulletInfo *p); 
static void stepfunc_7e706fd91482b75a92db83c813f7dc19(BulletInfo *p); 
static void stepfunc_0a5f43c8a7f4cb9e18593dbf7528d497(BulletInfo *p); 
static void stepfunc_9c90ed99040b4d9bc71de5da31f8e785(BulletInfo *p); 
static void stepfunc_06b1b7144d50961b4218e94d71232cf8(BulletInfo *p); 
static void stepfunc_b59c36be316a2539bf966af59a2aeb78(BulletInfo *p); 
static void stepfunc_8af320f016a41f0ea72a9e8ff30f3573(BulletInfo *p); 
static void stepfunc_4622a7d6444392fdfc648e21df8d4a9e(BulletInfo *p); 
static void stepfunc_dafca37970c0bb9616d6741566618fdd(BulletInfo *p); 
static void stepfunc_edd3278bd0dab21067bcadece1b5e8c7(BulletInfo *p); 
static void stepfunc_fc08d3fdbd6b58a1675a8ae2fa0ba80c(BulletInfo *p); 
static void stepfunc_19a0933a38901a9db2d374429590eeb9(BulletInfo *p); 
static void stepfunc_1e9d8cc7897b819079e02bc8c84de3b5(BulletInfo *p); 
static void stepfunc_00de3b4dd1d31174e601de4be8dc3747(BulletInfo *p); 
static void stepfunc_22192a015f5a3a26ef8e7e78ca27dd5d(BulletInfo *p); 
static void stepfunc_ae731ad7d892d5c83f9e08207528a8ff(BulletInfo *p); 
static void stepfunc_c9debd46790adbc34a86c62ba3db4087(BulletInfo *p); 
static void stepfunc_aeddde36e23295bd29f288da30b5b7f1(BulletInfo *p); 
static void stepfunc_e303de2197a2d5e52c96660a2b7e5218(BulletInfo *p); 
static void stepfunc_9651f9f293cc9594797c26b137f5c516(BulletInfo *p); 
static void stepfunc_937f7b7b567b32b456916597fb483f24(BulletInfo *p); 
static void stepfunc_60fc092d32a0db199a3b2ce7dd9b520e(BulletInfo *p); 
static void stepfunc_32d972b6018f43c1333526f2914b1895(BulletInfo *p); 
static void stepfunc_31d74cee9b4d6a475746a24d2d752a0c(BulletInfo *p); 
static void stepfunc_4742236406c3582f5e6a6262aff45d6c(BulletInfo *p); 
static void stepfunc_566931a4ef36fb930ead1f5f499bcb17(BulletInfo *p); 
static void stepfunc_7830628cd4e692db0730cc334a93a312(BulletInfo *p); 
static void stepfunc_4052635f5a23fabe3c3f0e02caae91e4(BulletInfo *p); 
static void stepfunc_22edb5159f6d8de1a93f2af43bf71a0a(BulletInfo *p); 
static void stepfunc_047d4ba8da10946be912a6c5bf388680(BulletInfo *p); 
static void stepfunc_3fd53ed2a26737e919f2fae178d4c9ff(BulletInfo *p); 
static void stepfunc_7389c5b257aa87c8c6b6b3024040721f(BulletInfo *p); 
static void stepfunc_d19534a4c7b1b4f2898d2f7695455a2e(BulletInfo *p); 
static void stepfunc_8af460bcfbf7359ae4e4aeb3b9ac19bd(BulletInfo *p); 
static void stepfunc_e8628e3d7149f6eda384fbc4b0920fb1(BulletInfo *p); 
static void stepfunc_80faf2195133c9626f2dc647d6369aed(BulletInfo *p); 
static void stepfunc_3ac2485cf96c73d43c951d49ccf99c66(BulletInfo *p); 
static void stepfunc_67ea8ff65d1a56e46b4b23654e5a2790(BulletInfo *p); 
static void stepfunc_656a741ff6ca5a922aa09cbb3fe34a06(BulletInfo *p); 
static void stepfunc_1b56c5331a60530d55d796f36be398bc(BulletInfo *p); 
static void stepfunc_a4d668a6f5e9f30daf44837c3c41923a(BulletInfo *p); 
static void stepfunc_59a27dc77625c27acefafdbb8eaf3e0b(BulletInfo *p); 
static void stepfunc_22dd36789b33f6dbb02f47fc3cb96d42(BulletInfo *p); 
static void stepfunc_bec1edc9f8ccd174bd6d899b2d487973(BulletInfo *p); 
static void stepfunc_19bb8df780744ac740aedecc7d67f169(BulletInfo *p); 
static void stepfunc_7981fb618e24c37daf9290287abd842e(BulletInfo *p); 
static void stepfunc_62679efe22a78705cdb3c099bc59c176(BulletInfo *p); 
static void stepfunc_51227b9c426b7bfe82c303e29995853d(BulletInfo *p); 
static void stepfunc_d5a9309c08dc5551e98e27cd47ac3e0d(BulletInfo *p); 
static void stepfunc_f29ad99fbfd40678fcef8762465bdb49(BulletInfo *p); 
static void stepfunc_c3b86e86be7cee5bc8eef680d8be8d95(BulletInfo *p); 
static void stepfunc_3472458e2c88ae8f2c064b4971a384b3(BulletInfo *p); 
static void stepfunc_cfe462079ed2eb0e32fb8a704276fbaa(BulletInfo *p); 
static void stepfunc_92474d12243300683f6f33d9a030b0c9(BulletInfo *p); 
static void stepfunc_30bf5cfd68ed5ea7ba2514b0dd2f059a(BulletInfo *p); 
static void stepfunc_f89560310faf1bb463c146a268157e1c(BulletInfo *p); 
static void stepfunc_46d71a9c72997bb25b85633f93b75fc6(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_267b712f9f1c4e184097e0415976c252[] = {
stepfunc_1521831f906eb81bc08cc8a1452a3d1e,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_52845df3630496f730a9bc9c5afcea0a,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_e26af0ca2a64ea6d337ac3303c870813,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_b4f24be965d7cd68a6661e2b8de5e31e,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_08d8b17cab48acf64b7e7d517d608429,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_71a16d9e5c44673763d1d2a52589d198,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_de6d23ae5815166e296dbf12beaed99c,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_d57336d65aeb2805e9688b97cf6897d5,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_755c75a2c5d6ca3062bbd31e34867e9c,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_2785447dfc2036e80c2f638852acd612,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_063904ec73a0a5e55d6458668d3d8543,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_7e5fa65c05198f9149faa63d0c0c4bef,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_23801a476bad388367d9d0936281a0c8,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_0948176b614f2ab5b15e415e1bda69f3,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_0996ac81d1cbcde01932f1d922861811,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_31c5f73fe1d22139cced932523a5262d,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_d62d2a189dc961d7b68304b86c5b6c16,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_6cede38f081578a6e288a73357750a5f,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_b1d126eb8885f645e6772d7c5f63f698,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_0d8b0f310b04f3b0ca1d2b0daa6ea01f,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_03f7ea02a972947c8a2d469a7a51d13d,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_8df7784b876fe561a230d040dce81647,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_1a5c6cf86f999e213e6998610d66a53d,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_f189a6de6c48ecc8ef124ae2b7b50c30,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_2becca843689936b1138703d539e2a41,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_7e706fd91482b75a92db83c813f7dc19,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_0a5f43c8a7f4cb9e18593dbf7528d497,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_9c90ed99040b4d9bc71de5da31f8e785,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_06b1b7144d50961b4218e94d71232cf8,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_b59c36be316a2539bf966af59a2aeb78,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_8af320f016a41f0ea72a9e8ff30f3573,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_4622a7d6444392fdfc648e21df8d4a9e,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_dafca37970c0bb9616d6741566618fdd,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_edd3278bd0dab21067bcadece1b5e8c7,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_fc08d3fdbd6b58a1675a8ae2fa0ba80c,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_19a0933a38901a9db2d374429590eeb9,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_1e9d8cc7897b819079e02bc8c84de3b5,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_00de3b4dd1d31174e601de4be8dc3747,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_22192a015f5a3a26ef8e7e78ca27dd5d,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_ae731ad7d892d5c83f9e08207528a8ff,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_c9debd46790adbc34a86c62ba3db4087,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_aeddde36e23295bd29f288da30b5b7f1,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_e303de2197a2d5e52c96660a2b7e5218,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_9651f9f293cc9594797c26b137f5c516,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_937f7b7b567b32b456916597fb483f24,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_60fc092d32a0db199a3b2ce7dd9b520e,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_32d972b6018f43c1333526f2914b1895,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_31d74cee9b4d6a475746a24d2d752a0c,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_4742236406c3582f5e6a6262aff45d6c,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_566931a4ef36fb930ead1f5f499bcb17,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_7830628cd4e692db0730cc334a93a312,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_4052635f5a23fabe3c3f0e02caae91e4,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_22edb5159f6d8de1a93f2af43bf71a0a,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_047d4ba8da10946be912a6c5bf388680,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_3fd53ed2a26737e919f2fae178d4c9ff,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_7389c5b257aa87c8c6b6b3024040721f,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_d19534a4c7b1b4f2898d2f7695455a2e,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_8af460bcfbf7359ae4e4aeb3b9ac19bd,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_e8628e3d7149f6eda384fbc4b0920fb1,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_80faf2195133c9626f2dc647d6369aed,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_3ac2485cf96c73d43c951d49ccf99c66,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_67ea8ff65d1a56e46b4b23654e5a2790,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_656a741ff6ca5a922aa09cbb3fe34a06,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_1b56c5331a60530d55d796f36be398bc,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_a4d668a6f5e9f30daf44837c3c41923a,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_59a27dc77625c27acefafdbb8eaf3e0b,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_22dd36789b33f6dbb02f47fc3cb96d42,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_bec1edc9f8ccd174bd6d899b2d487973,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_19bb8df780744ac740aedecc7d67f169,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_7981fb618e24c37daf9290287abd842e,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_62679efe22a78705cdb3c099bc59c176,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_51227b9c426b7bfe82c303e29995853d,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_d5a9309c08dc5551e98e27cd47ac3e0d,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_f29ad99fbfd40678fcef8762465bdb49,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_c3b86e86be7cee5bc8eef680d8be8d95,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_3472458e2c88ae8f2c064b4971a384b3,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_cfe462079ed2eb0e32fb8a704276fbaa,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_92474d12243300683f6f33d9a030b0c9,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_30bf5cfd68ed5ea7ba2514b0dd2f059a,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_f89560310faf1bb463c146a268157e1c,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_46d71a9c72997bb25b85633f93b75fc6,
#if 0
stepfunc_f11562396d23ebc50620c6c03ec21f63,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_f11562396d23ebc50620c6c03ec21f63(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(473, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1521831f906eb81bc08cc8a1452a3d1e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2833, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_52845df3630496f730a9bc9c5afcea0a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2797, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_e26af0ca2a64ea6d337ac3303c870813(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2762, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_b4f24be965d7cd68a6661e2b8de5e31e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2727, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_08d8b17cab48acf64b7e7d517d608429(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2691, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_71a16d9e5c44673763d1d2a52589d198(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2656, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_de6d23ae5815166e296dbf12beaed99c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2620, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_d57336d65aeb2805e9688b97cf6897d5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2585, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_755c75a2c5d6ca3062bbd31e34867e9c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2550, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_2785447dfc2036e80c2f638852acd612(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2514, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_063904ec73a0a5e55d6458668d3d8543(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2479, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_7e5fa65c05198f9149faa63d0c0c4bef(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2443, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_23801a476bad388367d9d0936281a0c8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2408, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_0948176b614f2ab5b15e415e1bda69f3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2372, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_0996ac81d1cbcde01932f1d922861811(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2337, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_31c5f73fe1d22139cced932523a5262d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2302, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_d62d2a189dc961d7b68304b86c5b6c16(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2266, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_6cede38f081578a6e288a73357750a5f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2231, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_b1d126eb8885f645e6772d7c5f63f698(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2195, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_0d8b0f310b04f3b0ca1d2b0daa6ea01f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2160, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_03f7ea02a972947c8a2d469a7a51d13d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2125, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_8df7784b876fe561a230d040dce81647(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2089, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_1a5c6cf86f999e213e6998610d66a53d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2054, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_f189a6de6c48ecc8ef124ae2b7b50c30(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2018, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_2becca843689936b1138703d539e2a41(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1983, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_7e706fd91482b75a92db83c813f7dc19(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1947, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_0a5f43c8a7f4cb9e18593dbf7528d497(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1912, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_9c90ed99040b4d9bc71de5da31f8e785(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1877, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_06b1b7144d50961b4218e94d71232cf8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1841, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_b59c36be316a2539bf966af59a2aeb78(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1806, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_8af320f016a41f0ea72a9e8ff30f3573(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1770, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_4622a7d6444392fdfc648e21df8d4a9e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1735, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_dafca37970c0bb9616d6741566618fdd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(17))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_edd3278bd0dab21067bcadece1b5e8c7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1664, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_fc08d3fdbd6b58a1675a8ae2fa0ba80c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1629, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_19a0933a38901a9db2d374429590eeb9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1593, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_1e9d8cc7897b819079e02bc8c84de3b5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1558, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_00de3b4dd1d31174e601de4be8dc3747(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1522, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_22192a015f5a3a26ef8e7e78ca27dd5d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1487, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_ae731ad7d892d5c83f9e08207528a8ff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1452, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_c9debd46790adbc34a86c62ba3db4087(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1416, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_aeddde36e23295bd29f288da30b5b7f1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1381, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_e303de2197a2d5e52c96660a2b7e5218(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1345, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_9651f9f293cc9594797c26b137f5c516(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1310, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_937f7b7b567b32b456916597fb483f24(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1275, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_60fc092d32a0db199a3b2ce7dd9b520e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1239, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_32d972b6018f43c1333526f2914b1895(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1204, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_31d74cee9b4d6a475746a24d2d752a0c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1168, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_4742236406c3582f5e6a6262aff45d6c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1133, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_566931a4ef36fb930ead1f5f499bcb17(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1097, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_7830628cd4e692db0730cc334a93a312(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1062, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_4052635f5a23fabe3c3f0e02caae91e4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1027, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_22edb5159f6d8de1a93f2af43bf71a0a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(991, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_047d4ba8da10946be912a6c5bf388680(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(956, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_3fd53ed2a26737e919f2fae178d4c9ff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(920, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_7389c5b257aa87c8c6b6b3024040721f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(885, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_d19534a4c7b1b4f2898d2f7695455a2e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(850, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_8af460bcfbf7359ae4e4aeb3b9ac19bd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(814, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_e8628e3d7149f6eda384fbc4b0920fb1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(779, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_80faf2195133c9626f2dc647d6369aed(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(743, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_3ac2485cf96c73d43c951d49ccf99c66(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(708, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_67ea8ff65d1a56e46b4b23654e5a2790(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(672, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_656a741ff6ca5a922aa09cbb3fe34a06(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(637, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_1b56c5331a60530d55d796f36be398bc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(602, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_a4d668a6f5e9f30daf44837c3c41923a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(566, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_59a27dc77625c27acefafdbb8eaf3e0b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(531, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_22dd36789b33f6dbb02f47fc3cb96d42(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(495, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_bec1edc9f8ccd174bd6d899b2d487973(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(460, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_19bb8df780744ac740aedecc7d67f169(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(425, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_7981fb618e24c37daf9290287abd842e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(389, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_62679efe22a78705cdb3c099bc59c176(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(354, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_51227b9c426b7bfe82c303e29995853d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(318, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_d5a9309c08dc5551e98e27cd47ac3e0d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(283, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_f29ad99fbfd40678fcef8762465bdb49(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(247, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_c3b86e86be7cee5bc8eef680d8be8d95(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(212, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_3472458e2c88ae8f2c064b4971a384b3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(177, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_cfe462079ed2eb0e32fb8a704276fbaa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(141, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_92474d12243300683f6f33d9a030b0c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(106, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_30bf5cfd68ed5ea7ba2514b0dd2f059a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(70, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_f89560310faf1bb463c146a268157e1c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(35, 100))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_46d71a9c72997bb25b85633f93b75fc6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0))+FixedPointNum::random()*FixedPointNum(212, 100)-FixedPointNum(3081, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 19; ++i) { 
stepfunc_f11562396d23ebc50620c6c03ec21f63(p);}
p->wait = 4; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_a6d5bb33187ce8ba0fddeb84413586f2(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_267b712f9f1c4e184097e0415976c252; }}


