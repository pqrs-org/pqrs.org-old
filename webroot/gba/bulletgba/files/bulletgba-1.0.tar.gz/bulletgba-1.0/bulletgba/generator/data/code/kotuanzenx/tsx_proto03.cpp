// XXX uniqID XXX 60a81b481bb4446645b841f047be49ee XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_2e3a2702df62210acdf70bf1d2ba863f(BulletInfo *p); 
static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p); 
static void stepfunc_3a13811803e63751cbc725bdc3b40cfd(BulletInfo *p); 
static void stepfunc_605f94a306373651b37be75f1e443586(BulletInfo *p); 
static void stepfunc_4e2edb17cf031dba6801b2d6bfb43c5e(BulletInfo *p); 
static void stepfunc_fd8cc79c210f9eab7d0b2aa8d96ea79a(BulletInfo *p); 
static void stepfunc_7163f379c14a045a081c9cf16ff60034(BulletInfo *p); 
static void stepfunc_f353b4a583ebeeb29447c7fab92abe41(BulletInfo *p); 
static void stepfunc_21f7f2f1da4684de1dc8c7874cbc737e(BulletInfo *p); 
static void stepfunc_3868a0cd447001a67af2ea4050dff7fc(BulletInfo *p); 
static void stepfunc_59dd011edfac87acb43a34492bd261bb(BulletInfo *p); 
static void stepfunc_d47b34ffc5c8499c8482f86d620ee2a1(BulletInfo *p); 
static void stepfunc_1c31356784e72e00138f3f6d119d1dca(BulletInfo *p); 
static void stepfunc_f782f453f6ad9c23ff2b1121ad31a875(BulletInfo *p); 
static void stepfunc_4fa23d879fa0491f8b07c7a8eb4b2285(BulletInfo *p); 
static void stepfunc_30eaa70ca5c6fb38ae22209177ae7065(BulletInfo *p); 
static void stepfunc_c2462046f27d2f862239b7f49ab1fc71(BulletInfo *p); 
static void stepfunc_4c421aa1f952fa217fde3b1972c6a4a3(BulletInfo *p); 
static void stepfunc_ed97661496fd6ddab2aa559a5c254cbb(BulletInfo *p); 
static void stepfunc_77d11f8386c4595bdf9c28562763a67e(BulletInfo *p); 
static void stepfunc_a1d4e25bda33a6d127915d20f01f88a2(BulletInfo *p); 
static void stepfunc_4137f33ca3e1b1cbb668a7f08b2df27a(BulletInfo *p); 
static void stepfunc_4816f83102d1d80ee694ef23e8d71065(BulletInfo *p); 
static void stepfunc_4be5ca55992f32fc7b14831552468c54(BulletInfo *p); 
static void stepfunc_b6e28783c6dc00e9da77c55edd289fdf(BulletInfo *p); 
static void stepfunc_ed12c8f0639cd94e0784ffcdb23e5e85(BulletInfo *p); 
static void stepfunc_3236c0817fc2c0718bc87ae801949215(BulletInfo *p); 
static void stepfunc_6af4ce3269b1f144b143b8efb2c2e0f3(BulletInfo *p); 
static void stepfunc_37e77ea97c9b9420f41a7a9eea29b06d(BulletInfo *p); 
static void stepfunc_872f3c9ba6c9ecec1c50e34b521db386(BulletInfo *p); 
static void stepfunc_74cd276a83c34be799f4686e925259e0(BulletInfo *p); 
static void stepfunc_dd03b4c155759cb8d735b40f741a2f65(BulletInfo *p); 
static void stepfunc_81d4dea576d01206beea6d8c1eaa7e71(BulletInfo *p); 
static void stepfunc_ae28776ef42d7ff2045aa76bcbdd6f9d(BulletInfo *p); 
static void stepfunc_96cd3a2ada99f49a8f8a2eb5f94104d9(BulletInfo *p); 
static void stepfunc_d803b58b96b9c74b680b0672f1c602c6(BulletInfo *p); 
static void stepfunc_9b2d7c1a8cb22f122d239eb5a193c78b(BulletInfo *p); 
static void stepfunc_18f03e1393a4439192fb8233f16d48b6(BulletInfo *p); 
static void stepfunc_fccaf8df0bc24983900e128f4a2bec56(BulletInfo *p); 
static void stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf(BulletInfo *p); 


static const BulletStepFunc bullet_98c5df61dbba89824ba45b9d8f2cddcb[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_5cba335d6232e08fdad36f61e002f698[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_2e3a2702df62210acdf70bf1d2ba863f,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_f0c4e7df1818bc575e7545208a06193e[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_3a13811803e63751cbc725bdc3b40cfd,
NULL}; 
static const BulletStepFunc bullet_52fa28d701e3a61daf7f5b9b84fe090d[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_605f94a306373651b37be75f1e443586,
NULL}; 
static const BulletStepFunc bullet_974a50f4fe3037aead83f6d80caf7c8a[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_4e2edb17cf031dba6801b2d6bfb43c5e,
NULL}; 
static const BulletStepFunc bullet_693f5590cacce1a82c9b9edb906337a9[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_fd8cc79c210f9eab7d0b2aa8d96ea79a,
NULL}; 
static const BulletStepFunc bullet_74820cd780f4643ce29d3ca61089b99b[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_7163f379c14a045a081c9cf16ff60034,
NULL}; 
static const BulletStepFunc bullet_c0868b00c366dd784cdbd90b172f47e7[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_f353b4a583ebeeb29447c7fab92abe41,
NULL}; 
static const BulletStepFunc bullet_99783adade2416ef8be2ce45e9b8d7dd[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_21f7f2f1da4684de1dc8c7874cbc737e,
NULL}; 
static const BulletStepFunc bullet_0427be193854947d8945865f4ef7a297[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_3868a0cd447001a67af2ea4050dff7fc,
NULL}; 
static const BulletStepFunc bullet_067a9e0d6012563fdaa4ae37ec087a15[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_59dd011edfac87acb43a34492bd261bb,
NULL}; 
static const BulletStepFunc bullet_e530d6e5d6c25b5f36330a1657f718e6[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_d47b34ffc5c8499c8482f86d620ee2a1,
NULL}; 
static const BulletStepFunc bullet_c1175ae3745ca7fcd7234a9390a751c9[] = {
stepfunc_1c31356784e72e00138f3f6d119d1dca,
NULL}; 
static const BulletStepFunc bullet_4825cfcf7780f3c876e415c378040d7c[] = {
stepfunc_f782f453f6ad9c23ff2b1121ad31a875,
NULL}; 
static const BulletStepFunc bullet_33756e713881be177398da3df028a236[] = {
stepfunc_4fa23d879fa0491f8b07c7a8eb4b2285,
NULL}; 
static const BulletStepFunc bullet_3fe03ce3fc37b85b9edff38ee95cd98c[] = {
stepfunc_30eaa70ca5c6fb38ae22209177ae7065,
NULL}; 
static const BulletStepFunc bullet_2f9a1dce1ec76cbc65e50da1a5bd3ef6[] = {
stepfunc_c2462046f27d2f862239b7f49ab1fc71,
NULL}; 
static const BulletStepFunc bullet_bc39b8bc967e7a2598528ec067a1cd42[] = {
stepfunc_4c421aa1f952fa217fde3b1972c6a4a3,
NULL}; 
static const BulletStepFunc bullet_454e690e2579b45926107b28f00c4404[] = {
stepfunc_ed97661496fd6ddab2aa559a5c254cbb,
NULL}; 
static const BulletStepFunc bullet_0805cbcd09cd3af8b9a8a0ad4605ed1b[] = {
stepfunc_77d11f8386c4595bdf9c28562763a67e,
NULL}; 
static const BulletStepFunc bullet_f0a930e8fecb21feee482844959154f7[] = {
stepfunc_a1d4e25bda33a6d127915d20f01f88a2,
NULL}; 
static const BulletStepFunc bullet_985864ee82d2e074ca48e4b450622332[] = {
stepfunc_4137f33ca3e1b1cbb668a7f08b2df27a,
NULL}; 
static const BulletStepFunc bullet_3d4dfd941a6fb998086ef41dc34cc5ab[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_4816f83102d1d80ee694ef23e8d71065,
NULL}; 
static const BulletStepFunc bullet_081988f87e618bab0426a0815a487904[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_4be5ca55992f32fc7b14831552468c54,
NULL}; 
static const BulletStepFunc bullet_d3510529e963251db03dee1a31e61360[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_b6e28783c6dc00e9da77c55edd289fdf,
NULL}; 
static const BulletStepFunc bullet_5ea63128fec44d678984d7743ddd4e19[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_ed12c8f0639cd94e0784ffcdb23e5e85,
NULL}; 
static const BulletStepFunc bullet_eedd45879d58b31bb0167878ba4018d8[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_3236c0817fc2c0718bc87ae801949215,
NULL}; 
static const BulletStepFunc bullet_cafdc8d792e0d9264eaccf84d4e057b2[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_6af4ce3269b1f144b143b8efb2c2e0f3,
NULL}; 
static const BulletStepFunc bullet_b72fc65a77671952f91f3aae1400aa04[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_37e77ea97c9b9420f41a7a9eea29b06d,
NULL}; 
static const BulletStepFunc bullet_ff71b0f42fe2379c3b6a3e5a6f921e89[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_872f3c9ba6c9ecec1c50e34b521db386,
NULL}; 
static const BulletStepFunc bullet_4a812cc1d6305ca820a79ed685aa4259[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_74cd276a83c34be799f4686e925259e0,
NULL}; 
static const BulletStepFunc bullet_71999779bc219f05a996c45cea054b1d[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_dd03b4c155759cb8d735b40f741a2f65,
NULL}; 
static const BulletStepFunc bullet_9ea846940313bb7c4535e2e277356909[] = {
stepfunc_81d4dea576d01206beea6d8c1eaa7e71,
#if 0
stepfunc_ae28776ef42d7ff2045aa76bcbdd6f9d,
#endif
NULL}; 
static const BulletStepFunc bullet_42381ac10c3566813b69e821975fd22b[] = {
stepfunc_96cd3a2ada99f49a8f8a2eb5f94104d9,
#if 0
stepfunc_d803b58b96b9c74b680b0672f1c602c6,
#endif
NULL}; 
static const BulletStepFunc bullet_4d30549faac6218532c64fc786d030b0[] = {
stepfunc_9b2d7c1a8cb22f122d239eb5a193c78b,
stepfunc_18f03e1393a4439192fb8233f16d48b6,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_fccaf8df0bc24983900e128f4a2bec56,
stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_ae28776ef42d7ff2045aa76bcbdd6f9d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-401, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_81d4dea576d01206beea6d8c1eaa7e71(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1204, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_ae28776ef42d7ff2045aa76bcbdd6f9d(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d803b58b96b9c74b680b0672f1c602c6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-100, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_96cd3a2ada99f49a8f8a2eb5f94104d9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(301, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 6; ++i) { 
stepfunc_d803b58b96b9c74b680b0672f1c602c6(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_fccaf8df0bc24983900e128f4a2bec56(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_42381ac10c3566813b69e821975fd22b;  }
}
p->wait = 20; 
}
static void stepfunc_2b2e70bf3151ebffcdf63b7a9c06fdaf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9ea846940313bb7c4535e2e277356909;  }
}
p->wait = 20; 
}
static void stepfunc_4137f33ca3e1b1cbb668a7f08b2df27a(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(480, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_4816f83102d1d80ee694ef23e8d71065(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_985864ee82d2e074ca48e4b450622332;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-8378, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_985864ee82d2e074ca48e4b450622332;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_a1d4e25bda33a6d127915d20f01f88a2(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(459, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_4be5ca55992f32fc7b14831552468c54(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f0a930e8fecb21feee482844959154f7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-8529, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f0a930e8fecb21feee482844959154f7;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_77d11f8386c4595bdf9c28562763a67e(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(440, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_b6e28783c6dc00e9da77c55edd289fdf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0805cbcd09cd3af8b9a8a0ad4605ed1b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-8680, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0805cbcd09cd3af8b9a8a0ad4605ed1b;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ed97661496fd6ddab2aa559a5c254cbb(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(420, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_ed12c8f0639cd94e0784ffcdb23e5e85(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_454e690e2579b45926107b28f00c4404;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-8830, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_454e690e2579b45926107b28f00c4404;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4c421aa1f952fa217fde3b1972c6a4a3(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(4 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_3236c0817fc2c0718bc87ae801949215(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc39b8bc967e7a2598528ec067a1cd42;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-8981, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc39b8bc967e7a2598528ec067a1cd42;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c2462046f27d2f862239b7f49ab1fc71(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(380, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_6af4ce3269b1f144b143b8efb2c2e0f3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2f9a1dce1ec76cbc65e50da1a5bd3ef6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-9131, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2f9a1dce1ec76cbc65e50da1a5bd3ef6;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_30eaa70ca5c6fb38ae22209177ae7065(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(360, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_37e77ea97c9b9420f41a7a9eea29b06d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3fe03ce3fc37b85b9edff38ee95cd98c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-9282, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3fe03ce3fc37b85b9edff38ee95cd98c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4fa23d879fa0491f8b07c7a8eb4b2285(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(340, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_872f3c9ba6c9ecec1c50e34b521db386(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_33756e713881be177398da3df028a236;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-9432, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_33756e713881be177398da3df028a236;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f782f453f6ad9c23ff2b1121ad31a875(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(320, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_74cd276a83c34be799f4686e925259e0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4825cfcf7780f3c876e415c378040d7c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-9583, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4825cfcf7780f3c876e415c378040d7c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1c31356784e72e00138f3f6d119d1dca(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(3 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_dd03b4c155759cb8d735b40f741a2f65(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c1175ae3745ca7fcd7234a9390a751c9;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-9733, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c1175ae3745ca7fcd7234a9390a751c9;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8c70c27911ef6743c3f1dbcbe5487d8d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(48, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_71999779bc219f05a996c45cea054b1d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(96, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a812cc1d6305ca820a79ed685aa4259;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(144, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ff71b0f42fe2379c3b6a3e5a6f921e89;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(192, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b72fc65a77671952f91f3aae1400aa04;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cafdc8d792e0d9264eaccf84d4e057b2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(288, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_eedd45879d58b31bb0167878ba4018d8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(336, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5ea63128fec44d678984d7743ddd4e19;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(384, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d3510529e963251db03dee1a31e61360;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(432, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_081988f87e618bab0426a0815a487904;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(480, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3d4dfd941a6fb998086ef41dc34cc5ab;  }
}
p->wait = 60; 
}
static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p) { 
p->wait = 9; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_3a13811803e63751cbc725bdc3b40cfd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_985864ee82d2e074ca48e4b450622332;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8378, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_985864ee82d2e074ca48e4b450622332;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_605f94a306373651b37be75f1e443586(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f0a930e8fecb21feee482844959154f7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8529, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f0a930e8fecb21feee482844959154f7;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4e2edb17cf031dba6801b2d6bfb43c5e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0805cbcd09cd3af8b9a8a0ad4605ed1b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8680, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0805cbcd09cd3af8b9a8a0ad4605ed1b;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_fd8cc79c210f9eab7d0b2aa8d96ea79a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_454e690e2579b45926107b28f00c4404;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8830, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_454e690e2579b45926107b28f00c4404;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_7163f379c14a045a081c9cf16ff60034(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc39b8bc967e7a2598528ec067a1cd42;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8981, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc39b8bc967e7a2598528ec067a1cd42;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f353b4a583ebeeb29447c7fab92abe41(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2f9a1dce1ec76cbc65e50da1a5bd3ef6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9131, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2f9a1dce1ec76cbc65e50da1a5bd3ef6;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_21f7f2f1da4684de1dc8c7874cbc737e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3fe03ce3fc37b85b9edff38ee95cd98c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9282, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3fe03ce3fc37b85b9edff38ee95cd98c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_3868a0cd447001a67af2ea4050dff7fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_33756e713881be177398da3df028a236;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9432, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_33756e713881be177398da3df028a236;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_59dd011edfac87acb43a34492bd261bb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4825cfcf7780f3c876e415c378040d7c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9583, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4825cfcf7780f3c876e415c378040d7c;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d47b34ffc5c8499c8482f86d620ee2a1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c1175ae3745ca7fcd7234a9390a751c9;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9733, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c1175ae3745ca7fcd7234a9390a751c9;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2e3a2702df62210acdf70bf1d2ba863f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(48, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e530d6e5d6c25b5f36330a1657f718e6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(96, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_067a9e0d6012563fdaa4ae37ec087a15;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(144, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0427be193854947d8945865f4ef7a297;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(192, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_99783adade2416ef8be2ce45e9b8d7dd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c0868b00c366dd784cdbd90b172f47e7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(288, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_74820cd780f4643ce29d3ca61089b99b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(336, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_693f5590cacce1a82c9b9edb906337a9;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(384, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_974a50f4fe3037aead83f6d80caf7c8a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(432, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_52fa28d701e3a61daf7f5b9b84fe090d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(480, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f0c4e7df1818bc575e7545208a06193e;  }
}
p->wait = 60; 
}
static void stepfunc_9b2d7c1a8cb22f122d239eb5a193c78b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(5519, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5cba335d6232e08fdad36f61e002f698;  }
}
p->wait = 30; 
}
static void stepfunc_18f03e1393a4439192fb8233f16d48b6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-5519, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98c5df61dbba89824ba45b9d8f2cddcb;  }
}
}


void genBulletFunc_60a81b481bb4446645b841f047be49ee(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_4d30549faac6218532c64fc786d030b0; }}


