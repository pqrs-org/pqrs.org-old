// XXX uniqID XXX 8bc72083ba7198d43f8ed151e75f545b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_aef2ffde810a0f45e6787e7d89be142d(BulletInfo *p); 
static void stepfunc_ef46ca672ec92470bee7b02fce26c842(BulletInfo *p); 
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p); 
static void stepfunc_322a38dbd1884147b2503e2225d9c680(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_0570c0797228cf887d293d4f2d9523bd(BulletInfo *p); 
static void stepfunc_b7616e87f273063fc3ad87921b767c7a(BulletInfo *p); 
static void stepfunc_e0aa72f2c00704252f52dab960fadb45(BulletInfo *p); 
static void stepfunc_d4161b2ed777f39d87f93c5e8ff6d3c6(BulletInfo *p); 
static void stepfunc_400fcc2f24a69ae23405151dd21972c2(BulletInfo *p); 


static const BulletStepFunc bullet_2659eff9c8cb02469eb1cf5f784dc9f7[] = {
stepfunc_aef2ffde810a0f45e6787e7d89be142d,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_8c40135a836f85c9127ff29c00a9ca38[] = {
stepfunc_aef2ffde810a0f45e6787e7d89be142d,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_22b4939394b805c7111c348f7952ef29[] = {
stepfunc_b7616e87f273063fc3ad87921b767c7a,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_322a38dbd1884147b2503e2225d9c680,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_649cd1d47e2f4f3cd65b52ba7a0289c8[] = {
stepfunc_b7616e87f273063fc3ad87921b767c7a,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_0570c0797228cf887d293d4f2d9523bd,
#if 0
stepfunc_ef46ca672ec92470bee7b02fce26c842,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_bb8a256eff608493baceb002baa5fa67[] = {
stepfunc_e0aa72f2c00704252f52dab960fadb45,
stepfunc_d4161b2ed777f39d87f93c5e8ff6d3c6,
stepfunc_400fcc2f24a69ae23405151dd21972c2,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_ef46ca672ec92470bee7b02fce26c842(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1062, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_322a38dbd1884147b2503e2225d9c680(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-852, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 23; ++i) { 
stepfunc_ef46ca672ec92470bee7b02fce26c842(p);}
}
static void stepfunc_aef2ffde810a0f45e6787e7d89be142d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(255)*((FixedPointNum::random())));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 23; ++i) { 
stepfunc_ef46ca672ec92470bee7b02fce26c842(p);}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_0570c0797228cf887d293d4f2d9523bd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(852, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 23; ++i) { 
stepfunc_ef46ca672ec92470bee7b02fce26c842(p);}
}
static void stepfunc_b7616e87f273063fc3ad87921b767c7a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(255)*(FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 23; ++i) { 
stepfunc_ef46ca672ec92470bee7b02fce26c842(p);}
}
static void stepfunc_e0aa72f2c00704252f52dab960fadb45(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_649cd1d47e2f4f3cd65b52ba7a0289c8;  }
}
p->wait = 180; 
}
static void stepfunc_d4161b2ed777f39d87f93c5e8ff6d3c6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_22b4939394b805c7111c348f7952ef29;  }
}
p->wait = 210; 
}
static void stepfunc_400fcc2f24a69ae23405151dd21972c2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8c40135a836f85c9127ff29c00a9ca38;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2659eff9c8cb02469eb1cf5f784dc9f7;  }
}
p->wait = 240; 
}


void genBulletFunc_8bc72083ba7198d43f8ed151e75f545b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_bb8a256eff608493baceb002baa5fa67; }}


