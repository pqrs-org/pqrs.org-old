// XXX uniqID XXX baa24048519e6ac92ef4a825be02bd7b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_ffbb1716623ed07d93e755517993e80c(BulletInfo *p); 
static void stepfunc_2ed1cfeb22a16ec048556c649a6113d6(BulletInfo *p); 
static void stepfunc_f9d390e907bd6ac58aa657b94ae1d1df(BulletInfo *p); 
static void stepfunc_c17f62807a73b971fe95a53dc9e56c07(BulletInfo *p); 
static void stepfunc_996fd76fbe7adf354ae2cb07b9b1f318(BulletInfo *p); 
static void stepfunc_3e48ea7f07652343f936e065dc104f07(BulletInfo *p); 
static void stepfunc_8db32453299136b772706fff66a200a6(BulletInfo *p); 
static void stepfunc_76a9df98725d4591e78ec0e560f8cdd0(BulletInfo *p); 
static void stepfunc_4d5a51e5e6dbd583fe604fd5ca835037(BulletInfo *p); 
static void stepfunc_08feaa8d1346e67a0be1c42e32eda0c1(BulletInfo *p); 
static void stepfunc_a76e30365dd486cba6ad43585182fa86(BulletInfo *p); 
static void stepfunc_94858c56d922b9b6577e714a83dcce72(BulletInfo *p); 
static void stepfunc_691ad35d853cee456a0a950e48dba431(BulletInfo *p); 
static void stepfunc_2151445f9840a03d0a99face4a1c74f0(BulletInfo *p); 
static void stepfunc_b10669bc2e08a439a524d100f71fc99e(BulletInfo *p); 
static void stepfunc_7f4e97b69c872ef10bbd808d97ecf806(BulletInfo *p); 
static void stepfunc_f24401f484a1707a13fa29efa13848eb(BulletInfo *p); 
static void stepfunc_1570382722caf81ff47ecb094ce70a40(BulletInfo *p); 
static void stepfunc_4c783e0d267712a1a587d92eff844b78(BulletInfo *p); 
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_16e82c50d9df62821f061e4cbd5c754e[] = {
stepfunc_ffbb1716623ed07d93e755517993e80c,
#if 0
stepfunc_2ed1cfeb22a16ec048556c649a6113d6,
#endif
NULL}; 
static const BulletStepFunc bullet_40abe8b33b6acb824d5cf55202356412[] = {
stepfunc_f9d390e907bd6ac58aa657b94ae1d1df,
#if 0
stepfunc_2ed1cfeb22a16ec048556c649a6113d6,
#endif
NULL}; 
static const BulletStepFunc bullet_5657f397d4fdb39c63cf13e244c37149[] = {
stepfunc_c17f62807a73b971fe95a53dc9e56c07,
#if 0
stepfunc_2ed1cfeb22a16ec048556c649a6113d6,
#endif
NULL}; 
static const BulletStepFunc bullet_94bea47811776e67deb574dbcf820f42[] = {
stepfunc_996fd76fbe7adf354ae2cb07b9b1f318,
#if 0
stepfunc_2ed1cfeb22a16ec048556c649a6113d6,
#endif
NULL}; 
static const BulletStepFunc bullet_f6efb4ddf33372f5cbd82622dda51dfb[] = {
stepfunc_3e48ea7f07652343f936e065dc104f07,
#if 0
stepfunc_2ed1cfeb22a16ec048556c649a6113d6,
#endif
NULL}; 
static const BulletStepFunc bullet_bf4d1f3afe9a2d3d2f429ee9b6c66cb1[] = {
stepfunc_8db32453299136b772706fff66a200a6,
#if 0
stepfunc_76a9df98725d4591e78ec0e560f8cdd0,
#endif
NULL}; 
static const BulletStepFunc bullet_3ee6167d8ef8e0a0bb62350c6061b2fe[] = {
stepfunc_4d5a51e5e6dbd583fe604fd5ca835037,
#if 0
stepfunc_08feaa8d1346e67a0be1c42e32eda0c1,
#endif
NULL}; 
static const BulletStepFunc bullet_1216a4275a69dd4eef9153dfe1c869dc[] = {
stepfunc_a76e30365dd486cba6ad43585182fa86,
#if 0
stepfunc_94858c56d922b9b6577e714a83dcce72,
#endif
NULL}; 
static const BulletStepFunc bullet_4aeaabd163f394321c810c492333804c[] = {
stepfunc_691ad35d853cee456a0a950e48dba431,
stepfunc_2151445f9840a03d0a99face4a1c74f0,
stepfunc_b10669bc2e08a439a524d100f71fc99e,
stepfunc_2151445f9840a03d0a99face4a1c74f0,
stepfunc_7f4e97b69c872ef10bbd808d97ecf806,
stepfunc_f24401f484a1707a13fa29efa13848eb,
stepfunc_b10669bc2e08a439a524d100f71fc99e,
stepfunc_f24401f484a1707a13fa29efa13848eb,
stepfunc_691ad35d853cee456a0a950e48dba431,
stepfunc_2151445f9840a03d0a99face4a1c74f0,
stepfunc_b10669bc2e08a439a524d100f71fc99e,
stepfunc_2151445f9840a03d0a99face4a1c74f0,
stepfunc_7f4e97b69c872ef10bbd808d97ecf806,
stepfunc_f24401f484a1707a13fa29efa13848eb,
stepfunc_b10669bc2e08a439a524d100f71fc99e,
stepfunc_f24401f484a1707a13fa29efa13848eb,
stepfunc_1570382722caf81ff47ecb094ce70a40,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_4c783e0d267712a1a587d92eff844b78,
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_76a9df98725d4591e78ec0e560f8cdd0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (10);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_8db32453299136b772706fff66a200a6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_76a9df98725d4591e78ec0e560f8cdd0(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_08feaa8d1346e67a0be1c42e32eda0c1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (10);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4d5a51e5e6dbd583fe604fd5ca835037(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(352, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_08feaa8d1346e67a0be1c42e32eda0c1(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_94858c56d922b9b6577e714a83dcce72(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (10);    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a76e30365dd486cba6ad43585182fa86(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(705, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_94858c56d922b9b6577e714a83dcce72(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4c783e0d267712a1a587d92eff844b78(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1216a4275a69dd4eef9153dfe1c869dc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3ee6167d8ef8e0a0bb62350c6061b2fe;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bf4d1f3afe9a2d3d2f429ee9b6c66cb1;  }
}
p->wait = 30; 
}
static void stepfunc_2ed1cfeb22a16ec048556c649a6113d6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (10);    p->lastBulletSpeed = (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_ffbb1716623ed07d93e755517993e80c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(250, 100));    p->lastBulletSpeed = (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_2ed1cfeb22a16ec048556c649a6113d6(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c17f62807a73b971fe95a53dc9e56c07(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (5);    p->lastBulletSpeed = (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_2ed1cfeb22a16ec048556c649a6113d6(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f9d390e907bd6ac58aa657b94ae1d1df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (10);    p->lastBulletSpeed = (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_2ed1cfeb22a16ec048556c649a6113d6(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_996fd76fbe7adf354ae2cb07b9b1f318(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(750, 100));    p->lastBulletSpeed = (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_2ed1cfeb22a16ec048556c649a6113d6(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_3e48ea7f07652343f936e065dc104f07(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_2ed1cfeb22a16ec048556c649a6113d6(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_691ad35d853cee456a0a950e48dba431(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f6efb4ddf33372f5cbd82622dda51dfb;  }
}
p->wait = 20; 
}
static void stepfunc_2151445f9840a03d0a99face4a1c74f0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_94bea47811776e67deb574dbcf820f42;  }
}
p->wait = 20; 
}
static void stepfunc_b10669bc2e08a439a524d100f71fc99e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5657f397d4fdb39c63cf13e244c37149;  }
}
p->wait = 20; 
}
static void stepfunc_7f4e97b69c872ef10bbd808d97ecf806(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_40abe8b33b6acb824d5cf55202356412;  }
}
p->wait = 20; 
}
static void stepfunc_f24401f484a1707a13fa29efa13848eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16e82c50d9df62821f061e4cbd5c754e;  }
}
p->wait = 20; 
}
static void stepfunc_1570382722caf81ff47ecb094ce70a40(BulletInfo *p) { 
p->wait = 80; 
}
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_baa24048519e6ac92ef4a825be02bd7b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_4aeaabd163f394321c810c492333804c; }}


