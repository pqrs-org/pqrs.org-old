// XXX uniqID XXX 787632bc0978ee85cd7e72568d477922 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_4e424fafac06e04fc95c647baee065e4(BulletInfo *p); 
static void stepfunc_c6352b69aad7ae6d449db499cb6edb29(BulletInfo *p); 
static void stepfunc_d5896d5991ff28ffdb42906a3334466c(BulletInfo *p); 
static void stepfunc_32410ae043288c80d6d76e0ba4742a9c(BulletInfo *p); 
static void stepfunc_bc7da5e4026ef294b7397505d69c7e01(BulletInfo *p); 
static void stepfunc_096f606f929189f05f280668215fb552(BulletInfo *p); 
static void stepfunc_6a84a77b2e386fc842d8658f4247741a(BulletInfo *p); 
static void stepfunc_f3d83d570da3048da642d706c36e0bdc(BulletInfo *p); 
static void stepfunc_2dade856b6cb7102ffaf1467d7b27ef8(BulletInfo *p); 
static void stepfunc_df31fb86846ba60960c493f6a9b87543(BulletInfo *p); 
static void stepfunc_8f3fdac68b9b5a0ae85dd6d1a71eef14(BulletInfo *p); 
static void stepfunc_eef59e52926ffdfd38e1055796d29236(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_65093f3ffd7ca550c7d4c88702073f80(BulletInfo *p); 
static void stepfunc_55b337b1656f665830bdf556fee64f48(BulletInfo *p); 
static void stepfunc_21c0d5a41a5c0b8c40ae1bed2249ec32(BulletInfo *p); 
static void stepfunc_272613048de9d10dfcfa77e2cd41b1d7(BulletInfo *p); 


static const BulletStepFunc bullet_7beeb93954f1d1990dffa599cddebca2[] = {
stepfunc_4e424fafac06e04fc95c647baee065e4,
stepfunc_c6352b69aad7ae6d449db499cb6edb29,
stepfunc_d5896d5991ff28ffdb42906a3334466c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_bc7da5e4026ef294b7397505d69c7e01,
NULL}; 
static const BulletStepFunc bullet_d6c1a27822164cd267af5233b0fb3265[] = {
stepfunc_4e424fafac06e04fc95c647baee065e4,
stepfunc_c6352b69aad7ae6d449db499cb6edb29,
stepfunc_096f606f929189f05f280668215fb552,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_32410ae043288c80d6d76e0ba4742a9c,
stepfunc_bc7da5e4026ef294b7397505d69c7e01,
NULL}; 
static const BulletStepFunc bullet_d538e74936af2fe81ca4eed58329bbfc[] = {
stepfunc_6a84a77b2e386fc842d8658f4247741a,
#if 0
stepfunc_f3d83d570da3048da642d706c36e0bdc,
#endif
stepfunc_6a84a77b2e386fc842d8658f4247741a,
#if 0
stepfunc_2dade856b6cb7102ffaf1467d7b27ef8,
#endif
stepfunc_6a84a77b2e386fc842d8658f4247741a,
#if 0
stepfunc_df31fb86846ba60960c493f6a9b87543,
#endif
stepfunc_6a84a77b2e386fc842d8658f4247741a,
#if 0
stepfunc_8f3fdac68b9b5a0ae85dd6d1a71eef14,
#endif
NULL}; 
static const BulletStepFunc bullet_e416aff0617a4b99fbd4b5a7f8255dff[] = {
stepfunc_eef59e52926ffdfd38e1055796d29236,
stepfunc_eef59e52926ffdfd38e1055796d29236,
stepfunc_eef59e52926ffdfd38e1055796d29236,
stepfunc_eef59e52926ffdfd38e1055796d29236,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9aa3adc132e1a5128ad155d602fc328b[] = {
stepfunc_65093f3ffd7ca550c7d4c88702073f80,
stepfunc_55b337b1656f665830bdf556fee64f48,
stepfunc_21c0d5a41a5c0b8c40ae1bed2249ec32,
stepfunc_272613048de9d10dfcfa77e2cd41b1d7,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_8f3fdac68b9b5a0ae85dd6d1a71eef14(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (10);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_df31fb86846ba60960c493f6a9b87543(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255) * FixedPointNum::random());    p->lastBulletSpeed = ((FixedPointNum(80, 100) + FixedPointNum(80, 100) * FixedPointNum::random()) * (FixedPointNum(25, 100) + FixedPointNum(75, 100) * FixedPointNum(FixedPointNum(1))));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_2dade856b6cb7102ffaf1467d7b27ef8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255) * FixedPointNum::random());    p->lastBulletSpeed = ((FixedPointNum(50, 100) + FixedPointNum(50, 100) * FixedPointNum::random()) * (FixedPointNum(25, 100) + FixedPointNum(75, 100) * FixedPointNum(FixedPointNum(1))));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_f3d83d570da3048da642d706c36e0bdc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255) * FixedPointNum::random());    p->lastBulletSpeed = ((FixedPointNum(30, 100) + FixedPointNum(30, 100) * FixedPointNum::random()) * (FixedPointNum(25, 100) + FixedPointNum(75, 100) * FixedPointNum(FixedPointNum(1))));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_6a84a77b2e386fc842d8658f4247741a(BulletInfo *p) { 
for (u32 i = 0; i < 20; ++i) { 
stepfunc_f3d83d570da3048da642d706c36e0bdc(p);}
for (u32 i = 0; i < 30; ++i) { 
stepfunc_2dade856b6cb7102ffaf1467d7b27ef8(p);}
for (u32 i = 0; i < 50; ++i) { 
stepfunc_df31fb86846ba60960c493f6a9b87543(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_8f3fdac68b9b5a0ae85dd6d1a71eef14(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_eef59e52926ffdfd38e1055796d29236(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-FixedPointNum(212, 100) + FixedPointNum(425, 100) * FixedPointNum::random());    p->lastBulletSpeed = ((FixedPointNum(150, 100)) * (FixedPointNum(1) + (FixedPointNum(30, 100)) * FixedPointNum::random()));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_32410ae043288c80d6d76e0ba4742a9c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(10625, 100) + FixedPointNum(4250, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e416aff0617a4b99fbd4b5a7f8255dff;  }
}
p->wait = 1; 
}
static void stepfunc_4e424fafac06e04fc95c647baee065e4(BulletInfo *p) { 
p->wait = 45; 
}
static void stepfunc_c6352b69aad7ae6d449db499cb6edb29(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 15; 
}
static void stepfunc_d5896d5991ff28ffdb42906a3334466c(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = ((-(FixedPointNum(15229, 100) + FixedPointNum(708, 100) * FixedPointNum::random()))) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 180;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_bc7da5e4026ef294b7397505d69c7e01(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d538e74936af2fe81ca4eed58329bbfc;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_096f606f929189f05f280668215fb552(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = ((FixedPointNum(15229, 100) + FixedPointNum(708, 100) * FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 180;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_65093f3ffd7ca550c7d4c88702073f80(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(5312, 100) + FixedPointNum(708, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d6c1a27822164cd267af5233b0fb3265;  }
}
p->wait = 50; 
}
static void stepfunc_55b337b1656f665830bdf556fee64f48(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(5312, 100) + FixedPointNum(708, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7beeb93954f1d1990dffa599cddebca2;  }
}
p->wait = 30; 
}
static void stepfunc_21c0d5a41a5c0b8c40ae1bed2249ec32(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(5312, 100) + FixedPointNum(708, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d6c1a27822164cd267af5233b0fb3265;  }
}
p->wait = 10; 
}
static void stepfunc_272613048de9d10dfcfa77e2cd41b1d7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-(FixedPointNum(5312, 100) + FixedPointNum(708, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7beeb93954f1d1990dffa599cddebca2;  }
}
p->wait = 500; 
}


void genBulletFunc_787632bc0978ee85cd7e72568d477922(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_9aa3adc132e1a5128ad155d602fc328b; }}


