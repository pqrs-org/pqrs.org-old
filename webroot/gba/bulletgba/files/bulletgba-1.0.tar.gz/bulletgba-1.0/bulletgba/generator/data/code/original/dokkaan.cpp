// XXX uniqID XXX 5f22d513e685dec43f037958f9df4526 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_cdb69aa94956a6379a203fc2cb3821f5(BulletInfo *p); 
static void stepfunc_0329b7d9c5092f66b697afa9489fe7f5(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_4f84b09526ea12276403593e74236d4a[] = {
stepfunc_cdb69aa94956a6379a203fc2cb3821f5,
#if 0
stepfunc_0329b7d9c5092f66b697afa9489fe7f5,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_0329b7d9c5092f66b697afa9489fe7f5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(85)*FixedPointNum::random()-FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(2));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_cdb69aa94956a6379a203fc2cb3821f5(BulletInfo *p) { 
for (u32 i = 0; i < 400; ++i) { 
stepfunc_0329b7d9c5092f66b697afa9489fe7f5(p);}
p->wait = 150; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_5f22d513e685dec43f037958f9df4526(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_4f84b09526ea12276403593e74236d4a; }}


