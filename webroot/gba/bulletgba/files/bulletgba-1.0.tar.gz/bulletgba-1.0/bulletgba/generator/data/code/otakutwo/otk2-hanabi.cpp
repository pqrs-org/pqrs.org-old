// XXX uniqID XXX d01c89e2e47ae155913320765cde4918 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p); 
static void stepfunc_40c7e20d9395cac2610ebc3b7e493612(BulletInfo *p); 
static void stepfunc_b8ca001e9659db3b9d9c40d40a9fe0c1(BulletInfo *p); 
static void stepfunc_4937a599cc203287b70e1ddde9634977(BulletInfo *p); 
static void stepfunc_1588fc9b870cb82599cd6b74259f110f(BulletInfo *p); 
static void stepfunc_2b8f909d8a8f9860838a277bbd317aeb(BulletInfo *p); 
static void stepfunc_13615724913f5a82970f233ea7cd6f83(BulletInfo *p); 
static void stepfunc_db1b2163180881e9931deca7b44e2bfe(BulletInfo *p); 


static const BulletStepFunc bullet_8d314febe3e9284250bd064ab01f72cf[] = {
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_043793363d64f167610f53042d554328[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_40c7e20d9395cac2610ebc3b7e493612,
#if 0
stepfunc_b8ca001e9659db3b9d9c40d40a9fe0c1,
#endif
NULL}; 
static const BulletStepFunc bullet_21115af20212e74966ea7dd4a7249df1[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_4937a599cc203287b70e1ddde9634977,
#if 0
stepfunc_b8ca001e9659db3b9d9c40d40a9fe0c1,
#endif
NULL}; 
static const BulletStepFunc bullet_a96cb379fe47a10d87b537953ee28ff6[] = {
stepfunc_1588fc9b870cb82599cd6b74259f110f,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_2b8f909d8a8f9860838a277bbd317aeb,
stepfunc_13615724913f5a82970f233ea7cd6f83,
stepfunc_db1b2163180881e9931deca7b44e2bfe,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_b8ca001e9659db3b9d9c40d40a9fe0c1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(566, 100));    p->lastBulletSpeed = ((FixedPointNum(2))*(FixedPointNum(1)+(FixedPointNum::random())));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_40c7e20d9395cac2610ebc3b7e493612(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d314febe3e9284250bd064ab01f72cf;  }
}
for (u32 i = 0; i < 45; ++i) { 
stepfunc_b8ca001e9659db3b9d9c40d40a9fe0c1(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4937a599cc203287b70e1ddde9634977(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(283, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d314febe3e9284250bd064ab01f72cf;  }
}
for (u32 i = 0; i < 45; ++i) { 
stepfunc_b8ca001e9659db3b9d9c40d40a9fe0c1(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2b8f909d8a8f9860838a277bbd317aeb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1062, 100)+(FixedPointNum::random())*FixedPointNum(1770, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_21115af20212e74966ea7dd4a7249df1;  }
}
p->wait = 10; 
}
static void stepfunc_13615724913f5a82970f233ea7cd6f83(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1062, 100)+(FixedPointNum::random())*FixedPointNum(1770, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_043793363d64f167610f53042d554328;  }
}
p->wait = 10; 
}
static void stepfunc_1588fc9b870cb82599cd6b74259f110f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*FixedPointNum::random());    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d314febe3e9284250bd064ab01f72cf;  }
}
}
static void stepfunc_db1b2163180881e9931deca7b44e2bfe(BulletInfo *p) { 
p->wait = 120; 
}


void genBulletFunc_d01c89e2e47ae155913320765cde4918(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_a96cb379fe47a10d87b537953ee28ff6; }}


