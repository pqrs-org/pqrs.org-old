// XXX uniqID XXX 543b90e60374029473858234b1380ba4 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_cb5236db260de9566705bd5a3e74ad7d(BulletInfo *p); 
static void stepfunc_51462384c37a0f4521521a12f1bc6a36(BulletInfo *p); 
static void stepfunc_9eab828acf38cb807b024a5c3c046203(BulletInfo *p); 
static void stepfunc_dfe8a09b16ceaf62018cb912ad554c16(BulletInfo *p); 
static void stepfunc_6daed1d32905339a53d9663fba8f0282(BulletInfo *p); 
static void stepfunc_aa076cd183606660f6b6912db6405c35(BulletInfo *p); 
static void stepfunc_53ec83ea4faaf7016e14aa618ef19a03(BulletInfo *p); 
static void stepfunc_ea5ff34b36514f9426c631982e04d7f4(BulletInfo *p); 
static void stepfunc_f84fcf98c8a842d4895af51d94c2dd24(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_2f73d7ee3c217268e7634b942cdb60b2[] = {
stepfunc_cb5236db260de9566705bd5a3e74ad7d,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_aa076cd183606660f6b6912db6405c35,
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_ea5ff34b36514f9426c631982e04d7f4,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_aa076cd183606660f6b6912db6405c35,
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_cb5236db260de9566705bd5a3e74ad7d,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_dfe8a09b16ceaf62018cb912ad554c16,
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_aa076cd183606660f6b6912db6405c35,
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_ea5ff34b36514f9426c631982e04d7f4,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_51462384c37a0f4521521a12f1bc6a36,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_f84fcf98c8a842d4895af51d94c2dd24,
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_aa076cd183606660f6b6912db6405c35,
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_53ec83ea4faaf7016e14aa618ef19a03,
#if 0
stepfunc_9eab828acf38cb807b024a5c3c046203,
#endif
stepfunc_6daed1d32905339a53d9663fba8f0282,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_9eab828acf38cb807b024a5c3c046203(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(12, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_53ec83ea4faaf7016e14aa618ef19a03(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 26; ++i) { 
stepfunc_9eab828acf38cb807b024a5c3c046203(p);}
p->wait = 6; 
}
static void stepfunc_51462384c37a0f4521521a12f1bc6a36(BulletInfo *p) { 
for (u32 i = 0; i < 26; ++i) { 
stepfunc_9eab828acf38cb807b024a5c3c046203(p);}
p->wait = 6; 
}
static void stepfunc_f84fcf98c8a842d4895af51d94c2dd24(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_dfe8a09b16ceaf62018cb912ad554c16(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_cb5236db260de9566705bd5a3e74ad7d(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum(255)*FixedPointNum::random()) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(50, 100) - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(12750, 100)-FixedPointNum::random()*FixedPointNum(6375, 100)));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_6daed1d32905339a53d9663fba8f0282(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_aa076cd183606660f6b6912db6405c35(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum(255)*FixedPointNum::random()) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(50, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_ea5ff34b36514f9426c631982e04d7f4(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (FixedPointNum(255)*FixedPointNum::random()) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(50, 100) - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(12750, 100)+FixedPointNum::random()*FixedPointNum(6375, 100)));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_543b90e60374029473858234b1380ba4(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_2f73d7ee3c217268e7634b942cdb60b2; }}


