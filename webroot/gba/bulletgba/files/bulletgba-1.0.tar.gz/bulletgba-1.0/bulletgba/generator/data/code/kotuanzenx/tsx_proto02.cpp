// XXX uniqID XXX 3081c8091f2fd95d698ce532b2b6b025 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_c76e0cfb7b572dd7d5fdd9bb1395fa9c(BulletInfo *p); 
static void stepfunc_e5b2b90d5013d6523a028397c176cb64(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9(BulletInfo *p); 
static void stepfunc_89ef7e4cd00f143ad300b067bfa34734(BulletInfo *p); 
static void stepfunc_fcfc3ec6da193566063956a334304226(BulletInfo *p); 
static void stepfunc_15007e8a81d8aa46641d7ae97bab9e64(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_4bb38f187e2baec6555aafa095ee801f(BulletInfo *p); 


static const BulletStepFunc bullet_5260c9ef01f7d40c014ed5834fc2616d[] = {
stepfunc_c76e0cfb7b572dd7d5fdd9bb1395fa9c,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_e5b2b90d5013d6523a028397c176cb64,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_989b6d1f263484b0d1612b36ee025c07[] = {
stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9,
stepfunc_89ef7e4cd00f143ad300b067bfa34734,
#if 0
stepfunc_fcfc3ec6da193566063956a334304226,
#endif
NULL}; 
static const BulletStepFunc bullet_be6194443bc367d26dbfd81041dc5416[] = {
stepfunc_15007e8a81d8aa46641d7ae97bab9e64,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_4bb38f187e2baec6555aafa095ee801f,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_fcfc3ec6da193566063956a334304226(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9(BulletInfo *p) { 
{
  u16 life = 40;  FixedPointNum speed = FixedPointNum(FixedPointNum(10, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 60; 
}
static void stepfunc_89ef7e4cd00f143ad300b067bfa34734(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12041, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 10; ++i) { 
stepfunc_fcfc3ec6da193566063956a334304226(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e5b2b90d5013d6523a028397c176cb64(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(5907, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
p->wait = 10; 
}
static void stepfunc_c76e0cfb7b572dd7d5fdd9bb1395fa9c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_989b6d1f263484b0d1612b36ee025c07;  }
}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_15007e8a81d8aa46641d7ae97bab9e64(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 4 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
p->wait = 9; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_4bb38f187e2baec6555aafa095ee801f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5260c9ef01f7d40c014ed5834fc2616d;  }
}
p->wait = 1200; 
}


void genBulletFunc_3081c8091f2fd95d698ce532b2b6b025(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_be6194443bc367d26dbfd81041dc5416; }}


