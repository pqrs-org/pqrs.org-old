// XXX uniqID XXX 72c2014b4e3d4fd073adf1e7a3890d18 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_09c5eb7bdb918322f9a0718f926fbd8c(BulletInfo *p); 
static void stepfunc_92034292911881a886c3179e0590265f(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_6c1f8924f1816c4b17037ca35cdfb188(BulletInfo *p); 
static void stepfunc_5e3953c897953e74528d342878fbd55e(BulletInfo *p); 


static const BulletStepFunc bullet_2efe74ffd4f6e96ecac3e692bf4a55ad[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_09c5eb7bdb918322f9a0718f926fbd8c,
#if 0
stepfunc_92034292911881a886c3179e0590265f,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_5086b68237c1339d1d1ee4a1c98c6c18[] = {
stepfunc_6c1f8924f1816c4b17037ca35cdfb188,
NULL}; 
static const BulletStepFunc bullet_3c3a214f0a11682a55a114acfaf09a81[] = {
stepfunc_5e3953c897953e74528d342878fbd55e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_6c1f8924f1816c4b17037ca35cdfb188(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-283, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(15, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(283, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(15, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_92034292911881a886c3179e0590265f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2125, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5086b68237c1339d1d1ee4a1c98c6c18;  }
}
}
static void stepfunc_09c5eb7bdb918322f9a0718f926fbd8c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(85)+FixedPointNum::random()*FixedPointNum(4250, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5086b68237c1339d1d1ee4a1c98c6c18;  }
}
for (u32 i = 0; i < 2; ++i) { 
stepfunc_92034292911881a886c3179e0590265f(p);}
}
static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p) { 
p->wait = 9; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_5e3953c897953e74528d342878fbd55e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2efe74ffd4f6e96ecac3e692bf4a55ad;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2efe74ffd4f6e96ecac3e692bf4a55ad;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4250, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2efe74ffd4f6e96ecac3e692bf4a55ad;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4250, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2efe74ffd4f6e96ecac3e692bf4a55ad;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2125, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2efe74ffd4f6e96ecac3e692bf4a55ad;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2125, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2efe74ffd4f6e96ecac3e692bf4a55ad;  }
}
p->wait = 600; 
}


void genBulletFunc_72c2014b4e3d4fd073adf1e7a3890d18(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_3c3a214f0a11682a55a114acfaf09a81; }}


