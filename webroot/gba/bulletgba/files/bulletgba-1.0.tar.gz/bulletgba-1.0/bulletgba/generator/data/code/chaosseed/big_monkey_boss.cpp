// XXX uniqID XXX e34a5e529fdbd1ef2698b1d524e8c234 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_5c83c6c967d8f39683e01b26e027a00f(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_28096341907acda3e40574a5ff0b4c5a(BulletInfo *p); 
static void stepfunc_01f87f5c6155e39b040a7629f5be1274(BulletInfo *p); 
static void stepfunc_a5867b35f1491509a25afb98fbb95512(BulletInfo *p); 
static void stepfunc_95e99b4a8f292841e0a7a8ae5c07be1f(BulletInfo *p); 
static void stepfunc_38a5db3cd045979a4ab3955d733ea70a(BulletInfo *p); 


static const BulletStepFunc bullet_0ccee838e32ae42611cc801f697697cc[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_5c83c6c967d8f39683e01b26e027a00f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_c9362b7d24e23a1f7ed683e13edace02[] = {
stepfunc_28096341907acda3e40574a5ff0b4c5a,
stepfunc_01f87f5c6155e39b040a7629f5be1274,
stepfunc_a5867b35f1491509a25afb98fbb95512,
stepfunc_95e99b4a8f292841e0a7a8ae5c07be1f,
NULL}; 
static const BulletStepFunc bullet_307de7328209665457c9fea92886fd44[] = {
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_38a5db3cd045979a4ab3955d733ea70a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_28096341907acda3e40574a5ff0b4c5a(BulletInfo *p) { 
{
  u16 life = 10000;  FixedPointNum speed = FixedPointNum(212, 100);p->setRound(speed, life);}
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 60; 
}
static void stepfunc_01f87f5c6155e39b040a7629f5be1274(BulletInfo *p) { 
{
  u16 life = 40;  FixedPointNum speed = FixedPointNum(FixedPointNum(180, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 40; 
}
static void stepfunc_a5867b35f1491509a25afb98fbb95512(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_95e99b4a8f292841e0a7a8ae5c07be1f(BulletInfo *p) { 
{
  u16 life = 10000;  FixedPointNum speed = FixedPointNum(141, 100);p->setRound(speed, life);}
{
  u16 life = 100000;  FixedPointNum speed = FixedPointNum(FixedPointNum(1, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_5c83c6c967d8f39683e01b26e027a00f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c9362b7d24e23a1f7ed683e13edace02;  }
}
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_38a5db3cd045979a4ab3955d733ea70a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(6375, 100)+FixedPointNum(12750, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum::random()*FixedPointNum(3)+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0ccee838e32ae42611cc801f697697cc;  }
}
p->wait = 30; 
}


void genBulletFunc_e34a5e529fdbd1ef2698b1d524e8c234(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_307de7328209665457c9fea92886fd44; }}


