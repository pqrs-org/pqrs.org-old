// XXX uniqID XXX 3576013f1e8a5a5125c5dc6a1dee631e XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac(BulletInfo *p); 
static void stepfunc_f637d86d748499e50e7804aacdfc43db(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_e96834257234b38ccd287679439a5237[] = {
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac,
#if 0
stepfunc_f637d86d748499e50e7804aacdfc43db,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_f637d86d748499e50e7804aacdfc43db(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(708, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1a212bc4bcbf283b4a09fb5a63b52aac(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum::random()*FixedPointNum(255));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_f637d86d748499e50e7804aacdfc43db(p);}
p->wait = 5; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_3576013f1e8a5a5125c5dc6a1dee631e(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_e96834257234b38ccd287679439a5237; }}


