// XXX uniqID XXX a749a8afb3b9290182f718da7926ba76 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_1ddf85bcc8190140fbb3332be4a151f1(BulletInfo *p); 
static void stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3(BulletInfo *p); 
static void stepfunc_a4b4d1e9f500be02a90f488efc4d28bb(BulletInfo *p); 
static void stepfunc_8d5cd95be2495a07b327ddc261148b37(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_aa049bb77ff2bc907d90d6a444e681e9(BulletInfo *p); 
static void stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a(BulletInfo *p); 


static const BulletStepFunc bullet_d5b806fc0b86d76786fba91d1c2159ad[] = {
stepfunc_1ddf85bcc8190140fbb3332be4a151f1,
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_8d5cd95be2495a07b327ddc261148b37,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_e6084c67ee298f040867c87bad9953df[] = {
stepfunc_aa049bb77ff2bc907d90d6a444e681e9,
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3,
#if 0
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_a4b4d1e9f500be02a90f488efc4d28bb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2125, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_72c7b0824d0a004ca4af8dfc8d5939d3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2125, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb(p);}
p->wait = 5; 
}
static void stepfunc_8d5cd95be2495a07b327ddc261148b37(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2054, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb(p);}
p->wait = 5; 
}
static void stepfunc_1ddf85bcc8190140fbb3332be4a151f1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-141, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_5a51e53d31efb22b2c8a1c4d30aeee4a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2195, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_a4b4d1e9f500be02a90f488efc4d28bb(p);}
p->wait = 5; 
}
static void stepfunc_aa049bb77ff2bc907d90d6a444e681e9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(141, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}


void genBulletFunc_a749a8afb3b9290182f718da7926ba76(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_e6084c67ee298f040867c87bad9953df; }  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_d5b806fc0b86d76786fba91d1c2159ad; }}


