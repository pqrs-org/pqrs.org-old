#!/usr/bin/env php
<?php //-*- Mode: php; indent-tabs-mode: nil; Coding: utf-8; -*-

require_once sprintf('%s/libcommon.php', dirname(__FILE__));

class Format
{
  var $document;

  function Format($doc) {
    $this->document = $doc;
  }

  function doConv() {
    while ($this->addTopLevelFire());
    //while ($this->pushFunctionElement($this->document));
    while ($this->makeScene());
    //$this->pushFunctionElement($this->document);

    return $this->document;
  }

  function addTopLevelFire() {
    $bulletmlNode = $this->document->lastChild;

    foreach ($bulletmlNode->childNodes as $elem) {
      if ($elem->nodeName == 'action') {
        // put vanish for toplevel action.
        $elem->appendChild($this->document->createElement('vanish'));

        // wrap toplevel action element with fire.
        $toplevelfire = $this->document->createElement('fire');
        $toplevelfire->appendChild($elem->cloneNode(true));
        $elem->parentNode->replaceChild($toplevelfire, $elem);
        return true;
      }
    }
    return false;
  }

  function makeScene() {
    foreach ($this->document->getElementsByTagName('action') as $elem) {
      if ($elem->getAttribute('makescene') != NULL) {
        continue;
      }

      $newaction = $this->document->createElement('action');
      $newaction->setAttribute('makescene', '1');
      $scene = $this->document->createElement('scene');
      foreach ($elem->childNodes as $e) {
        if ($e->nodeName == 'repeat') {
          if ($scene->hasChildNodes()) {
            $newaction->appendChild($scene);
          }
          $scene = $this->document->createElement('scene');
          $scene->appendChild($e->cloneNode(true));
          $newaction->appendChild($scene);

          $scene = $this->document->createElement('scene');
        } elseif ($e->nodeName == 'wait') {
          $scene->appendChild($e->cloneNode(true));
          $newaction->appendChild($scene);
          $scene = $this->document->createElement('scene');
        } else {
          $scene->appendChild($e->cloneNode(true));
        }
      }
      if ($scene->hasChildNodes()) {
        $newaction->appendChild($scene);
      }

      if ($newaction->hasChildNodes()) {
        $elem->parentNode->replaceChild($newaction, $elem);
      } else {
        $elem->parentNode->removeChild($elem);
      }
      return true;
    }
    return false;
  }
}


if (realpath($argv[0]) == __FILE__) {
  $xmlfile = Common::getArg1();

  $doc = new DOMDocument;
  $doc->preserveWhiteSpace = false;
  $doc->load($xmlfile);

  $format = new Format($doc);
  print $format->doConv()->saveXML();
}

?>
