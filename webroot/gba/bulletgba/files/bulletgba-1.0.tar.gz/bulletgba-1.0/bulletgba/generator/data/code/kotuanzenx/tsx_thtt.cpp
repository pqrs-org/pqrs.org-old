// XXX uniqID XXX dc480d4bcf51bd410f465f049b6534ff XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_278e1abccc0c2ae8afbf75df2c0cdc2a(BulletInfo *p); 
static void stepfunc_13f30e9d18c3b82b47795a4f4e5035a2(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9(BulletInfo *p); 
static void stepfunc_cd5cd4aecc8d1834051722c4f83eeab9(BulletInfo *p); 
static void stepfunc_1aaa93f8ddcc9676ff7413a0933118d0(BulletInfo *p); 
static void stepfunc_15007e8a81d8aa46641d7ae97bab9e64(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_7e17774d9d1d9792aa80fe84bfd07107(BulletInfo *p); 


static const BulletStepFunc bullet_72f694f997bad4a2981314c8f649c569[] = {
stepfunc_278e1abccc0c2ae8afbf75df2c0cdc2a,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_13f30e9d18c3b82b47795a4f4e5035a2,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_23202184462d7954a5950f4e46cff8a0[] = {
stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9,
stepfunc_cd5cd4aecc8d1834051722c4f83eeab9,
#if 0
stepfunc_1aaa93f8ddcc9676ff7413a0933118d0,
#endif
NULL}; 
static const BulletStepFunc bullet_1d0c8456c6825c00d693f50ff493d9d8[] = {
stepfunc_15007e8a81d8aa46641d7ae97bab9e64,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_7e17774d9d1d9792aa80fe84bfd07107,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_1aaa93f8ddcc9676ff7413a0933118d0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_6d38faabd8baadd4bbc4f348f2f34ac9(BulletInfo *p) { 
{
  u16 life = 40;  FixedPointNum speed = FixedPointNum(FixedPointNum(10, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 60; 
}
static void stepfunc_cd5cd4aecc8d1834051722c4f83eeab9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(12041, 100));    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 10; ++i) { 
stepfunc_1aaa93f8ddcc9676ff7413a0933118d0(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_13f30e9d18c3b82b47795a4f4e5035a2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(5907, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
p->wait = 10; 
}
static void stepfunc_278e1abccc0c2ae8afbf75df2c0cdc2a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23202184462d7954a5950f4e46cff8a0;  }
}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_15007e8a81d8aa46641d7ae97bab9e64(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 4 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
p->wait = 9; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_7e17774d9d1d9792aa80fe84bfd07107(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_72f694f997bad4a2981314c8f649c569;  }
}
p->wait = 1200; 
}


void genBulletFunc_dc480d4bcf51bd410f465f049b6534ff(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_1d0c8456c6825c00d693f50ff493d9d8; }}


