// XXX uniqID XXX 211870273682e98b27fe9860e549f55d XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p); 
static void stepfunc_8922fe73617df61637e635b6285f4bbb(BulletInfo *p); 
static void stepfunc_17e8e658ead4988db7c617403a776a7b(BulletInfo *p); 
static void stepfunc_6e0e7115fce73110871bae6345b44c36(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_45632357977ac36215690c4cd2ce78f7(BulletInfo *p); 
static void stepfunc_c3d1af34af9a706dd3397cf39bb5a122(BulletInfo *p); 
static void stepfunc_2cf3dafe1081a6465feb005e4d8bb6e5(BulletInfo *p); 
static void stepfunc_2b0a4a78a487f64c0f8416d075830771(BulletInfo *p); 
static void stepfunc_fe0bb1ef413251c5c3fc0d1bd30b258e(BulletInfo *p); 
static void stepfunc_f3e55cb9010c48464a54b5f597564bd4(BulletInfo *p); 
static void stepfunc_4f4cd5cf551e729258e4a7e166ccd05e(BulletInfo *p); 
static void stepfunc_6a958128ae731bd2be35bb7deae79da6(BulletInfo *p); 
static void stepfunc_6ae2583bb371018c02f20d8e7d4de567(BulletInfo *p); 
static void stepfunc_0f353e1dd1b06c472f0b9822b8f04f58(BulletInfo *p); 


static const BulletStepFunc bullet_56b30df28cc392e6c8a2d4a188592d30[] = {
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_8922fe73617df61637e635b6285f4bbb,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_05d1116d8b3d7aac51c78f496cb7508e[] = {
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_45632357977ac36215690c4cd2ce78f7,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d4ed1b0d242a6063a8f11b08cf55d84e[] = {
stepfunc_2cf3dafe1081a6465feb005e4d8bb6e5,
stepfunc_2b0a4a78a487f64c0f8416d075830771,
stepfunc_fe0bb1ef413251c5c3fc0d1bd30b258e,
stepfunc_f3e55cb9010c48464a54b5f597564bd4,
stepfunc_4f4cd5cf551e729258e4a7e166ccd05e,
stepfunc_6a958128ae731bd2be35bb7deae79da6,
stepfunc_6ae2583bb371018c02f20d8e7d4de567,
stepfunc_0f353e1dd1b06c472f0b9822b8f04f58,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_17e8e658ead4988db7c617403a776a7b(BulletInfo *p) { 
p->wait = 2; 
}
static void stepfunc_6e0e7115fce73110871bae6345b44c36(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-9417, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_8922fe73617df61637e635b6285f4bbb(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*((FixedPointNum::random()))*((-FixedPointNum(70, 100))));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_c3d1af34af9a706dd3397cf39bb5a122(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(9417, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_45632357977ac36215690c4cd2ce78f7(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*((FixedPointNum::random()))*(( FixedPointNum(70, 100))));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_2cf3dafe1081a6465feb005e4d8bb6e5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
p->wait = 100; 
}
static void stepfunc_2b0a4a78a487f64c0f8416d075830771(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
p->wait = 100; 
}
static void stepfunc_fe0bb1ef413251c5c3fc0d1bd30b258e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
p->wait = 100; 
}
static void stepfunc_f3e55cb9010c48464a54b5f597564bd4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
p->wait = 100; 
}
static void stepfunc_4f4cd5cf551e729258e4a7e166ccd05e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
p->wait = 100; 
}
static void stepfunc_6a958128ae731bd2be35bb7deae79da6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
p->wait = 100; 
}
static void stepfunc_6ae2583bb371018c02f20d8e7d4de567(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
p->wait = 100; 
}
static void stepfunc_0f353e1dd1b06c472f0b9822b8f04f58(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
p->wait = 100; 
}


void genBulletFunc_211870273682e98b27fe9860e549f55d(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_d4ed1b0d242a6063a8f11b08cf55d84e; }}


