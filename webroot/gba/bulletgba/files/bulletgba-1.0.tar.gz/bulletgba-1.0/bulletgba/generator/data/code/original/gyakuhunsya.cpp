// XXX uniqID XXX 2e744d6cf664d5d5dd26fa37314a268f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_71bb001dc7728571a9a6ca3718c0697c(BulletInfo *p); 
static void stepfunc_8f67076238570ce89fac133b88df2340(BulletInfo *p); 
static void stepfunc_bdafc19582090b2f615d28e0d333d96b(BulletInfo *p); 
static void stepfunc_de85ce59d53d4d8fe395ba0def2d7b61(BulletInfo *p); 
static void stepfunc_824f6144c8d57c36a6debd6d4ed26990(BulletInfo *p); 
static void stepfunc_5087d3575f5147f0183b43f1f47d6eaa(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_7ed44b3fe52c98b833f25ec1be9418db[] = {
stepfunc_71bb001dc7728571a9a6ca3718c0697c,
stepfunc_8f67076238570ce89fac133b88df2340,
stepfunc_bdafc19582090b2f615d28e0d333d96b,
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_de85ce59d53d4d8fe395ba0def2d7b61,
#if 0
stepfunc_824f6144c8d57c36a6debd6d4ed26990,
#endif
stepfunc_5087d3575f5147f0183b43f1f47d6eaa,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_824f6144c8d57c36a6debd6d4ed26990(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum::random()*FixedPointNum(85)-FixedPointNum(4250, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_de85ce59d53d4d8fe395ba0def2d7b61(BulletInfo *p) { 
for (u32 i = 0; i < 4; ++i) { 
stepfunc_824f6144c8d57c36a6debd6d4ed26990(p);}
p->wait = 1; 
}
static void stepfunc_71bb001dc7728571a9a6ca3718c0697c(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 60; 
}
static void stepfunc_8f67076238570ce89fac133b88df2340(BulletInfo *p) { 
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_bdafc19582090b2f615d28e0d333d96b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(2 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_5087d3575f5147f0183b43f1f47d6eaa(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_2e744d6cf664d5d5dd26fa37314a268f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_7ed44b3fe52c98b833f25ec1be9418db; }}


