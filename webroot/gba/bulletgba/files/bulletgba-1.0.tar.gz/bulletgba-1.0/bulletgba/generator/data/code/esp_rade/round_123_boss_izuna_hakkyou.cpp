// XXX uniqID XXX 50a1687045849dc9f64fb6afb3e2668b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_5aa98bab57516922045abb7f2c427635(BulletInfo *p); 
static void stepfunc_e4547dce74c2f31cf07f256255486988(BulletInfo *p); 
static void stepfunc_675a5dc88bdc089dfc7910754b973b0e(BulletInfo *p); 
static void stepfunc_b37af8f54f35092580d1cd962e18b2d8(BulletInfo *p); 
static void stepfunc_37f150b6bcb3061078c0684bc1f6a32b(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_71c6b374c4362550992aa66826951edb(BulletInfo *p); 
static void stepfunc_432c2a72ebe3e5356791a8122241e090(BulletInfo *p); 
static void stepfunc_00ba2a169558f2566c262b98c27778c0(BulletInfo *p); 
static void stepfunc_94042f7a0f875c1f9c79957458113b96(BulletInfo *p); 
static void stepfunc_a6501a17079681900470a91a5ff5916b(BulletInfo *p); 
static void stepfunc_1b92ae8b10bbb20f53e29850acdf0a75(BulletInfo *p); 
static void stepfunc_98b641b4f6c47b8f737df891edf095bf(BulletInfo *p); 
static void stepfunc_07c675682aa2d9dff5be1c144f0e3fb5(BulletInfo *p); 


static const BulletStepFunc bullet_1dcbefd02790142afdcee188d1e3e1d4[] = {
stepfunc_5aa98bab57516922045abb7f2c427635,
stepfunc_e4547dce74c2f31cf07f256255486988,
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_675a5dc88bdc089dfc7910754b973b0e,
stepfunc_b37af8f54f35092580d1cd962e18b2d8,
#if 0
stepfunc_37f150b6bcb3061078c0684bc1f6a32b,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_8a4a2cc42c6dfd5b05c1b27c80901027[] = {
stepfunc_5aa98bab57516922045abb7f2c427635,
stepfunc_71c6b374c4362550992aa66826951edb,
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_00ba2a169558f2566c262b98c27778c0,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_a6501a17079681900470a91a5ff5916b,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_201fe93412d52bc7220b2fce49bab435[] = {
stepfunc_5aa98bab57516922045abb7f2c427635,
stepfunc_71c6b374c4362550992aa66826951edb,
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_1b92ae8b10bbb20f53e29850acdf0a75,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_432c2a72ebe3e5356791a8122241e090,
stepfunc_98b641b4f6c47b8f737df891edf095bf,
#if 0
stepfunc_94042f7a0f875c1f9c79957458113b96,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3dd93423e7fd8a39ed06741148e3c47b[] = {
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_75dbe0827c4d717ccb0cf203a3c54f5e[] = {
stepfunc_07c675682aa2d9dff5be1c144f0e3fb5,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_37f150b6bcb3061078c0684bc1f6a32b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-141, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_675a5dc88bdc089dfc7910754b973b0e(BulletInfo *p) { 
p->wait = 50; 
}
static void stepfunc_b37af8f54f35092580d1cd962e18b2d8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-70, 100));    p->lastBulletSpeed = (FixedPointNum(170, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 8; ++i) { 
stepfunc_37f150b6bcb3061078c0684bc1f6a32b(p);}
}
static void stepfunc_5aa98bab57516922045abb7f2c427635(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_e4547dce74c2f31cf07f256255486988(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_94042f7a0f875c1f9c79957458113b96(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(3187, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_432c2a72ebe3e5356791a8122241e090(BulletInfo *p) { 
p->wait = 8; 
}
static void stepfunc_a6501a17079681900470a91a5ff5916b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-150, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(16, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_94042f7a0f875c1f9c79957458113b96(p);}
}
static void stepfunc_00ba2a169558f2566c262b98c27778c0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-265, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_94042f7a0f875c1f9c79957458113b96(p);}
}
static void stepfunc_71c6b374c4362550992aa66826951edb(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
}
static void stepfunc_98b641b4f6c47b8f737df891edf095bf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(150, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(16, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_94042f7a0f875c1f9c79957458113b96(p);}
}
static void stepfunc_1b92ae8b10bbb20f53e29850acdf0a75(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(265, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_94042f7a0f875c1f9c79957458113b96(p);}
}
static void stepfunc_07c675682aa2d9dff5be1c144f0e3fb5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_201fe93412d52bc7220b2fce49bab435;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8a4a2cc42c6dfd5b05c1b27c80901027;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dcbefd02790142afdcee188d1e3e1d4;  }
}
p->wait = 500; 
}


void genBulletFunc_50a1687045849dc9f64fb6afb3e2668b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_75dbe0827c4d717ccb0cf203a3c54f5e; }}


