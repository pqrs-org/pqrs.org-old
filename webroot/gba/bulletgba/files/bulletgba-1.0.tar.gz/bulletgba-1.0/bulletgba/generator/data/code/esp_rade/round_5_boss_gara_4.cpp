// XXX uniqID XXX cf9e1428717db28659ffd1fb78a3622d XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_8f67076238570ce89fac133b88df2340(BulletInfo *p); 
static void stepfunc_cb159785e5ee4a4582051a68b1b5b51b(BulletInfo *p); 
static void stepfunc_d15f6a365b684283efb4ec2d38d084f4(BulletInfo *p); 
static void stepfunc_76001af8012bc40633bbc6abc245f8d8(BulletInfo *p); 
static void stepfunc_00de263e5db08a9b07d0b325e328cbf5(BulletInfo *p); 
static void stepfunc_4353a7676635a508b7e4a5b8e0e9754f(BulletInfo *p); 
static void stepfunc_4cb692d2505e401bb354cc47d603b955(BulletInfo *p); 
static void stepfunc_c48ab7002752accb26a3ba7c6b7b21eb(BulletInfo *p); 
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_669e38b6de6ad936fb100116bcb1dae1[] = {
stepfunc_8f67076238570ce89fac133b88df2340,
stepfunc_cb159785e5ee4a4582051a68b1b5b51b,
#if 0
stepfunc_d15f6a365b684283efb4ec2d38d084f4,
#endif
NULL}; 
static const BulletStepFunc bullet_b48ac35395b3abd16944eb4a507b2754[] = {
stepfunc_76001af8012bc40633bbc6abc245f8d8,
stepfunc_00de263e5db08a9b07d0b325e328cbf5,
stepfunc_76001af8012bc40633bbc6abc245f8d8,
stepfunc_00de263e5db08a9b07d0b325e328cbf5,
stepfunc_76001af8012bc40633bbc6abc245f8d8,
stepfunc_00de263e5db08a9b07d0b325e328cbf5,
stepfunc_76001af8012bc40633bbc6abc245f8d8,
stepfunc_00de263e5db08a9b07d0b325e328cbf5,
stepfunc_4353a7676635a508b7e4a5b8e0e9754f,
stepfunc_4cb692d2505e401bb354cc47d603b955,
stepfunc_c48ab7002752accb26a3ba7c6b7b21eb,
stepfunc_4cb692d2505e401bb354cc47d603b955,
stepfunc_c48ab7002752accb26a3ba7c6b7b21eb,
stepfunc_4cb692d2505e401bb354cc47d603b955,
stepfunc_c48ab7002752accb26a3ba7c6b7b21eb,
stepfunc_4cb692d2505e401bb354cc47d603b955,
stepfunc_c48ab7002752accb26a3ba7c6b7b21eb,
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_d15f6a365b684283efb4ec2d38d084f4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1416, 100)*FixedPointNum::random()-FixedPointNum(708, 100));    p->lastBulletSpeed = (FixedPointNum(2)*FixedPointNum::random()+FixedPointNum(70, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_8f67076238570ce89fac133b88df2340(BulletInfo *p) { 
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_cb159785e5ee4a4582051a68b1b5b51b(BulletInfo *p) { 
for (u32 i = 0; i < 50; ++i) { 
stepfunc_d15f6a365b684283efb4ec2d38d084f4(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4cb692d2505e401bb354cc47d603b955(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_669e38b6de6ad936fb100116bcb1dae1;  }
}
p->wait = 20; 
}
static void stepfunc_c48ab7002752accb26a3ba7c6b7b21eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_669e38b6de6ad936fb100116bcb1dae1;  }
}
p->wait = 20; 
}
static void stepfunc_76001af8012bc40633bbc6abc245f8d8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_669e38b6de6ad936fb100116bcb1dae1;  }
}
p->wait = 60; 
}
static void stepfunc_00de263e5db08a9b07d0b325e328cbf5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_669e38b6de6ad936fb100116bcb1dae1;  }
}
p->wait = 60; 
}
static void stepfunc_4353a7676635a508b7e4a5b8e0e9754f(BulletInfo *p) { 
p->wait = 120; 
}
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_cf9e1428717db28659ffd1fb78a3622d(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_b48ac35395b3abd16944eb4a507b2754; }}


