// XXX uniqID XXX 9baeb10b619a9434d45da296752e5266 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_2391c75f30f7858505f5c084b7012e48(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_0361ed4535e94d4cd24bae13726611d3(BulletInfo *p); 
static void stepfunc_f05d33821a3b367102acc270752a2b2c(BulletInfo *p); 
static void stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3(BulletInfo *p); 
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p); 
static void stepfunc_2a1767e4a12eed670b6d56d99868dc30(BulletInfo *p); 
static void stepfunc_5487efa73c5e6213f1be8473e1944c1f(BulletInfo *p); 
static void stepfunc_9de52f30be9c4926b144e4671e32da73(BulletInfo *p); 
static void stepfunc_ddbfa4980073608874cdfa61b21488fc(BulletInfo *p); 
static void stepfunc_14bd2c3d6ea7e77f5d62ad9be773faf9(BulletInfo *p); 
static void stepfunc_b8d11b532b7e8bc03e43663d50a6dbaf(BulletInfo *p); 
static void stepfunc_4a43b1085c1de97126c2e1845ea4e581(BulletInfo *p); 
static void stepfunc_e4915bc12951ca61f54e9539ae397232(BulletInfo *p); 
static void stepfunc_fff3edcad1a70e4559f221ef1f9b1459(BulletInfo *p); 
static void stepfunc_c7154b3ad32477a583e212fafa9a6203(BulletInfo *p); 
static void stepfunc_5cf0edffdb357278c608454350162fb9(BulletInfo *p); 
static void stepfunc_96b47f4565ecc4ab654ba6c4cca0610a(BulletInfo *p); 
static void stepfunc_be47b5c77b0cf478a5e59cd30b6c5c23(BulletInfo *p); 
static void stepfunc_56d1ea871588d2693fe21bbea75acbbb(BulletInfo *p); 
static void stepfunc_6d7fc36327d4f432550d8bfbecddaad0(BulletInfo *p); 
static void stepfunc_4a91081db5f1018f3d0ea22f82315b02(BulletInfo *p); 
static void stepfunc_8c53e2d35fdc0cf4c5bc75d69bfde9b8(BulletInfo *p); 
static void stepfunc_cf2720e0c9405fcc6274d3a293376864(BulletInfo *p); 
static void stepfunc_a66f8304766f2926974b130ecb2d194d(BulletInfo *p); 
static void stepfunc_56269e8bcafd645c04184650d67c577b(BulletInfo *p); 
static void stepfunc_1275822567917586952f9ce1eee71c3d(BulletInfo *p); 


static const BulletStepFunc bullet_708df97db8edf79e7d2191e5ed4dff4a[] = {
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_2391c75f30f7858505f5c084b7012e48,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_ad1d211815ebb49c775a1d4e5320d7b4[] = {
stepfunc_0361ed4535e94d4cd24bae13726611d3,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_f05d33821a3b367102acc270752a2b2c,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_7026be2d760b8751e4ea3a225216b6d8[] = {
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_27d0c2b81aafb190f182fbe085f5331b[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_2a1767e4a12eed670b6d56d99868dc30,
NULL}; 
static const BulletStepFunc bullet_3fbe26a10d44c6c01e56c2fc0dc50dd6[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_5487efa73c5e6213f1be8473e1944c1f,
NULL}; 
static const BulletStepFunc bullet_76aea13a94fda28e8abedc0634b61680[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_9de52f30be9c4926b144e4671e32da73,
NULL}; 
static const BulletStepFunc bullet_8b479c0fb6704504aa7820ccfec416ef[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_ddbfa4980073608874cdfa61b21488fc,
NULL}; 
static const BulletStepFunc bullet_409437b8df9be2060bbb4de6590ec062[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_14bd2c3d6ea7e77f5d62ad9be773faf9,
NULL}; 
static const BulletStepFunc bullet_554986a7c263a18633fb38cecb0ecc95[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_b8d11b532b7e8bc03e43663d50a6dbaf,
NULL}; 
static const BulletStepFunc bullet_a46e80cbbe0dc62de5a0b8e28f576280[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_4a43b1085c1de97126c2e1845ea4e581,
NULL}; 
static const BulletStepFunc bullet_dcffaa0e4bc6a703df50a0569b0644ef[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_e4915bc12951ca61f54e9539ae397232,
NULL}; 
static const BulletStepFunc bullet_ecef05a76cb722cda234477c4bd7322e[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_fff3edcad1a70e4559f221ef1f9b1459,
NULL}; 
static const BulletStepFunc bullet_8e1b61cb18db140716a0c04ca25c198b[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_c7154b3ad32477a583e212fafa9a6203,
NULL}; 
static const BulletStepFunc bullet_77ebcc6a2f43547f874fe711575de5c1[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_5cf0edffdb357278c608454350162fb9,
NULL}; 
static const BulletStepFunc bullet_270231424295b7d1b07db3693a4a5a7e[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_96b47f4565ecc4ab654ba6c4cca0610a,
NULL}; 
static const BulletStepFunc bullet_0948e56fb8abdd7e7bb0c23ce7bf8133[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_be47b5c77b0cf478a5e59cd30b6c5c23,
NULL}; 
static const BulletStepFunc bullet_9ea763eb5837592c95bda4bba834f7c8[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_56d1ea871588d2693fe21bbea75acbbb,
NULL}; 
static const BulletStepFunc bullet_4f12d434398e3461bd69291a8db9f999[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_6d7fc36327d4f432550d8bfbecddaad0,
NULL}; 
static const BulletStepFunc bullet_d5f794173e1f3d49a2517b16e8923de0[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_4a91081db5f1018f3d0ea22f82315b02,
NULL}; 
static const BulletStepFunc bullet_309c18a4537db0a7976394fefd6a0da8[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8c53e2d35fdc0cf4c5bc75d69bfde9b8,
NULL}; 
static const BulletStepFunc bullet_ceb06c2e890d8887a36e6acfd516527e[] = {
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_cf2720e0c9405fcc6274d3a293376864,
NULL}; 
static const BulletStepFunc bullet_847623246981c2cc85112bcf7814cd63[] = {
stepfunc_a66f8304766f2926974b130ecb2d194d,
stepfunc_56269e8bcafd645c04184650d67c577b,
stepfunc_1275822567917586952f9ce1eee71c3d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_2a1767e4a12eed670b6d56d99868dc30(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-12083, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5487efa73c5e6213f1be8473e1944c1f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-11372, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9de52f30be9c4926b144e4671e32da73(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-10661, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ddbfa4980073608874cdfa61b21488fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-9951, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_14bd2c3d6ea7e77f5d62ad9be773faf9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-9240, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b8d11b532b7e8bc03e43663d50a6dbaf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-8529, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4a43b1085c1de97126c2e1845ea4e581(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-7818, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e4915bc12951ca61f54e9539ae397232(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-7107, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_fff3edcad1a70e4559f221ef1f9b1459(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-6397, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c7154b3ad32477a583e212fafa9a6203(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-5686, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5cf0edffdb357278c608454350162fb9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4975, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_96b47f4565ecc4ab654ba6c4cca0610a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4264, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_be47b5c77b0cf478a5e59cd30b6c5c23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3553, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_56d1ea871588d2693fe21bbea75acbbb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2843, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_6d7fc36327d4f432550d8bfbecddaad0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2132, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4a91081db5f1018f3d0ea22f82315b02(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1421, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8c53e2d35fdc0cf4c5bc75d69bfde9b8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-710, 100));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_cf2720e0c9405fcc6274d3a293376864(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(FixedPointNum(1)))*FixedPointNum(150, 100))+FixedPointNum(1));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2391c75f30f7858505f5c084b7012e48(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ceb06c2e890d8887a36e6acfd516527e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1003, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_309c18a4537db0a7976394fefd6a0da8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2006, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d5f794173e1f3d49a2517b16e8923de0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3010, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4f12d434398e3461bd69291a8db9f999;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4013, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9ea763eb5837592c95bda4bba834f7c8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5017, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0948e56fb8abdd7e7bb0c23ce7bf8133;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6020, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_270231424295b7d1b07db3693a4a5a7e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7024, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_77ebcc6a2f43547f874fe711575de5c1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8027, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8e1b61cb18db140716a0c04ca25c198b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9031, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ecef05a76cb722cda234477c4bd7322e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10034, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dcffaa0e4bc6a703df50a0569b0644ef;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11038, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a46e80cbbe0dc62de5a0b8e28f576280;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12041, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_554986a7c263a18633fb38cecb0ecc95;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13045, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_409437b8df9be2060bbb4de6590ec062;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14048, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8b479c0fb6704504aa7820ccfec416ef;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15052, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_76aea13a94fda28e8abedc0634b61680;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16055, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3fbe26a10d44c6c01e56c2fc0dc50dd6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17059, 100));    p->lastBulletSpeed = (FixedPointNum(225, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_27d0c2b81aafb190f182fbe085f5331b;  }
}
p->wait = 18; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_2d6f1f56b8ff17c6b6b3dff4daf11bd3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_f05d33821a3b367102acc270752a2b2c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1629, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7026be2d760b8751e4ea3a225216b6d8;  }
}
p->wait = 1; 
}
static void stepfunc_0361ed4535e94d4cd24bae13726611d3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(1629, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7026be2d760b8751e4ea3a225216b6d8;  }
}
p->wait = 1; 
}
static void stepfunc_a66f8304766f2926974b130ecb2d194d(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 15; 
}
static void stepfunc_56269e8bcafd645c04184650d67c577b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_1275822567917586952f9ce1eee71c3d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ad1d211815ebb49c775a1d4e5320d7b4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_708df97db8edf79e7d2191e5ed4dff4a;  }
}
p->wait = 360; 
}


void genBulletFunc_9baeb10b619a9434d45da296752e5266(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_847623246981c2cc85112bcf7814cd63; }}


