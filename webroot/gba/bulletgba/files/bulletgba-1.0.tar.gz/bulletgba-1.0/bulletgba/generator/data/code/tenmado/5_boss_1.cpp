// XXX uniqID XXX 599f386a5184f9d204fc27e71dd21206 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_3496dc0cbc731810bb2e3c15f8d93189(BulletInfo *p); 
static void stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p); 
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p); 
static void stepfunc_a167334eba7ec24a8be185cd69dd595e(BulletInfo *p); 
static void stepfunc_065dcd18e56c522d6a90ff69cfbc71da(BulletInfo *p); 
static void stepfunc_997377febe1631f46460abd7c72a44b7(BulletInfo *p); 
static void stepfunc_fc818c52c24e9625283f51798379b8ee(BulletInfo *p); 
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 


static const BulletStepFunc bullet_172ee9c48bc9f014971dff45a715ec8a[] = {
stepfunc_3496dc0cbc731810bb2e3c15f8d93189,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_1719c8c433f8621562924b0aa3a53c54[] = {
stepfunc_97e8979d1a7c719f55deab0bdea20675,
stepfunc_769bdefb02579aa79348dd03cdd26c8a,
stepfunc_a167334eba7ec24a8be185cd69dd595e,
#if 0
stepfunc_065dcd18e56c522d6a90ff69cfbc71da,
#endif
stepfunc_a167334eba7ec24a8be185cd69dd595e,
#if 0
stepfunc_065dcd18e56c522d6a90ff69cfbc71da,
#endif
stepfunc_a167334eba7ec24a8be185cd69dd595e,
#if 0
stepfunc_065dcd18e56c522d6a90ff69cfbc71da,
#endif
stepfunc_a167334eba7ec24a8be185cd69dd595e,
#if 0
stepfunc_065dcd18e56c522d6a90ff69cfbc71da,
#endif
stepfunc_a167334eba7ec24a8be185cd69dd595e,
#if 0
stepfunc_065dcd18e56c522d6a90ff69cfbc71da,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_857e6599e68ba67eb04908b8e15cd53d[] = {
stepfunc_997377febe1631f46460abd7c72a44b7,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_fc818c52c24e9625283f51798379b8ee,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_065dcd18e56c522d6a90ff69cfbc71da(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(247, 100));    p->lastBulletSpeed = (FixedPointNum(15)+FixedPointNum::random()*FixedPointNum(15));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-247, 100));    p->lastBulletSpeed = (FixedPointNum(15)+FixedPointNum::random()*FixedPointNum(15));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a167334eba7ec24a8be185cd69dd595e(BulletInfo *p) { 
for (u32 i = 0; i < 30; ++i) { 
stepfunc_065dcd18e56c522d6a90ff69cfbc71da(p);}
p->wait = 1; 
}
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p) { 
p->wait = 100; 
}
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_fc818c52c24e9625283f51798379b8ee(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1719c8c433f8621562924b0aa3a53c54;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1719c8c433f8621562924b0aa3a53c54;  }
}
p->wait = 100; 
}
static void stepfunc_7f11e8328fb2eb6b7676a4476f56f1c3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(1558, 100) + FixedPointNum(3116, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(160, 100) + FixedPointNum(1) * FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_3496dc0cbc731810bb2e3c15f8d93189(BulletInfo *p) { 
p->wait = 200; 
}
static void stepfunc_997377febe1631f46460abd7c72a44b7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_172ee9c48bc9f014971dff45a715ec8a;  }
}
}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}


void genBulletFunc_599f386a5184f9d204fc27e71dd21206(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_857e6599e68ba67eb04908b8e15cd53d; }}


