// XXX uniqID XXX ba72053026dfb1a5ee8ac4e26a64ff33 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e90c4b329c05f34a8b3762c03a2834d2(BulletInfo *p); 
static void stepfunc_105f2cf48511adea33be24d1774aef05(BulletInfo *p); 
static void stepfunc_6a44bb20f393a4c1d9283abe159a2ec3(BulletInfo *p); 
static void stepfunc_b091d92f297670f9bd9555cd91664b39(BulletInfo *p); 
static void stepfunc_2e824ca1b6addeab43255a677731320e(BulletInfo *p); 
static void stepfunc_f986f2d6620d8c77c7cff934fbae021f(BulletInfo *p); 
static void stepfunc_ff185b18c451356853536711e9b7209d(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_3d880a78ba32824aa66517ef05854017(BulletInfo *p); 
static void stepfunc_a79f67d2288d1858f8dae8fdc853cd08(BulletInfo *p); 
static void stepfunc_e30d971c67c76e88fe88f6dc2513dc00(BulletInfo *p); 
static void stepfunc_a854bcc4a4fd4202a5176a9ade93f2a7(BulletInfo *p); 
static void stepfunc_1f6633455711680fd98ce5187ff28079(BulletInfo *p); 
static void stepfunc_039504a3f97915332099fa67556e772b(BulletInfo *p); 
static void stepfunc_684a47bf183d40e41ff373b1e6758000(BulletInfo *p); 
static void stepfunc_aa09e039ec226acec14f4d7613156f72(BulletInfo *p); 
static void stepfunc_78d69fe32eb2138a9cd1cf354f8b34b5(BulletInfo *p); 
static void stepfunc_374e097f1f29c43f5ff7580bd638e702(BulletInfo *p); 
static void stepfunc_e230e1f661d8b717f95f573fe88410a2(BulletInfo *p); 
static void stepfunc_04fb294f133b694824e7692b26665006(BulletInfo *p); 


static const BulletStepFunc bullet_781f700307df611876f480a32087dad5[] = {
stepfunc_e90c4b329c05f34a8b3762c03a2834d2,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_105f2cf48511adea33be24d1774aef05,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_b091d92f297670f9bd9555cd91664b39,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_2e824ca1b6addeab43255a677731320e,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_f986f2d6620d8c77c7cff934fbae021f,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_ff185b18c451356853536711e9b7209d,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_fce9287e5a768f62554af121abb0a7e1[] = {
stepfunc_3d880a78ba32824aa66517ef05854017,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_a79f67d2288d1858f8dae8fdc853cd08,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_b091d92f297670f9bd9555cd91664b39,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_e30d971c67c76e88fe88f6dc2513dc00,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_a854bcc4a4fd4202a5176a9ade93f2a7,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_1f6633455711680fd98ce5187ff28079,
stepfunc_6a44bb20f393a4c1d9283abe159a2ec3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_27b167fe6d2aa19bf44456dabca15f4d[] = {
stepfunc_039504a3f97915332099fa67556e772b,
stepfunc_684a47bf183d40e41ff373b1e6758000,
stepfunc_684a47bf183d40e41ff373b1e6758000,
stepfunc_684a47bf183d40e41ff373b1e6758000,
stepfunc_684a47bf183d40e41ff373b1e6758000,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_076fa37565616c68d3aa1b4cc33a0b7d[] = {
stepfunc_aa09e039ec226acec14f4d7613156f72,
stepfunc_78d69fe32eb2138a9cd1cf354f8b34b5,
stepfunc_78d69fe32eb2138a9cd1cf354f8b34b5,
stepfunc_78d69fe32eb2138a9cd1cf354f8b34b5,
stepfunc_78d69fe32eb2138a9cd1cf354f8b34b5,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_19448953a3efa68e14ccb548e59eeff9[] = {
stepfunc_374e097f1f29c43f5ff7580bd638e702,
stepfunc_e230e1f661d8b717f95f573fe88410a2,
stepfunc_e230e1f661d8b717f95f573fe88410a2,
stepfunc_e230e1f661d8b717f95f573fe88410a2,
stepfunc_e230e1f661d8b717f95f573fe88410a2,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_505cf926b390e01d163f0d60b2ebd893[] = {
stepfunc_04fb294f133b694824e7692b26665006,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_684a47bf183d40e41ff373b1e6758000(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(35, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_039504a3f97915332099fa67556e772b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_ff185b18c451356853536711e9b7209d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-213, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_27b167fe6d2aa19bf44456dabca15f4d;  }
}
}
static void stepfunc_6a44bb20f393a4c1d9283abe159a2ec3(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_e230e1f661d8b717f95f573fe88410a2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(35, 100));    p->lastBulletSpeed = (FixedPointNum(90, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_374e097f1f29c43f5ff7580bd638e702(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(90, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_2e824ca1b6addeab43255a677731320e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-213, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_19448953a3efa68e14ccb548e59eeff9;  }
}
}
static void stepfunc_78d69fe32eb2138a9cd1cf354f8b34b5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(35, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_aa09e039ec226acec14f4d7613156f72(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_105f2cf48511adea33be24d1774aef05(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-213, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_076fa37565616c68d3aa1b4cc33a0b7d;  }
}
}
static void stepfunc_e90c4b329c05f34a8b3762c03a2834d2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-142, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_076fa37565616c68d3aa1b4cc33a0b7d;  }
}
p->wait = 1; 
}
static void stepfunc_b091d92f297670f9bd9555cd91664b39(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_19448953a3efa68e14ccb548e59eeff9;  }
}
p->wait = 1; 
}
static void stepfunc_f986f2d6620d8c77c7cff934fbae021f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-551, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_27b167fe6d2aa19bf44456dabca15f4d;  }
}
p->wait = 1; 
}
static void stepfunc_1f6633455711680fd98ce5187ff28079(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(213, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_27b167fe6d2aa19bf44456dabca15f4d;  }
}
}
static void stepfunc_e30d971c67c76e88fe88f6dc2513dc00(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(213, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_19448953a3efa68e14ccb548e59eeff9;  }
}
}
static void stepfunc_a79f67d2288d1858f8dae8fdc853cd08(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(213, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_076fa37565616c68d3aa1b4cc33a0b7d;  }
}
}
static void stepfunc_3d880a78ba32824aa66517ef05854017(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_076fa37565616c68d3aa1b4cc33a0b7d;  }
}
p->wait = 1; 
}
static void stepfunc_a854bcc4a4fd4202a5176a9ade93f2a7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(551, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_27b167fe6d2aa19bf44456dabca15f4d;  }
}
p->wait = 1; 
}
static void stepfunc_04fb294f133b694824e7692b26665006(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fce9287e5a768f62554af121abb0a7e1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_781f700307df611876f480a32087dad5;  }
}
p->wait = 190; 
}


void genBulletFunc_ba72053026dfb1a5ee8ac4e26a64ff33(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_505cf926b390e01d163f0d60b2ebd893; }}


