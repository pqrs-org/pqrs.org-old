// XXX uniqID XXX c05c4b846fdfae2c41bebf0ca5935fe9 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p); 
static void stepfunc_8922fe73617df61637e635b6285f4bbb(BulletInfo *p); 
static void stepfunc_17e8e658ead4988db7c617403a776a7b(BulletInfo *p); 
static void stepfunc_6e0e7115fce73110871bae6345b44c36(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_45632357977ac36215690c4cd2ce78f7(BulletInfo *p); 
static void stepfunc_c3d1af34af9a706dd3397cf39bb5a122(BulletInfo *p); 
static void stepfunc_dba4590926a0dccae6e6bc08572be2a3(BulletInfo *p); 
static void stepfunc_c4e721260e0b356b0e00bc717762e7bc(BulletInfo *p); 
static void stepfunc_2632fec49542063897da4fc9a4783131(BulletInfo *p); 
static void stepfunc_d0cd7805620fc84837b371755ea0b667(BulletInfo *p); 
static void stepfunc_e9178c60a943ab0a1f9afe307dfd2616(BulletInfo *p); 
static void stepfunc_d538b8b937020a1e1eed93f8b13d024c(BulletInfo *p); 
static void stepfunc_d17095d76d0e2d44698af40e5a7a5a7c(BulletInfo *p); 


static const BulletStepFunc bullet_56b30df28cc392e6c8a2d4a188592d30[] = {
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_8922fe73617df61637e635b6285f4bbb,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_6e0e7115fce73110871bae6345b44c36,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_05d1116d8b3d7aac51c78f496cb7508e[] = {
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_45632357977ac36215690c4cd2ce78f7,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_17e8e658ead4988db7c617403a776a7b,
stepfunc_c3d1af34af9a706dd3397cf39bb5a122,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d64159a07e6f59539b514d23b78cdce0[] = {
stepfunc_dba4590926a0dccae6e6bc08572be2a3,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_e9178c60a943ab0a1f9afe307dfd2616,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_e9178c60a943ab0a1f9afe307dfd2616,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_dba4590926a0dccae6e6bc08572be2a3,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_dba4590926a0dccae6e6bc08572be2a3,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_e9178c60a943ab0a1f9afe307dfd2616,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_e9178c60a943ab0a1f9afe307dfd2616,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_dba4590926a0dccae6e6bc08572be2a3,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_2632fec49542063897da4fc9a4783131,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_c4e721260e0b356b0e00bc717762e7bc,
stepfunc_d17095d76d0e2d44698af40e5a7a5a7c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d538b8b937020a1e1eed93f8b13d024c,
stepfunc_d0cd7805620fc84837b371755ea0b667,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_17e8e658ead4988db7c617403a776a7b(BulletInfo *p) { 
p->wait = 2; 
}
static void stepfunc_6e0e7115fce73110871bae6345b44c36(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-9417, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_8922fe73617df61637e635b6285f4bbb(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*((FixedPointNum::random()))*((-FixedPointNum(70, 100))));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_d538b8b937020a1e1eed93f8b13d024c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
}
static void stepfunc_c3d1af34af9a706dd3397cf39bb5a122(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(9417, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_45632357977ac36215690c4cd2ce78f7(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(255)*((FixedPointNum::random()))*(( FixedPointNum(70, 100))));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(9031, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_c4e721260e0b356b0e00bc717762e7bc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
}
static void stepfunc_dba4590926a0dccae6e6bc08572be2a3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
}
static void stepfunc_2632fec49542063897da4fc9a4783131(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_05d1116d8b3d7aac51c78f496cb7508e;  }
}
}
static void stepfunc_d0cd7805620fc84837b371755ea0b667(BulletInfo *p) { 
p->wait = 100; 
}
static void stepfunc_e9178c60a943ab0a1f9afe307dfd2616(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3187, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
}
static void stepfunc_d17095d76d0e2d44698af40e5a7a5a7c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_56b30df28cc392e6c8a2d4a188592d30;  }
}
}


void genBulletFunc_c05c4b846fdfae2c41bebf0ca5935fe9(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_d64159a07e6f59539b514d23b78cdce0; }}


