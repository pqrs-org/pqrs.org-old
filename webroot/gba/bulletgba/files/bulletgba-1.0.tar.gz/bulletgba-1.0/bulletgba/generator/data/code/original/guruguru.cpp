// XXX uniqID XXX cbe8c85d45047f76af83c300b2c43635 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_3b44e0b64b6a8bb431d74616a4e71a7d(BulletInfo *p); 
static void stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb(BulletInfo *p); 
static void stepfunc_51d6f13992ca90f2051d62e2aa16243c(BulletInfo *p); 
static void stepfunc_687fd673910e751049501b30aac9c062(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_7b3d0294588dd3512ab2522237dc707c(BulletInfo *p); 


static const BulletStepFunc bullet_550439e87af4ba794103e08fb480cb3f[] = {
stepfunc_3b44e0b64b6a8bb431d74616a4e71a7d,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_51d6f13992ca90f2051d62e2aa16243c,
stepfunc_687fd673910e751049501b30aac9c062,
#if 0
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9073935cc91d90fc418c43942a3cf85e[] = {
stepfunc_7b3d0294588dd3512ab2522237dc707c,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(850, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_51d6f13992ca90f2051d62e2aa16243c(BulletInfo *p) { 
p->wait = 12; 
}
static void stepfunc_687fd673910e751049501b30aac9c062(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-25216, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 37; ++i) { 
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb(p);}
}
static void stepfunc_3b44e0b64b6a8bb431d74616a4e71a7d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (FixedPointNum(70, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 37; ++i) { 
stepfunc_ef3f6ed37a606eb5495cd07645b2cbbb(p);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_7b3d0294588dd3512ab2522237dc707c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_550439e87af4ba794103e08fb480cb3f;  }
}
p->wait = 500; 
}


void genBulletFunc_cbe8c85d45047f76af83c300b2c43635(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_9073935cc91d90fc418c43942a3cf85e; }}


