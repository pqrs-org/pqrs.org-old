// XXX uniqID XXX 39ae97c337a2efe3d3e8dd47997da374 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p); 
static void stepfunc_c38b8de19a604c51b502ffd088e4d6af(BulletInfo *p); 
static void stepfunc_914d654698522394ea1ac5a5565cd332(BulletInfo *p); 
static void stepfunc_598ff12d99cc447949189617045dd074(BulletInfo *p); 
static void stepfunc_ecb1a2d19a18fc23fdd81e418f4769ab(BulletInfo *p); 
static void stepfunc_a6374cf1aa9779598690b2b4241bf6ce(BulletInfo *p); 
static void stepfunc_f786e4084ebd5d60a29296719fbac659(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_0d269923f50d0077902eee5d608afee7(BulletInfo *p); 
static void stepfunc_97ef24a129da1af365aba1bf6139fc41(BulletInfo *p); 
static void stepfunc_f7aaf9dae0880db2d6e1cfc00ee49bd9(BulletInfo *p); 
static void stepfunc_2b69fc5a032606d9b98a7184a7613cda(BulletInfo *p); 
static void stepfunc_55da3fcce44b588e6e9c88e16d553971(BulletInfo *p); 
static void stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d(BulletInfo *p); 
static void stepfunc_1012e5ce14a0a6853007769367fd10b9(BulletInfo *p); 
static void stepfunc_bedb3626a018924cef3262daec49203d(BulletInfo *p); 
static void stepfunc_6140fec31134a5cfc2fcf43bbf2c4990(BulletInfo *p); 
static void stepfunc_0421514c60641b60254b213bf374fd92(BulletInfo *p); 
static void stepfunc_01a9d0202b21ee05572703fc34ebd798(BulletInfo *p); 
static void stepfunc_9ac57fecaf8d0ef57701245f9e9971e4(BulletInfo *p); 
static void stepfunc_17f0eaa6375e6972005898384f6af8a9(BulletInfo *p); 
static void stepfunc_63713c5b3e85b708876f7e4101a2290f(BulletInfo *p); 
static void stepfunc_0fdcaffc937206dd3330c2bf6c79ec26(BulletInfo *p); 
static void stepfunc_620d17484409a532c0383f975b917a0c(BulletInfo *p); 
static void stepfunc_45811cd85f2a91b79b56da6d3635d147(BulletInfo *p); 
static void stepfunc_7944170f9c3fd5f3103ea478143563da(BulletInfo *p); 
static void stepfunc_2cc67d79ae0da6c6305c5de10dbb3d5f(BulletInfo *p); 
static void stepfunc_4c3702853fd3168445aa4ea36d41c051(BulletInfo *p); 
static void stepfunc_2bb1838f320ed92c3d719717f75c2b7e(BulletInfo *p); 
static void stepfunc_3f12ab4b4d864633218ba16685fd7b5c(BulletInfo *p); 
static void stepfunc_240ed82e8f6adca7033afb33b5c44948(BulletInfo *p); 
static void stepfunc_2007447c6c087596a977f4a298f5a6b8(BulletInfo *p); 
static void stepfunc_9188a20ba3d75ff36129ee4d9432594c(BulletInfo *p); 
static void stepfunc_08089edf4a10ee96646d7fd90941a103(BulletInfo *p); 
static void stepfunc_d454468f85fa5318add002c4d7c02a87(BulletInfo *p); 
static void stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be(BulletInfo *p); 
static void stepfunc_dbc055c6cf999cdf3acf2e7444b0acae(BulletInfo *p); 
static void stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec(BulletInfo *p); 
static void stepfunc_22b8804777d24e584ae3ff17217939ab(BulletInfo *p); 
static void stepfunc_603771d72033a230e75a02f535bc8f01(BulletInfo *p); 
static void stepfunc_4d8459fd6da8edf15baa61c8180de5de(BulletInfo *p); 
static void stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470(BulletInfo *p); 
static void stepfunc_cbb88ff283475def1b5915970b99371a(BulletInfo *p); 
static void stepfunc_c5ece8196a63649efed1d71b4c0a3c52(BulletInfo *p); 
static void stepfunc_6ef36c79bc1ab21ad56a6d5e22389ebf(BulletInfo *p); 
static void stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a(BulletInfo *p); 
static void stepfunc_c54ecef138f210af08e7172a608ede2d(BulletInfo *p); 
static void stepfunc_a8f138423c13e57d174b39a4f1564661(BulletInfo *p); 
static void stepfunc_d7c45ad90039ea158378524531f9d1e8(BulletInfo *p); 
static void stepfunc_791f36ed09dc20c88ce47c09cfb3c44e(BulletInfo *p); 
static void stepfunc_afc40784285dd51799fb53fad56a49bc(BulletInfo *p); 
static void stepfunc_80728fd5aef66090a507688ec467c214(BulletInfo *p); 
static void stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d(BulletInfo *p); 
static void stepfunc_05ca74c52b11c748632fb81d1b07090c(BulletInfo *p); 
static void stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf(BulletInfo *p); 
static void stepfunc_2b290df63c03443df2825c2ed54f30e5(BulletInfo *p); 
static void stepfunc_51538615c49171d5017acfbd7b325574(BulletInfo *p); 
static void stepfunc_7ff06e21b05017e1423c3e8e5745470b(BulletInfo *p); 
static void stepfunc_42c8678bc6247bba1210b878e3e951c2(BulletInfo *p); 
static void stepfunc_11fde2d1ba44f789debcb5f423608ceb(BulletInfo *p); 
static void stepfunc_8dda9727191127f3a48527bbb163136e(BulletInfo *p); 
static void stepfunc_3a0e4e636e9e4f50bf108d73eb6c4ba9(BulletInfo *p); 
static void stepfunc_5886f1c58f4b1838708007d575be49fd(BulletInfo *p); 
static void stepfunc_f0c8cc1a128f84e6ba581fc73711808f(BulletInfo *p); 
static void stepfunc_4218e869938971c02625304482ca35b6(BulletInfo *p); 
static void stepfunc_2bf3ff42cc762f5ca76495b48a29e8f0(BulletInfo *p); 
static void stepfunc_3559ec89dc5766ae683e731df8b86e2b(BulletInfo *p); 
static void stepfunc_a97ea61b8dd185cd3dff5a5d4131689f(BulletInfo *p); 
static void stepfunc_a3f88b7244294c4893eb618033649ed0(BulletInfo *p); 
static void stepfunc_d0b294e6666acc78b0e870457c5dd746(BulletInfo *p); 
static void stepfunc_32b0f8c95f61ba11a743d605ec26db9c(BulletInfo *p); 
static void stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8(BulletInfo *p); 
static void stepfunc_6a24f87a569ea0dfdd062683063f06c4(BulletInfo *p); 


static const BulletStepFunc bullet_046587bf1acffc9f8326a6192272c153[] = {
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_c38b8de19a604c51b502ffd088e4d6af,
NULL}; 
static const BulletStepFunc bullet_3d88916b47cda34307ca05a8a0ac0042[] = {
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_914d654698522394ea1ac5a5565cd332,
NULL}; 
static const BulletStepFunc bullet_a1eb97fe10c524a0647f55f0fb52bef4[] = {
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_598ff12d99cc447949189617045dd074,
NULL}; 
static const BulletStepFunc bullet_f09b411d4e13ee367619a99f33225a27[] = {
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_ecb1a2d19a18fc23fdd81e418f4769ab,
NULL}; 
static const BulletStepFunc bullet_bebfa9200844b04b42b983867436007b[] = {
stepfunc_a6374cf1aa9779598690b2b4241bf6ce,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_f786e4084ebd5d60a29296719fbac659,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_6be471e9cd387ae653dfb2203b0d683b[] = {
stepfunc_0d269923f50d0077902eee5d608afee7,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_97ef24a129da1af365aba1bf6139fc41,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_0345b4978e19443ec68767319d89139f[] = {
stepfunc_f7aaf9dae0880db2d6e1cfc00ee49bd9,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_2b69fc5a032606d9b98a7184a7613cda,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_c79c0f012229348f16601d349ff9780b[] = {
stepfunc_55da3fcce44b588e6e9c88e16d553971,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_9c74c01cbfd5f4559c2fceb7412795a2[] = {
stepfunc_1012e5ce14a0a6853007769367fd10b9,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_bedb3626a018924cef3262daec49203d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_1355aea2ac4be98c96cee941158d9098[] = {
stepfunc_6140fec31134a5cfc2fcf43bbf2c4990,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_0421514c60641b60254b213bf374fd92,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_08d707b6b26f1bee641f413a6359abb5[] = {
stepfunc_01a9d0202b21ee05572703fc34ebd798,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_9ac57fecaf8d0ef57701245f9e9971e4,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_54d501b77101d291513ec78a1779e798[] = {
stepfunc_17f0eaa6375e6972005898384f6af8a9,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_63713c5b3e85b708876f7e4101a2290f,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_30159824c84f04bebc5d56c2a827ee21[] = {
stepfunc_0fdcaffc937206dd3330c2bf6c79ec26,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_620d17484409a532c0383f975b917a0c,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_604bb0473177ca787708f652b8160d57[] = {
stepfunc_45811cd85f2a91b79b56da6d3635d147,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_7944170f9c3fd5f3103ea478143563da,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_76064ada5cec8de90e512ab544af1bfe[] = {
stepfunc_2cc67d79ae0da6c6305c5de10dbb3d5f,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_47d9f6fa3f1d1a72077714efe7f2d2ec[] = {
stepfunc_2bb1838f320ed92c3d719717f75c2b7e,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_3f12ab4b4d864633218ba16685fd7b5c,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_76589ef2c16c6a9117c9f39284ffd893[] = {
stepfunc_240ed82e8f6adca7033afb33b5c44948,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_2007447c6c087596a977f4a298f5a6b8,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_6608b880c4212e34e877d6ecbfbf0833[] = {
stepfunc_9188a20ba3d75ff36129ee4d9432594c,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_08089edf4a10ee96646d7fd90941a103,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_7dbf7e769053432b98ea9250d42f115b[] = {
stepfunc_d454468f85fa5318add002c4d7c02a87,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_b1b0346a234d273a468a826de043ff13[] = {
stepfunc_dbc055c6cf999cdf3acf2e7444b0acae,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_a21e158c806fddb07741f37d92baebee[] = {
stepfunc_22b8804777d24e584ae3ff17217939ab,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_603771d72033a230e75a02f535bc8f01,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_2a3a5651de022b9cdacf95ddde14f37b[] = {
stepfunc_4d8459fd6da8edf15baa61c8180de5de,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_15db74e5e287b0fb06a541d28477f737[] = {
stepfunc_cbb88ff283475def1b5915970b99371a,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_c5ece8196a63649efed1d71b4c0a3c52,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_57f61498f50eb6c2b8abffed2b9000ae[] = {
stepfunc_6ef36c79bc1ab21ad56a6d5e22389ebf,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_13f64b5c5ae456058b83c35a8f38520e[] = {
stepfunc_c54ecef138f210af08e7172a608ede2d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_212347d089f50172adec31bff1e375c3[] = {
stepfunc_a8f138423c13e57d174b39a4f1564661,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_d7c45ad90039ea158378524531f9d1e8,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_e4ca37f78e368878081e75f23527835f[] = {
stepfunc_791f36ed09dc20c88ce47c09cfb3c44e,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_afc40784285dd51799fb53fad56a49bc,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_34c2139312b646ac2147ce141e862210[] = {
stepfunc_80728fd5aef66090a507688ec467c214,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_bcfc10742c95b722f77b68545578772a[] = {
stepfunc_05ca74c52b11c748632fb81d1b07090c,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_9fa618001a33a34794a027922977ce41[] = {
stepfunc_2b290df63c03443df2825c2ed54f30e5,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_51538615c49171d5017acfbd7b325574,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_a9d83af3478db7d7858a8440af73d668[] = {
stepfunc_7ff06e21b05017e1423c3e8e5745470b,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_42c8678bc6247bba1210b878e3e951c2,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_bc0f9832aa3217f1b12398deb242f2b3[] = {
stepfunc_11fde2d1ba44f789debcb5f423608ceb,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_8dda9727191127f3a48527bbb163136e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_4b9a5ea1fe42ab149533dea754a8d65e[] = {
stepfunc_3a0e4e636e9e4f50bf108d73eb6c4ba9,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_5886f1c58f4b1838708007d575be49fd,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_16fbc6dc6ad2215f57415f1d1f2e4493[] = {
stepfunc_f0c8cc1a128f84e6ba581fc73711808f,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_4218e869938971c02625304482ca35b6,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_e83569786d18a9c9829225b5797f9e8c[] = {
stepfunc_2bf3ff42cc762f5ca76495b48a29e8f0,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_4c3702853fd3168445aa4ea36d41c051,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_0ba4db418da56ac89ee3854a0d8548bb[] = {
stepfunc_3559ec89dc5766ae683e731df8b86e2b,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_a97ea61b8dd185cd3dff5a5d4131689f,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_50ec2dfc212bc521f21bd2e8c966f0e6[] = {
stepfunc_a3f88b7244294c4893eb618033649ed0,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_d0b294e6666acc78b0e870457c5dd746,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_2869d09b369b5ce37ecf4e228e4e852a[] = {
stepfunc_32b0f8c95f61ba11a743d605ec26db9c,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_aba991db5bf79c9d42ff08060fc2e2c5[] = {
stepfunc_6a24f87a569ea0dfdd062683063f06c4,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_0c48d8e1fb9b6cd81ed81721c2f44adf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(202, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_05ca74c52b11c748632fb81d1b07090c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2859, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_51538615c49171d5017acfbd7b325574(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(181, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_2b290df63c03443df2825c2ed54f30e5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2558, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_42c8678bc6247bba1210b878e3e951c2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(159, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_7ff06e21b05017e1423c3e8e5745470b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2257, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_8dda9727191127f3a48527bbb163136e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(138, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_11fde2d1ba44f789debcb5f423608ceb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1956, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_5886f1c58f4b1838708007d575be49fd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(117, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_3a0e4e636e9e4f50bf108d73eb6c4ba9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1655, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_4218e869938971c02625304482ca35b6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(95, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_f0c8cc1a128f84e6ba581fc73711808f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1354, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_4c3702853fd3168445aa4ea36d41c051(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(74, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_2bf3ff42cc762f5ca76495b48a29e8f0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1053, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_a97ea61b8dd185cd3dff5a5d4131689f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(53, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_3559ec89dc5766ae683e731df8b86e2b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-752, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_d0b294e6666acc78b0e870457c5dd746(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(31, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_a3f88b7244294c4893eb618033649ed0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-451, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_422b33c8f10ef6d988bc36f4a34ae4b8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(10, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_32b0f8c95f61ba11a743d605ec26db9c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-150, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_c38b8de19a604c51b502ffd088e4d6af(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2869d09b369b5ce37ecf4e228e4e852a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_50ec2dfc212bc521f21bd2e8c966f0e6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0ba4db418da56ac89ee3854a0d8548bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e83569786d18a9c9829225b5797f9e8c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16fbc6dc6ad2215f57415f1d1f2e4493;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4b9a5ea1fe42ab149533dea754a8d65e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc0f9832aa3217f1b12398deb242f2b3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a9d83af3478db7d7858a8440af73d668;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fa618001a33a34794a027922977ce41;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bcfc10742c95b722f77b68545578772a;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_bd5bec751fcd43a10db79dd7e0a7d0be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-202, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_d454468f85fa5318add002c4d7c02a87(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2859, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_669bd5c4788cec1e4a5f02efc0ebd6ec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-181, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_dbc055c6cf999cdf3acf2e7444b0acae(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2558, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_603771d72033a230e75a02f535bc8f01(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-159, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_22b8804777d24e584ae3ff17217939ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2257, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_2fb6f9c7eabec5982f1bfcbf23d99470(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-138, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_4d8459fd6da8edf15baa61c8180de5de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1956, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_c5ece8196a63649efed1d71b4c0a3c52(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-117, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_cbb88ff283475def1b5915970b99371a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1655, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_dca53eee9a0496ddccd4672bc0a6fc0a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-95, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_6ef36c79bc1ab21ad56a6d5e22389ebf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1354, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_ecabc4b7a6eee16bb167ed35b6486a9d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-74, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_c54ecef138f210af08e7172a608ede2d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1053, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_d7c45ad90039ea158378524531f9d1e8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-53, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_a8f138423c13e57d174b39a4f1564661(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(752, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_afc40784285dd51799fb53fad56a49bc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-31, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_791f36ed09dc20c88ce47c09cfb3c44e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(451, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_5f6fdc58b22eeeb95d0b42d64deabb4d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-10, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_80728fd5aef66090a507688ec467c214(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(150, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_914d654698522394ea1ac5a5565cd332(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_34c2139312b646ac2147ce141e862210;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e4ca37f78e368878081e75f23527835f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_212347d089f50172adec31bff1e375c3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_13f64b5c5ae456058b83c35a8f38520e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_57f61498f50eb6c2b8abffed2b9000ae;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_15db74e5e287b0fb06a541d28477f737;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2a3a5651de022b9cdacf95ddde14f37b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a21e158c806fddb07741f37d92baebee;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b1b0346a234d273a468a826de043ff13;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7dbf7e769053432b98ea9250d42f115b;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_63713c5b3e85b708876f7e4101a2290f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(149, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_17f0eaa6375e6972005898384f6af8a9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1404, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_620d17484409a532c0383f975b917a0c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(124, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_0fdcaffc937206dd3330c2bf6c79ec26(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1053, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_7944170f9c3fd5f3103ea478143563da(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(99, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_45811cd85f2a91b79b56da6d3635d147(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-702, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_2cc67d79ae0da6c6305c5de10dbb3d5f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-351, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_3f12ab4b4d864633218ba16685fd7b5c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(49, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_2bb1838f320ed92c3d719717f75c2b7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_2007447c6c087596a977f4a298f5a6b8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(24, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_240ed82e8f6adca7033afb33b5c44948(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(351, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_08089edf4a10ee96646d7fd90941a103(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_9188a20ba3d75ff36129ee4d9432594c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(702, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_598ff12d99cc447949189617045dd074(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6608b880c4212e34e877d6ecbfbf0833;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_76589ef2c16c6a9117c9f39284ffd893;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_47d9f6fa3f1d1a72077714efe7f2d2ec;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_76064ada5cec8de90e512ab544af1bfe;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_604bb0473177ca787708f652b8160d57;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_30159824c84f04bebc5d56c2a827ee21;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_54d501b77101d291513ec78a1779e798;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f786e4084ebd5d60a29296719fbac659(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-149, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_a6374cf1aa9779598690b2b4241bf6ce(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1404, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_97ef24a129da1af365aba1bf6139fc41(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-124, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_0d269923f50d0077902eee5d608afee7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1053, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_2b69fc5a032606d9b98a7184a7613cda(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-99, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_f7aaf9dae0880db2d6e1cfc00ee49bd9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(702, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_55da3fcce44b588e6e9c88e16d553971(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(351, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_bedb3626a018924cef3262daec49203d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-49, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_1012e5ce14a0a6853007769367fd10b9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_0421514c60641b60254b213bf374fd92(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-24, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_6140fec31134a5cfc2fcf43bbf2c4990(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-351, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_9ac57fecaf8d0ef57701245f9e9971e4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_01a9d0202b21ee05572703fc34ebd798(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-702, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 7; 
}
static void stepfunc_ecb1a2d19a18fc23fdd81e418f4769ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_08d707b6b26f1bee641f413a6359abb5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1355aea2ac4be98c96cee941158d9098;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9c74c01cbfd5f4559c2fceb7412795a2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c79c0f012229348f16601d349ff9780b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0345b4978e19443ec68767319d89139f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6be471e9cd387ae653dfb2203b0d683b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bebfa9200844b04b42b983867436007b;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_6a24f87a569ea0dfdd062683063f06c4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15937, 100) + FixedPointNum(2125, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(50, 100) + FixedPointNum(30, 100) * FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f09b411d4e13ee367619a99f33225a27;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9562, 100) - FixedPointNum(2125, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(50, 100) + FixedPointNum(30, 100) * FixedPointNum::random());    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a1eb97fe10c524a0647f55f0fb52bef4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3d88916b47cda34307ca05a8a0ac0042;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_046587bf1acffc9f8326a6192272c153;  }
}
p->wait = 200; 
}


void genBulletFunc_39ae97c337a2efe3d3e8dd47997da374(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_aba991db5bf79c9d42ff08060fc2e2c5; }}


