// XXX uniqID XXX a983a30a9e511187154a54717c0143ea XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_ab0fd8a77cda5ccea72996d1b769bb36(BulletInfo *p); 
static void stepfunc_1dfc3afd8447fc188784bb358cd10f50(BulletInfo *p); 
static void stepfunc_57f390f67e31d12a7ae6c6629a0437fa(BulletInfo *p); 
static void stepfunc_4ebce9571a4319e43228f0f2ffcefb23(BulletInfo *p); 
static void stepfunc_e0482d42e1744850f3811c8a43cc5003(BulletInfo *p); 
static void stepfunc_5fa59814e2a5b6f4a8677ca6f9af353a(BulletInfo *p); 
static void stepfunc_cc7f150dc5d2ca8b7b58acd98c675258(BulletInfo *p); 
static void stepfunc_09e4d3d4889af564e6263f09217b9b99(BulletInfo *p); 
static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p); 


static const BulletStepFunc bullet_71641a5ff0170f04984e0d61ee3907f0[] = {
stepfunc_ab0fd8a77cda5ccea72996d1b769bb36,
stepfunc_1dfc3afd8447fc188784bb358cd10f50,
NULL}; 
static const BulletStepFunc bullet_16ad4aa1a7aa11445a2b054aa4246947[] = {
stepfunc_ab0fd8a77cda5ccea72996d1b769bb36,
stepfunc_57f390f67e31d12a7ae6c6629a0437fa,
NULL}; 
static const BulletStepFunc bullet_690401de4385d3682cfd043e393a88f6[] = {
stepfunc_4ebce9571a4319e43228f0f2ffcefb23,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_e0482d42e1744850f3811c8a43cc5003,
stepfunc_5fa59814e2a5b6f4a8677ca6f9af353a,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_cc7f150dc5d2ca8b7b58acd98c675258,
stepfunc_09e4d3d4889af564e6263f09217b9b99,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static void stepfunc_ab0fd8a77cda5ccea72996d1b769bb36(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_1dfc3afd8447fc188784bb358cd10f50(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4766, 100));    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_cc7f150dc5d2ca8b7b58acd98c675258(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-212, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_71641a5ff0170f04984e0d61ee3907f0;  }
}
}
static void stepfunc_57f390f67e31d12a7ae6c6629a0437fa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(4766, 100));    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e0482d42e1744850f3811c8a43cc5003(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(212, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16ad4aa1a7aa11445a2b054aa4246947;  }
}
}
static void stepfunc_4ebce9571a4319e43228f0f2ffcefb23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16ad4aa1a7aa11445a2b054aa4246947;  }
}
}
static void stepfunc_5fa59814e2a5b6f4a8677ca6f9af353a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_71641a5ff0170f04984e0d61ee3907f0;  }
}
}
static void stepfunc_09e4d3d4889af564e6263f09217b9b99(BulletInfo *p) { 
p->wait = 40; 
}
static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_a983a30a9e511187154a54717c0143ea(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_690401de4385d3682cfd043e393a88f6; }}


