// XXX uniqID XXX cffa211c702fc9b01b8ba8b00baf79ff XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d3088e9e7e4a67b408d3ac880ec3cd8c(BulletInfo *p); 
static void stepfunc_abb445c058075092e9fafa2f628ca971(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_27ca4fb2363271494558e09ca668bd81(BulletInfo *p); 
static void stepfunc_788e69452175e72ec07c11d326074aef(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_91c7c22abf5d44da3950dc1cc2b8d0fa(BulletInfo *p); 
static void stepfunc_f6a271b53f7ad53d82b3ec5db732a486(BulletInfo *p); 
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p); 
static void stepfunc_2378255ac0350fba31e5a6827042bafd(BulletInfo *p); 
static void stepfunc_7f4c52cff467b0a2efb9717099b1e379(BulletInfo *p); 
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p); 
static void stepfunc_de69ffec80b8572178888ed8c285cf62(BulletInfo *p); 
static void stepfunc_d1613a8d7b83e92647f6109fb15c8e72(BulletInfo *p); 
static void stepfunc_41ff32bf6e0b01f2e019a1918c7128db(BulletInfo *p); 
static void stepfunc_82b8d3a90598baed91f378e80fa94567(BulletInfo *p); 
static void stepfunc_2ce4b3752e24a53035408f73d7db73db(BulletInfo *p); 
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p); 
static void stepfunc_ddcc967ce7a08a0edd5db09f90fd7fda(BulletInfo *p); 
static void stepfunc_783386b18a49280bd963e451107845fd(BulletInfo *p); 


static const BulletStepFunc bullet_98a9f9c939433cb134af99b4b68dcb1a[] = {
stepfunc_d3088e9e7e4a67b408d3ac880ec3cd8c,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_08144451d0f0d77795d26c1510a4756f[] = {
stepfunc_d3088e9e7e4a67b408d3ac880ec3cd8c,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_740a2eeb6850147127014f5038be4f9a[] = {
stepfunc_d3088e9e7e4a67b408d3ac880ec3cd8c,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_82f08d81449d2383d3ec7c572ee41d25[] = {
stepfunc_d3088e9e7e4a67b408d3ac880ec3cd8c,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_27ca4fb2363271494558e09ca668bd81,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_fc2a36c1f35d9a4fe8bcd80a3740a524[] = {
stepfunc_d3088e9e7e4a67b408d3ac880ec3cd8c,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_abb445c058075092e9fafa2f628ca971,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_8d314febe3e9284250bd064ab01f72cf[] = {
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_405f45a6cf2398b32df20ce426c66aa7[] = {
stepfunc_788e69452175e72ec07c11d326074aef,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_91c7c22abf5d44da3950dc1cc2b8d0fa,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_f6a271b53f7ad53d82b3ec5db732a486,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_2378255ac0350fba31e5a6827042bafd,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_7f4c52cff467b0a2efb9717099b1e379,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_de69ffec80b8572178888ed8c285cf62,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_d1613a8d7b83e92647f6109fb15c8e72,
stepfunc_41ff32bf6e0b01f2e019a1918c7128db,
stepfunc_82b8d3a90598baed91f378e80fa94567,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_2ce4b3752e24a53035408f73d7db73db,
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_ddcc967ce7a08a0edd5db09f90fd7fda,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_783386b18a49280bd963e451107845fd,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_abb445c058075092e9fafa2f628ca971(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-20, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_d3088e9e7e4a67b408d3ac880ec3cd8c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d314febe3e9284250bd064ab01f72cf;  }
}
}
static void stepfunc_783386b18a49280bd963e451107845fd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-250, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98a9f9c939433cb134af99b4b68dcb1a;  }
}
}
static void stepfunc_27ca4fb2363271494558e09ca668bd81(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(20, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_2ce4b3752e24a53035408f73d7db73db(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(250, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_08144451d0f0d77795d26c1510a4756f;  }
}
}
static void stepfunc_d1613a8d7b83e92647f6109fb15c8e72(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-250, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_740a2eeb6850147127014f5038be4f9a;  }
}
}
static void stepfunc_7f4c52cff467b0a2efb9717099b1e379(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(250, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_82f08d81449d2383d3ec7c572ee41d25;  }
}
}
static void stepfunc_f6a271b53f7ad53d82b3ec5db732a486(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-250, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fc2a36c1f35d9a4fe8bcd80a3740a524;  }
}
}
static void stepfunc_788e69452175e72ec07c11d326074aef(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 4 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
p->wait = 15; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_91c7c22abf5d44da3950dc1cc2b8d0fa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fc2a36c1f35d9a4fe8bcd80a3740a524;  }
}
p->wait = 2; 
}
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_2378255ac0350fba31e5a6827042bafd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_82f08d81449d2383d3ec7c572ee41d25;  }
}
p->wait = 2; 
}
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p) { 
p->wait = 40; 
}
static void stepfunc_de69ffec80b8572178888ed8c285cf62(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_740a2eeb6850147127014f5038be4f9a;  }
}
p->wait = 2; 
}
static void stepfunc_41ff32bf6e0b01f2e019a1918c7128db(BulletInfo *p) { 
p->wait = 50; 
}
static void stepfunc_82b8d3a90598baed91f378e80fa94567(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_08144451d0f0d77795d26c1510a4756f;  }
}
p->wait = 2; 
}
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_ddcc967ce7a08a0edd5db09f90fd7fda(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_98a9f9c939433cb134af99b4b68dcb1a;  }
}
p->wait = 2; 
}


void genBulletFunc_cffa211c702fc9b01b8ba8b00baf79ff(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_405f45a6cf2398b32df20ce426c66aa7; }}


