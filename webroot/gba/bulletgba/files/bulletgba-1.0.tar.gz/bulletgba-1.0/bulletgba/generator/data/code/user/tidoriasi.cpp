// XXX uniqID XXX f917950c540d69b2ce49e994ea879638 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_3c92ce82c86a5cd12bdf89472721f652(BulletInfo *p); 
static void stepfunc_a4a415bda3459512bad8897880f29b63(BulletInfo *p); 
static void stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb(BulletInfo *p); 
static void stepfunc_bcbc4d2c29a664d846df0f399baaa717(BulletInfo *p); 
static void stepfunc_2de197e55bf19b6b5fca2512b97243fd(BulletInfo *p); 
static void stepfunc_a6f487590921a3fab6ca929b1fc139d5(BulletInfo *p); 
static void stepfunc_00f29168466f65a13699d50fb22e0690(BulletInfo *p); 
static void stepfunc_bb67c9502feaaa59b85d4002259e1032(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_2cd929520bb36ef60323e72a954a7d61[] = {
stepfunc_3c92ce82c86a5cd12bdf89472721f652,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
stepfunc_a4a415bda3459512bad8897880f29b63,
stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb,
NULL}; 
static const BulletStepFunc bullet_0e3663640b4f22d7760caba2fd2735a9[] = {
stepfunc_bcbc4d2c29a664d846df0f399baaa717,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
stepfunc_2de197e55bf19b6b5fca2512b97243fd,
stepfunc_a6f487590921a3fab6ca929b1fc139d5,
NULL}; 
static const BulletStepFunc bullet_e65a4436f80a7b32e6e51f0ec3d4ecaa[] = {
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_00f29168466f65a13699d50fb22e0690,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_a4a415bda3459512bad8897880f29b63(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((-FixedPointNum(7083, 100)-FixedPointNum::random()*FixedPointNum(2833, 100))*(-FixedPointNum(70, 100))) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 30; 
}
static void stepfunc_ce40dd78263f18e9d7334e69e9a2bbeb(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(7083, 100)+FixedPointNum::random()*FixedPointNum(2833, 100))*(-FixedPointNum(70, 100))) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 30; 
}
static void stepfunc_3c92ce82c86a5cd12bdf89472721f652(BulletInfo *p) { 
{
  u16 life = 15;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(3541, 100)+FixedPointNum::random()*FixedPointNum(1416, 100))*(-FixedPointNum(70, 100))) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 15; 
}
static void stepfunc_2de197e55bf19b6b5fca2512b97243fd(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((-FixedPointNum(7083, 100)-FixedPointNum::random()*FixedPointNum(2833, 100))*(FixedPointNum(70, 100))) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 30; 
}
static void stepfunc_a6f487590921a3fab6ca929b1fc139d5(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(7083, 100)+FixedPointNum::random()*FixedPointNum(2833, 100))*(FixedPointNum(70, 100))) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 30; 
}
static void stepfunc_bcbc4d2c29a664d846df0f399baaa717(BulletInfo *p) { 
{
  u16 life = 15;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(3541, 100)+FixedPointNum::random()*FixedPointNum(1416, 100))*(FixedPointNum(70, 100))) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 15; 
}
static void stepfunc_00f29168466f65a13699d50fb22e0690(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4958, 100)-FixedPointNum(9916, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(60, 100)+FixedPointNum::random()*FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e3663640b4f22d7760caba2fd2735a9;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4958, 100)-FixedPointNum(9916, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(60, 100)+FixedPointNum::random()*FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2cd929520bb36ef60323e72a954a7d61;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3541, 100)-FixedPointNum(7083, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e3663640b4f22d7760caba2fd2735a9;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3541, 100)-FixedPointNum(7083, 100)*FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2cd929520bb36ef60323e72a954a7d61;  }
}
p->wait = 4; 
}
static void stepfunc_bb67c9502feaaa59b85d4002259e1032(BulletInfo *p) { 
p->wait = 150; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_f917950c540d69b2ce49e994ea879638(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_e65a4436f80a7b32e6e51f0ec3d4ecaa; }}


