#!/usr/bin/env php
<?php //-*- Mode: php; indent-tabs-mode: nil; Coding: utf-8; -*-

define('MAX_REPEAT_TIMES', 20000);

require_once sprintf('%s/libcommon.php', dirname(__FILE__));
require_once sprintf('%s/libgenerate.php', dirname(__FILE__));

class Direction
{
  var $type = NULL;
  var $value = NULL;

  function Direction($elem = NULL) {
    if ($elem != NULL) {
      $this->type = $elem->getAttribute('type');
      if ($this->type == NULL) {
        $this->type = 'aim';
      }
      
      $this->value = $elem->nodeValue;
      if ($GLOBALS['horizontal']) {
        if ($this->type == "absolute") {
          $this->value = "({$this->value}) - 90";
        }
      }
      $this->value = Common::adjustAngle($this->value);
      $this->value = Common::convSpecialChar($this->value);
    }
  }

  function toCode() {
    if ($this->value !== NULL) { // compare with !== for when value == '0'.
      switch($this->type) {
        case "aim":
          return sprintf('SelfPos::getAngle(p) + (%s)', $this->value);
        case "sequence":
          return sprintf('p->lastBulletAngle + (%s)', $this->value);
        case "relative":
          return sprintf('p->getAngle() + (%s)', $this->value);
        case "absolute":
          return sprintf('(%s)', $this->value);
        default:
          error_log(Common::error('Not Supported in Direction'));
          break;
      }
    }
    return "(SelfPos::getAngle(p))";
  }
}

class Speed
{
  var $type = NULL;
  var $value = NULL;

  function Speed($elem = NULL) {
    if ($elem != NULL) {
      $this->type = $elem->getAttribute('type');
      if ($this->type == NULL) {
        $this->type = 'absolute';
      }
      $this->value = $elem->nodeValue;
      $this->value = Common::convSpecialChar($this->value);
    }
  }

  function toCode() {
    if ($this->value !== NULL) { // compare with !== for when value == '0'.
      switch ($this->type) {
        case 'relative':
          return sprintf('p->getSpeed() + (%s)', $this->value);
          break;
        case 'sequence':
          return sprintf('p->lastBulletSpeed + (%s)', $this->value);
        case 'absolute':
          return sprintf('(%s)', $this->value);
        default:
          error_log(Common::error("Not Supported in Speed ({$this->type})"));
          break;
      }
    }
    return '1';
  }
}


class ChangeDirection
{
  var $direction = NULL;
  var $term = NULL;

  function ChangeDirection($elem) {
    foreach ($elem->childNodes as $e) {
      switch ($e->nodeName) {
        case 'direction':
          $this->direction = new Direction($e);
          break;
        case 'term':
          $this->term = Common::convSpecialChar($e->nodeValue);
          break;
        default:
          error_log(Common::error('Not Supported in ChangeDirection'));
          break;
      }
    }
  }

  function generateCode($outputFileResource) {
    print "{\n";
    print "  u16 life = {$this->term};";
    print "  FixedPointNum speed = ";

    switch ($this->direction->type) {
      case 'sequence':
        print $this->direction->value;
        break;

      default:
        $speed = sprintf('%s - p->getAngle()', $this->direction->toCode());
        if ($this->term == '1') {
          print $speed;
        } else {
          print "FixedPointNum($speed, life);";
        }
        break;
    }

    print ";";
    print "p->setRound(speed, life);";
    print "}\n";
  }
}


class ChangeSpeed
{
  var $speed = NULL;
  var $term = NULL;

  function ChangeSpeed($elem) {
    foreach ($elem->childNodes as $e) {
      switch ($e->nodeName) {
        case 'speed':
          $this->speed = new Speed($e);
          break;
        case 'term':
          $this->term = Common::convSpecialChar($e->nodeValue);
          break;
        default:
          error_log(Common::error('Not Supported in ChangeSpeed'));
          break;
      }
    }
  }

  function generateCode($outputFileResource) {
    print "{\n";
    print "  u16 life = {$this->term};";
    print "  FixedPointNum speed = ";

    switch ($this->direction->type) {
      case 'sequence':
        print $this->speed->value;
        break;

      case 'relative':
        $speed = "p->getSpeed() + {$this->speed->value}";
        if ($this->term == '1') {
          print $speed;
        } else {
          print "FixedPointNum($speed, life)";
        }
        break;

      default:
        $speed = "{$this->speed->value} - p->getSpeed()";
        if ($this->term == '1') {
          print $speed;
        } else {
          print "FixedPointNum($speed, life)";
        }
        break;
    }

    print ";";
    print "p->setAccel(speed, life);";
    print "}\n";
  }
}

class Fire
{
  var $elem = NULL;
  var $direction = NULL;
  var $speed = NULL;
  var $bulletLabel = NULL;

  function Fire($elem) {
    $this->elem = $elem;

    foreach ($elem->childNodes as $e) {
      switch ($e->nodeName) {
        case 'direction':
          $this->direction = new Direction($e);
          break;
        case 'speed':
          $this->speed = new Speed($e);
          break;
        case 'bulletCall':
          $this->bulletLabel = $e->getAttribute('label');
          break;
        default:
          error_log(Common::error("Not Supported in Fire ({$e->nodeName})"));
          break;
      }
    }
    if ($this->direction == NULL) {
      $this->direction = new Direction();
    }
    if ($this->speed == NULL) {
      $this->speed = new Speed();
    }
  }

  function outputCode() {
    $angleCode = $this->direction->toCode();
    $speedCode = $this->speed->toCode();

    print "{ \n";
    print "  BulletInfo *bi;";
    print "  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);";
    print "  if (bi != NULL) {";
    print "    p->lastBulletAngle = $angleCode;";
    print "    p->lastBulletSpeed = $speedCode;";
    print "    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);";
    if ($this->bulletLabel) {
      print "  bi->stepFuncList = {$this->bulletLabel};";
    }
    print "  }\n";
    print "}\n";
  }
}

class StepFunc
{
  var $elem;

  function StepFunc($elem) {
    $this->elem = $elem;
  }

  function doConv() {
    $label = $this->elem->getAttribute('label');
    print "static void ${label}(BulletInfo *p) { \n";

    foreach ($this->elem->childNodes as $e) {
      switch ($e->nodeName) {
        case 'repeat':
          $repeat = new Repeat($e);
          if ($repeat->nowait) {
            print "for (u32 i = 0; i < {$repeat->times}; ++i) { \n";
            foreach ($e->getElementsByTagName('stepfuncCall') as $call) {
              printf("%s(p);", $call->getAttribute('label'));
            }
            print "}\n";
          }
          break;

        case 'fire':
          $newelem = new Fire($e);
          $newelem->outputCode($outputFileResource);
          break;

        case 'changeDirection':
          $newelem = new ChangeDirection($e);
          $newelem->generateCode($outputFileResource);
          break;

        case 'changeSpeed':
          $newelem = new ChangeSpeed($e);
          $newelem->generateCode($outputFileResource);
          break;

        case 'wait':
          printf("p->wait = %s; \n", Common::convSpecialChar($e->nodeValue));
          break;

        case 'vanish':
          print "ListBullets::stepFuncDrop(p);";
          break;

        default:
          error_log(Common::error("Not Supported in StepFunc {$e->nodeName} {$e->nodeValue}"));
          break;
      }
    }

    print "}\n";
  }
}

class Generator
{
  var $document;
  var $uniqID;
  var $callingvectorfile;
  var $stepfuncHash;

  function Generator($doc, $uniqID, $callingvectorfile) {
    $this->document = $doc;
    $this->uniqID = $uniqID;
    $this->callingvectorfile = $callingvectorfile;
    
    $this->stepfuncHash = array();

    if (Common::getBulletMLNode($this->document)->getAttribute('type') == 'horizontal') {
      $GLOBALS['horizontal'] = true;
    }
  }

  function doConv() {
    $this->outputHeader();
    print "\n\n";

    $this->parseCallingVectorFile();
    print "\n\n";

    $this->outputFuncDecl();
    print "\n\n";

    readfile($this->callingvectorfile);

    $this->outputStepFunc();
    print "\n\n";
    $this->outputTopFire();
    print "\n\n";
  }

  function outputHeader() {
    print "// XXX uniqID XXX {$this->uniqID} XXX \n\n";
    $listInclude = array(
      '#include <gba_types.h>',
      '#include "bullet.hpp"',
      '#include "fixed.hpp"',
      '',
      );
    print join("\n", $listInclude);
  }

  function parseCallingVectorFile() {
    $this->stepfuncHash = array();
    
    $fp = fopen($this->callingvectorfile, "r");
    while (! feof($fp)) {
      $line = fgets($fp);
      if (preg_match('/(stepfunc_.+?),/', $line, $matches)) {
        $this->stepfuncHash[$matches[1]] = true;
      }
    }
  }

  function outputFuncDecl() {
    foreach (array_keys($this->stepfuncHash) as $func) {
      print "static void $func(BulletInfo *p); \n";
    }
  }

  function outputStepFunc() {
    foreach ($this->document->getElementsByTagName('stepfuncDef') as $elem) {
      $label = $elem->getAttribute('label');
      if ($this->stepfuncHash[$label]) {
        $stepfunc = new StepFunc($elem);
        $stepfunc->doConv();
      }
    }
  }

  function outputTopFire() {
    print "void genBulletFunc_{$this->uniqID}(FixedPointNum posx, FixedPointNum posy) {";
    print "  BulletInfo * bi;";

    foreach ($this->document->getElementsByTagName('topFire') as $elem) {
      print "  bi = ListBullets::makeNewBullet(posx, posy, NULL);";
      $bulletCall = $elem->getElementsByTagName('bulletCall')->item(0);
      if ($bulletCall) {
        $label = $bulletCall->getAttribute('label');
        print "if (bi) { bi->stepFuncList = ${label}; }";
      }
    }
    print "}\n";
  }
}

if (realpath($argv[0]) == __FILE__) {
  $xmlfile = Common::getArg1();

  $doc = new DOMDocument;
  $doc->preserveWhiteSpace = false;
  $doc->load($xmlfile, LIBXML_NSCLEAN);

  $callingvectorfile = sprintf('tmp/gencallingvector/%s/%s.cpp', 
                               basename(dirname($xmlfile)),
                               basename($xmlfile, '.xml'));
  $generator = new Generator($doc, md5($xmlfile), $callingvectorfile);
  $doc = $generator->doConv();
}

?>
