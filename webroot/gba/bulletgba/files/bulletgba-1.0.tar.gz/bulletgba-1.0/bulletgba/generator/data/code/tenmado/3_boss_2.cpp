// XXX uniqID XXX 607cbe61726dd0f19d985d6de791c202 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_4353a7676635a508b7e4a5b8e0e9754f(BulletInfo *p); 
static void stepfunc_c1750c882b2e0e67456df073fa9dd5c1(BulletInfo *p); 
static void stepfunc_db42e6c51a20a5a3965e3b991657fc30(BulletInfo *p); 
static void stepfunc_5f2783fa3fd5558427e49a9a207fb390(BulletInfo *p); 
static void stepfunc_e8f9b3111825f2c6f2a2e44ca920072a(BulletInfo *p); 
static void stepfunc_eb2978b8315c966125315a5153450ed1(BulletInfo *p); 
static void stepfunc_bbc81871049cc616c3afc2f91b3b1ac5(BulletInfo *p); 
static void stepfunc_49c12bdc9a0ab3e45c5a46039cd6a334(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_f65b85457c16cff53e263d4e2e419897(BulletInfo *p); 
static void stepfunc_889798e49c62401fd7d1467956583d2b(BulletInfo *p); 
static void stepfunc_34687e43d6b1802228fdcf535cf59d3a(BulletInfo *p); 
static void stepfunc_bff8c459e578bd3d1bbeafd3b085710f(BulletInfo *p); 
static void stepfunc_f2537a8331bc3a74e9be80b9c5460071(BulletInfo *p); 
static void stepfunc_5c991efd872a3ac0ed18bb1c0952cc9c(BulletInfo *p); 
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 
static void stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466(BulletInfo *p); 
static void stepfunc_bbb4748cba4ad164ffe458c0d89c5cfa(BulletInfo *p); 
static void stepfunc_dffcb9a20d4d6218b0026b81fdb7375c(BulletInfo *p); 
static void stepfunc_642f14f5af9dd63e4828cd2d77682f38(BulletInfo *p); 
static void stepfunc_566f11f52a1dc383166f5b6e6b6a9885(BulletInfo *p); 
static void stepfunc_b8d488ec041e85c977db323ea7ad263e(BulletInfo *p); 
static void stepfunc_abf84f79d0154c71d4d8d4464109f87a(BulletInfo *p); 
static void stepfunc_cd16122b683fe4db7aee1a4dc6d6545f(BulletInfo *p); 
static void stepfunc_8df4f3e7d174d0dc2bbd2a3ae1c2d8e5(BulletInfo *p); 
static void stepfunc_9a69aca1843956363439e76d631b74e2(BulletInfo *p); 
static void stepfunc_a47c08e2340d5c0467f5952c2062d702(BulletInfo *p); 
static void stepfunc_84172e4ae77381f6b77b1888567c1668(BulletInfo *p); 
static void stepfunc_431c9823f4a3dc836e4714d384ec3732(BulletInfo *p); 


static const BulletStepFunc bullet_de5f2d17778c0951dc1adc2e48200dce[] = {
stepfunc_4353a7676635a508b7e4a5b8e0e9754f,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_db42e6c51a20a5a3965e3b991657fc30,
stepfunc_5f2783fa3fd5558427e49a9a207fb390,
stepfunc_e8f9b3111825f2c6f2a2e44ca920072a,
stepfunc_5f2783fa3fd5558427e49a9a207fb390,
stepfunc_e8f9b3111825f2c6f2a2e44ca920072a,
stepfunc_eb2978b8315c966125315a5153450ed1,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_bbc81871049cc616c3afc2f91b3b1ac5,
stepfunc_49c12bdc9a0ab3e45c5a46039cd6a334,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9da529ebefd246e8bfc9775133f407e7[] = {
stepfunc_4353a7676635a508b7e4a5b8e0e9754f,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_f65b85457c16cff53e263d4e2e419897,
stepfunc_5f2783fa3fd5558427e49a9a207fb390,
stepfunc_e8f9b3111825f2c6f2a2e44ca920072a,
stepfunc_5f2783fa3fd5558427e49a9a207fb390,
stepfunc_e8f9b3111825f2c6f2a2e44ca920072a,
stepfunc_889798e49c62401fd7d1467956583d2b,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_34687e43d6b1802228fdcf535cf59d3a,
stepfunc_bff8c459e578bd3d1bbeafd3b085710f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_59de63aac5a2044d4567a5eeff0d1dec[] = {
stepfunc_4353a7676635a508b7e4a5b8e0e9754f,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_f2537a8331bc3a74e9be80b9c5460071,
stepfunc_5c991efd872a3ac0ed18bb1c0952cc9c,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_bbb4748cba4ad164ffe458c0d89c5cfa,
stepfunc_dffcb9a20d4d6218b0026b81fdb7375c,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_642f14f5af9dd63e4828cd2d77682f38,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_642f14f5af9dd63e4828cd2d77682f38,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_642f14f5af9dd63e4828cd2d77682f38,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_642f14f5af9dd63e4828cd2d77682f38,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_0d6703a7c39512f4e505fae342c5f0ee[] = {
stepfunc_4353a7676635a508b7e4a5b8e0e9754f,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_f2537a8331bc3a74e9be80b9c5460071,
stepfunc_566f11f52a1dc383166f5b6e6b6a9885,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_b8d488ec041e85c977db323ea7ad263e,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_b8d488ec041e85c977db323ea7ad263e,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_b8d488ec041e85c977db323ea7ad263e,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_b8d488ec041e85c977db323ea7ad263e,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_b8d488ec041e85c977db323ea7ad263e,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_b8d488ec041e85c977db323ea7ad263e,
stepfunc_c1750c882b2e0e67456df073fa9dd5c1,
stepfunc_bbb4748cba4ad164ffe458c0d89c5cfa,
stepfunc_abf84f79d0154c71d4d8d4464109f87a,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_cd16122b683fe4db7aee1a4dc6d6545f,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_cd16122b683fe4db7aee1a4dc6d6545f,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_cd16122b683fe4db7aee1a4dc6d6545f,
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_cd16122b683fe4db7aee1a4dc6d6545f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9fff6d7060ae1caf6fcafca0ca02859b[] = {
stepfunc_8df4f3e7d174d0dc2bbd2a3ae1c2d8e5,
NULL}; 
static const BulletStepFunc bullet_9fc77da52df907089d1621cc8fbe44fe[] = {
stepfunc_9a69aca1843956363439e76d631b74e2,
NULL}; 
static const BulletStepFunc bullet_c699124be39f31d9eef03cb416c516de[] = {
stepfunc_a47c08e2340d5c0467f5952c2062d702,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_84172e4ae77381f6b77b1888567c1668,
stepfunc_431c9823f4a3dc836e4714d384ec3732,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_84172e4ae77381f6b77b1888567c1668(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(2125, 100) + FixedPointNum(4250, 100) * FixedPointNum::random());    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_5f2783fa3fd5558427e49a9a207fb390(BulletInfo *p) { 
p->wait = 70; 
}
static void stepfunc_e8f9b3111825f2c6f2a2e44ca920072a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(708, 100) + FixedPointNum(1416, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4353a7676635a508b7e4a5b8e0e9754f(BulletInfo *p) { 
p->wait = 120; 
}
static void stepfunc_c1750c882b2e0e67456df073fa9dd5c1(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_db42e6c51a20a5a3965e3b991657fc30(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(60, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 35; 
}
static void stepfunc_eb2978b8315c966125315a5153450ed1(BulletInfo *p) { 
p->wait = 35; 
}
static void stepfunc_bbc81871049cc616c3afc2f91b3b1ac5(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(80, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 35; 
}
static void stepfunc_49c12bdc9a0ab3e45c5a46039cd6a334(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(708, 100) + FixedPointNum(1416, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 55; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_f65b85457c16cff53e263d4e2e419897(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(60, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_889798e49c62401fd7d1467956583d2b(BulletInfo *p) { 
p->wait = 65; 
}
static void stepfunc_34687e43d6b1802228fdcf535cf59d3a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(80, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_bff8c459e578bd3d1bbeafd3b085710f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(708, 100) + FixedPointNum(1416, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 85; 
}
static void stepfunc_8df4f3e7d174d0dc2bbd2a3ae1c2d8e5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(151, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(152, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(153, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(154, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(155, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_642f14f5af9dd63e4828cd2d77682f38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(708, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fff6d7060ae1caf6fcafca0ca02859b;  }
}
}
static void stepfunc_9a69aca1843956363439e76d631b74e2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(31, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(32, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(33, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(34, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(35, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_0fe2d869ad3d4202ed0c085f7a8b0466(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-708, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fc77da52df907089d1621cc8fbe44fe;  }
}
}
static void stepfunc_f2537a8331bc3a74e9be80b9c5460071(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(12750, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(60, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 90; 
}
static void stepfunc_5c991efd872a3ac0ed18bb1c0952cc9c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4250, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fc77da52df907089d1621cc8fbe44fe;  }
}
}
static void stepfunc_bbb4748cba4ad164ffe458c0d89c5cfa(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (0) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(80, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_dffcb9a20d4d6218b0026b81fdb7375c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-6006, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fff6d7060ae1caf6fcafca0ca02859b;  }
}
}
static void stepfunc_cd16122b683fe4db7aee1a4dc6d6545f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-708, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fff6d7060ae1caf6fcafca0ca02859b;  }
}
}
static void stepfunc_b8d488ec041e85c977db323ea7ad263e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(708, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fc77da52df907089d1621cc8fbe44fe;  }
}
}
static void stepfunc_566f11f52a1dc383166f5b6e6b6a9885(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4250, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fc77da52df907089d1621cc8fbe44fe;  }
}
}
static void stepfunc_abf84f79d0154c71d4d8d4464109f87a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6006, 100));    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9fff6d7060ae1caf6fcafca0ca02859b;  }
}
}
static void stepfunc_a47c08e2340d5c0467f5952c2062d702(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (170);    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0d6703a7c39512f4e505fae342c5f0ee;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-170);    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_59de63aac5a2044d4567a5eeff0d1dec;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (170);    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9da529ebefd246e8bfc9775133f407e7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-170);    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_de5f2d17778c0951dc1adc2e48200dce;  }
}
p->wait = 60; 
}
static void stepfunc_431c9823f4a3dc836e4714d384ec3732(BulletInfo *p) { 
p->wait = 90; 
}


void genBulletFunc_607cbe61726dd0f19d985d6de791c202(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_c699124be39f31d9eef03cb416c516de; }}


