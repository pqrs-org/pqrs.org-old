// XXX uniqID XXX 2b1ce1ae9e66fb64478306a082ed09ba XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_1ab5ce99a38603460f76f7cdae1418fe(BulletInfo *p); 
static void stepfunc_716f6ad40ef40e6339c1596619f8159e(BulletInfo *p); 
static void stepfunc_b5fd945cce0782857e6266f2ff31bb21(BulletInfo *p); 
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p); 
static void stepfunc_182c039d2702cb43b64f51e77535f327(BulletInfo *p); 
static void stepfunc_0b3084c7292e66d5707f362257fba542(BulletInfo *p); 
static void stepfunc_fa337117f8aa28d2a35f9db3b7dcbaf2(BulletInfo *p); 
static void stepfunc_529ebfcd89d534001b526a6593349d76(BulletInfo *p); 
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p); 
static void stepfunc_280e5a5951608e040e94d3655d52b3ca(BulletInfo *p); 
static void stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a(BulletInfo *p); 
static void stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c(BulletInfo *p); 
static void stepfunc_11deb638165e70face19c6468d4119ce(BulletInfo *p); 
static void stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2(BulletInfo *p); 
static void stepfunc_b1b07460ad40000583403c78f7097d0a(BulletInfo *p); 
static void stepfunc_b5f90f9855f778209b4835844fc5e2fe(BulletInfo *p); 
static void stepfunc_b0622bf620fbbccd9270ff924e3adcc3(BulletInfo *p); 
static void stepfunc_7e5cde8f4492262c0603518198a8e65d(BulletInfo *p); 
static void stepfunc_88f44187520d572d87454d9bdab6cb51(BulletInfo *p); 
static void stepfunc_fdffb4adcadba3f53d85127d3887e48e(BulletInfo *p); 
static void stepfunc_9d3095d0de3365c24269935a0c7b9dfe(BulletInfo *p); 
static void stepfunc_602cdfb38e9724722a86d5736de15913(BulletInfo *p); 
static void stepfunc_0f4da85c03ee6ab5c0463b267b07fd56(BulletInfo *p); 
static void stepfunc_63cfb41b0c7a038064e2891aa2c1ea20(BulletInfo *p); 
static void stepfunc_e00f9889da1e4b7da27b2f61583cc234(BulletInfo *p); 
static void stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f(BulletInfo *p); 
static void stepfunc_43ad7b211bd2e483c7029866c03bb5df(BulletInfo *p); 
static void stepfunc_04f5f8a2eba6e2fa62d642560a0e1317(BulletInfo *p); 
static void stepfunc_2d6291aabc7f271d911c11f61aaced0e(BulletInfo *p); 
static void stepfunc_3560586c6704845d603988eef76e74c9(BulletInfo *p); 
static void stepfunc_7eebe060414ecc4ab2548fdf4b3e3e59(BulletInfo *p); 
static void stepfunc_70a4bc5b03672d45af700b72a52623fc(BulletInfo *p); 
static void stepfunc_0e8b1f3c35c4e70eb0a5fc29b5323f0c(BulletInfo *p); 


static const BulletStepFunc bullet_c683385841df5edaee271776ec20fe25[] = {
stepfunc_1ab5ce99a38603460f76f7cdae1418fe,
stepfunc_716f6ad40ef40e6339c1596619f8159e,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b5fd945cce0782857e6266f2ff31bb21,
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_1db06ce26af309e61acacbda66316d64[] = {
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_716f6ad40ef40e6339c1596619f8159e,
stepfunc_182c039d2702cb43b64f51e77535f327,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_0b3084c7292e66d5707f362257fba542,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_14d30ac5b087c2cd7b72627ab7d0d87c[] = {
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_716f6ad40ef40e6339c1596619f8159e,
stepfunc_fa337117f8aa28d2a35f9db3b7dcbaf2,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_529ebfcd89d534001b526a6593349d76,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_ef20a8d5259808afa4eea7bd01a56208[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_716f6ad40ef40e6339c1596619f8159e,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_280e5a5951608e040e94d3655d52b3ca,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d511d53ef390a988c298196608ed91ed[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_716f6ad40ef40e6339c1596619f8159e,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_e034fed3971613adc4b03fa0dd25ec7e[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_716f6ad40ef40e6339c1596619f8159e,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_c42f701185ff93e6c258628617394986[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_11deb638165e70face19c6468d4119ce,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9dd0bd96b308f41d95437d47f9b83dc8[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_b5f90f9855f778209b4835844fc5e2fe,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b93930c03bd5532b6b3a61188f9647a7[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_b0622bf620fbbccd9270ff924e3adcc3,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_0e431ce20872d407c807cdcace50f106[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_7e5cde8f4492262c0603518198a8e65d,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_c60a0efff2b29d569a1f59144c4a9197[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_88f44187520d572d87454d9bdab6cb51,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2,
stepfunc_b1b07460ad40000583403c78f7097d0a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_282676a7b2b33f43bf8a2a91442cf55d[] = {
stepfunc_fdffb4adcadba3f53d85127d3887e48e,
NULL}; 
static const BulletStepFunc bullet_1d128b32f739aea39ee7015fb602d5e1[] = {
stepfunc_9d3095d0de3365c24269935a0c7b9dfe,
NULL}; 
static const BulletStepFunc bullet_f29f4d5c9bbe54aa3a30fb317de1bf7a[] = {
stepfunc_602cdfb38e9724722a86d5736de15913,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_0f4da85c03ee6ab5c0463b267b07fd56,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d4a95ec7bb2b5db137a7744a1ce9faed[] = {
stepfunc_63cfb41b0c7a038064e2891aa2c1ea20,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_e00f9889da1e4b7da27b2f61583cc234,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_612c7636f6c199d0d6bbbe75a1ca126d[] = {
stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f,
stepfunc_43ad7b211bd2e483c7029866c03bb5df,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_04f5f8a2eba6e2fa62d642560a0e1317,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_696c95415189d1686005f6087fd774fb[] = {
stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f,
stepfunc_43ad7b211bd2e483c7029866c03bb5df,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_2d6291aabc7f271d911c11f61aaced0e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_855aa4027f846c5cbdd4d6d20e4d48b3[] = {
stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f,
stepfunc_43ad7b211bd2e483c7029866c03bb5df,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_3560586c6704845d603988eef76e74c9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_1e3982c135909b7f19f2a08b30e569c1[] = {
stepfunc_7eebe060414ecc4ab2548fdf4b3e3e59,
stepfunc_70a4bc5b03672d45af700b72a52623fc,
stepfunc_70a4bc5b03672d45af700b72a52623fc,
stepfunc_70a4bc5b03672d45af700b72a52623fc,
stepfunc_0e8b1f3c35c4e70eb0a5fc29b5323f0c,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_04f5f8a2eba6e2fa62d642560a0e1317(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(4409, 100));    p->lastBulletSpeed = (FixedPointNum(290, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f(BulletInfo *p) { 
p->wait = 4; 
}
static void stepfunc_43ad7b211bd2e483c7029866c03bb5df(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 13; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_2d6291aabc7f271d911c11f61aaced0e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4409, 100));    p->lastBulletSpeed = (FixedPointNum(290, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_3560586c6704845d603988eef76e74c9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(290, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_9d3095d0de3365c24269935a0c7b9dfe(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_855aa4027f846c5cbdd4d6d20e4d48b3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_696c95415189d1686005f6087fd774fb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-6375, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_612c7636f6c199d0d6bbbe75a1ca126d;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_0f4da85c03ee6ab5c0463b267b07fd56(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(93, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = FixedPointNum(166, 100); 
}
static void stepfunc_602cdfb38e9724722a86d5736de15913(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = FixedPointNum(166, 100); 
}
static void stepfunc_e00f9889da1e4b7da27b2f61583cc234(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-93, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = FixedPointNum(166, 100); 
}
static void stepfunc_63cfb41b0c7a038064e2891aa2c1ea20(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4515, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = FixedPointNum(166, 100); 
}
static void stepfunc_70a4bc5b03672d45af700b72a52623fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d4a95ec7bb2b5db137a7744a1ce9faed;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f29f4d5c9bbe54aa3a30fb317de1bf7a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1d128b32f739aea39ee7015fb602d5e1;  }
}
p->wait = 90; 
}
static void stepfunc_b5fd945cce0782857e6266f2ff31bb21(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(290, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_1ab5ce99a38603460f76f7cdae1418fe(BulletInfo *p) { 
p->wait = 13; 
}
static void stepfunc_716f6ad40ef40e6339c1596619f8159e(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_0b3084c7292e66d5707f362257fba542(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1756, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1505, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 15; 
}
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_182c039d2702cb43b64f51e77535f327(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9562, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8057, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 15; 
}
static void stepfunc_529ebfcd89d534001b526a6593349d76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1756, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1505, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 15; 
}
static void stepfunc_fa337117f8aa28d2a35f9db3b7dcbaf2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15937, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17442, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 15; 
}
static void stepfunc_280e5a5951608e040e94d3655d52b3ca(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17779, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(16645, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15512, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 25; 
}
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_3abe47b59f1f63ffe667e0e33cfe2b2a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(13883, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(11616, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 25; 
}
static void stepfunc_c8cfc6bbe3cf7d7e60f222d46f14e08c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9987, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8854, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7720, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 25; 
}
static void stepfunc_fdffb4adcadba3f53d85127d3887e48e(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(260, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_6b2e1e161f5a87aa7ed70396e4da71c2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(247, 100)-(FixedPointNum(495, 100)*FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(0)+(FixedPointNum(30, 100)*FixedPointNum::random()));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_282676a7b2b33f43bf8a2a91442cf55d;  }
}
p->wait = 3; 
}
static void stepfunc_b1b07460ad40000583403c78f7097d0a(BulletInfo *p) { 
p->wait = 45; 
}
static void stepfunc_11deb638165e70face19c6468d4119ce(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_b5f90f9855f778209b4835844fc5e2fe(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_b0622bf620fbbccd9270ff924e3adcc3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 15; 
}
static void stepfunc_7e5cde8f4492262c0603518198a8e65d(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_88f44187520d572d87454d9bdab6cb51(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 25; 
}
static void stepfunc_7eebe060414ecc4ab2548fdf4b3e3e59(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14957, 100));    p->lastBulletSpeed = (FixedPointNum(372, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c60a0efff2b29d569a1f59144c4a9197;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15534, 100));    p->lastBulletSpeed = (FixedPointNum(313, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e431ce20872d407c807cdcace50f106;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15509, 100));    p->lastBulletSpeed = (FixedPointNum(381, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b93930c03bd5532b6b3a61188f9647a7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(16262, 100));    p->lastBulletSpeed = (FixedPointNum(272, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9dd0bd96b308f41d95437d47f9b83dc8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(16161, 100));    p->lastBulletSpeed = (FixedPointNum(340, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c42f701185ff93e6c258628617394986;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10542, 100));    p->lastBulletSpeed = (FixedPointNum(372, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c60a0efff2b29d569a1f59144c4a9197;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9965, 100));    p->lastBulletSpeed = (FixedPointNum(313, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e431ce20872d407c807cdcace50f106;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9990, 100));    p->lastBulletSpeed = (FixedPointNum(381, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b93930c03bd5532b6b3a61188f9647a7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9237, 100));    p->lastBulletSpeed = (FixedPointNum(272, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9dd0bd96b308f41d95437d47f9b83dc8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9338, 100));    p->lastBulletSpeed = (FixedPointNum(340, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c42f701185ff93e6c258628617394986;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12395, 100));    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e034fed3971613adc4b03fa0dd25ec7e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d511d53ef390a988c298196608ed91ed;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(13104, 100));    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ef20a8d5259808afa4eea7bd01a56208;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(13301, 100));    p->lastBulletSpeed = (10);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_14d30ac5b087c2cd7b72627ab7d0d87c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12198, 100));    p->lastBulletSpeed = (10);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1db06ce26af309e61acacbda66316d64;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(16864, 100));    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c683385841df5edaee271776ec20fe25;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8635, 100));    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c683385841df5edaee271776ec20fe25;  }
}
p->wait = 50; 
}
static void stepfunc_0e8b1f3c35c4e70eb0a5fc29b5323f0c(BulletInfo *p) { 
p->wait = 110; 
}


void genBulletFunc_2b1ce1ae9e66fb64478306a082ed09ba(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_1e3982c135909b7f19f2a08b30e569c1; }}


