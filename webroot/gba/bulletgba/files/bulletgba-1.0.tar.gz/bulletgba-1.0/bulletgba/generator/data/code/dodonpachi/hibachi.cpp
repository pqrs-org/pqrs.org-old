// XXX uniqID XXX a7556e1003358aebfcf8f8259e6f80be XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_2da1303dc022b41bf87b46d8ae26241f(BulletInfo *p); 
static void stepfunc_ee3e781202522f9fe63ede75c9a055be(BulletInfo *p); 
static void stepfunc_605a07e58a9ce437faf2bbf84769780c(BulletInfo *p); 
static void stepfunc_ce5d56c9328c8a32b63d834522d8d0be(BulletInfo *p); 
static void stepfunc_c33a225e8c1ff0c722cc860114ef262e(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_a922514ff9d073e4db1dbd81dbf1568c[] = {
stepfunc_2da1303dc022b41bf87b46d8ae26241f,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ce5d56c9328c8a32b63d834522d8d0be,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ce5d56c9328c8a32b63d834522d8d0be,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_2da1303dc022b41bf87b46d8ae26241f,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_2da1303dc022b41bf87b46d8ae26241f,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ce5d56c9328c8a32b63d834522d8d0be,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ce5d56c9328c8a32b63d834522d8d0be,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_2da1303dc022b41bf87b46d8ae26241f,
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_ee3e781202522f9fe63ede75c9a055be,
#if 0
stepfunc_605a07e58a9ce437faf2bbf84769780c,
#endif
stepfunc_c33a225e8c1ff0c722cc860114ef262e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_605a07e58a9ce437faf2bbf84769780c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(850, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_ee3e781202522f9fe63ede75c9a055be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-FixedPointNum(3541, 100)+FixedPointNum::random()*FixedPointNum(1416, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 31; ++i) { 
stepfunc_605a07e58a9ce437faf2bbf84769780c(p);}
p->wait = 3; 
}
static void stepfunc_2da1303dc022b41bf87b46d8ae26241f(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(6375, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_ce5d56c9328c8a32b63d834522d8d0be(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (FixedPointNum(-6375, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_c33a225e8c1ff0c722cc860114ef262e(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_a7556e1003358aebfcf8f8259e6f80be(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_a922514ff9d073e4db1dbd81dbf1568c; }}


