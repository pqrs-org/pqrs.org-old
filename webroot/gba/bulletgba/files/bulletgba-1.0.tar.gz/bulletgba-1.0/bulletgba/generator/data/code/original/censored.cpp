// XXX uniqID XXX 12acb97956d2d2e64bce021bd4d52c4b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p); 
static void stepfunc_0bdce86a0befbc314ac05d3e836f90e1(BulletInfo *p); 
static void stepfunc_9aee3813c973b484bb5fd460f6567140(BulletInfo *p); 
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p); 
static void stepfunc_6a9ffc99e4d5272222c9fdb1179829d5(BulletInfo *p); 
static void stepfunc_a14dd3b750315712642a0b95973a297f(BulletInfo *p); 
static void stepfunc_a905dee32a5b9c4a64fea64b7735f9f8(BulletInfo *p); 
static void stepfunc_12ad0ce2ef56ad14e77fc03124992282(BulletInfo *p); 
static void stepfunc_4d8cf1fc51f871d9edeea1b97356a070(BulletInfo *p); 
static void stepfunc_566fcfff056d5dc08565045df27b6e7d(BulletInfo *p); 
static void stepfunc_3a3a78a015d6ad19696503ff88a2581c(BulletInfo *p); 
static void stepfunc_906075fe1199e7f508526ead7748559d(BulletInfo *p); 
static void stepfunc_1af0ce8258f5cffffb5357acb9436d98(BulletInfo *p); 
static void stepfunc_4f9ea0fe7ff80f19ce949124b1f6e75b(BulletInfo *p); 
static void stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_420ddd01c945273ce464f58d122aa6e2(BulletInfo *p); 
static void stepfunc_3d0082ac9931d68e3238322a019f6acb(BulletInfo *p); 
static void stepfunc_1bfb45546ff6a60d64853be034e10468(BulletInfo *p); 
static void stepfunc_16a8ec7961e4758c70b37833cf81a335(BulletInfo *p); 
static void stepfunc_fc3044f6e9262e8b5d2f2b198731f36f(BulletInfo *p); 
static void stepfunc_bc7a125124d6bcc2e02bd4aa93e10ec3(BulletInfo *p); 
static void stepfunc_96f68377a013f6b043661f300cfa7192(BulletInfo *p); 
static void stepfunc_c6006b9029cde8bd98aa91440d40f4e5(BulletInfo *p); 
static void stepfunc_b0cd05d1872dc474db839fe8b8fadc00(BulletInfo *p); 
static void stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5(BulletInfo *p); 
static void stepfunc_41291f91bdfe3e0060cb9effa828c2a5(BulletInfo *p); 
static void stepfunc_34b2b0f0428b5a5cea1437db837fa80c(BulletInfo *p); 
static void stepfunc_ae1ab3e5d16938d9eaaba535f598a6e0(BulletInfo *p); 
static void stepfunc_95136183c7a920b372018ba0bd831267(BulletInfo *p); 
static void stepfunc_e1d23a9f32b39771f3d2804bab1302b6(BulletInfo *p); 
static void stepfunc_973d42b41bd6727440b6831f7caa9d22(BulletInfo *p); 
static void stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d(BulletInfo *p); 
static void stepfunc_8ee91090d63e1b1a0d8af050012fe6da(BulletInfo *p); 
static void stepfunc_ce1ebd13bfc2699997fa30aacde18b3c(BulletInfo *p); 
static void stepfunc_5b7db755db9396e196c39ea236c135bb(BulletInfo *p); 
static void stepfunc_95f88097ae74d296035c54ec69f996e6(BulletInfo *p); 
static void stepfunc_326319567a3de0d38d13ebd0bc8d03d4(BulletInfo *p); 
static void stepfunc_6d046c5996069cd47a4ffb8eabd2e795(BulletInfo *p); 
static void stepfunc_491c6f61a40292a52572f15d686c105e(BulletInfo *p); 
static void stepfunc_d238e134ba13cae4d00ad3cb70a4867e(BulletInfo *p); 
static void stepfunc_a9da88cc99d25e9a0eaeb8f2cd6bf520(BulletInfo *p); 
static void stepfunc_bb269d32729c1ed147864e53b971eadc(BulletInfo *p); 
static void stepfunc_948314b25af0d30a0bfa9158af179287(BulletInfo *p); 


static const BulletStepFunc bullet_4c0274415805e99c356ff54b2ac3af16[] = {
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_0bdce86a0befbc314ac05d3e836f90e1,
NULL}; 
static const BulletStepFunc bullet_0e5734f6375eb48ce29b6ea95eb02f98[] = {
stepfunc_9aee3813c973b484bb5fd460f6567140,
stepfunc_142b983889f08346cc7f29996da6f2b3,
stepfunc_6a9ffc99e4d5272222c9fdb1179829d5,
NULL}; 
static const BulletStepFunc bullet_afe3487e5ffc356963e2a4923765e5ac[] = {
stepfunc_a14dd3b750315712642a0b95973a297f,
NULL}; 
static const BulletStepFunc bullet_3158f688fc1af7e08d35bf2d338ee5c7[] = {
stepfunc_a905dee32a5b9c4a64fea64b7735f9f8,
NULL}; 
static const BulletStepFunc bullet_91e85fddd1939afba2db771fccd5986c[] = {
stepfunc_12ad0ce2ef56ad14e77fc03124992282,
NULL}; 
static const BulletStepFunc bullet_9d9c5d2cfce8878b603f4fab16a5c888[] = {
stepfunc_4d8cf1fc51f871d9edeea1b97356a070,
NULL}; 
static const BulletStepFunc bullet_18c8f2c5850b277b0295409f82d5802d[] = {
stepfunc_566fcfff056d5dc08565045df27b6e7d,
NULL}; 
static const BulletStepFunc bullet_6306fc8815db296bcc9b4091d3c371a3[] = {
stepfunc_3a3a78a015d6ad19696503ff88a2581c,
NULL}; 
static const BulletStepFunc bullet_53d670175a39f741831b041706b7c854[] = {
stepfunc_906075fe1199e7f508526ead7748559d,
stepfunc_1af0ce8258f5cffffb5357acb9436d98,
NULL}; 
static const BulletStepFunc bullet_5e372bb49fe4b04cd1f760a312694aed[] = {
stepfunc_4f9ea0fe7ff80f19ce949124b1f6e75b,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_dda2783cb9640adc6f210f986b68f102[] = {
stepfunc_420ddd01c945273ce464f58d122aa6e2,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_3d0082ac9931d68e3238322a019f6acb,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b2808e0a8160632036baab3fe693386a[] = {
stepfunc_906075fe1199e7f508526ead7748559d,
stepfunc_1bfb45546ff6a60d64853be034e10468,
NULL}; 
static const BulletStepFunc bullet_662c7e4fdab39da3cc5ba08cf096c30a[] = {
stepfunc_16a8ec7961e4758c70b37833cf81a335,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_fc3044f6e9262e8b5d2f2b198731f36f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_ef54e05296a3ded3dec853255d64c721[] = {
stepfunc_bc7a125124d6bcc2e02bd4aa93e10ec3,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_96f68377a013f6b043661f300cfa7192,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d935a5619fb1e23701223c82cd7a5d65[] = {
stepfunc_906075fe1199e7f508526ead7748559d,
stepfunc_c6006b9029cde8bd98aa91440d40f4e5,
NULL}; 
static const BulletStepFunc bullet_8a8c6ed9c19285d63dc763ea6feaa232[] = {
stepfunc_b0cd05d1872dc474db839fe8b8fadc00,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_2ea7b9b354de0d731d0616b730f88096[] = {
stepfunc_41291f91bdfe3e0060cb9effa828c2a5,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_34b2b0f0428b5a5cea1437db837fa80c,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_c77930129073b8252405d68d29ccad16[] = {
stepfunc_906075fe1199e7f508526ead7748559d,
stepfunc_ae1ab3e5d16938d9eaaba535f598a6e0,
NULL}; 
static const BulletStepFunc bullet_179c7d2b844a3fb408614d797500fc1d[] = {
stepfunc_95136183c7a920b372018ba0bd831267,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_e1d23a9f32b39771f3d2804bab1302b6,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9db65835fba5b9813534040593b84f53[] = {
stepfunc_973d42b41bd6727440b6831f7caa9d22,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b4fe9001897845db990750abe5222bb0[] = {
stepfunc_906075fe1199e7f508526ead7748559d,
stepfunc_8ee91090d63e1b1a0d8af050012fe6da,
NULL}; 
static const BulletStepFunc bullet_bf99300b310a33c8c0cb9723bb95139b[] = {
stepfunc_ce1ebd13bfc2699997fa30aacde18b3c,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_5b7db755db9396e196c39ea236c135bb,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_2453c89d860237f2e3c5e0b85cc4a98f[] = {
stepfunc_95f88097ae74d296035c54ec69f996e6,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_326319567a3de0d38d13ebd0bc8d03d4,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_f041d06559a6ca4acdcaa84924cb3c43[] = {
stepfunc_906075fe1199e7f508526ead7748559d,
stepfunc_6d046c5996069cd47a4ffb8eabd2e795,
NULL}; 
static const BulletStepFunc bullet_25e1fd60f07db7fd8b9d9b160dd67f13[] = {
stepfunc_491c6f61a40292a52572f15d686c105e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_d238e134ba13cae4d00ad3cb70a4867e,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_100fba185dfc646dde6e6ccb083c2e11[] = {
stepfunc_a9da88cc99d25e9a0eaeb8f2cd6bf520,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_bb269d32729c1ed147864e53b971eadc,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_547554d8299702badf83ebe63e1e6e44[] = {
stepfunc_948314b25af0d30a0bfa9158af179287,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_bb269d32729c1ed147864e53b971eadc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-566, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_a9da88cc99d25e9a0eaeb8f2cd6bf520(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_906075fe1199e7f508526ead7748559d(BulletInfo *p) { 
p->wait = 4; 
}
static void stepfunc_6d046c5996069cd47a4ffb8eabd2e795(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_100fba185dfc646dde6e6ccb083c2e11;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d238e134ba13cae4d00ad3cb70a4867e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(566, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_491c6f61a40292a52572f15d686c105e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_a14dd3b750315712642a0b95973a297f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_25e1fd60f07db7fd8b9d9b160dd67f13;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f041d06559a6ca4acdcaa84924cb3c43;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_326319567a3de0d38d13ebd0bc8d03d4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_95f88097ae74d296035c54ec69f996e6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_8ee91090d63e1b1a0d8af050012fe6da(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2453c89d860237f2e3c5e0b85cc4a98f;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5b7db755db9396e196c39ea236c135bb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_ce1ebd13bfc2699997fa30aacde18b3c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6375, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_a905dee32a5b9c4a64fea64b7735f9f8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bf99300b310a33c8c0cb9723bb95139b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b4fe9001897845db990750abe5222bb0;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_67ebe5f1aac940f3ed08c8c3aefbcd4d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-141, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_973d42b41bd6727440b6831f7caa9d22(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10625, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_ae1ab3e5d16938d9eaaba535f598a6e0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9db65835fba5b9813534040593b84f53;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e1d23a9f32b39771f3d2804bab1302b6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_95136183c7a920b372018ba0bd831267(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10625, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_12ad0ce2ef56ad14e77fc03124992282(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_179c7d2b844a3fb408614d797500fc1d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c77930129073b8252405d68d29ccad16;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_34b2b0f0428b5a5cea1437db837fa80c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(141, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_41291f91bdfe3e0060cb9effa828c2a5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14875, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_c6006b9029cde8bd98aa91440d40f4e5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2ea7b9b354de0d731d0616b730f88096;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b46f2e5cedfc4d73b6dec7bbfb8b93f5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-141, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_b0cd05d1872dc474db839fe8b8fadc00(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14875, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_4d8cf1fc51f871d9edeea1b97356a070(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8a8c6ed9c19285d63dc763ea6feaa232;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d935a5619fb1e23701223c82cd7a5d65;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_96f68377a013f6b043661f300cfa7192(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_bc7a125124d6bcc2e02bd4aa93e10ec3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_1bfb45546ff6a60d64853be034e10468(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ef54e05296a3ded3dec853255d64c721;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_fc3044f6e9262e8b5d2f2b198731f36f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_16a8ec7961e4758c70b37833cf81a335(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_566fcfff056d5dc08565045df27b6e7d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_662c7e4fdab39da3cc5ba08cf096c30a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b2808e0a8160632036baab3fe693386a;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_3d0082ac9931d68e3238322a019f6acb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(566, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_420ddd01c945273ce464f58d122aa6e2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(23375, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_1af0ce8258f5cffffb5357acb9436d98(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_dda2783cb9640adc6f210f986b68f102;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_78433fc08b6e8cca9f07b44e82ca1a5a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-566, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_4f9ea0fe7ff80f19ce949124b1f6e75b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(23375, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 12; 
}
static void stepfunc_3a3a78a015d6ad19696503ff88a2581c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5e372bb49fe4b04cd1f760a312694aed;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_53d670175a39f741831b041706b7c854;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9aee3813c973b484bb5fd460f6567140(BulletInfo *p) { 
p->wait = 25; 
}
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_6a9ffc99e4d5272222c9fdb1179829d5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6306fc8815db296bcc9b4091d3c371a3;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_18c8f2c5850b277b0295409f82d5802d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9d9c5d2cfce8878b603f4fab16a5c888;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_91e85fddd1939afba2db771fccd5986c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3158f688fc1af7e08d35bf2d338ee5c7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_afe3487e5ffc356963e2a4923765e5ac;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_0bdce86a0befbc314ac05d3e836f90e1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-708, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e5734f6375eb48ce29b6ea95eb02f98;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(5666, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e5734f6375eb48ce29b6ea95eb02f98;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12041, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e5734f6375eb48ce29b6ea95eb02f98;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(18416, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e5734f6375eb48ce29b6ea95eb02f98;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_948314b25af0d30a0bfa9158af179287(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4c0274415805e99c356ff54b2ac3af16;  }
}
p->wait = 750; 
}


void genBulletFunc_12acb97956d2d2e64bce021bd4d52c4b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_547554d8299702badf83ebe63e1e6e44; }}


