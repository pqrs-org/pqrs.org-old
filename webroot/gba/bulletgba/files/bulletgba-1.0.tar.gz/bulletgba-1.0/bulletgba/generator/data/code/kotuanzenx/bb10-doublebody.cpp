// XXX uniqID XXX af43cb9d2f22d4551030ae4412dd6055 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p); 
static void stepfunc_9538014c64f1ddabbe581babf4685107(BulletInfo *p); 
static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p); 
static void stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119(BulletInfo *p); 
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_f2b86f358e3c399ecaf52e1ef3c4fe73(BulletInfo *p); 
static void stepfunc_960e7f3735019e4c445aa59741237fef(BulletInfo *p); 
static void stepfunc_3bf071f6d43b17c0451a1c27986ff9c4(BulletInfo *p); 
static void stepfunc_be96ec69e5012af27f30e5ce968967df(BulletInfo *p); 
static void stepfunc_7424e8b218d3bd101c65f652976c7b7f(BulletInfo *p); 
static void stepfunc_69595f7445d276f13db26078979294ad(BulletInfo *p); 
static void stepfunc_3491256c43b05cb1ba4cb801973a724f(BulletInfo *p); 
static void stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb(BulletInfo *p); 


static const BulletStepFunc bullet_f4579f7b1dbacd743de71f70678b00b6[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_9538014c64f1ddabbe581babf4685107,
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119,
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_ef9be4c72e4ef07c21e0a584ec0bfb7d[] = {
stepfunc_f2b86f358e3c399ecaf52e1ef3c4fe73,
stepfunc_960e7f3735019e4c445aa59741237fef,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_3bf071f6d43b17c0451a1c27986ff9c4,
#if 0
stepfunc_be96ec69e5012af27f30e5ce968967df,
#endif
stepfunc_7424e8b218d3bd101c65f652976c7b7f,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_69595f7445d276f13db26078979294ad,
#if 0
stepfunc_3491256c43b05cb1ba4cb801973a724f,
#endif
stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_3491256c43b05cb1ba4cb801973a724f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(70, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_69595f7445d276f13db26078979294ad(BulletInfo *p) { 
for (u32 i = 0; i < 17; ++i) { 
stepfunc_3491256c43b05cb1ba4cb801973a724f(p);}
p->wait = 10; 
}
static void stepfunc_9c08f3e7b5cec04702b2db6ad3ced5eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1275, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_be96ec69e5012af27f30e5ce968967df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-70, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_3bf071f6d43b17c0451a1c27986ff9c4(BulletInfo *p) { 
for (u32 i = 0; i < 17; ++i) { 
stepfunc_be96ec69e5012af27f30e5ce968967df(p);}
p->wait = 10; 
}
static void stepfunc_7424e8b218d3bd101c65f652976c7b7f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1275, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_f7ed0d3deb9adacb01d2cbc6b2ba7119(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1062, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-354, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(354, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1062, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_9538014c64f1ddabbe581babf4685107(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1416, 100));    p->lastBulletSpeed = (FixedPointNum(170, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-708, 100));    p->lastBulletSpeed = (FixedPointNum(170, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(170, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(708, 100));    p->lastBulletSpeed = (FixedPointNum(170, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1416, 100));    p->lastBulletSpeed = (FixedPointNum(170, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p) { 
p->wait = 40; 
}
static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_f2b86f358e3c399ecaf52e1ef3c4fe73(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4958, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f4579f7b1dbacd743de71f70678b00b6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(20541, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f4579f7b1dbacd743de71f70678b00b6;  }
}
p->wait = 30; 
}
static void stepfunc_960e7f3735019e4c445aa59741237fef(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19125, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}


void genBulletFunc_af43cb9d2f22d4551030ae4412dd6055(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_ef9be4c72e4ef07c21e0a584ec0bfb7d; }}


