// XXX uniqID XXX 3c09fcb6f15c061f00907d2637765f42 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_72a5af886ba941ff946e10e591dbb78a(BulletInfo *p); 
static void stepfunc_8a777dd8e9c314bf83dc3b25a6478810(BulletInfo *p); 
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_d2ae8a4d7f01208b30aeeedd484efed4(BulletInfo *p); 
static void stepfunc_a1840804524ee4300f3e429844d12f3c(BulletInfo *p); 
static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_e02b9348be75c18e43b0e42492bcf0ac(BulletInfo *p); 
static void stepfunc_675473bac5d7e6392e92e5a0922980ca(BulletInfo *p); 
static void stepfunc_01ac3a0ca8afb80ba6e3b3066589dfef(BulletInfo *p); 
static void stepfunc_44ea3b0e415c2b81eb1de388157afc03(BulletInfo *p); 
static void stepfunc_d0254aa118f15268799c6cfbd96ff15e(BulletInfo *p); 
static void stepfunc_70079b3368200db8c60ee6e436648093(BulletInfo *p); 
static void stepfunc_74fc2ad623d32e4eb8736079cfd901fd(BulletInfo *p); 
static void stepfunc_ab9733544207173f1ee1cca829bc2c5e(BulletInfo *p); 


static const BulletStepFunc bullet_e3ce53810aa5be5918c3313b339e2cd8[] = {
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_72a5af886ba941ff946e10e591dbb78a,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_8a777dd8e9c314bf83dc3b25a6478810,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_45bbc6c4a914fc2867d266c9146766bf[] = {
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_d2ae8a4d7f01208b30aeeedd484efed4,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_a1840804524ee4300f3e429844d12f3c,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_7e1cfdc81bab19a2e34da1fefafb3456[] = {
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_e02b9348be75c18e43b0e42492bcf0ac,
#if 0
stepfunc_675473bac5d7e6392e92e5a0922980ca,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_c00751a1d58faa09b362cd69cf904f26[] = {
stepfunc_01ac3a0ca8afb80ba6e3b3066589dfef,
stepfunc_44ea3b0e415c2b81eb1de388157afc03,
NULL}; 
static const BulletStepFunc bullet_fd03f39f6a482a6e8d8aa3c3254780cf[] = {
stepfunc_d0254aa118f15268799c6cfbd96ff15e,
stepfunc_70079b3368200db8c60ee6e436648093,
NULL}; 
static const BulletStepFunc bullet_c8bfbab15bd8cd63a54e1f18acd5455a[] = {
stepfunc_74fc2ad623d32e4eb8736079cfd901fd,
stepfunc_ab9733544207173f1ee1cca829bc2c5e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_d0254aa118f15268799c6cfbd96ff15e(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4515, 100)) - p->getAngle();p->setRound(speed, life);}
p->wait = 2; 
}
static void stepfunc_70079b3368200db8c60ee6e436648093(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(4515, 100)) - p->getAngle();p->setRound(speed, life);}
}
static void stepfunc_8a777dd8e9c314bf83dc3b25a6478810(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fd03f39f6a482a6e8d8aa3c3254780cf;  }
}
p->wait = 3; 
}
static void stepfunc_72a5af886ba941ff946e10e591dbb78a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fd03f39f6a482a6e8d8aa3c3254780cf;  }
}
p->wait = 3; 
}
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_01ac3a0ca8afb80ba6e3b3066589dfef(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(4515, 100)) - p->getAngle();p->setRound(speed, life);}
p->wait = 2; 
}
static void stepfunc_44ea3b0e415c2b81eb1de388157afc03(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4515, 100)) - p->getAngle();p->setRound(speed, life);}
}
static void stepfunc_a1840804524ee4300f3e429844d12f3c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c00751a1d58faa09b362cd69cf904f26;  }
}
p->wait = 3; 
}
static void stepfunc_d2ae8a4d7f01208b30aeeedd484efed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c00751a1d58faa09b362cd69cf904f26;  }
}
p->wait = 3; 
}
static void stepfunc_675473bac5d7e6392e92e5a0922980ca(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-708, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e02b9348be75c18e43b0e42492bcf0ac(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4250, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 12; ++i) { 
stepfunc_675473bac5d7e6392e92e5a0922980ca(p);}
p->wait = 10; 
}
static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p) { 
p->wait = 9; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_74fc2ad623d32e4eb8736079cfd901fd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7e1cfdc81bab19a2e34da1fefafb3456;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4515, 100));    p->lastBulletSpeed = (6);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7e1cfdc81bab19a2e34da1fefafb3456;  }
}
p->wait = 10; 
}
static void stepfunc_ab9733544207173f1ee1cca829bc2c5e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_45bbc6c4a914fc2867d266c9146766bf;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e3ce53810aa5be5918c3313b339e2cd8;  }
}
p->wait = 400; 
}


void genBulletFunc_3c09fcb6f15c061f00907d2637765f42(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_c8bfbab15bd8cd63a54e1f18acd5455a; }}


