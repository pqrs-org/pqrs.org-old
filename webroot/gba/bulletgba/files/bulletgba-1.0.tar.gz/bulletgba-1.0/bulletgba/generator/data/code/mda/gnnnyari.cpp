// XXX uniqID XXX 1b6ece292bd07ef0f5f993a075363670 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_9bf217c473c2f9d72c9e9f73149d122b(BulletInfo *p); 
static void stepfunc_09415ef2442d124f53863202eba967ca(BulletInfo *p); 
static void stepfunc_2da310896a8c373888ebf1e34dfa0eb2(BulletInfo *p); 
static void stepfunc_d54b6bd3832b2663cee1707e4bdd85fa(BulletInfo *p); 
static void stepfunc_4353a7676635a508b7e4a5b8e0e9754f(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_caa5514444ce3698229c34ba343d094a[] = {
stepfunc_9bf217c473c2f9d72c9e9f73149d122b,
#if 0
stepfunc_09415ef2442d124f53863202eba967ca,
#endif
NULL}; 
static const BulletStepFunc bullet_1e90f481893cb3b70914108a4e9d0fbc[] = {
stepfunc_2da310896a8c373888ebf1e34dfa0eb2,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_d54b6bd3832b2663cee1707e4bdd85fa,
stepfunc_4353a7676635a508b7e4a5b8e0e9754f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_09415ef2442d124f53863202eba967ca(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2125, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9bf217c473c2f9d72c9e9f73149d122b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 11; ++i) { 
stepfunc_09415ef2442d124f53863202eba967ca(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d54b6bd3832b2663cee1707e4bdd85fa(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1912, 100));    p->lastBulletSpeed = (FixedPointNum(750, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_caa5514444ce3698229c34ba343d094a;  }
}
p->wait = 2; 
}
static void stepfunc_2da310896a8c373888ebf1e34dfa0eb2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(12750, 100));    p->lastBulletSpeed = (FixedPointNum(750, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_caa5514444ce3698229c34ba343d094a;  }
}
p->wait = 2; 
}
static void stepfunc_4353a7676635a508b7e4a5b8e0e9754f(BulletInfo *p) { 
p->wait = 120; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_1b6ece292bd07ef0f5f993a075363670(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->stepFuncList = bullet_1e90f481893cb3b70914108a4e9d0fbc; }}


