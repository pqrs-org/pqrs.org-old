// XXX uniqID XXX 7c04c8ddb4cc59ec98fcfa85b44b9f3b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_006a613e127492b4392549734b5ef80b(BulletInfo *p); 
static void stepfunc_2eefac386815a1c8cbcb899dc9882434(BulletInfo *p); 
static void stepfunc_b2b0433243fb5832cc76b77a7f5b171e(BulletInfo *p); 
static void stepfunc_213fa2f56014bb92a5ab176ec8e2458d(BulletInfo *p); 
static void stepfunc_d020d5689ea70532e3997e2d5f9b06de(BulletInfo *p); 
static void stepfunc_2b12488d4d8ebe4da6a9930cdd690bd8(BulletInfo *p); 
static void stepfunc_5c1cf5bb5861c48ebc1cdb7b51509e88(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_01e836f74f947984081ca92f52c5fa80(BulletInfo *p); 
static void stepfunc_1cb4c105eba21355701b38c716bf446c(BulletInfo *p); 
static void stepfunc_3ddab7d59c40cd7c2d0d70eb4a68ed23(BulletInfo *p); 
static void stepfunc_f428cdd6b6e605b87b39227ac798fd55(BulletInfo *p); 
static void stepfunc_e8451810fe66d1826413952bbcd5836e(BulletInfo *p); 
static void stepfunc_a082777ffb2781f757076e9d53bc7e97(BulletInfo *p); 
static void stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3(BulletInfo *p); 
static void stepfunc_24280bdc943bac352a130ab48ccee3c4(BulletInfo *p); 
static void stepfunc_45c692033982eddc058008f7932ad8ef(BulletInfo *p); 
static void stepfunc_729d39df95407a983ba169d29c29c482(BulletInfo *p); 
static void stepfunc_47ef506264e363ebbddc7745d9dbaa4e(BulletInfo *p); 
static void stepfunc_c5924a7d0dcd73bc90f06f0efdd4a6b0(BulletInfo *p); 


static const BulletStepFunc bullet_a8d5004127d83ff2da8d17b3d73f0ec4[] = {
stepfunc_006a613e127492b4392549734b5ef80b,
stepfunc_2eefac386815a1c8cbcb899dc9882434,
stepfunc_2eefac386815a1c8cbcb899dc9882434,
stepfunc_2eefac386815a1c8cbcb899dc9882434,
stepfunc_2eefac386815a1c8cbcb899dc9882434,
stepfunc_b2b0433243fb5832cc76b77a7f5b171e,
stepfunc_213fa2f56014bb92a5ab176ec8e2458d,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_2b12488d4d8ebe4da6a9930cdd690bd8,
stepfunc_5c1cf5bb5861c48ebc1cdb7b51509e88,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_d020d5689ea70532e3997e2d5f9b06de,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_7760cbb7cb0dc84ecb401dfa992df631[] = {
stepfunc_01e836f74f947984081ca92f52c5fa80,
#if 0
stepfunc_1cb4c105eba21355701b38c716bf446c,
#endif
stepfunc_3ddab7d59c40cd7c2d0d70eb4a68ed23,
#if 0
stepfunc_f428cdd6b6e605b87b39227ac798fd55,
#endif
NULL}; 
static const BulletStepFunc bullet_4b60a7c3e3facd508cddd620464802de[] = {
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_e8451810fe66d1826413952bbcd5836e,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_a082777ffb2781f757076e9d53bc7e97,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_24280bdc943bac352a130ab48ccee3c4,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_46ab351862f42b4720bcebf2aaae9931[] = {
stepfunc_45c692033982eddc058008f7932ad8ef,
stepfunc_729d39df95407a983ba169d29c29c482,
stepfunc_47ef506264e363ebbddc7745d9dbaa4e,
stepfunc_729d39df95407a983ba169d29c29c482,
stepfunc_47ef506264e363ebbddc7745d9dbaa4e,
stepfunc_729d39df95407a983ba169d29c29c482,
stepfunc_47ef506264e363ebbddc7745d9dbaa4e,
stepfunc_47ef506264e363ebbddc7745d9dbaa4e,
stepfunc_47ef506264e363ebbddc7745d9dbaa4e,
stepfunc_729d39df95407a983ba169d29c29c482,
stepfunc_47ef506264e363ebbddc7745d9dbaa4e,
stepfunc_729d39df95407a983ba169d29c29c482,
stepfunc_47ef506264e363ebbddc7745d9dbaa4e,
stepfunc_729d39df95407a983ba169d29c29c482,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_150bd1606b029bd19534bbd467995575[] = {
stepfunc_c5924a7d0dcd73bc90f06f0efdd4a6b0,
NULL}; 
static void stepfunc_f428cdd6b6e605b87b39227ac798fd55(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-142, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1cb4c105eba21355701b38c716bf446c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(186, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_01e836f74f947984081ca92f52c5fa80(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2417, 100));    p->lastBulletSpeed = (FixedPointNum(186, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 34; ++i) { 
stepfunc_1cb4c105eba21355701b38c716bf446c(p);}
p->wait = 5; 
}
static void stepfunc_3ddab7d59c40cd7c2d0d70eb4a68ed23(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-71, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 33; ++i) { 
stepfunc_f428cdd6b6e605b87b39227ac798fd55(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_d020d5689ea70532e3997e2d5f9b06de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(5120, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7760cbb7cb0dc84ecb401dfa992df631;  }
}
}
static void stepfunc_47ef506264e363ebbddc7745d9dbaa4e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-142, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_729d39df95407a983ba169d29c29c482(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_45c692033982eddc058008f7932ad8ef(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(71, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_bf7607b0239e281cfcbf328d3fdcd0e3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_46ab351862f42b4720bcebf2aaae9931;  }
}
p->wait = 14; 
}
static void stepfunc_24280bdc943bac352a130ab48ccee3c4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-568, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_46ab351862f42b4720bcebf2aaae9931;  }
}
p->wait = 14; 
}
static void stepfunc_a082777ffb2781f757076e9d53bc7e97(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(284, 100));    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_46ab351862f42b4720bcebf2aaae9931;  }
}
p->wait = 14; 
}
static void stepfunc_e8451810fe66d1826413952bbcd5836e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(1, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_46ab351862f42b4720bcebf2aaae9931;  }
}
p->wait = 14; 
}
static void stepfunc_2eefac386815a1c8cbcb899dc9882434(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(5120, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4b60a7c3e3facd508cddd620464802de;  }
}
}
static void stepfunc_006a613e127492b4392549734b5ef80b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(5120, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4b60a7c3e3facd508cddd620464802de;  }
}
}
static void stepfunc_b2b0433243fb5832cc76b77a7f5b171e(BulletInfo *p) { 
p->wait = 420; 
}
static void stepfunc_213fa2f56014bb92a5ab176ec8e2458d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(5120, 100) * FixedPointNum::random()) + FixedPointNum(6826, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7760cbb7cb0dc84ecb401dfa992df631;  }
}
}
static void stepfunc_2b12488d4d8ebe4da6a9930cdd690bd8(BulletInfo *p) { 
p->wait = 350; 
}
static void stepfunc_5c1cf5bb5861c48ebc1cdb7b51509e88(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(5120, 100) * FixedPointNum::random()) - FixedPointNum(1706, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7760cbb7cb0dc84ecb401dfa992df631;  }
}
}
static void stepfunc_c5924a7d0dcd73bc90f06f0efdd4a6b0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a8d5004127d83ff2da8d17b3d73f0ec4;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_7c04c8ddb4cc59ec98fcfa85b44b9f3b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_150bd1606b029bd19534bbd467995575; }}


