// XXX uniqID XXX b0115792693451f1b0019a70da665614 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p); 
static void stepfunc_8fcaeec1521d40c6b9cb77141ba2eee1(BulletInfo *p); 
static void stepfunc_77c295ee9ce62a365d57ed97b9cee6d7(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_e9087c4decbb3472a5242f331b0ddbc4(BulletInfo *p); 
static void stepfunc_6f3d1c0109f3d3f74d58174ae9766028(BulletInfo *p); 
static void stepfunc_25f1f9a3d29d94f7108ab0443601f25e(BulletInfo *p); 
static void stepfunc_b87d75df22df3e3ad09b396f4e9e4641(BulletInfo *p); 
static void stepfunc_68981b23bdc95d6eec6064ad55684fad(BulletInfo *p); 
static void stepfunc_65730bbd6482fb065d128bb399d39d38(BulletInfo *p); 


static const BulletStepFunc bullet_bdf6ee6487b29cbf3e3fb9d58fb426dd[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_8fcaeec1521d40c6b9cb77141ba2eee1,
NULL}; 
static const BulletStepFunc bullet_b0391b704f969325dce239acc7c5d019[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_77c295ee9ce62a365d57ed97b9cee6d7,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_49bcdcb97c0f5f6b0e3e74fc070e9968[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_e9087c4decbb3472a5242f331b0ddbc4,
#if 0
stepfunc_6f3d1c0109f3d3f74d58174ae9766028,
#endif
NULL}; 
static const BulletStepFunc bullet_6e67811d292d17a9e0f187733ba03e2b[] = {
stepfunc_25f1f9a3d29d94f7108ab0443601f25e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_16501b9fe19947c9158f5542b7602d8d[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b87d75df22df3e3ad09b396f4e9e4641,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_68981b23bdc95d6eec6064ad55684fad,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_371311251214e7f1228261a72431aea4[] = {
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_65730bbd6482fb065d128bb399d39d38,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_68981b23bdc95d6eec6064ad55684fad(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_b87d75df22df3e3ad09b396f4e9e4641(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(11377, 100)+FixedPointNum::random()*FixedPointNum(2844, 100)));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 2; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_8fcaeec1521d40c6b9cb77141ba2eee1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16501b9fe19947c9158f5542b7602d8d;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_25f1f9a3d29d94f7108ab0443601f25e(BulletInfo *p) { 
p->wait = 9999; 
}
static void stepfunc_77c295ee9ce62a365d57ed97b9cee6d7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum::random()*FixedPointNum(256)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(40, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_6f3d1c0109f3d3f74d58174ae9766028(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e9087c4decbb3472a5242f331b0ddbc4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(7822, 100)+FixedPointNum::random()*FixedPointNum(9955, 100)));    p->lastBulletSpeed = (FixedPointNum(70, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_6f3d1c0109f3d3f74d58174ae9766028(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_65730bbd6482fb065d128bb399d39d38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_49bcdcb97c0f5f6b0e3e74fc070e9968;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_49bcdcb97c0f5f6b0e3e74fc070e9968;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_49bcdcb97c0f5f6b0e3e74fc070e9968;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b0391b704f969325dce239acc7c5d019;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b0391b704f969325dce239acc7c5d019;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(4977, 100)+FixedPointNum::random()*FixedPointNum(15644, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(250, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bdf6ee6487b29cbf3e3fb9d58fb426dd;  }
}
}


void genBulletFunc_b0115792693451f1b0019a70da665614(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_371311251214e7f1228261a72431aea4; }}


