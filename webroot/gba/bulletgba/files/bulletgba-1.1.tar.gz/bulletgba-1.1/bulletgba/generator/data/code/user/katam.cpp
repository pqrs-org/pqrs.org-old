// XXX uniqID XXX 1149f116b0a988d47aa6550165fedf28 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_eda3c4844ab0e23db7ba058e82c14b00(BulletInfo *p); 
static void stepfunc_bbd5fcfa97ef6b60bd782ede93efc037(BulletInfo *p); 
static void stepfunc_0c09ac1e14d0a9f85d8301cd0771c526(BulletInfo *p); 
static void stepfunc_0363ae10148f2e078604cc0cb82f521c(BulletInfo *p); 
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p); 
static void stepfunc_03034928edf60127eff624e6a4334758(BulletInfo *p); 
static void stepfunc_791bd331f3196931cf83b338c33146eb(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_e3aac6dde283a8bdf603c9403d24fb8f(BulletInfo *p); 
static void stepfunc_3ae91687fcd6be207e26c49ad3da69c5(BulletInfo *p); 
static void stepfunc_c3c161e74e0403e6f2a126059bd3c949(BulletInfo *p); 
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p); 
static void stepfunc_772b39ed6331e56075ce61f1ea7848ab(BulletInfo *p); 


static const BulletStepFunc bullet_29744535fe6a2b97a412013bfd7df8d6[] = {
stepfunc_eda3c4844ab0e23db7ba058e82c14b00,
stepfunc_bbd5fcfa97ef6b60bd782ede93efc037,
stepfunc_0c09ac1e14d0a9f85d8301cd0771c526,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_03034928edf60127eff624e6a4334758,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_03034928edf60127eff624e6a4334758,
stepfunc_791bd331f3196931cf83b338c33146eb,
stepfunc_791bd331f3196931cf83b338c33146eb,
stepfunc_791bd331f3196931cf83b338c33146eb,
stepfunc_791bd331f3196931cf83b338c33146eb,
stepfunc_791bd331f3196931cf83b338c33146eb,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_03034928edf60127eff624e6a4334758,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_0363ae10148f2e078604cc0cb82f521c,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_1fbc7f494b44605adc5153426c0986d7[] = {
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_e3aac6dde283a8bdf603c9403d24fb8f,
stepfunc_3ae91687fcd6be207e26c49ad3da69c5,
stepfunc_c3c161e74e0403e6f2a126059bd3c949,
NULL}; 
static const BulletStepFunc bullet_8d0f1b2229e7dcc0780ecb1431c14360[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_772b39ed6331e56075ce61f1ea7848ab,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_e3aac6dde283a8bdf603c9403d24fb8f(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-3, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_3ae91687fcd6be207e26c49ad3da69c5(BulletInfo *p) { 
p->wait = 2; 
}
static void stepfunc_c3c161e74e0403e6f2a126059bd3c949(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (0) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 100;  FixedPointNum speed = FixedPointNum(3 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_0363ae10148f2e078604cc0cb82f521c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1fbc7f494b44605adc5153426c0986d7;  }
}
}
static void stepfunc_791bd331f3196931cf83b338c33146eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(284, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1fbc7f494b44605adc5153426c0986d7;  }
}
}
static void stepfunc_03034928edf60127eff624e6a4334758(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1208, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1fbc7f494b44605adc5153426c0986d7;  }
}
}
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_eda3c4844ab0e23db7ba058e82c14b00(BulletInfo *p) { 
p->wait = (FixedPointNum(20)+FixedPointNum::random()*FixedPointNum(5)); 
}
static void stepfunc_bbd5fcfa97ef6b60bd782ede93efc037(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = (FixedPointNum(3)+FixedPointNum::random()*FixedPointNum(10)); 
}
static void stepfunc_0c09ac1e14d0a9f85d8301cd0771c526(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1fbc7f494b44605adc5153426c0986d7;  }
}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_772b39ed6331e56075ce61f1ea7848ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((-FixedPointNum(64)+FixedPointNum(128)*FixedPointNum::random()));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_29744535fe6a2b97a412013bfd7df8d6;  }
}
}
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p) { 
p->wait = 10; 
}


void genBulletFunc_1149f116b0a988d47aa6550165fedf28(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_8d0f1b2229e7dcc0780ecb1431c14360; }}


