// XXX uniqID XXX 31f7d852540ff65e2a09f118d80bb291 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d999f5e2d4c6f7bb3622ae7218c91777(BulletInfo *p); 
static void stepfunc_a242393356b9107044443862b10f3ac8(BulletInfo *p); 
static void stepfunc_cbb7477baa2f06980b85592a6168e1e1(BulletInfo *p); 
static void stepfunc_ee628cdbdeedbfa54f81736abd3bf6a0(BulletInfo *p); 
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p); 
static void stepfunc_2f99471138ff0f89bbb44d98d7474b97(BulletInfo *p); 
static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p); 
static void stepfunc_cb918c8dfdbb8ea8a7a1adce58322f4e(BulletInfo *p); 
static void stepfunc_a08edce5676d55dc5f77ec6bfc9f1cf9(BulletInfo *p); 
static void stepfunc_b64711a8ae85eed652fc886f28b42bd2(BulletInfo *p); 
static void stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7(BulletInfo *p); 
static void stepfunc_78b593420e9664eb75091c0c96b0bc6a(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_187c139bfa7d54972de86ae18b89e815[] = {
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_a242393356b9107044443862b10f3ac8,
stepfunc_cbb7477baa2f06980b85592a6168e1e1,
#if 0
stepfunc_ee628cdbdeedbfa54f81736abd3bf6a0,
#endif
NULL}; 
static const BulletStepFunc bullet_1ba21f4c8c49117ebb9fe0cc237ceaa8[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_2f99471138ff0f89bbb44d98d7474b97,
stepfunc_cbb7477baa2f06980b85592a6168e1e1,
#if 0
stepfunc_ee628cdbdeedbfa54f81736abd3bf6a0,
#endif
NULL}; 
static const BulletStepFunc bullet_4e12e015b941e6a3799c666992a12ffe[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_cb918c8dfdbb8ea8a7a1adce58322f4e,
stepfunc_cbb7477baa2f06980b85592a6168e1e1,
#if 0
stepfunc_ee628cdbdeedbfa54f81736abd3bf6a0,
#endif
NULL}; 
static const BulletStepFunc bullet_9da3888c8740fbc29b92eafdb80a8b30[] = {
stepfunc_a08edce5676d55dc5f77ec6bfc9f1cf9,
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_a08edce5676d55dc5f77ec6bfc9f1cf9,
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_a08edce5676d55dc5f77ec6bfc9f1cf9,
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_a08edce5676d55dc5f77ec6bfc9f1cf9,
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_b64711a8ae85eed652fc886f28b42bd2,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_78b593420e9664eb75091c0c96b0bc6a,
#if 0
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b64711a8ae85eed652fc886f28b42bd2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3128, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7(p);}
p->wait = 15; 
}
static void stepfunc_78b593420e9664eb75091c0c96b0bc6a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3840, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_d0cd9e3b5145c9ac6097a44ca56bc7f7(p);}
p->wait = 15; 
}
static void stepfunc_ee628cdbdeedbfa54f81736abd3bf6a0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d999f5e2d4c6f7bb3622ae7218c91777(BulletInfo *p) { 
p->wait = 7; 
}
static void stepfunc_a242393356b9107044443862b10f3ac8(BulletInfo *p) { 
{
  u16 life = 40;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 133; 
}
static void stepfunc_cbb7477baa2f06980b85592a6168e1e1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(220, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_ee628cdbdeedbfa54f81736abd3bf6a0(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_2f99471138ff0f89bbb44d98d7474b97(BulletInfo *p) { 
{
  u16 life = 40;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 130; 
}
static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_cb918c8dfdbb8ea8a7a1adce58322f4e(BulletInfo *p) { 
{
  u16 life = 40;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 120; 
}
static void stepfunc_a08edce5676d55dc5f77ec6bfc9f1cf9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4977, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4e12e015b941e6a3799c666992a12ffe;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4977, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4e12e015b941e6a3799c666992a12ffe;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(3555, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4e12e015b941e6a3799c666992a12ffe;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-3555, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4e12e015b941e6a3799c666992a12ffe;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1ba21f4c8c49117ebb9fe0cc237ceaa8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1ba21f4c8c49117ebb9fe0cc237ceaa8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_187c139bfa7d54972de86ae18b89e815;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_187c139bfa7d54972de86ae18b89e815;  }
}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_31f7d852540ff65e2a09f118d80bb291(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_9da3888c8740fbc29b92eafdb80a8b30; }}


