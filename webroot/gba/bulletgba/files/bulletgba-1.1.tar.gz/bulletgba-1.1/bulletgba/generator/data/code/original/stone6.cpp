// XXX uniqID XXX b745da1e97fe21aaba580867de0b09d6 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p); 
static void stepfunc_a90c7f07902b352ea2ef449dc87b1993(BulletInfo *p); 
static void stepfunc_d48778f14d2240a9b455b3233cd90bcc(BulletInfo *p); 
static void stepfunc_baf77633a2d1b656dc3dd5e2419fd57c(BulletInfo *p); 
static void stepfunc_b742fa8f1fb5a01d88f4f52c27532834(BulletInfo *p); 
static void stepfunc_dd37917856369b6acf90c25adbfe9bbf(BulletInfo *p); 
static void stepfunc_6478f7c2e4e49e8dcf5f8d06aaad800c(BulletInfo *p); 
static void stepfunc_25292ccbb4342b16ae94878c84530980(BulletInfo *p); 
static void stepfunc_1525fd28d138edc9d01d1a55b92ff4ee(BulletInfo *p); 


static const BulletStepFunc bullet_97cc9a06dd6a4963333073e97e9bd6bd[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_a90c7f07902b352ea2ef449dc87b1993,
#if 0
stepfunc_d48778f14d2240a9b455b3233cd90bcc,
#endif
NULL}; 
static const BulletStepFunc bullet_7a9cabebb401082865743f5a4cb180a5[] = {
stepfunc_baf77633a2d1b656dc3dd5e2419fd57c,
stepfunc_b742fa8f1fb5a01d88f4f52c27532834,
stepfunc_dd37917856369b6acf90c25adbfe9bbf,
stepfunc_6478f7c2e4e49e8dcf5f8d06aaad800c,
stepfunc_25292ccbb4342b16ae94878c84530980,
stepfunc_1525fd28d138edc9d01d1a55b92ff4ee,
NULL}; 
static void stepfunc_d48778f14d2240a9b455b3233cd90bcc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(568, 100));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_a90c7f07902b352ea2ef449dc87b1993(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
for (u32 i = 0; i < 45; ++i) { 
stepfunc_d48778f14d2240a9b455b3233cd90bcc(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_baf77633a2d1b656dc3dd5e2419fd57c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10666, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97cc9a06dd6a4963333073e97e9bd6bd;  }
}
p->wait = 2; 
}
static void stepfunc_b742fa8f1fb5a01d88f4f52c27532834(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14933, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97cc9a06dd6a4963333073e97e9bd6bd;  }
}
p->wait = 2; 
}
static void stepfunc_dd37917856369b6acf90c25adbfe9bbf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97cc9a06dd6a4963333073e97e9bd6bd;  }
}
p->wait = 2; 
}
static void stepfunc_6478f7c2e4e49e8dcf5f8d06aaad800c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97cc9a06dd6a4963333073e97e9bd6bd;  }
}
p->wait = 2; 
}
static void stepfunc_25292ccbb4342b16ae94878c84530980(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97cc9a06dd6a4963333073e97e9bd6bd;  }
}
p->wait = 2; 
}
static void stepfunc_1525fd28d138edc9d01d1a55b92ff4ee(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_97cc9a06dd6a4963333073e97e9bd6bd;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_b745da1e97fe21aaba580867de0b09d6(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_7a9cabebb401082865743f5a4cb180a5; }}


