// XXX uniqID XXX 54e3ac1c7d8719e6c08417ece9d0a581 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 
static void stepfunc_eb8ca55bd7482524ff07b7027aa0ddc4(BulletInfo *p); 
static void stepfunc_fd558b62063e0da4c517bc4f9f6f671d(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_302286ceaaebb9a65744ad503a2c515c[] = {
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_eb8ca55bd7482524ff07b7027aa0ddc4,
NULL}; 
static const BulletStepFunc bullet_4a3c2cc0b471fa3d57b095680db00082[] = {
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_fd558b62063e0da4c517bc4f9f6f671d,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_eb8ca55bd7482524ff07b7027aa0ddc4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1493, 100)+FixedPointNum::random()*FixedPointNum(5973, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1493, 100)-FixedPointNum::random()*FixedPointNum(5973, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(497, 100)+FixedPointNum::random()*FixedPointNum(1991, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(497, 100)-FixedPointNum::random()*FixedPointNum(1991, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum::random()*FixedPointNum(995, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum::random()*(-FixedPointNum(995, 100))));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_fd558b62063e0da4c517bc4f9f6f671d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1066, 100));    p->lastBulletSpeed = (FixedPointNum(54, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_302286ceaaebb9a65744ad503a2c515c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(10880, 100));    p->lastBulletSpeed = (FixedPointNum(54, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_302286ceaaebb9a65744ad503a2c515c;  }
}
p->wait = 3; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_54e3ac1c7d8719e6c08417ece9d0a581(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_4a3c2cc0b471fa3d57b095680db00082; }}


