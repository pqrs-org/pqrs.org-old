// XXX uniqID XXX 1826f1b70570a49c436e155d1a055e7f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_a865c6c8b44585d6739ff7b1938fd90f(BulletInfo *p); 
static void stepfunc_8e13b3bc86e83829f4bca10e4c9e6e8e(BulletInfo *p); 
static void stepfunc_1a3e455f5d921bf06129ceb8a7496dad(BulletInfo *p); 
static void stepfunc_a3a897c8160713fd874566a816f11df8(BulletInfo *p); 
static void stepfunc_b53510be08f4ad3bb0647a296b6f0e12(BulletInfo *p); 
static void stepfunc_24ec406bc2af43b9c4355b40ad3767a0(BulletInfo *p); 
static void stepfunc_1f8f9493d984c5245f32e70ccc8bc434(BulletInfo *p); 
static void stepfunc_02dbc09c05106c2ea7496ed512bb461a(BulletInfo *p); 
static void stepfunc_7c564656058d6d2b1776df53d659037b(BulletInfo *p); 
static void stepfunc_04d26531c96b1994281dba8545f8a2ac(BulletInfo *p); 
static void stepfunc_e741543fb559b0053df8f06d9acedfef(BulletInfo *p); 
static void stepfunc_023aa3d24ede88f534935bb8e810d5f4(BulletInfo *p); 
static void stepfunc_8c00fe0a4c84f9fbc784329551c103ec(BulletInfo *p); 
static void stepfunc_f18d27f58a022356b208a9ddf9296310(BulletInfo *p); 
static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p); 
static void stepfunc_c2d98fe33c6703259cdb0bd438dbae86(BulletInfo *p); 
static void stepfunc_9e413b85bd849b0e9a9dba563376dcd2(BulletInfo *p); 
static void stepfunc_2636dddee383d11c7f10f81dac98ed63(BulletInfo *p); 
static void stepfunc_11d46ce79ea4913d6f810e01e039ee3b(BulletInfo *p); 
static void stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a(BulletInfo *p); 
static void stepfunc_5ed3d9fc2eb84740c1179b80bd163792(BulletInfo *p); 
static void stepfunc_9c871d861a91f097d81073ca097cc7d4(BulletInfo *p); 


static const BulletStepFunc bullet_bd5beb965bbe927a0a60088d17052b65[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_8e13b3bc86e83829f4bca10e4c9e6e8e,
#if 0
stepfunc_1a3e455f5d921bf06129ceb8a7496dad,
#endif
stepfunc_8e13b3bc86e83829f4bca10e4c9e6e8e,
#if 0
stepfunc_a3a897c8160713fd874566a816f11df8,
#endif
NULL}; 
static const BulletStepFunc bullet_9e39cf409362ca10195fbe8423dac08a[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_b53510be08f4ad3bb0647a296b6f0e12,
#if 0
stepfunc_24ec406bc2af43b9c4355b40ad3767a0,
#endif
stepfunc_b53510be08f4ad3bb0647a296b6f0e12,
#if 0
stepfunc_1f8f9493d984c5245f32e70ccc8bc434,
#endif
NULL}; 
static const BulletStepFunc bullet_8f3b1c1f452ce96f505a52b6911f099d[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_02dbc09c05106c2ea7496ed512bb461a,
#if 0
stepfunc_7c564656058d6d2b1776df53d659037b,
#endif
stepfunc_02dbc09c05106c2ea7496ed512bb461a,
#if 0
stepfunc_04d26531c96b1994281dba8545f8a2ac,
#endif
NULL}; 
static const BulletStepFunc bullet_3608010f6e5d7d14b98003bd593b1651[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_e741543fb559b0053df8f06d9acedfef,
#if 0
stepfunc_023aa3d24ede88f534935bb8e810d5f4,
#endif
stepfunc_e741543fb559b0053df8f06d9acedfef,
#if 0
stepfunc_8c00fe0a4c84f9fbc784329551c103ec,
#endif
NULL}; 
static const BulletStepFunc bullet_77b40024ea7d9ef5c8280f6516f55f94[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_f18d27f58a022356b208a9ddf9296310,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_a006e44f18b69731d7180e94ec5e2780[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_c2d98fe33c6703259cdb0bd438dbae86,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_e0666bdf20dd28a752ed94bd503560dc[] = {
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_9e413b85bd849b0e9a9dba563376dcd2,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_2636dddee383d11c7f10f81dac98ed63,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_11d46ce79ea4913d6f810e01e039ee3b,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_5ed3d9fc2eb84740c1179b80bd163792,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_9c871d861a91f097d81073ca097cc7d4,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static void stepfunc_a3a897c8160713fd874566a816f11df8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1a3e455f5d921bf06129ceb8a7496dad(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-355, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a865c6c8b44585d6739ff7b1938fd90f(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_8e13b3bc86e83829f4bca10e4c9e6e8e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-355, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_1a3e455f5d921bf06129ceb8a7496dad(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a3a897c8160713fd874566a816f11df8(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1f8f9493d984c5245f32e70ccc8bc434(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_24ec406bc2af43b9c4355b40ad3767a0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(355, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b53510be08f4ad3bb0647a296b6f0e12(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(355, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_24ec406bc2af43b9c4355b40ad3767a0(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_1f8f9493d984c5245f32e70ccc8bc434(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_04d26531c96b1994281dba8545f8a2ac(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_7c564656058d6d2b1776df53d659037b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_02dbc09c05106c2ea7496ed512bb461a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_7c564656058d6d2b1776df53d659037b(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_04d26531c96b1994281dba8545f8a2ac(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8c00fe0a4c84f9fbc784329551c103ec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_023aa3d24ede88f534935bb8e810d5f4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e741543fb559b0053df8f06d9acedfef(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_023aa3d24ede88f534935bb8e810d5f4(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c00fe0a4c84f9fbc784329551c103ec(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c2d98fe33c6703259cdb0bd438dbae86(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(0)+FixedPointNum::random()*FixedPointNum(142, 100)));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1422, 100)+FixedPointNum::random()*FixedPointNum(142, 100)));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(2844, 100)+FixedPointNum::random()*FixedPointNum(142, 100)));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1422, 100)+FixedPointNum::random()*FixedPointNum(142, 100)));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2844, 100)+FixedPointNum::random()*FixedPointNum(142, 100)));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 4; 
}
static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_f18d27f58a022356b208a9ddf9296310(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2133, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a006e44f18b69731d7180e94ec5e2780;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a006e44f18b69731d7180e94ec5e2780;  }
}
p->wait = 10; 
}
static void stepfunc_5ed3d9fc2eb84740c1179b80bd163792(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_77b40024ea7d9ef5c8280f6516f55f94;  }
}
p->wait = 5; 
}
static void stepfunc_9c871d861a91f097d81073ca097cc7d4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3608010f6e5d7d14b98003bd593b1651;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8f3b1c1f452ce96f505a52b6911f099d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e39cf409362ca10195fbe8423dac08a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd5beb965bbe927a0a60088d17052b65;  }
}
p->wait = 5; 
}
static void stepfunc_11d46ce79ea4913d6f810e01e039ee3b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_77b40024ea7d9ef5c8280f6516f55f94;  }
}
p->wait = 10; 
}
static void stepfunc_dd1f0f77cca9e0ccb97a25ceff99dd7a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3608010f6e5d7d14b98003bd593b1651;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8f3b1c1f452ce96f505a52b6911f099d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e39cf409362ca10195fbe8423dac08a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd5beb965bbe927a0a60088d17052b65;  }
}
p->wait = 10; 
}
static void stepfunc_9e413b85bd849b0e9a9dba563376dcd2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_77b40024ea7d9ef5c8280f6516f55f94;  }
}
p->wait = 20; 
}
static void stepfunc_2636dddee383d11c7f10f81dac98ed63(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3608010f6e5d7d14b98003bd593b1651;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8f3b1c1f452ce96f505a52b6911f099d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e39cf409362ca10195fbe8423dac08a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd5beb965bbe927a0a60088d17052b65;  }
}
p->wait = 20; 
}


void genBulletFunc_1826f1b70570a49c436e155d1a055e7f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_e0666bdf20dd28a752ed94bd503560dc; }}


