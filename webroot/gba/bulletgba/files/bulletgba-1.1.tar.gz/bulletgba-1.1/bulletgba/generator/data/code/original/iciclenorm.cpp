// XXX uniqID XXX 53c13894eae8edf5506d14ddfc5e8ca0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_7eb4837f2b20d4622c4c1e8f21bbe02c(BulletInfo *p); 
static void stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd(BulletInfo *p); 
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p); 
static void stepfunc_0894dd4185a3466d1baed6c4e9e47def(BulletInfo *p); 
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_c7437e7373b4e409806267e9bfecacbb(BulletInfo *p); 
static void stepfunc_9c21bb72c443b999b91a090d78b6e6df(BulletInfo *p); 
static void stepfunc_b2a7b3a5506d461c3b20696c817ee562(BulletInfo *p); 
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p); 
static void stepfunc_c171546d34da720eb4dcf7e93b89067a(BulletInfo *p); 
static void stepfunc_1cdee57bd8b063b9f0f8496fb082c321(BulletInfo *p); 
static void stepfunc_39a3b2b47d9c6032de5b2096c17ed7c3(BulletInfo *p); 
static void stepfunc_ce62d9dfffdc20095dd9fc380c8eaf75(BulletInfo *p); 
static void stepfunc_c5b2d23d3b5a0ca1f3e650efeffc7d4c(BulletInfo *p); 
static void stepfunc_b3fac4a89e7897815219673933d99a1c(BulletInfo *p); 
static void stepfunc_040710afaff73cb37459339f48381b53(BulletInfo *p); 
static void stepfunc_ea40f6c57e1300587d9f3739aaeac613(BulletInfo *p); 


static const BulletStepFunc bullet_2de8d17288e8519ac2b4d8bffe2e3efd[] = {
stepfunc_7eb4837f2b20d4622c4c1e8f21bbe02c,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_0894dd4185a3466d1baed6c4e9e47def,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_d65ed5ffde90c2180ff4ef9b19c65766[] = {
stepfunc_c7437e7373b4e409806267e9bfecacbb,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_b2a7b3a5506d461c3b20696c817ee562,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_9c21bb72c443b999b91a090d78b6e6df,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_4bcac5eabf2acefe1cbc28a2de5ad6fa[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_c171546d34da720eb4dcf7e93b89067a,
stepfunc_1cdee57bd8b063b9f0f8496fb082c321,
stepfunc_39a3b2b47d9c6032de5b2096c17ed7c3,
NULL}; 
static const BulletStepFunc bullet_6d2425c51d5370cb00f82a4a071c2731[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_c171546d34da720eb4dcf7e93b89067a,
stepfunc_ce62d9dfffdc20095dd9fc380c8eaf75,
stepfunc_39a3b2b47d9c6032de5b2096c17ed7c3,
NULL}; 
static const BulletStepFunc bullet_20eba77a5b40f436e2b139fe417699b1[] = {
stepfunc_c5b2d23d3b5a0ca1f3e650efeffc7d4c,
stepfunc_b3fac4a89e7897815219673933d99a1c,
stepfunc_040710afaff73cb37459339f48381b53,
#if 0
stepfunc_ea40f6c57e1300587d9f3739aaeac613,
#endif
stepfunc_b3fac4a89e7897815219673933d99a1c,
stepfunc_040710afaff73cb37459339f48381b53,
#if 0
stepfunc_ea40f6c57e1300587d9f3739aaeac613,
#endif
stepfunc_b3fac4a89e7897815219673933d99a1c,
stepfunc_040710afaff73cb37459339f48381b53,
#if 0
stepfunc_ea40f6c57e1300587d9f3739aaeac613,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_ea40f6c57e1300587d9f3739aaeac613(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1422, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b3fac4a89e7897815219673933d99a1c(BulletInfo *p) { 
p->wait = 100; 
}
static void stepfunc_040710afaff73cb37459339f48381b53(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2844, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_ea40f6c57e1300587d9f3739aaeac613(p);}
}
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p) { 
p->wait = 40; 
}
static void stepfunc_c171546d34da720eb4dcf7e93b89067a(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_ce62d9dfffdc20095dd9fc380c8eaf75(BulletInfo *p) { 
{
  u16 life = 0;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-5937, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 20; 
}
static void stepfunc_39a3b2b47d9c6032de5b2096c17ed7c3(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(FixedPointNum(80, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_5c68b29e8ccad6ddd047ae195f61a0fd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6d2425c51d5370cb00f82a4a071c2731;  }
}
}
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_0894dd4185a3466d1baed6c4e9e47def(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-462, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6d2425c51d5370cb00f82a4a071c2731;  }
}
}
static void stepfunc_7eb4837f2b20d4622c4c1e8f21bbe02c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-5937, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6d2425c51d5370cb00f82a4a071c2731;  }
}
}
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_1cdee57bd8b063b9f0f8496fb082c321(BulletInfo *p) { 
{
  u16 life = 0;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(5937, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 20; 
}
static void stepfunc_9c21bb72c443b999b91a090d78b6e6df(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4bcac5eabf2acefe1cbc28a2de5ad6fa;  }
}
}
static void stepfunc_b2a7b3a5506d461c3b20696c817ee562(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(462, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4bcac5eabf2acefe1cbc28a2de5ad6fa;  }
}
}
static void stepfunc_c7437e7373b4e409806267e9bfecacbb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(5937, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4bcac5eabf2acefe1cbc28a2de5ad6fa;  }
}
}
static void stepfunc_c5b2d23d3b5a0ca1f3e650efeffc7d4c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d65ed5ffde90c2180ff4ef9b19c65766;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2de8d17288e8519ac2b4d8bffe2e3efd;  }
}
}


void genBulletFunc_53c13894eae8edf5506d14ddfc5e8ca0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_20eba77a5b40f436e2b139fe417699b1; }}


