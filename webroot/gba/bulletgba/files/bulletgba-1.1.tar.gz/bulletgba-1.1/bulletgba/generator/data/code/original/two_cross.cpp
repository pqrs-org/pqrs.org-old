// XXX uniqID XXX 04db868b07ae624fec8214f68ad240c3 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p); 
static void stepfunc_dbadaad2ff82a071691a3a7881768a62(BulletInfo *p); 
static void stepfunc_42af9e0fea3afbb77371472da9ddde1c(BulletInfo *p); 
static void stepfunc_4c80b8efad0c07716c511d601956d683(BulletInfo *p); 
static void stepfunc_3c81a7b3e65497d75f2c6dd0b4d94056(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_8766a5032d8ac2357040c2de74340782[] = {
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_dbadaad2ff82a071691a3a7881768a62,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
NULL}; 
static const BulletStepFunc bullet_aa3ad95af73af73ca51c696b4924ce89[] = {
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
stepfunc_4c80b8efad0c07716c511d601956d683,
#if 0
stepfunc_42af9e0fea3afbb77371472da9ddde1c,
#endif
NULL}; 
static const BulletStepFunc bullet_d05fdaf7d015632b7ca66e3cecbddafb[] = {
stepfunc_3c81a7b3e65497d75f2c6dd0b4d94056,
stepfunc_3c81a7b3e65497d75f2c6dd0b4d94056,
stepfunc_3c81a7b3e65497d75f2c6dd0b4d94056,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_42af9e0fea3afbb77371472da9ddde1c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (64);    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_dbadaad2ff82a071691a3a7881768a62(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-202, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_42af9e0fea3afbb77371472da9ddde1c(p);}
p->wait = 4; 
}
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_4c80b8efad0c07716c511d601956d683(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(202, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_42af9e0fea3afbb77371472da9ddde1c(p);}
p->wait = 4; 
}
static void stepfunc_3c81a7b3e65497d75f2c6dd0b4d94056(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1517, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_aa3ad95af73af73ca51c696b4924ce89;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1517, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8766a5032d8ac2357040c2de74340782;  }
}
p->wait = 80; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_04db868b07ae624fec8214f68ad240c3(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_d05fdaf7d015632b7ca66e3cecbddafb; }}


