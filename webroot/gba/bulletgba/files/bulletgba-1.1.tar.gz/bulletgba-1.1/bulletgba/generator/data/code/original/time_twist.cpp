// XXX uniqID XXX 49c777a07e5ff5012ab8673422373223 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_f4323c2faff95e5d43596ceb701f1f8c(BulletInfo *p); 
static void stepfunc_c7d3bb89a2f48689092bf7b478d3e52f(BulletInfo *p); 
static void stepfunc_1406dbc0e95d0e28d136d83b6fb7b91a(BulletInfo *p); 
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 
static void stepfunc_5439538fd4baf1feae7a3abd132fe9a8(BulletInfo *p); 
static void stepfunc_d0b16b98f2c9e7394fa3442969567303(BulletInfo *p); 
static void stepfunc_e8dc0db58e1159e94b4f3477982a2bab(BulletInfo *p); 
static void stepfunc_2d1ce767abae5406f6b9ffff33898788(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_c4a3bb6edfd0630697b1510f02afd9ff(BulletInfo *p); 
static void stepfunc_4742e174cc351c99041cd0b0bec5d0e9(BulletInfo *p); 
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p); 
static void stepfunc_9614c45ae3acafc62e3820bf3fa17b06(BulletInfo *p); 
static void stepfunc_17171781cbd716ace724cf7344b39fba(BulletInfo *p); 
static void stepfunc_2f624a9685000b947084015ec2e794ef(BulletInfo *p); 
static void stepfunc_6616569ffc4b15d198bedc782c5aa499(BulletInfo *p); 
static void stepfunc_d1bd02a5b42bf28a515664b6d6302b08(BulletInfo *p); 
static void stepfunc_7f0075d67c1f721c4f48a329150948a7(BulletInfo *p); 
static void stepfunc_7f0a30884d50a3b8ba8fe845e184b11d(BulletInfo *p); 
static void stepfunc_88c24c68b77d06335b2afe7e6f76f94f(BulletInfo *p); 
static void stepfunc_9f9b673a4b97f3d3cfb6add98a7ed662(BulletInfo *p); 
static void stepfunc_35dfb82b81f9ca721a64c8f07177ffb6(BulletInfo *p); 
static void stepfunc_150d8c9baf034133bfa1984cc5b334f1(BulletInfo *p); 
static void stepfunc_3738da4e799ae77c78338e3db7be8b68(BulletInfo *p); 
static void stepfunc_42dbb348fc2be4bdf3d3441eee09c416(BulletInfo *p); 
static void stepfunc_117670ea76a704aae84164b6f2730877(BulletInfo *p); 
static void stepfunc_b4db4a15e9d73afe83dd865209d7269e(BulletInfo *p); 
static void stepfunc_64d1a1821c2c5a242fc6c0d3b5ca1dda(BulletInfo *p); 
static void stepfunc_11e8c05faebc19dca42bbf97f3fea693(BulletInfo *p); 


static const BulletStepFunc bullet_f190aa6884a278f4529e5232116c1e3a[] = {
stepfunc_f4323c2faff95e5d43596ceb701f1f8c,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_1406dbc0e95d0e28d136d83b6fb7b91a,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_c7d3bb89a2f48689092bf7b478d3e52f,
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_5439538fd4baf1feae7a3abd132fe9a8,
#if 0
stepfunc_d0b16b98f2c9e7394fa3442969567303,
#endif
NULL}; 
static const BulletStepFunc bullet_a67c117a35e32445d70c7275640985be[] = {
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_e8dc0db58e1159e94b4f3477982a2bab,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_2d1ce767abae5406f6b9ffff33898788,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_00f6f4401b9621ab6ef85bfc138124bb[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_c4a3bb6edfd0630697b1510f02afd9ff,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_4742e174cc351c99041cd0b0bec5d0e9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_40e3effd1227168104764c562bc55357[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_142b983889f08346cc7f29996da6f2b3,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9614c45ae3acafc62e3820bf3fa17b06,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_07e53e76dab24b6f0cfb36cc8460f7cd[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_17171781cbd716ace724cf7344b39fba,
stepfunc_2f624a9685000b947084015ec2e794ef,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
stepfunc_6616569ffc4b15d198bedc782c5aa499,
stepfunc_d1bd02a5b42bf28a515664b6d6302b08,
stepfunc_7f0075d67c1f721c4f48a329150948a7,
NULL}; 
static const BulletStepFunc bullet_4319deb805b093dacef80764abe8750f[] = {
stepfunc_7f0a30884d50a3b8ba8fe845e184b11d,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_88c24c68b77d06335b2afe7e6f76f94f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_c8b556e4e1a9404b40a07c545cfa53bd[] = {
stepfunc_9f9b673a4b97f3d3cfb6add98a7ed662,
NULL}; 
static const BulletStepFunc bullet_d95c107110383f3de8a7446d3f50614d[] = {
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_35dfb82b81f9ca721a64c8f07177ffb6,
NULL}; 
static const BulletStepFunc bullet_183cf84ebd7bc18dbd4ad3b3aebe8d28[] = {
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_150d8c9baf034133bfa1984cc5b334f1,
NULL}; 
static const BulletStepFunc bullet_8a7c319b39fc0744cf296622866e36cc[] = {
stepfunc_3738da4e799ae77c78338e3db7be8b68,
stepfunc_42dbb348fc2be4bdf3d3441eee09c416,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_117670ea76a704aae84164b6f2730877,
stepfunc_b4db4a15e9d73afe83dd865209d7269e,
stepfunc_64d1a1821c2c5a242fc6c0d3b5ca1dda,
stepfunc_11e8c05faebc19dca42bbf97f3fea693,
NULL}; 
static void stepfunc_d0b16b98f2c9e7394fa3442969567303(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128) * FixedPointNum::random()) * FixedPointNum(71, 100));    p->lastBulletSpeed = ((
      (FixedPointNum(80, 100) + FixedPointNum(110, 100)*(FixedPointNum(180) * FixedPointNum::random())*(FixedPointNum(180)-(FixedPointNum(180) * FixedPointNum::random()))/FixedPointNum(8100)) * (FixedPointNum(50, 100)+FixedPointNum(50, 100)*FixedPointNum::random()) * FixedPointNum(1)
    ));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128) * FixedPointNum::random()) * (-FixedPointNum(71, 100)));    p->lastBulletSpeed = ((
      (FixedPointNum(80, 100) + FixedPointNum(110, 100)*(FixedPointNum(180) * FixedPointNum::random())*(FixedPointNum(180)-(FixedPointNum(180) * FixedPointNum::random()))/FixedPointNum(8100)) * (FixedPointNum(50, 100)+FixedPointNum(50, 100)*FixedPointNum::random()) * FixedPointNum(1)
    ));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_c7d3bb89a2f48689092bf7b478d3e52f(BulletInfo *p) { 
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 5; 
}
static void stepfunc_f4323c2faff95e5d43596ceb701f1f8c(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(FixedPointNum(110, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_1406dbc0e95d0e28d136d83b6fb7b91a(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_5439538fd4baf1feae7a3abd132fe9a8(BulletInfo *p) { 
for (u32 i = 0; i < 300; ++i) { 
stepfunc_d0b16b98f2c9e7394fa3442969567303(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_35dfb82b81f9ca721a64c8f07177ffb6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-64);    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_150d8c9baf034133bfa1984cc5b334f1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2d1ce767abae5406f6b9ffff33898788(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_183cf84ebd7bc18dbd4ad3b3aebe8d28;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d95c107110383f3de8a7446d3f50614d;  }
}
p->wait = 2; 
}
static void stepfunc_e8dc0db58e1159e94b4f3477982a2bab(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_9f9b673a4b97f3d3cfb6add98a7ed662(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(((FixedPointNum(11377, 100) + FixedPointNum(2844, 100) * FixedPointNum::random())) - p->getAngle(), life);;p->setRound(speed, life);}
{
  u16 life = 300;  FixedPointNum speed = FixedPointNum(3 - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_88c24c68b77d06335b2afe7e6f76f94f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((-FixedPointNum(32) + FixedPointNum(64) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c8b556e4e1a9404b40a07c545cfa53bd;  }
}
p->wait = 3; 
}
static void stepfunc_7f0a30884d50a3b8ba8fe845e184b11d(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(((FixedPointNum(11377, 100) + FixedPointNum(2844, 100) * FixedPointNum::random())) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 30; 
}
static void stepfunc_117670ea76a704aae84164b6f2730877(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((-FixedPointNum(32) + FixedPointNum(64) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4319deb805b093dacef80764abe8750f;  }
}
p->wait = 6; 
}
static void stepfunc_6616569ffc4b15d198bedc782c5aa499(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (32);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_d1bd02a5b42bf28a515664b6d6302b08(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-32);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_7f0075d67c1f721c4f48a329150948a7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4266, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_17171781cbd716ace724cf7344b39fba(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(8533, 100)) - p->getAngle();p->setRound(speed, life);}
p->wait = 5; 
}
static void stepfunc_2f624a9685000b947084015ec2e794ef(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_4742e174cc351c99041cd0b0bec5d0e9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_07e53e76dab24b6f0cfb36cc8460f7cd;  }
}
}
static void stepfunc_c4a3bb6edfd0630697b1510f02afd9ff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_07e53e76dab24b6f0cfb36cc8460f7cd;  }
}
}
static void stepfunc_9614c45ae3acafc62e3820bf3fa17b06(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_3738da4e799ae77c78338e3db7be8b68(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_40e3effd1227168104764c562bc55357;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-64);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_40e3effd1227168104764c562bc55357;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_40e3effd1227168104764c562bc55357;  }
}
p->wait = 20; 
}
static void stepfunc_42dbb348fc2be4bdf3d3441eee09c416(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_00f6f4401b9621ab6ef85bfc138124bb;  }
}
p->wait = 20; 
}
static void stepfunc_b4db4a15e9d73afe83dd865209d7269e(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_64d1a1821c2c5a242fc6c0d3b5ca1dda(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a67c117a35e32445d70c7275640985be;  }
}
p->wait = 20; 
}
static void stepfunc_11e8c05faebc19dca42bbf97f3fea693(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f190aa6884a278f4529e5232116c1e3a;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_49c777a07e5ff5012ab8673422373223(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_8a7c319b39fc0744cf296622866e36cc; }}


