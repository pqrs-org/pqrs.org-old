<?php //-*- Mode: php; indent-tabs-mode: nil; Coding: utf-8; -*-

; // add semicolon for Emacs php-mode indent issue.

define('ANGLENUM', 256);
define('FIXEDPOINT_DECIMALS', 4);

function convNumToFP($matches) {
  $num = $matches[1];
  if (intval($num) == floatval($num)) {
    return sprintf("FixedPointNum(%d)", intval($num));
  } else {
    $precision = 100;
    return sprintf("FixedPointNum(%d, %d)", intval(floatval($num) * $precision), $precision);
  }
}


class Common
{
  function getArg1() {
    $xmlfile = $_SERVER['argv'][1];
    if (! file_exists($xmlfile)) {
      Common::error("File ${argv[1]} is not exist!");
      exit;
    }
    return $xmlfile;
  }

  function getTmpFile($name, $xmlfile) {
    $file = sprintf('tmp/%s/%s/%s',
                    $name,
                    basename(dirname($xmlfile)),
                    basename($xmlfile));
    @mkdir(dirname($file), 0700, true);
    return $file;
  }

  // ------------------------------------------------------------
  function adjustAngle($text) {
    $function = sprintf('return floatval($matches[1]) * %d / 360;', ANGLENUM);
    return preg_replace_callback(
      '/([\d\.]+)/',
      create_function('$matches', $function),
      $text);
  }

  function normalizeNumber($text) {
    return preg_replace('/\(\s*([\.\d]+)\s*\)/', '$1', $text);
  }

  function foldMulDiv($text) {
    $function = 'eval(sprintf(\'$tmp = floatval(%s);\', $matches[1])); return $tmp;';
    return preg_replace_callback(
      '/(\s*[\.\d]+\s*(?:\*|\/)\s*[\.\d]+)/', 
      create_function('$matches', $function), 
      $text);
  }

  function foldAddSub($text) {
    if (! preg_match('/^\(/', $text)) {
      $text = "($text)";
    }
        
    $function = 'eval(sprintf(\'$tmp = floatval(%s);\', $matches[1])); return $tmp;';
    return preg_replace_callback(
      '/\((\s*[\.\d]+\s*(?:\+|\-)\s*[\.\d]+)\)/', 
      create_function('$matches', $function), 
      $text);
  }

  function joinConst($text) {
    if (! preg_match('/\$rand/', $text)) {
      if (! preg_match('/__/', $text)) {
        eval(sprintf('$text = number_format(%s, %d, ".", "");', $text, FIXEDPOINT_DECIMALS));
      }
      return $text;
    } else {
      $regexp = "#\((((?>[^()]+)|(?R))*)\)#";
      if (preg_match($regexp, $text, $matches)) {
        $subtext1 = $matches[1];
        $replace1 = sprintf('(%s)', Common::joinConst($subtext1));

        $id = sprintf('__%s__', md5(mt_rand()));
        $subtext2 = preg_replace($regexp, $id, $text, 1);
        $replace2 = $subtext2;
        if (preg_match($regexp, $subtext2)) {
          $replace2 = Common::joinConst($subtext2);
        }

        return preg_replace("/$id/", $replace1, $replace2);
      } else {
        return $text;
      }
    }
  }

  function convSpecialChar($text) {
    $conved = str_replace('$rank', '1', $text);

    $before = '';
    while ($before != $conved) {
      $before = $conved;
      $conved = Common::normalizeNumber($conved);
      $conved = Common::foldMulDiv($conved);
      $conved = Common::foldAddSub($conved);
      $conved = Common::joinConst($conved);
    }

    $conved = preg_replace('/\$rand/', 'FixedPointNum::random()', $conved);

    if (! preg_match('/FixedPointNum/', $conved)) {
      eval(sprintf('$conved = number_format(%s, %d, ".", "");', $conved, FIXEDPOINT_DECIMALS));
      if (intval($conved) == floatval($conved)) {
        return intval($conved);
      } else {
        $precision = 100;
        return sprintf("FixedPointNum(%d, %d)", intval(floatval($conved) * $precision), $precision);
      }
    } else {
      $conved = preg_replace_callback(
        '/([\d\.]+)/',
        convNumToFP,
        $conved);
    }

    return $conved;
  }

  function dropSpecialChar($text) {
    $text = preg_replace('/\$rand/', '1', $text);
    $text = preg_replace('/\$rank/', '1', $text);
    return $text;
  }

  function error($message) {
    error_log("$$$ [ERROR] ($message) $$$");
    exit(1);
  }

  function getTopElementByName($domElem, $name) {
    if ($domElem->nodeName == $name) {
      return $domElem;
    }

    if (! $domElem->hasChildNodes()) {
      return NULL;
    }
    foreach ($domElem->childNodes as $childNodes) {
      $node = Common::getTopElementByName($childNodes, $name);
      if ($node !== NULL) {
        return $node;
      }
    }
    return NULL;
  }

  function getBulletMLNode($document) {
    return $document->getElementsByTagName('bulletml')->item(0);
  }
}


if (realpath($argv[0]) == __FILE__) {
  print intval(ANGLENUM * 3 / 4) . "\n";

  $keys = array(
    '(((4*($rank*$rank*16))*1.61803398875)/2)-($rand*((4*($rank*$rank*16))*1.61803398875))',
    '(2-($rank*0.4))+($rand*(1+($rank*$rank0.8)))',
    '125 - ((30 * $rand))',
    '180 + ((30 * $rand)) * ((-1))',
    '1+($rank+$rand)',
    );
  foreach ($keys as $v) {
    print "--------------------------------------------------\n";
    print "$v\n";
    print "    To\n";
    print Common::joinConst($v);
    print "\n\n";
    print "CS: " . Common::convSpecialChar($v);
    print "\n\n";
  }

  $keys = array(
    '(200)',
    '( 200.32 )',
    '(200 + 100)',
    '125 - ((30 * $rand))',
    '(((4*($rank*$rank*16))*1.61803398875)/2)-($rand*((4*($rank*$rank*16))*1.61803398875))',
    '440/(120+$rank*200)+$rand',
    '400 * 100 + 10',
    '400 / 100 + 10',
    '(24 + 6 * $rand)/ (2.4 * (0.25 + 0.75 * $rank))',
    '(2.4 * (0.25 + 0.75 * $rank))',
    );
  foreach ($keys as $v) {
    $v = str_replace('$rank', '1', $v);

    print "--------------------------------------------------\n";
    print "$v\n";
    print "    normalizeNumber\n";
    $v = Common::joinConst($v);
    print "$v\n";
    $v = Common::normalizeNumber($v);
    print "$v\n";
    $v = Common::foldMulDiv($v);
    print "$v\n";
    $v = Common::foldAddSub($v);
    print "$v\n";
    print "\n";
  }
}

?>
