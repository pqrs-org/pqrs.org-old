// XXX uniqID XXX a482d06a5e18a335ec48c1e49d0b1f04 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p); 
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p); 
static void stepfunc_73876024dcdcb6c49391dbc9950a4bcc(BulletInfo *p); 
static void stepfunc_2630730af0851bda6a88d50cdf9b4cd5(BulletInfo *p); 
static void stepfunc_9bdbf425cb9556beb6f0db9d4bf3e364(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_540a583ab8c82aba11e6b251df5ea31b(BulletInfo *p); 
static void stepfunc_4e54a2baf18b79908557b13469302c5b(BulletInfo *p); 
static void stepfunc_f9be458c726fd63dd7847e937f9acfc0(BulletInfo *p); 
static void stepfunc_cbae3a63f987b7f32fe417379ead9085(BulletInfo *p); 
static void stepfunc_23462d6c79ed03f2fc509189309b8d0b(BulletInfo *p); 
static void stepfunc_cd7e05304cff1049dd9a7c057d3d81c5(BulletInfo *p); 
static void stepfunc_4badabd64abfe3f7bf4313acd1b22ea4(BulletInfo *p); 
static void stepfunc_afcc82cb706c3bd18e61d1c047961ae2(BulletInfo *p); 
static void stepfunc_eeffc0d0abf0a726462596e9a74bfe3d(BulletInfo *p); 
static void stepfunc_9d085f6b754b2650ece484ea2780b361(BulletInfo *p); 
static void stepfunc_0ef5bf117845dcb9dd992e472b027cf3(BulletInfo *p); 
static void stepfunc_1654c77425d854a62b017eb0e2e57dc5(BulletInfo *p); 
static void stepfunc_39ab6fbadf9fb70e200eb86dc12be25e(BulletInfo *p); 
static void stepfunc_66f4f56d71dd5287762acf7e751ab32c(BulletInfo *p); 
static void stepfunc_25f1f9a3d29d94f7108ab0443601f25e(BulletInfo *p); 
static void stepfunc_98603baff29a6af6a4e6058787364eb0(BulletInfo *p); 
static void stepfunc_cc3b0a1c5cd588bff351f203602ec63b(BulletInfo *p); 
static void stepfunc_f5677274a0db27f1ae704525c97a156d(BulletInfo *p); 
static void stepfunc_534d2d0860b0d12fab6a2c1815b2dc38(BulletInfo *p); 


static const BulletStepFunc bullet_10b015a98dfa3efa2641802f4fb16d63[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_73876024dcdcb6c49391dbc9950a4bcc,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_9bdbf425cb9556beb6f0db9d4bf3e364,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_4da4f66e473289dce0db9094301f8bdc[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_540a583ab8c82aba11e6b251df5ea31b,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_4e54a2baf18b79908557b13469302c5b,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_bc82d7904e4937200a19545947307322[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_f9be458c726fd63dd7847e937f9acfc0,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_cbae3a63f987b7f32fe417379ead9085,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_5a0b2b90279d18e1ed676fec1c4a52fa[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_23462d6c79ed03f2fc509189309b8d0b,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_cd7e05304cff1049dd9a7c057d3d81c5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_2630730af0851bda6a88d50cdf9b4cd5,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_3274046c393f423698ea0eb05dbbfccd[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_4badabd64abfe3f7bf4313acd1b22ea4,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
stepfunc_4badabd64abfe3f7bf4313acd1b22ea4,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
NULL}; 
static const BulletStepFunc bullet_c11a2126854ec31ae6a00ed47ccef97a[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_eeffc0d0abf0a726462596e9a74bfe3d,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
stepfunc_eeffc0d0abf0a726462596e9a74bfe3d,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
NULL}; 
static const BulletStepFunc bullet_1efb5795b5206992e3836603cbb5344b[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_9d085f6b754b2650ece484ea2780b361,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
stepfunc_9d085f6b754b2650ece484ea2780b361,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
NULL}; 
static const BulletStepFunc bullet_f583b9a7686de16f0a914ab0fc9ca538[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_0ef5bf117845dcb9dd992e472b027cf3,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
stepfunc_0ef5bf117845dcb9dd992e472b027cf3,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
NULL}; 
static const BulletStepFunc bullet_6a1425cf4da99253e6452e1845cad707[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_1654c77425d854a62b017eb0e2e57dc5,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
stepfunc_1654c77425d854a62b017eb0e2e57dc5,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
NULL}; 
static const BulletStepFunc bullet_23d9ce3de5c3d73976bcbeece8ae6c8d[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_39ab6fbadf9fb70e200eb86dc12be25e,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
stepfunc_39ab6fbadf9fb70e200eb86dc12be25e,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
NULL}; 
static const BulletStepFunc bullet_9c5dee9039347fa8f2f03c324c8b34a1[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_6536e4546bdcfcf651852434db03b678,
stepfunc_66f4f56d71dd5287762acf7e751ab32c,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
stepfunc_66f4f56d71dd5287762acf7e751ab32c,
#if 0
stepfunc_afcc82cb706c3bd18e61d1c047961ae2,
#endif
NULL}; 
static const BulletStepFunc bullet_6e67811d292d17a9e0f187733ba03e2b[] = {
stepfunc_25f1f9a3d29d94f7108ab0443601f25e,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_bb12df7a4fbc8094eaeffa04c1286f12[] = {
stepfunc_98603baff29a6af6a4e6058787364eb0,
stepfunc_cc3b0a1c5cd588bff351f203602ec63b,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_f5677274a0db27f1ae704525c97a156d,
stepfunc_534d2d0860b0d12fab6a2c1815b2dc38,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_25f1f9a3d29d94f7108ab0443601f25e(BulletInfo *p) { 
p->wait = 9999; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_2630730af0851bda6a88d50cdf9b4cd5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_6536e4546bdcfcf651852434db03b678(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_73876024dcdcb6c49391dbc9950a4bcc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_9bdbf425cb9556beb6f0db9d4bf3e364(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_540a583ab8c82aba11e6b251df5ea31b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_4e54a2baf18b79908557b13469302c5b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_f9be458c726fd63dd7847e937f9acfc0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_cbae3a63f987b7f32fe417379ead9085(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_23462d6c79ed03f2fc509189309b8d0b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_cd7e05304cff1049dd9a7c057d3d81c5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6e67811d292d17a9e0f187733ba03e2b;  }
}
}
static void stepfunc_afcc82cb706c3bd18e61d1c047961ae2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(15, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4badabd64abfe3f7bf4313acd1b22ea4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_eeffc0d0abf0a726462596e9a74bfe3d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9d085f6b754b2650ece484ea2780b361(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_0ef5bf117845dcb9dd992e472b027cf3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1654c77425d854a62b017eb0e2e57dc5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_39ab6fbadf9fb70e200eb86dc12be25e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_66f4f56d71dd5287762acf7e751ab32c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f5677274a0db27f1ae704525c97a156d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(4266, 100)-FixedPointNum(2133, 100)+(FixedPointNum::random()*FixedPointNum(14933, 100))));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9c5dee9039347fa8f2f03c324c8b34a1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_23d9ce3de5c3d73976bcbeece8ae6c8d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6a1425cf4da99253e6452e1845cad707;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f583b9a7686de16f0a914ab0fc9ca538;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1efb5795b5206992e3836603cbb5344b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c11a2126854ec31ae6a00ed47ccef97a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3274046c393f423698ea0eb05dbbfccd;  }
}
p->wait = 30; 
}
static void stepfunc_534d2d0860b0d12fab6a2c1815b2dc38(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(7466, 100)-FixedPointNum(2844, 100)-(FixedPointNum::random()*FixedPointNum(14933, 100))));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5a0b2b90279d18e1ed676fec1c4a52fa;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc82d7904e4937200a19545947307322;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4da4f66e473289dce0db9094301f8bdc;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_10b015a98dfa3efa2641802f4fb16d63;  }
}
p->wait = 60; 
}
static void stepfunc_98603baff29a6af6a4e6058787364eb0(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = (128) - p->getAngle();p->setRound(speed, life);}
p->wait = 10; 
}
static void stepfunc_cc3b0a1c5cd588bff351f203602ec63b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}


void genBulletFunc_a482d06a5e18a335ec48c1e49d0b1f04(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_bb12df7a4fbc8094eaeffa04c1286f12; }}


