// XXX uniqID XXX 054304476395db4730d32082eb1547d5 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_0ebdfd090df03c5477158bfa13efee90(BulletInfo *p); 
static void stepfunc_ac1fbdb904bb2140b7666f6df7463bd5(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_203adc5b640dde8e3db296386931859c(BulletInfo *p); 
static void stepfunc_5dae280ad8aa9479f3436a1db4ae00da(BulletInfo *p); 
static void stepfunc_ec9996148bf423f9f565c5981a0ee58f(BulletInfo *p); 
static void stepfunc_87b99481751b22356c9fcac9066725db(BulletInfo *p); 
static void stepfunc_e68eb819205b43f0e6a4498419b59ebd(BulletInfo *p); 
static void stepfunc_037a180b6a3fd72af16c57ced2d9adf1(BulletInfo *p); 


static const BulletStepFunc bullet_0988af3434724b88da0b1b2d552e53ab[] = {
stepfunc_0ebdfd090df03c5477158bfa13efee90,
stepfunc_ac1fbdb904bb2140b7666f6df7463bd5,
stepfunc_ac1fbdb904bb2140b7666f6df7463bd5,
stepfunc_ac1fbdb904bb2140b7666f6df7463bd5,
stepfunc_ac1fbdb904bb2140b7666f6df7463bd5,
stepfunc_ac1fbdb904bb2140b7666f6df7463bd5,
stepfunc_ac1fbdb904bb2140b7666f6df7463bd5,
stepfunc_ac1fbdb904bb2140b7666f6df7463bd5,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_156bc81e561cc58a89593ff8149f60d6[] = {
stepfunc_203adc5b640dde8e3db296386931859c,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_ec9996148bf423f9f565c5981a0ee58f,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_87b99481751b22356c9fcac9066725db,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_bd556814ce73633f045a33babcbf634a[] = {
stepfunc_e68eb819205b43f0e6a4498419b59ebd,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_037a180b6a3fd72af16c57ced2d9adf1,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_87b99481751b22356c9fcac9066725db(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(782, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_203adc5b640dde8e3db296386931859c(BulletInfo *p) { 
p->wait = 55; 
}
static void stepfunc_5dae280ad8aa9479f3436a1db4ae00da(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_ec9996148bf423f9f565c5981a0ee58f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-12088, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_ac1fbdb904bb2140b7666f6df7463bd5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-497, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_156bc81e561cc58a89593ff8149f60d6;  }
}
p->wait = 2; 
}
static void stepfunc_0ebdfd090df03c5477158bfa13efee90(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_156bc81e561cc58a89593ff8149f60d6;  }
}
p->wait = 2; 
}
static void stepfunc_037a180b6a3fd72af16c57ced2d9adf1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2133, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0988af3434724b88da0b1b2d552e53ab;  }
}
}
static void stepfunc_e68eb819205b43f0e6a4498419b59ebd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0988af3434724b88da0b1b2d552e53ab;  }
}
}


void genBulletFunc_054304476395db4730d32082eb1547d5(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_bd556814ce73633f045a33babcbf634a; }}


