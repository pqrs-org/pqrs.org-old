// XXX uniqID XXX 926ed90fbe351431b58c45ee1800e8d4 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p); 
static void stepfunc_32b34111ef00d159b8a8aab27cff177d(BulletInfo *p); 
static void stepfunc_1f68bd6258f476ca0d319fa42d154bfb(BulletInfo *p); 
static void stepfunc_c599d65a1262387d5bd40ff7cf106e9e(BulletInfo *p); 
static void stepfunc_7124cf9e7af2f9face22d474aeb5fc03(BulletInfo *p); 
static void stepfunc_a8e6927b8ee67208f3c1170af28ea0b8(BulletInfo *p); 
static void stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d(BulletInfo *p); 
static void stepfunc_807898767ec5204e207c6e60b30dc56a(BulletInfo *p); 
static void stepfunc_359334354a1127016592de11163fc77e(BulletInfo *p); 
static void stepfunc_f3c199e65a63974868b5391d9e1b49af(BulletInfo *p); 
static void stepfunc_85515dd70dc458ae263f06cd09f65ac7(BulletInfo *p); 
static void stepfunc_622aefeef52215fd845a803c09714494(BulletInfo *p); 
static void stepfunc_fcf7dff9ffece8cade2eadcdb6882bc3(BulletInfo *p); 
static void stepfunc_35b7ee7ee9c4cf70cb421a8c520c3b21(BulletInfo *p); 
static void stepfunc_b31a9b5164c91ecce15ee6ed61d1fea5(BulletInfo *p); 
static void stepfunc_f2f4d31a45613fc4f2e6651e8640be7f(BulletInfo *p); 
static void stepfunc_009d109532e5bfaad127c4d681017430(BulletInfo *p); 
static void stepfunc_8f4efb5ba66e5da032d2b670ff1f231b(BulletInfo *p); 
static void stepfunc_d7e79ed62981d23b3d8a3a2632efeeea(BulletInfo *p); 
static void stepfunc_5a940b249c416e852acd04f23317b70d(BulletInfo *p); 
static void stepfunc_a1d272d5d2cd571f8068704d0c9ed5f0(BulletInfo *p); 
static void stepfunc_89c7d86fd00acdc215e14b20d197f6d7(BulletInfo *p); 
static void stepfunc_63eff9ef0340422c33a331becf55e52c(BulletInfo *p); 
static void stepfunc_2e8599351dd28b4b047329010d1c85d0(BulletInfo *p); 
static void stepfunc_0ac405ce1d26eff7a586861f5f147afb(BulletInfo *p); 
static void stepfunc_b589b1383dbf93e4134324059743fb9b(BulletInfo *p); 
static void stepfunc_5098e9dba7a91c735d4cc5da3a03b849(BulletInfo *p); 
static void stepfunc_eea796f76c16584363cb99da974dcb70(BulletInfo *p); 
static void stepfunc_b5bfdac65505f75fc77963b76afc93ff(BulletInfo *p); 
static void stepfunc_7583f5a8b0ae0ac8f61995e2cebd1d68(BulletInfo *p); 
static void stepfunc_b410ae524e6a1a4c2a400ccea2933b1b(BulletInfo *p); 
static void stepfunc_fb68a0f3b74db99b98b4ae91172ca823(BulletInfo *p); 
static void stepfunc_171ac4f179b7acbbf75ce0989ed95d97(BulletInfo *p); 


static const BulletStepFunc bullet_a63001196b4aa25e56a8f173fc18efee[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_32b34111ef00d159b8a8aab27cff177d,
NULL}; 
static const BulletStepFunc bullet_6950d86ce5ca9169ddedf0afe5b005d7[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_1f68bd6258f476ca0d319fa42d154bfb,
NULL}; 
static const BulletStepFunc bullet_bd93852bef501be73f65c2882e98995d[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_c599d65a1262387d5bd40ff7cf106e9e,
NULL}; 
static const BulletStepFunc bullet_5f3cfd3c79381baca69e416d236438ba[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_7124cf9e7af2f9face22d474aeb5fc03,
NULL}; 
static const BulletStepFunc bullet_affbe71c150b5c941cfcbd748adb715f[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_a8e6927b8ee67208f3c1170af28ea0b8,
NULL}; 
static const BulletStepFunc bullet_8ed39235cc3c6417175d468c183aa2c0[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_807898767ec5204e207c6e60b30dc56a,
NULL}; 
static const BulletStepFunc bullet_cb611b081e5513cc83bab8c1147abf3a[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_359334354a1127016592de11163fc77e,
NULL}; 
static const BulletStepFunc bullet_954e7cad589a4dac35bfc2256b58b41a[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_f3c199e65a63974868b5391d9e1b49af,
NULL}; 
static const BulletStepFunc bullet_d0e84448d58b9f111a62fc7a7a422602[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_85515dd70dc458ae263f06cd09f65ac7,
NULL}; 
static const BulletStepFunc bullet_299a76545935edd845ca603b44fa0a30[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_622aefeef52215fd845a803c09714494,
NULL}; 
static const BulletStepFunc bullet_38bad03623caf9a06f82a90cba2d41a5[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_fcf7dff9ffece8cade2eadcdb6882bc3,
NULL}; 
static const BulletStepFunc bullet_01b628f83adb91fa57e277001c677ed8[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_35b7ee7ee9c4cf70cb421a8c520c3b21,
NULL}; 
static const BulletStepFunc bullet_13c33aa9426d288830606c39f10e0a2b[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_b31a9b5164c91ecce15ee6ed61d1fea5,
NULL}; 
static const BulletStepFunc bullet_786e1a703997dde92302736710535b8d[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_f2f4d31a45613fc4f2e6651e8640be7f,
NULL}; 
static const BulletStepFunc bullet_705a8c68a95c029a96b29a35e11294c0[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_009d109532e5bfaad127c4d681017430,
NULL}; 
static const BulletStepFunc bullet_4a5bedd0dee9e847e33d0e4cec7d0598[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_8f4efb5ba66e5da032d2b670ff1f231b,
NULL}; 
static const BulletStepFunc bullet_a2955504390fe664afd51281a97876cb[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_d7e79ed62981d23b3d8a3a2632efeeea,
NULL}; 
static const BulletStepFunc bullet_80328e548e87060bffe58aa2882d6334[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_5a940b249c416e852acd04f23317b70d,
NULL}; 
static const BulletStepFunc bullet_a57ee69f4ca5594623043e47ca1d49cb[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_a1d272d5d2cd571f8068704d0c9ed5f0,
NULL}; 
static const BulletStepFunc bullet_db2e85d36a4aa6244ef6d4dc186cb3da[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_89c7d86fd00acdc215e14b20d197f6d7,
NULL}; 
static const BulletStepFunc bullet_1922ac01508ea23f638a6929855c21b2[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_63eff9ef0340422c33a331becf55e52c,
NULL}; 
static const BulletStepFunc bullet_44acd3f245438feff448c6d298f57dd4[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_2e8599351dd28b4b047329010d1c85d0,
NULL}; 
static const BulletStepFunc bullet_cb58c07c079c7ef39d18d3448c0e3909[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_0ac405ce1d26eff7a586861f5f147afb,
NULL}; 
static const BulletStepFunc bullet_8da9ec3943fdc60677af7df725d0c665[] = {
stepfunc_b589b1383dbf93e4134324059743fb9b,
stepfunc_5098e9dba7a91c735d4cc5da3a03b849,
stepfunc_eea796f76c16584363cb99da974dcb70,
stepfunc_b5bfdac65505f75fc77963b76afc93ff,
stepfunc_7583f5a8b0ae0ac8f61995e2cebd1d68,
stepfunc_b410ae524e6a1a4c2a400ccea2933b1b,
stepfunc_fb68a0f3b74db99b98b4ae91172ca823,
stepfunc_171ac4f179b7acbbf75ce0989ed95d97,
NULL}; 
static void stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d(BulletInfo *p) { 
p->wait = 6; 
}
static void stepfunc_807898767ec5204e207c6e60b30dc56a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-17193, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_359334354a1127016592de11163fc77e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-16181, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_f3c199e65a63974868b5391d9e1b49af(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-15170, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_85515dd70dc458ae263f06cd09f65ac7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-14159, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_622aefeef52215fd845a803c09714494(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-13147, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_fcf7dff9ffece8cade2eadcdb6882bc3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-12136, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_35b7ee7ee9c4cf70cb421a8c520c3b21(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-11124, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b31a9b5164c91ecce15ee6ed61d1fea5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-10113, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_f2f4d31a45613fc4f2e6651e8640be7f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-9102, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_009d109532e5bfaad127c4d681017430(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-8090, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_8f4efb5ba66e5da032d2b670ff1f231b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-7079, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d7e79ed62981d23b3d8a3a2632efeeea(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-6068, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_5a940b249c416e852acd04f23317b70d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-5056, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a1d272d5d2cd571f8068704d0c9ed5f0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4045, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_89c7d86fd00acdc215e14b20d197f6d7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3034, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_63eff9ef0340422c33a331becf55e52c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2022, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_2e8599351dd28b4b047329010d1c85d0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_0ac405ce1d26eff7a586861f5f147afb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_32b34111ef00d159b8a8aab27cff177d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1314, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb58c07c079c7ef39d18d3448c0e3909;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2326, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_44acd3f245438feff448c6d298f57dd4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3337, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1922ac01508ea23f638a6929855c21b2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4348, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_db2e85d36a4aa6244ef6d4dc186cb3da;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5360, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a57ee69f4ca5594623043e47ca1d49cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6371, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_80328e548e87060bffe58aa2882d6334;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7382, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a2955504390fe664afd51281a97876cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8394, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a5bedd0dee9e847e33d0e4cec7d0598;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9405, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_705a8c68a95c029a96b29a35e11294c0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10416, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_786e1a703997dde92302736710535b8d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11428, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_13c33aa9426d288830606c39f10e0a2b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12439, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_01b628f83adb91fa57e277001c677ed8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13451, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_38bad03623caf9a06f82a90cba2d41a5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14462, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_299a76545935edd845ca603b44fa0a30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15473, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d0e84448d58b9f111a62fc7a7a422602;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16485, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_954e7cad589a4dac35bfc2256b58b41a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17496, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb611b081e5513cc83bab8c1147abf3a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(18507, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ed39235cc3c6417175d468c183aa2c0;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1f68bd6258f476ca0d319fa42d154bfb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(657, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb58c07c079c7ef39d18d3448c0e3909;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1668, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_44acd3f245438feff448c6d298f57dd4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2680, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1922ac01508ea23f638a6929855c21b2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3691, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_db2e85d36a4aa6244ef6d4dc186cb3da;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4702, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a57ee69f4ca5594623043e47ca1d49cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5714, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_80328e548e87060bffe58aa2882d6334;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6725, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a2955504390fe664afd51281a97876cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7736, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a5bedd0dee9e847e33d0e4cec7d0598;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8748, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_705a8c68a95c029a96b29a35e11294c0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9759, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_786e1a703997dde92302736710535b8d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10770, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_13c33aa9426d288830606c39f10e0a2b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11782, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_01b628f83adb91fa57e277001c677ed8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12793, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_38bad03623caf9a06f82a90cba2d41a5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13805, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_299a76545935edd845ca603b44fa0a30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14816, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d0e84448d58b9f111a62fc7a7a422602;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15827, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_954e7cad589a4dac35bfc2256b58b41a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16839, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb611b081e5513cc83bab8c1147abf3a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17850, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ed39235cc3c6417175d468c183aa2c0;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c599d65a1262387d5bd40ff7cf106e9e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb58c07c079c7ef39d18d3448c0e3909;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_44acd3f245438feff448c6d298f57dd4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2022, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1922ac01508ea23f638a6929855c21b2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3034, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_db2e85d36a4aa6244ef6d4dc186cb3da;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4045, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a57ee69f4ca5594623043e47ca1d49cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5056, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_80328e548e87060bffe58aa2882d6334;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6068, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a2955504390fe664afd51281a97876cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7079, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a5bedd0dee9e847e33d0e4cec7d0598;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8090, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_705a8c68a95c029a96b29a35e11294c0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9102, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_786e1a703997dde92302736710535b8d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10113, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_13c33aa9426d288830606c39f10e0a2b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11124, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_01b628f83adb91fa57e277001c677ed8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12136, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_38bad03623caf9a06f82a90cba2d41a5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13147, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_299a76545935edd845ca603b44fa0a30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14159, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d0e84448d58b9f111a62fc7a7a422602;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15170, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_954e7cad589a4dac35bfc2256b58b41a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16181, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb611b081e5513cc83bab8c1147abf3a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17193, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ed39235cc3c6417175d468c183aa2c0;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_7124cf9e7af2f9face22d474aeb5fc03(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-657, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb58c07c079c7ef39d18d3448c0e3909;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(353, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_44acd3f245438feff448c6d298f57dd4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1365, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1922ac01508ea23f638a6929855c21b2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2376, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_db2e85d36a4aa6244ef6d4dc186cb3da;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3388, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a57ee69f4ca5594623043e47ca1d49cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4399, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_80328e548e87060bffe58aa2882d6334;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5410, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a2955504390fe664afd51281a97876cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6422, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a5bedd0dee9e847e33d0e4cec7d0598;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7433, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_705a8c68a95c029a96b29a35e11294c0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8444, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_786e1a703997dde92302736710535b8d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9456, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_13c33aa9426d288830606c39f10e0a2b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10467, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_01b628f83adb91fa57e277001c677ed8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11478, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_38bad03623caf9a06f82a90cba2d41a5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12490, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_299a76545935edd845ca603b44fa0a30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13501, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d0e84448d58b9f111a62fc7a7a422602;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14512, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_954e7cad589a4dac35bfc2256b58b41a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15524, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb611b081e5513cc83bab8c1147abf3a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16535, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ed39235cc3c6417175d468c183aa2c0;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_a8e6927b8ee67208f3c1170af28ea0b8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1314, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb58c07c079c7ef39d18d3448c0e3909;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-303, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_44acd3f245438feff448c6d298f57dd4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(707, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1922ac01508ea23f638a6929855c21b2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1719, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_db2e85d36a4aa6244ef6d4dc186cb3da;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2730, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a57ee69f4ca5594623043e47ca1d49cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3742, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_80328e548e87060bffe58aa2882d6334;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4753, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a2955504390fe664afd51281a97876cb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5764, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a5bedd0dee9e847e33d0e4cec7d0598;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6776, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_705a8c68a95c029a96b29a35e11294c0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7787, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_786e1a703997dde92302736710535b8d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8798, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_13c33aa9426d288830606c39f10e0a2b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9810, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_01b628f83adb91fa57e277001c677ed8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10821, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_38bad03623caf9a06f82a90cba2d41a5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11832, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_299a76545935edd845ca603b44fa0a30;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12844, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d0e84448d58b9f111a62fc7a7a422602;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13855, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_954e7cad589a4dac35bfc2256b58b41a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14866, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cb611b081e5513cc83bab8c1147abf3a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15878, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ed39235cc3c6417175d468c183aa2c0;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b589b1383dbf93e4134324059743fb9b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(18488, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a63001196b4aa25e56a8f173fc18efee;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15644, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd93852bef501be73f65c2882e98995d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_affbe71c150b5c941cfcbd748adb715f;  }
}
p->wait = 30; 
}
static void stepfunc_5098e9dba7a91c735d4cc5da3a03b849(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a63001196b4aa25e56a8f173fc18efee;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9955, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd93852bef501be73f65c2882e98995d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7111, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_affbe71c150b5c941cfcbd748adb715f;  }
}
p->wait = 30; 
}
static void stepfunc_eea796f76c16584363cb99da974dcb70(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5f3cfd3c79381baca69e416d236438ba;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14222, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6950d86ce5ca9169ddedf0afe5b005d7;  }
}
p->wait = 30; 
}
static void stepfunc_b5bfdac65505f75fc77963b76afc93ff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(11377, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5f3cfd3c79381baca69e416d236438ba;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6950d86ce5ca9169ddedf0afe5b005d7;  }
}
p->wait = 60; 
}
static void stepfunc_7583f5a8b0ae0ac8f61995e2cebd1d68(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(18488, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a63001196b4aa25e56a8f173fc18efee;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6950d86ce5ca9169ddedf0afe5b005d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15644, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd93852bef501be73f65c2882e98995d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14222, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5f3cfd3c79381baca69e416d236438ba;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_affbe71c150b5c941cfcbd748adb715f;  }
}
p->wait = 40; 
}
static void stepfunc_b410ae524e6a1a4c2a400ccea2933b1b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a63001196b4aa25e56a8f173fc18efee;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(11377, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6950d86ce5ca9169ddedf0afe5b005d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9955, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd93852bef501be73f65c2882e98995d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5f3cfd3c79381baca69e416d236438ba;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7111, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_affbe71c150b5c941cfcbd748adb715f;  }
}
p->wait = 40; 
}
static void stepfunc_fb68a0f3b74db99b98b4ae91172ca823(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(18488, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_affbe71c150b5c941cfcbd748adb715f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5f3cfd3c79381baca69e416d236438ba;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15644, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd93852bef501be73f65c2882e98995d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14222, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6950d86ce5ca9169ddedf0afe5b005d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a63001196b4aa25e56a8f173fc18efee;  }
}
p->wait = 40; 
}
static void stepfunc_171ac4f179b7acbbf75ce0989ed95d97(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_affbe71c150b5c941cfcbd748adb715f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(11377, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5f3cfd3c79381baca69e416d236438ba;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9955, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bd93852bef501be73f65c2882e98995d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6950d86ce5ca9169ddedf0afe5b005d7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7111, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a63001196b4aa25e56a8f173fc18efee;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_926ed90fbe351431b58c45ee1800e8d4(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_8da9ec3943fdc60677af7df725d0c665; }}


