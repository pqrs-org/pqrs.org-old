// XXX uniqID XXX 8e105821f987f05263cddee5d18d0f17 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e5dac1bb74454b91cc93ecde5d45150f(BulletInfo *p); 
static void stepfunc_5141677ced7d93c881aca1376bc411b8(BulletInfo *p); 
static void stepfunc_770a795206a070da3d3afa51cc17ac4f(BulletInfo *p); 
static void stepfunc_daca9c341c5ba8ed2ed41f3787bda013(BulletInfo *p); 
static void stepfunc_3669c2cbfb5b8084701bad54c2fefea6(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_e7583fabb79ecd55020a02e7e2e448c0(BulletInfo *p); 
static void stepfunc_5172d54cdc49913f0cec2f7a000dd87a(BulletInfo *p); 
static void stepfunc_29d7fd1786c5cbb72e02cb275fbb8c39(BulletInfo *p); 
static void stepfunc_09ec691b7caed59b6b5425e3e5b4ec5c(BulletInfo *p); 
static void stepfunc_db803fe3e1edfebdc96f83a464bb6c55(BulletInfo *p); 


static const BulletStepFunc bullet_e9337ef54f75840aa1921a50ac355bf4[] = {
stepfunc_e5dac1bb74454b91cc93ecde5d45150f,
stepfunc_5141677ced7d93c881aca1376bc411b8,
stepfunc_770a795206a070da3d3afa51cc17ac4f,
stepfunc_daca9c341c5ba8ed2ed41f3787bda013,
stepfunc_5141677ced7d93c881aca1376bc411b8,
stepfunc_3669c2cbfb5b8084701bad54c2fefea6,
stepfunc_daca9c341c5ba8ed2ed41f3787bda013,
stepfunc_5141677ced7d93c881aca1376bc411b8,
stepfunc_3669c2cbfb5b8084701bad54c2fefea6,
stepfunc_daca9c341c5ba8ed2ed41f3787bda013,
stepfunc_5141677ced7d93c881aca1376bc411b8,
stepfunc_3669c2cbfb5b8084701bad54c2fefea6,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_9e457067cdf89f9005a5afa868e9d42f[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_5141677ced7d93c881aca1376bc411b8,
stepfunc_e7583fabb79ecd55020a02e7e2e448c0,
#if 0
stepfunc_5172d54cdc49913f0cec2f7a000dd87a,
#endif
NULL}; 
static const BulletStepFunc bullet_0ef3d202539e4ac6796f5243cbed2155[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_5141677ced7d93c881aca1376bc411b8,
stepfunc_29d7fd1786c5cbb72e02cb275fbb8c39,
#if 0
stepfunc_09ec691b7caed59b6b5425e3e5b4ec5c,
#endif
NULL}; 
static const BulletStepFunc bullet_e06d1045a05e02e4743c9653f52d8744[] = {
stepfunc_db803fe3e1edfebdc96f83a464bb6c55,
NULL}; 
static void stepfunc_5172d54cdc49913f0cec2f7a000dd87a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((FixedPointNum(2844, 100) - FixedPointNum(32) + FixedPointNum(64) * FixedPointNum::random()));    p->lastBulletSpeed = ((FixedPointNum(350, 100) + FixedPointNum(1) * FixedPointNum::random()));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_5141677ced7d93c881aca1376bc411b8(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_e7583fabb79ecd55020a02e7e2e448c0(BulletInfo *p) { 
for (u32 i = 0; i < 250; ++i) { 
stepfunc_5172d54cdc49913f0cec2f7a000dd87a(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_09ec691b7caed59b6b5425e3e5b4ec5c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((-FixedPointNum(2844, 100)) - FixedPointNum(32) + FixedPointNum(64) * FixedPointNum::random());    p->lastBulletSpeed = ((FixedPointNum(350, 100) + FixedPointNum(1) * FixedPointNum::random()));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_29d7fd1786c5cbb72e02cb275fbb8c39(BulletInfo *p) { 
for (u32 i = 0; i < 250; ++i) { 
stepfunc_09ec691b7caed59b6b5425e3e5b4ec5c(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_daca9c341c5ba8ed2ed41f3787bda013(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + ((FixedPointNum(12088, 100) + FixedPointNum(1422, 100) * FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(85, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 40; 
}
static void stepfunc_3669c2cbfb5b8084701bad54c2fefea6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0ef3d202539e4ac6796f5243cbed2155;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-4266, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e457067cdf89f9005a5afa868e9d42f;  }
}
p->wait = 45; 
}
static void stepfunc_e5dac1bb74454b91cc93ecde5d45150f(BulletInfo *p) { 
p->wait = 40; 
}
static void stepfunc_770a795206a070da3d3afa51cc17ac4f(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(((FixedPointNum(11377, 100) + FixedPointNum(2844, 100) * FixedPointNum::random())) - p->getAngle(), life);;p->setRound(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0ef3d202539e4ac6796f5243cbed2155;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4266, 100));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9e457067cdf89f9005a5afa868e9d42f;  }
}
p->wait = 90; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_db803fe3e1edfebdc96f83a464bb6c55(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e9337ef54f75840aa1921a50ac355bf4;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_8e105821f987f05263cddee5d18d0f17(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_e06d1045a05e02e4743c9653f52d8744; }}


