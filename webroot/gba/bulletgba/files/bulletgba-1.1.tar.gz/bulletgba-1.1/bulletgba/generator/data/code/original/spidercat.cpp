// XXX uniqID XXX f19cda06e1325845d5e3f1c33ee5df51 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_487c2a5be7cb5b922bad47afe30e50bf(BulletInfo *p); 
static void stepfunc_58e9e7cf0c8e54afe462d34e3be24281(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_af267ea647956ed98ad8eef25e32b9c8(BulletInfo *p); 
static void stepfunc_37b4fddb9e707abb47df871b33cfbcdc(BulletInfo *p); 
static void stepfunc_6f4601da7d31ad6bee0d38daffb976d0(BulletInfo *p); 
static void stepfunc_916259e67781dc3c2aa63bd1170927b0(BulletInfo *p); 
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p); 
static void stepfunc_bef9f9fc0d78043e7fe30adde6efeb78(BulletInfo *p); 
static void stepfunc_4b027fa06e21ffcbc71176698146e5fb(BulletInfo *p); 
static void stepfunc_f3010f68bc663d5c6f53f70d38853f74(BulletInfo *p); 


static const BulletStepFunc bullet_11191a85385a8db245d00f1a5ccfcede[] = {
stepfunc_487c2a5be7cb5b922bad47afe30e50bf,
stepfunc_58e9e7cf0c8e54afe462d34e3be24281,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_c61f7fd5be041c1f57fe775355dd90de[] = {
stepfunc_487c2a5be7cb5b922bad47afe30e50bf,
stepfunc_af267ea647956ed98ad8eef25e32b9c8,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_caff48c5671387d8859eb4eee6bb8714[] = {
stepfunc_37b4fddb9e707abb47df871b33cfbcdc,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_916259e67781dc3c2aa63bd1170927b0,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_00d751e8e18842b110670ae5365d8c1d[] = {
stepfunc_37b4fddb9e707abb47df871b33cfbcdc,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_bef9f9fc0d78043e7fe30adde6efeb78,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_b55158c88380a5f66be7c7d0d31f4d2d[] = {
stepfunc_4b027fa06e21ffcbc71176698146e5fb,
stepfunc_f3010f68bc663d5c6f53f70d38853f74,
stepfunc_4b027fa06e21ffcbc71176698146e5fb,
stepfunc_f3010f68bc663d5c6f53f70d38853f74,
stepfunc_4b027fa06e21ffcbc71176698146e5fb,
stepfunc_f3010f68bc663d5c6f53f70d38853f74,
stepfunc_4b027fa06e21ffcbc71176698146e5fb,
stepfunc_f3010f68bc663d5c6f53f70d38853f74,
stepfunc_4b027fa06e21ffcbc71176698146e5fb,
stepfunc_f3010f68bc663d5c6f53f70d38853f74,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_6f4601da7d31ad6bee0d38daffb976d0(BulletInfo *p) { 
p->wait = 3; 
}
static void stepfunc_bef9f9fc0d78043e7fe30adde6efeb78(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1280, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(3, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (128);    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_37b4fddb9e707abb47df871b33cfbcdc(BulletInfo *p) { 
{
  u16 life = 300;  FixedPointNum speed = FixedPointNum(3 - p->getSpeed(), life);p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256)*FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (128);    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_487c2a5be7cb5b922bad47afe30e50bf(BulletInfo *p) { 
p->wait = (FixedPointNum(3)*FixedPointNum::random()); 
}
static void stepfunc_58e9e7cf0c8e54afe462d34e3be24281(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(9955, 100)+FixedPointNum(5688, 100)*FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_00d751e8e18842b110670ae5365d8c1d;  }
}
p->wait = 1; 
}
static void stepfunc_916259e67781dc3c2aa63bd1170927b0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1280, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(3, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (128);    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_af267ea647956ed98ad8eef25e32b9c8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(9955, 100)+FixedPointNum(5688, 100)*FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_caff48c5671387d8859eb4eee6bb8714;  }
}
p->wait = 1; 
}
static void stepfunc_4b027fa06e21ffcbc71176698146e5fb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(6044, 100));    p->lastBulletSpeed = (10);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c61f7fd5be041c1f57fe775355dd90de;  }
}
p->wait = 45; 
}
static void stepfunc_f3010f68bc663d5c6f53f70d38853f74(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(19555, 100));    p->lastBulletSpeed = (10);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_11191a85385a8db245d00f1a5ccfcede;  }
}
p->wait = 45; 
}


void genBulletFunc_f19cda06e1325845d5e3f1c33ee5df51(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_b55158c88380a5f66be7c7d0d31f4d2d; }}


