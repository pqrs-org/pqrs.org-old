// XXX uniqID XXX b44dbec62b2b86f34cb4657c468eea7c XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e5dac1bb74454b91cc93ecde5d45150f(BulletInfo *p); 
static void stepfunc_5dae280ad8aa9479f3436a1db4ae00da(BulletInfo *p); 
static void stepfunc_39a41e10237c0efbfb4049ca34588ac9(BulletInfo *p); 
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p); 
static void stepfunc_7d3c926b10fe6b195daa4ee3abe004de(BulletInfo *p); 
static void stepfunc_1570382722caf81ff47ecb094ce70a40(BulletInfo *p); 
static void stepfunc_72a2bf137cb4959f26d58ed96032323c(BulletInfo *p); 
static void stepfunc_e6316ec9ce89c0aee45c4601e77191b9(BulletInfo *p); 
static void stepfunc_bf84c9239f1a2d016713d314b4ffce12(BulletInfo *p); 
static void stepfunc_b0797e37916ed9e968d31e327d5c98eb(BulletInfo *p); 
static void stepfunc_b2413b25f15c1368ad120c0c6519c8e7(BulletInfo *p); 
static void stepfunc_617bd136fba5574bf4137ba461995628(BulletInfo *p); 
static void stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_bde21b7103fe3be005fd681c13c62c0f(BulletInfo *p); 
static void stepfunc_f436a23f924f7c44b4b96cee8d35ef59(BulletInfo *p); 
static void stepfunc_8279ca80e62fbb6b29135aff4a3a36a2(BulletInfo *p); 
static void stepfunc_d62489f8469688eca05aed53304fcaa2(BulletInfo *p); 
static void stepfunc_487d972b898de7352d592b36332dbae7(BulletInfo *p); 
static void stepfunc_74e36bdf1f338b844183787d7d23cd98(BulletInfo *p); 
static void stepfunc_2b1498e4df7a72dcc0d9e70096ac4f6e(BulletInfo *p); 
static void stepfunc_1c26369ae5b69e5fd9508bd3c063ed80(BulletInfo *p); 
static void stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1(BulletInfo *p); 
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 
static void stepfunc_5458944d072145057cfe835b1d31d012(BulletInfo *p); 
static void stepfunc_85639d0ef3349b6248421e9ed4d90ddb(BulletInfo *p); 
static void stepfunc_f8bbc9c0b869fcc73e651b90ea60f27b(BulletInfo *p); 
static void stepfunc_2b719b46dbf1fc767b62f8fba06d6e38(BulletInfo *p); 
static void stepfunc_5ba0042830fda1e665dce97e2d668f26(BulletInfo *p); 
static void stepfunc_d82bc4f3fa82ceef518b9e13eff3ea90(BulletInfo *p); 
static void stepfunc_c6117bd84c3976e11d844d1c29d21c28(BulletInfo *p); 
static void stepfunc_8509d7e41cb9d7ebc450c11b72ca1b1d(BulletInfo *p); 
static void stepfunc_eb3335e4a0aab0d47cfba754361e4e49(BulletInfo *p); 


static const BulletStepFunc bullet_bdae2f0a68966df93ade8b2350a4dcad[] = {
stepfunc_e5dac1bb74454b91cc93ecde5d45150f,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_39a41e10237c0efbfb4049ca34588ac9,
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_7d3c926b10fe6b195daa4ee3abe004de,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_39a41e10237c0efbfb4049ca34588ac9,
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_7d3c926b10fe6b195daa4ee3abe004de,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_39a41e10237c0efbfb4049ca34588ac9,
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_7d3c926b10fe6b195daa4ee3abe004de,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_39a41e10237c0efbfb4049ca34588ac9,
stepfunc_1570382722caf81ff47ecb094ce70a40,
stepfunc_7d3c926b10fe6b195daa4ee3abe004de,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_72a2bf137cb4959f26d58ed96032323c,
#if 0
stepfunc_e6316ec9ce89c0aee45c4601e77191b9,
#endif
stepfunc_bf84c9239f1a2d016713d314b4ffce12,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_b0797e37916ed9e968d31e327d5c98eb,
#if 0
stepfunc_e6316ec9ce89c0aee45c4601e77191b9,
#endif
NULL}; 
static const BulletStepFunc bullet_5c632ffa3e61edc40c2ce031322cdf59[] = {
stepfunc_b2413b25f15c1368ad120c0c6519c8e7,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_617bd136fba5574bf4137ba461995628,
stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_ea063e40fa175a6e5559a4254cb42444[] = {
stepfunc_bde21b7103fe3be005fd681c13c62c0f,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_f436a23f924f7c44b4b96cee8d35ef59,
stepfunc_8279ca80e62fbb6b29135aff4a3a36a2,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d9a87280b18b37ff9fe5101b1763f4d4[] = {
stepfunc_d62489f8469688eca05aed53304fcaa2,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_487d972b898de7352d592b36332dbae7,
stepfunc_74e36bdf1f338b844183787d7d23cd98,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b995bd8702fa60dddc7589678465e28d[] = {
stepfunc_2b1498e4df7a72dcc0d9e70096ac4f6e,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_1c26369ae5b69e5fd9508bd3c063ed80,
stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_547d108912443f3f374f297f571f3537[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_5458944d072145057cfe835b1d31d012,
NULL}; 
static const BulletStepFunc bullet_fd15e8000ee18538696d7ebd4b38d836[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_85639d0ef3349b6248421e9ed4d90ddb,
NULL}; 
static const BulletStepFunc bullet_64ee767a11b61b670a94e4ce54d7472c[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_f8bbc9c0b869fcc73e651b90ea60f27b,
NULL}; 
static const BulletStepFunc bullet_5717e8f36e0dc25d03993fcce86f34c5[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_2b719b46dbf1fc767b62f8fba06d6e38,
NULL}; 
static const BulletStepFunc bullet_83547012dac9d4566a346c9a59b02b1d[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_5ba0042830fda1e665dce97e2d668f26,
NULL}; 
static const BulletStepFunc bullet_bdd9fb1aaacf3f6b29b0cacb21db6cc4[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_d82bc4f3fa82ceef518b9e13eff3ea90,
NULL}; 
static const BulletStepFunc bullet_6835aff5f8b5d76232714195b280a806[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_c6117bd84c3976e11d844d1c29d21c28,
NULL}; 
static const BulletStepFunc bullet_3c56e746ae89b40a6086e6078cb3cdf2[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_8509d7e41cb9d7ebc450c11b72ca1b1d,
NULL}; 
static const BulletStepFunc bullet_a0f57187702ee68c65874c618db54b21[] = {
stepfunc_eb3335e4a0aab0d47cfba754361e4e49,
NULL}; 
static void stepfunc_e6316ec9ce89c0aee45c4601e77191b9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_c6117bd84c3976e11d844d1c29d21c28(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-8533, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_8509d7e41cb9d7ebc450c11b72ca1b1d(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(8533, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_617bd136fba5574bf4137ba461995628(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3c56e746ae89b40a6086e6078cb3cdf2;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_cd61fe6d298f14a64fa2eb4816a0f7e9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6835aff5f8b5d76232714195b280a806;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_b2413b25f15c1368ad120c0c6519c8e7(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-8533, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_5ba0042830fda1e665dce97e2d668f26(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_d82bc4f3fa82ceef518b9e13eff3ea90(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_f436a23f924f7c44b4b96cee8d35ef59(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bdd9fb1aaacf3f6b29b0cacb21db6cc4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_8279ca80e62fbb6b29135aff4a3a36a2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_83547012dac9d4566a346c9a59b02b1d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_bde21b7103fe3be005fd681c13c62c0f(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_f8bbc9c0b869fcc73e651b90ea60f27b(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(8533, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_2b719b46dbf1fc767b62f8fba06d6e38(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-8533, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_487d972b898de7352d592b36332dbae7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5717e8f36e0dc25d03993fcce86f34c5;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_74e36bdf1f338b844183787d7d23cd98(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_64ee767a11b61b670a94e4ce54d7472c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_d62489f8469688eca05aed53304fcaa2(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(8533, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_5458944d072145057cfe835b1d31d012(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_85639d0ef3349b6248421e9ed4d90ddb(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(-10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_1c26369ae5b69e5fd9508bd3c063ed80(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fd15e8000ee18538696d7ebd4b38d836;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_0c097c9558a6c2ea0f1e47ad9b58a9b1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_547d108912443f3f374f297f571f3537;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (-64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_2b1498e4df7a72dcc0d9e70096ac4f6e(BulletInfo *p) { 
{
  u16 life = 90;  FixedPointNum speed = FixedPointNum(p->getAngle() + (FixedPointNum(10666, 100)) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_7d3c926b10fe6b195daa4ee3abe004de(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(180, 100) - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + ((FixedPointNum(12088, 100) + FixedPointNum(1422, 100) * FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
p->wait = 40; 
}
static void stepfunc_5dae280ad8aa9479f3436a1db4ae00da(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_39a41e10237c0efbfb4049ca34588ac9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-213, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(426, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-213, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e5dac1bb74454b91cc93ecde5d45150f(BulletInfo *p) { 
p->wait = 40; 
}
static void stepfunc_1570382722caf81ff47ecb094ce70a40(BulletInfo *p) { 
p->wait = 80; 
}
static void stepfunc_72a2bf137cb4959f26d58ed96032323c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(22, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b995bd8702fa60dddc7589678465e28d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(22, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b995bd8702fa60dddc7589678465e28d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(22, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b995bd8702fa60dddc7589678465e28d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (128);    p->lastBulletSpeed = (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d9a87280b18b37ff9fe5101b1763f4d4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d9a87280b18b37ff9fe5101b1763f4d4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d9a87280b18b37ff9fe5101b1763f4d4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(10666, 100));    p->lastBulletSpeed = (FixedPointNum(17, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea063e40fa175a6e5559a4254cb42444;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(17, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea063e40fa175a6e5559a4254cb42444;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(17, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea063e40fa175a6e5559a4254cb42444;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (128);    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c632ffa3e61edc40c2ce031322cdf59;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c632ffa3e61edc40c2ce031322cdf59;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c632ffa3e61edc40c2ce031322cdf59;  }
}
for (u32 i = 0; i < 18; ++i) { 
stepfunc_e6316ec9ce89c0aee45c4601e77191b9(p);}
p->wait = 150; 
}
static void stepfunc_bf84c9239f1a2d016713d314b4ffce12(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(180, 100) - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + ((-FixedPointNum(2133, 100) + FixedPointNum(4266, 100) * FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
p->wait = 15; 
}
static void stepfunc_b0797e37916ed9e968d31e327d5c98eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(22, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b995bd8702fa60dddc7589678465e28d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(22, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b995bd8702fa60dddc7589678465e28d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(22, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b995bd8702fa60dddc7589678465e28d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (128);    p->lastBulletSpeed = (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d9a87280b18b37ff9fe5101b1763f4d4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d9a87280b18b37ff9fe5101b1763f4d4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d9a87280b18b37ff9fe5101b1763f4d4;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(10666, 100));    p->lastBulletSpeed = (FixedPointNum(17, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea063e40fa175a6e5559a4254cb42444;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(17, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea063e40fa175a6e5559a4254cb42444;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(17, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ea063e40fa175a6e5559a4254cb42444;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (128);    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c632ffa3e61edc40c2ce031322cdf59;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c632ffa3e61edc40c2ce031322cdf59;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c632ffa3e61edc40c2ce031322cdf59;  }
}
for (u32 i = 0; i < 18; ++i) { 
stepfunc_e6316ec9ce89c0aee45c4601e77191b9(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_eb3335e4a0aab0d47cfba754361e4e49(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(12088, 100) + FixedPointNum(1422, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bdae2f0a68966df93ade8b2350a4dcad;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_b44dbec62b2b86f34cb4657c468eea7c(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_a0f57187702ee68c65874c618db54b21; }}


