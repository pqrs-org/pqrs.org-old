// XXX uniqID XXX 515f6916f9e44cb2756bcbe1dfdc8cf0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_0b725083a5d1cf9d803659ffbb8fbe57(BulletInfo *p); 
static void stepfunc_05c35b6f65e50046397868607b54288a(BulletInfo *p); 
static void stepfunc_d375f926e8630a8dcf1ecee92d9e04b1(BulletInfo *p); 
static void stepfunc_b2b9cd795f8b7f26ec7d612d6ec7185e(BulletInfo *p); 
static void stepfunc_90de205f13c2acd5196a0dfb09cdfa6c(BulletInfo *p); 
static void stepfunc_b9a6e8d2e235e1b015a68844fb952ece(BulletInfo *p); 
static void stepfunc_5f11b8d1a69c0be946f15cbdd9c57f6e(BulletInfo *p); 
static void stepfunc_7cded1f9945e292a53f463868a606b2d(BulletInfo *p); 
static void stepfunc_184e9f40c56bde60405ced00a7bf3a28(BulletInfo *p); 
static void stepfunc_9a75dba2f15715b9f692d175bf12e362(BulletInfo *p); 
static void stepfunc_4c8dadb793642c64a663d118fedf7e6b(BulletInfo *p); 
static void stepfunc_0c3e2ee6d973f1f9336d60aa48f204eb(BulletInfo *p); 
static void stepfunc_7749697662468af5790d1fe35d3f949b(BulletInfo *p); 
static void stepfunc_bb9560c0e50074aceca0591390297db0(BulletInfo *p); 
static void stepfunc_fde1fb828fc6073fa0ec720642a277e2(BulletInfo *p); 
static void stepfunc_5234a30c9dbaa2818cf40e5c375bb473(BulletInfo *p); 
static void stepfunc_2b491eea3f5f1e31785013b0bab36054(BulletInfo *p); 
static void stepfunc_556a97d5fdb579ee91cd918fe2d5171d(BulletInfo *p); 
static void stepfunc_ab06bb835d30ce2fe4123c8b31728a9e(BulletInfo *p); 
static void stepfunc_2438eff374c5fadcb03065d2816eedc5(BulletInfo *p); 


static const BulletStepFunc bullet_02f0968fc3e6d2e20dc006706ee8e277[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_0b725083a5d1cf9d803659ffbb8fbe57,
stepfunc_05c35b6f65e50046397868607b54288a,
#if 0
stepfunc_d375f926e8630a8dcf1ecee92d9e04b1,
#endif
NULL}; 
static const BulletStepFunc bullet_a36d790ed13fe2734b30d93cd89544a1[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_b2b9cd795f8b7f26ec7d612d6ec7185e,
stepfunc_90de205f13c2acd5196a0dfb09cdfa6c,
#if 0
stepfunc_b9a6e8d2e235e1b015a68844fb952ece,
#endif
NULL}; 
static const BulletStepFunc bullet_746a13316c2cda1d574870499d2dc636[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_5f11b8d1a69c0be946f15cbdd9c57f6e,
stepfunc_7cded1f9945e292a53f463868a606b2d,
#if 0
stepfunc_184e9f40c56bde60405ced00a7bf3a28,
#endif
NULL}; 
static const BulletStepFunc bullet_52ec35c9a62fe4287a013f24e39123ae[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_9a75dba2f15715b9f692d175bf12e362,
stepfunc_4c8dadb793642c64a663d118fedf7e6b,
#if 0
stepfunc_0c3e2ee6d973f1f9336d60aa48f204eb,
#endif
NULL}; 
static const BulletStepFunc bullet_e1355d5bba84b4db4f777cb4de7eae87[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_7749697662468af5790d1fe35d3f949b,
stepfunc_bb9560c0e50074aceca0591390297db0,
#if 0
stepfunc_fde1fb828fc6073fa0ec720642a277e2,
#endif
NULL}; 
static const BulletStepFunc bullet_398ffaaef8b793b3d75a5317b302bf2b[] = {
stepfunc_5234a30c9dbaa2818cf40e5c375bb473,
stepfunc_2b491eea3f5f1e31785013b0bab36054,
stepfunc_556a97d5fdb579ee91cd918fe2d5171d,
stepfunc_ab06bb835d30ce2fe4123c8b31728a9e,
stepfunc_2438eff374c5fadcb03065d2816eedc5,
NULL}; 
static void stepfunc_d375f926e8630a8dcf1ecee92d9e04b1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(302, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_0b725083a5d1cf9d803659ffbb8fbe57(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_05c35b6f65e50046397868607b54288a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 119; ++i) { 
stepfunc_d375f926e8630a8dcf1ecee92d9e04b1(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b9a6e8d2e235e1b015a68844fb952ece(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(302, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_b2b9cd795f8b7f26ec7d612d6ec7185e(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_90de205f13c2acd5196a0dfb09cdfa6c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 119; ++i) { 
stepfunc_b9a6e8d2e235e1b015a68844fb952ece(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_184e9f40c56bde60405ced00a7bf3a28(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(302, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_5f11b8d1a69c0be946f15cbdd9c57f6e(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 50; 
}
static void stepfunc_7cded1f9945e292a53f463868a606b2d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 119; ++i) { 
stepfunc_184e9f40c56bde60405ced00a7bf3a28(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_0c3e2ee6d973f1f9336d60aa48f204eb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(302, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9a75dba2f15715b9f692d175bf12e362(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 70; 
}
static void stepfunc_4c8dadb793642c64a663d118fedf7e6b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 119; ++i) { 
stepfunc_0c3e2ee6d973f1f9336d60aa48f204eb(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_fde1fb828fc6073fa0ec720642a277e2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(302, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_7749697662468af5790d1fe35d3f949b(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 90; 
}
static void stepfunc_bb9560c0e50074aceca0591390297db0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 119; ++i) { 
stepfunc_fde1fb828fc6073fa0ec720642a277e2(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5234a30c9dbaa2818cf40e5c375bb473(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e1355d5bba84b4db4f777cb4de7eae87;  }
}
p->wait = 10; 
}
static void stepfunc_2b491eea3f5f1e31785013b0bab36054(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10666, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_52ec35c9a62fe4287a013f24e39123ae;  }
}
p->wait = 10; 
}
static void stepfunc_556a97d5fdb579ee91cd918fe2d5171d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_746a13316c2cda1d574870499d2dc636;  }
}
p->wait = 10; 
}
static void stepfunc_ab06bb835d30ce2fe4123c8b31728a9e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14933, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a36d790ed13fe2734b30d93cd89544a1;  }
}
p->wait = 10; 
}
static void stepfunc_2438eff374c5fadcb03065d2816eedc5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_02f0968fc3e6d2e20dc006706ee8e277;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_515f6916f9e44cb2756bcbe1dfdc8cf0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_398ffaaef8b793b3d75a5317b302bf2b; }}


