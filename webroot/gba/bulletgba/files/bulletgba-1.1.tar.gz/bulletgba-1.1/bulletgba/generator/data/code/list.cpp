void genBulletFunc_1826f1b70570a49c436e155d1a055e7f(FixedPointNum, FixedPointNum); 
void genBulletFunc_ec2ce785bd9cb98a9e4e191ae44b1129(FixedPointNum, FixedPointNum); 
void genBulletFunc_b13faf00331510c39ba0cf76a794d963(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_bulletgba[] = { 
genBulletFunc_1826f1b70570a49c436e155d1a055e7f, 
genBulletFunc_ec2ce785bd9cb98a9e4e191ae44b1129, 
genBulletFunc_b13faf00331510c39ba0cf76a794d963, 
}; 

static const char *listBulletNames_bulletgba[] = { 
"- 5way", 
"- homing_circle", 
"- targetself", 
}; 

void genBulletFunc_a1e33d024b369c59f6b0c522d84a9878(FixedPointNum, FixedPointNum); 
void genBulletFunc_fe10d2602f269ec13b34c0f264792191(FixedPointNum, FixedPointNum); 
void genBulletFunc_2ce56b918311d1336a9732743ec2e841(FixedPointNum, FixedPointNum); 
void genBulletFunc_901634567937e382f1c7f6e78be57f2c(FixedPointNum, FixedPointNum); 
void genBulletFunc_bcd2ae9e74a329e8d4d12a1a0e554705(FixedPointNum, FixedPointNum); 
void genBulletFunc_c37e3478bc4ae90d436ce61ed20d5330(FixedPointNum, FixedPointNum); 
void genBulletFunc_1a55e51b5a8380232e0cc4859647bc97(FixedPointNum, FixedPointNum); 
void genBulletFunc_6ea716e10fdd5c31f9889a3a775a6d09(FixedPointNum, FixedPointNum); 
void genBulletFunc_ad0aed396e8b3a84affb9755c1dc02cd(FixedPointNum, FixedPointNum); 
void genBulletFunc_413a3ad36c18e3d2963f7f955bd2bf80(FixedPointNum, FixedPointNum); 
void genBulletFunc_df406d2cce1f440bc58eb237d8892b2f(FixedPointNum, FixedPointNum); 
void genBulletFunc_564ccc475c532a8d8cd89465edf1f349(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_bulletsmorph[] = { 
genBulletFunc_a1e33d024b369c59f6b0c522d84a9878, 
genBulletFunc_fe10d2602f269ec13b34c0f264792191, 
genBulletFunc_2ce56b918311d1336a9732743ec2e841, 
genBulletFunc_901634567937e382f1c7f6e78be57f2c, 
genBulletFunc_bcd2ae9e74a329e8d4d12a1a0e554705, 
genBulletFunc_c37e3478bc4ae90d436ce61ed20d5330, 
genBulletFunc_1a55e51b5a8380232e0cc4859647bc97, 
genBulletFunc_6ea716e10fdd5c31f9889a3a775a6d09, 
genBulletFunc_ad0aed396e8b3a84affb9755c1dc02cd, 
genBulletFunc_413a3ad36c18e3d2963f7f955bd2bf80, 
genBulletFunc_df406d2cce1f440bc58eb237d8892b2f, 
genBulletFunc_564ccc475c532a8d8cd89465edf1f349, 
}; 

static const char *listBulletNames_bulletsmorph[] = { 
"- aba_1", 
"- aba_2", 
"- aba_3", 
"- aba_4", 
"- aba_5", 
"- aba_6", 
"- aba_7", 
"- convergent", 
"- double_seduction", 
"- first_bravery", 
"- kunekune_plus_homing", 
"- satoru4", 
}; 

void genBulletFunc_ce4db8bbabe6accfd42dc9f5b1e4eacb(FixedPointNum, FixedPointNum); 
void genBulletFunc_b4d2a53d1501d4c1cfaa9add7580018b(FixedPointNum, FixedPointNum); 
void genBulletFunc_46f3243afcb31750e5624904f6623b47(FixedPointNum, FixedPointNum); 
void genBulletFunc_ad6be99f6a6db649ef6d0723a026471a(FixedPointNum, FixedPointNum); 
void genBulletFunc_c3518c8cc2bb36eabc65fe8f261dad33(FixedPointNum, FixedPointNum); 
void genBulletFunc_4de9c726e3050a6b9da7e78e2ba61556(FixedPointNum, FixedPointNum); 
void genBulletFunc_26f2d632aa1a4a29bc18aa63c6e9715a(FixedPointNum, FixedPointNum); 
void genBulletFunc_40759d27129182f029856c1f8b630e13(FixedPointNum, FixedPointNum); 
void genBulletFunc_80354378b3b889124b5a47c77141baee(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_bwda[] = { 
genBulletFunc_ce4db8bbabe6accfd42dc9f5b1e4eacb, 
genBulletFunc_b4d2a53d1501d4c1cfaa9add7580018b, 
genBulletFunc_46f3243afcb31750e5624904f6623b47, 
genBulletFunc_ad6be99f6a6db649ef6d0723a026471a, 
genBulletFunc_c3518c8cc2bb36eabc65fe8f261dad33, 
genBulletFunc_4de9c726e3050a6b9da7e78e2ba61556, 
genBulletFunc_26f2d632aa1a4a29bc18aa63c6e9715a, 
genBulletFunc_40759d27129182f029856c1f8b630e13, 
genBulletFunc_80354378b3b889124b5a47c77141baee, 
}; 

static const char *listBulletNames_bwda[] = { 
"- bwda01", 
"- bwda02", 
"- bwda03", 
"- bwda05", 
"- bwda05b", 
"- bwda05b2", 
"- bwda05c", 
"- bwda06", 
"- bwda07", 
}; 

void genBulletFunc_e34a5e529fdbd1ef2698b1d524e8c234(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_chaosseed[] = { 
genBulletFunc_e34a5e529fdbd1ef2698b1d524e8c234, 
}; 

static const char *listBulletNames_chaosseed[] = { 
"- big_monkey_boss", 
}; 

void genBulletFunc_334719a55d8277c0a93a68e944b62892(FixedPointNum, FixedPointNum); 
void genBulletFunc_ca08dca039f83b6cfad0ec898b7ed61f(FixedPointNum, FixedPointNum); 
void genBulletFunc_68d47e6046c78036efb1bd8f66d83470(FixedPointNum, FixedPointNum); 
void genBulletFunc_6934c674fdf5133f77db571008caa44a(FixedPointNum, FixedPointNum); 
void genBulletFunc_524eb6b7113b8918166f295ac12dcb62(FixedPointNum, FixedPointNum); 
void genBulletFunc_b9b9a8089fcf78ce80761b899a1807b7(FixedPointNum, FixedPointNum); 
void genBulletFunc_de1e2e7cf4264816abc1bbac01044c42(FixedPointNum, FixedPointNum); 
void genBulletFunc_ebe5b3567c26aa323a0ab06a722c0ee4(FixedPointNum, FixedPointNum); 
void genBulletFunc_0fbd44719292fee3755ff69e2e74453f(FixedPointNum, FixedPointNum); 
void genBulletFunc_7b72cfbd4c075fcc2115678825f28631(FixedPointNum, FixedPointNum); 
void genBulletFunc_72435491d0d2967071dddf0f34e77a1c(FixedPointNum, FixedPointNum); 
void genBulletFunc_93d139fa2c50df4acc0ff652f4b8ccea(FixedPointNum, FixedPointNum); 
void genBulletFunc_237daf15f30bb8f44d56576f9ff7b21b(FixedPointNum, FixedPointNum); 
void genBulletFunc_62d2d3337538d5d221c28420edaad61f(FixedPointNum, FixedPointNum); 
void genBulletFunc_9e204b0634fad9d73431286dfdb7b5be(FixedPointNum, FixedPointNum); 
void genBulletFunc_c0830ef6d27df38f141bdf18ecd75e48(FixedPointNum, FixedPointNum); 
void genBulletFunc_615c9922fb17846ccd0b1eaa489a863f(FixedPointNum, FixedPointNum); 
void genBulletFunc_c7298729652c342e4255e858892a9556(FixedPointNum, FixedPointNum); 
void genBulletFunc_040116d015ac20f87bd9b000301551a9(FixedPointNum, FixedPointNum); 
void genBulletFunc_3f9c56dbbd28b34c4a5bf7fbc0796d78(FixedPointNum, FixedPointNum); 
void genBulletFunc_e438b573c867cf704e135cb154518c0d(FixedPointNum, FixedPointNum); 
void genBulletFunc_bc5408753c310f8c269f37ba8a969401(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_daiouzyou[] = { 
genBulletFunc_334719a55d8277c0a93a68e944b62892, 
genBulletFunc_ca08dca039f83b6cfad0ec898b7ed61f, 
genBulletFunc_68d47e6046c78036efb1bd8f66d83470, 
genBulletFunc_6934c674fdf5133f77db571008caa44a, 
genBulletFunc_524eb6b7113b8918166f295ac12dcb62, 
genBulletFunc_b9b9a8089fcf78ce80761b899a1807b7, 
genBulletFunc_de1e2e7cf4264816abc1bbac01044c42, 
genBulletFunc_ebe5b3567c26aa323a0ab06a722c0ee4, 
genBulletFunc_0fbd44719292fee3755ff69e2e74453f, 
genBulletFunc_7b72cfbd4c075fcc2115678825f28631, 
genBulletFunc_72435491d0d2967071dddf0f34e77a1c, 
genBulletFunc_93d139fa2c50df4acc0ff652f4b8ccea, 
genBulletFunc_237daf15f30bb8f44d56576f9ff7b21b, 
genBulletFunc_62d2d3337538d5d221c28420edaad61f, 
genBulletFunc_9e204b0634fad9d73431286dfdb7b5be, 
genBulletFunc_c0830ef6d27df38f141bdf18ecd75e48, 
genBulletFunc_615c9922fb17846ccd0b1eaa489a863f, 
genBulletFunc_c7298729652c342e4255e858892a9556, 
genBulletFunc_040116d015ac20f87bd9b000301551a9, 
genBulletFunc_3f9c56dbbd28b34c4a5bf7fbc0796d78, 
genBulletFunc_e438b573c867cf704e135cb154518c0d, 
genBulletFunc_bc5408753c310f8c269f37ba8a969401, 
}; 

static const char *listBulletNames_daiouzyou[] = { 
"- hibachi_1", 
"- hibachi_2", 
"- hibachi_3", 
"- hibachi_image", 
"- hibachi_maybe", 
"- round_1_boss", 
"- round_1_boss_hakkyou", 
"- round_3_boss", 
"- round_3_boss_2", 
"- round_3_boss_last", 
"- round_4_boss", 
"- round_4_boss_1", 
"- round_4_boss_2", 
"- round_4_boss_4", 
"- round_4_boss_5", 
"- round_5_boss_1", 
"- round_5_boss_2", 
"- round_6_boss_1", 
"- round_6_boss_2", 
"- round_6_boss_3", 
"- round_6_boss_4", 
"- round_6_boss_5", 
}; 

void genBulletFunc_a7556e1003358aebfcf8f8259e6f80be(FixedPointNum, FixedPointNum); 
void genBulletFunc_53a7fc7f1c0bb27346bd81c88435868d(FixedPointNum, FixedPointNum); 
void genBulletFunc_0dba329100a592341092c52b8cccaa1a(FixedPointNum, FixedPointNum); 
void genBulletFunc_65d8c864865fd7faab14ffc30bb69cfd(FixedPointNum, FixedPointNum); 
void genBulletFunc_bc572d16d6818e0645ae13e9954fce27(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_dodonpachi[] = { 
genBulletFunc_a7556e1003358aebfcf8f8259e6f80be, 
genBulletFunc_53a7fc7f1c0bb27346bd81c88435868d, 
genBulletFunc_0dba329100a592341092c52b8cccaa1a, 
genBulletFunc_65d8c864865fd7faab14ffc30bb69cfd, 
genBulletFunc_bc572d16d6818e0645ae13e9954fce27, 
}; 

static const char *listBulletNames_dodonpachi[] = { 
"- hibachi", 
"- kitiku_1", 
"- kitiku_2", 
"- kitiku_3", 
"- kitiku_5", 
}; 

void genBulletFunc_ef1c2457cc64cfc80b9fd485342c5471(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_dragonblaze[] = { 
genBulletFunc_ef1c2457cc64cfc80b9fd485342c5471, 
}; 

static const char *listBulletNames_dragonblaze[] = { 
"- nebyurosu_2", 
}; 

void genBulletFunc_c518f5a1d6e4645d399963fb8742b4db(FixedPointNum, FixedPointNum); 
void genBulletFunc_7799983d747e9aea22306683e2999466(FixedPointNum, FixedPointNum); 
void genBulletFunc_6c0721d13bdf6105800d2c521bc530ce(FixedPointNum, FixedPointNum); 
void genBulletFunc_0a09a897406045d93b4e3a236160fdfc(FixedPointNum, FixedPointNum); 
void genBulletFunc_6f75b6003cc2ae2b8a92ca9c013526a0(FixedPointNum, FixedPointNum); 
void genBulletFunc_75664967f917ec0d465826b0b5c60d6b(FixedPointNum, FixedPointNum); 
void genBulletFunc_458131fa4f066e7d338c00a6ca0aab67(FixedPointNum, FixedPointNum); 
void genBulletFunc_e560b5b2eb46f6240ff44300ca51a6ec(FixedPointNum, FixedPointNum); 
void genBulletFunc_11577bd829132b258637476399b6ed64(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_esp_galuda_lt[] = { 
genBulletFunc_c518f5a1d6e4645d399963fb8742b4db, 
genBulletFunc_7799983d747e9aea22306683e2999466, 
genBulletFunc_6c0721d13bdf6105800d2c521bc530ce, 
genBulletFunc_0a09a897406045d93b4e3a236160fdfc, 
genBulletFunc_6f75b6003cc2ae2b8a92ca9c013526a0, 
genBulletFunc_75664967f917ec0d465826b0b5c60d6b, 
genBulletFunc_458131fa4f066e7d338c00a6ca0aab67, 
genBulletFunc_e560b5b2eb46f6240ff44300ca51a6ec, 
genBulletFunc_11577bd829132b258637476399b6ed64, 
}; 

static const char *listBulletNames_esp_galuda_lt[] = { 
"- esp_galuda_lt_stage1", 
"- esp_galuda_lt_stage1", 
"- esp_galuda_lt_stage2", 
"- esp_galuda_lt_stage2", 
"- esp_galuda_lt_stage2", 
"- esp_galuda_lt_stage3", 
"- esp_galuda_lt_stage3", 
"- esp_galuda_lt_stage3", 
"- esp_galuda_lt_stage4", 
}; 

void genBulletFunc_50a1687045849dc9f64fb6afb3e2668b(FixedPointNum, FixedPointNum); 
void genBulletFunc_9819c3d624cc76fa498934586ccf6f3e(FixedPointNum, FixedPointNum); 
void genBulletFunc_9775f4d4d5f6a787fe0fa3496459b059(FixedPointNum, FixedPointNum); 
void genBulletFunc_7a583108443650ba8b6f75c21d0d4333(FixedPointNum, FixedPointNum); 
void genBulletFunc_d4c4104593f97c409a3bd57fba5fed31(FixedPointNum, FixedPointNum); 
void genBulletFunc_b69210483397768b79d4babf9ed15c7f(FixedPointNum, FixedPointNum); 
void genBulletFunc_08c150ab86b351f266f2dc5dcacfce92(FixedPointNum, FixedPointNum); 
void genBulletFunc_c4fc1ea28edec18f6bb50128ab578a98(FixedPointNum, FixedPointNum); 
void genBulletFunc_898960ac300c5959d4ae6bbb646b85e6(FixedPointNum, FixedPointNum); 
void genBulletFunc_cf9e1428717db28659ffd1fb78a3622d(FixedPointNum, FixedPointNum); 
void genBulletFunc_543b90e60374029473858234b1380ba4(FixedPointNum, FixedPointNum); 
void genBulletFunc_740492a6569d251c4550519af137ad67(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_esp_rade[] = { 
genBulletFunc_50a1687045849dc9f64fb6afb3e2668b, 
genBulletFunc_9819c3d624cc76fa498934586ccf6f3e, 
genBulletFunc_9775f4d4d5f6a787fe0fa3496459b059, 
genBulletFunc_7a583108443650ba8b6f75c21d0d4333, 
genBulletFunc_d4c4104593f97c409a3bd57fba5fed31, 
genBulletFunc_b69210483397768b79d4babf9ed15c7f, 
genBulletFunc_08c150ab86b351f266f2dc5dcacfce92, 
genBulletFunc_c4fc1ea28edec18f6bb50128ab578a98, 
genBulletFunc_898960ac300c5959d4ae6bbb646b85e6, 
genBulletFunc_cf9e1428717db28659ffd1fb78a3622d, 
genBulletFunc_543b90e60374029473858234b1380ba4, 
genBulletFunc_740492a6569d251c4550519af137ad67, 
}; 

static const char *listBulletNames_esp_rade[] = { 
"- round_123_boss_izuna", 
"- round_123_boss_pelab", 
"- round_123_boss_sator", 
"- round_5_alice_clone", 
"- round_5_boss_ares_2", 
"- round_5_boss_gara_1_", 
"- round_5_boss_gara_1_", 
"- round_5_boss_gara_2", 
"- round_5_boss_gara_3", 
"- round_5_boss_gara_4", 
"- round_5_boss_gara_5", 
"- round_5_boss_kakusi_", 
}; 

void genBulletFunc_9bf27585fcde55cb675bf16f731d9817(FixedPointNum, FixedPointNum); 
void genBulletFunc_f7f40451640c3178ab1e7b753ed19994(FixedPointNum, FixedPointNum); 
void genBulletFunc_6bd4218adbfa1da955874016234e7102(FixedPointNum, FixedPointNum); 
void genBulletFunc_9d3ca2a7de83603442aab54a0513fc2a(FixedPointNum, FixedPointNum); 
void genBulletFunc_f6523782d6d5ce07c61ba7c6e002a33c(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_g_wange[] = { 
genBulletFunc_9bf27585fcde55cb675bf16f731d9817, 
genBulletFunc_f7f40451640c3178ab1e7b753ed19994, 
genBulletFunc_6bd4218adbfa1da955874016234e7102, 
genBulletFunc_9d3ca2a7de83603442aab54a0513fc2a, 
genBulletFunc_f6523782d6d5ce07c61ba7c6e002a33c, 
}; 

static const char *listBulletNames_g_wange[] = { 
"- g_wange_hi_ishi_1", 
"- g_wange_hi_ishi_3", 
"- g_wange_hi_ishi_4", 
"- roll_gara", 
"- round_trip_bit", 
}; 

void genBulletFunc_639682e986f3fbe5e6b7062d71ccbd72(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_g_darius[] = { 
genBulletFunc_639682e986f3fbe5e6b7062d71ccbd72, 
}; 

static const char *listBulletNames_g_darius[] = { 
"- homing_laser", 
}; 

void genBulletFunc_e457e3280b609a4bb8ab59c27fdbecb0(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_garegga[] = { 
genBulletFunc_e457e3280b609a4bb8ab59c27fdbecb0, 
}; 

static const char *listBulletNames_garegga[] = { 
"- black_heart_mk2_wind", 
}; 

void genBulletFunc_15e4f43466a69a84e122e8d894c52d64(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_gigawing2[] = { 
genBulletFunc_15e4f43466a69a84e122e8d894c52d64, 
}; 

static const char *listBulletNames_gigawing2[] = { 
"- akurimi", 
}; 

void genBulletFunc_1591104d8d72e66a2a6a97bdbcab77cc(FixedPointNum, FixedPointNum); 
void genBulletFunc_0fbccba092c27f1f07e6b73631ec1219(FixedPointNum, FixedPointNum); 
void genBulletFunc_44b233dbd6db9a3ccf524fb01176fcb0(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_guwange[] = { 
genBulletFunc_1591104d8d72e66a2a6a97bdbcab77cc, 
genBulletFunc_0fbccba092c27f1f07e6b73631ec1219, 
genBulletFunc_44b233dbd6db9a3ccf524fb01176fcb0, 
}; 

static const char *listBulletNames_guwange[] = { 
"- round_2_boss_circle_", 
"- round_3_boss_fast_3w", 
"- round_4_boss_eye_bal", 
}; 

void genBulletFunc_0a7eccb63e4fd5cbca6dfe97d6fee9a9(FixedPointNum, FixedPointNum); 
void genBulletFunc_77f3a1ad788ce0f352487ae5a56babd7(FixedPointNum, FixedPointNum); 
void genBulletFunc_533f4d8c48c9a5749a6f3dc2a282b918(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_ketui_lt[] = { 
genBulletFunc_0a7eccb63e4fd5cbca6dfe97d6fee9a9, 
genBulletFunc_77f3a1ad788ce0f352487ae5a56babd7, 
genBulletFunc_533f4d8c48c9a5749a6f3dc2a282b918, 
}; 

static const char *listBulletNames_ketui_lt[] = { 
"- 2boss_winder_crash", 
"- 3boss_kunekune", 
"- 3boss_roll_and_aim", 
}; 

void genBulletFunc_22c1c89112e53cd1523eb5f688ce28a8(FixedPointNum, FixedPointNum); 
void genBulletFunc_6448999ed143182bb93703c4950cba7f(FixedPointNum, FixedPointNum); 
void genBulletFunc_8c7b0711492be53fef20be8ac99b027f(FixedPointNum, FixedPointNum); 
void genBulletFunc_012e49d6334baa6382b7b45044ee739d(FixedPointNum, FixedPointNum); 
void genBulletFunc_76df96fc8bfa237dfbd77d6d523da1e5(FixedPointNum, FixedPointNum); 
void genBulletFunc_b3a2f2760fed32b84080a5a31aa51393(FixedPointNum, FixedPointNum); 
void genBulletFunc_a15e4e6f5f2a5ea1d963dbf57a3a77f7(FixedPointNum, FixedPointNum); 
void genBulletFunc_af43cb9d2f22d4551030ae4412dd6055(FixedPointNum, FixedPointNum); 
void genBulletFunc_143001ba37f72942b5dfaabc2b2afafb(FixedPointNum, FixedPointNum); 
void genBulletFunc_f170e3155d79ce84b0759075202141a9(FixedPointNum, FixedPointNum); 
void genBulletFunc_71f30ece3e8720a6ebd291232949bb0f(FixedPointNum, FixedPointNum); 
void genBulletFunc_aae6cbb628bf7657aa587f22d698fdae(FixedPointNum, FixedPointNum); 
void genBulletFunc_3c09fcb6f15c061f00907d2637765f42(FixedPointNum, FixedPointNum); 
void genBulletFunc_51de9f01c3d5900e25c22296cddcada7(FixedPointNum, FixedPointNum); 
void genBulletFunc_e96ca6894f57511189bebe339c750de7(FixedPointNum, FixedPointNum); 
void genBulletFunc_9af899c5b076bb7e647cbf738a6cc70f(FixedPointNum, FixedPointNum); 
void genBulletFunc_8056ed1dce74cf53a5fc7dea8b4cde33(FixedPointNum, FixedPointNum); 
void genBulletFunc_bb1f9bd4b096d1d89e81217429fbfcd8(FixedPointNum, FixedPointNum); 
void genBulletFunc_236b4228549548ab1dada469cbd61d7c(FixedPointNum, FixedPointNum); 
void genBulletFunc_3d5c252016ad86e880db26df95895c26(FixedPointNum, FixedPointNum); 
void genBulletFunc_11d9a256aca0bb75cd02a44cfcdf0c66(FixedPointNum, FixedPointNum); 
void genBulletFunc_cffa211c702fc9b01b8ba8b00baf79ff(FixedPointNum, FixedPointNum); 
void genBulletFunc_8bfbaf6f4daa2384b76feb27d8615282(FixedPointNum, FixedPointNum); 
void genBulletFunc_293cb0c199ebf46c63acf6289d65ab2c(FixedPointNum, FixedPointNum); 
void genBulletFunc_1ff1fb6faea7cc70d9cd03fd8d7f864d(FixedPointNum, FixedPointNum); 
void genBulletFunc_46b3a7b72609463c4938d3c34513d1eb(FixedPointNum, FixedPointNum); 
void genBulletFunc_3081c8091f2fd95d698ce532b2b6b025(FixedPointNum, FixedPointNum); 
void genBulletFunc_60a81b481bb4446645b841f047be49ee(FixedPointNum, FixedPointNum); 
void genBulletFunc_85ed4674522a98a054b082c2fbec33b6(FixedPointNum, FixedPointNum); 
void genBulletFunc_799af0ed22862c09f2e5c175c6c30efd(FixedPointNum, FixedPointNum); 
void genBulletFunc_5a76b37d6b348138e2d4fbb082933562(FixedPointNum, FixedPointNum); 
void genBulletFunc_72c2014b4e3d4fd073adf1e7a3890d18(FixedPointNum, FixedPointNum); 
void genBulletFunc_3576013f1e8a5a5125c5dc6a1dee631e(FixedPointNum, FixedPointNum); 
void genBulletFunc_5b9353b8b5e65db9bcba719647fdf82e(FixedPointNum, FixedPointNum); 
void genBulletFunc_2565af30d98ae21ab37ad1f950136563(FixedPointNum, FixedPointNum); 
void genBulletFunc_2c8f182176a3c5058da240439be6598a(FixedPointNum, FixedPointNum); 
void genBulletFunc_dc480d4bcf51bd410f465f049b6534ff(FixedPointNum, FixedPointNum); 
void genBulletFunc_149f9855018619ebccf2d86c43d5fc51(FixedPointNum, FixedPointNum); 
void genBulletFunc_165b149a05ac2e2dcf9bd1762b6d9ab7(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_kotuanzenx[] = { 
genBulletFunc_22c1c89112e53cd1523eb5f688ce28a8, 
genBulletFunc_6448999ed143182bb93703c4950cba7f, 
genBulletFunc_8c7b0711492be53fef20be8ac99b027f, 
genBulletFunc_012e49d6334baa6382b7b45044ee739d, 
genBulletFunc_76df96fc8bfa237dfbd77d6d523da1e5, 
genBulletFunc_b3a2f2760fed32b84080a5a31aa51393, 
genBulletFunc_a15e4e6f5f2a5ea1d963dbf57a3a77f7, 
genBulletFunc_af43cb9d2f22d4551030ae4412dd6055, 
genBulletFunc_143001ba37f72942b5dfaabc2b2afafb, 
genBulletFunc_f170e3155d79ce84b0759075202141a9, 
genBulletFunc_71f30ece3e8720a6ebd291232949bb0f, 
genBulletFunc_aae6cbb628bf7657aa587f22d698fdae, 
genBulletFunc_3c09fcb6f15c061f00907d2637765f42, 
genBulletFunc_51de9f01c3d5900e25c22296cddcada7, 
genBulletFunc_e96ca6894f57511189bebe339c750de7, 
genBulletFunc_9af899c5b076bb7e647cbf738a6cc70f, 
genBulletFunc_8056ed1dce74cf53a5fc7dea8b4cde33, 
genBulletFunc_bb1f9bd4b096d1d89e81217429fbfcd8, 
genBulletFunc_236b4228549548ab1dada469cbd61d7c, 
genBulletFunc_3d5c252016ad86e880db26df95895c26, 
genBulletFunc_11d9a256aca0bb75cd02a44cfcdf0c66, 
genBulletFunc_cffa211c702fc9b01b8ba8b00baf79ff, 
genBulletFunc_8bfbaf6f4daa2384b76feb27d8615282, 
genBulletFunc_293cb0c199ebf46c63acf6289d65ab2c, 
genBulletFunc_1ff1fb6faea7cc70d9cd03fd8d7f864d, 
genBulletFunc_46b3a7b72609463c4938d3c34513d1eb, 
genBulletFunc_3081c8091f2fd95d698ce532b2b6b025, 
genBulletFunc_60a81b481bb4446645b841f047be49ee, 
genBulletFunc_85ed4674522a98a054b082c2fbec33b6, 
genBulletFunc_799af0ed22862c09f2e5c175c6c30efd, 
genBulletFunc_5a76b37d6b348138e2d4fbb082933562, 
genBulletFunc_72c2014b4e3d4fd073adf1e7a3890d18, 
genBulletFunc_3576013f1e8a5a5125c5dc6a1dee631e, 
genBulletFunc_5b9353b8b5e65db9bcba719647fdf82e, 
genBulletFunc_2565af30d98ae21ab37ad1f950136563, 
genBulletFunc_2c8f182176a3c5058da240439be6598a, 
genBulletFunc_dc480d4bcf51bd410f465f049b6534ff, 
genBulletFunc_149f9855018619ebccf2d86c43d5fc51, 
genBulletFunc_165b149a05ac2e2dcf9bd1762b6d9ab7, 
}; 

static const char *listBulletNames_kotuanzenx[] = { 
"- bb03-winderjiki", 
"- bb04-r7", 
"- bb05-bomb", 
"- bb06-ohgi", 
"- bb07-las1", 
"- bb08-las1+", 
"- bb09-ohka", 
"- bb10-doublebody", 
"- bb11-sp", 
"- tsx-bx1-seahorse", 
"- tsx-bx1h-seahorse2", 
"- tsx-bx2-mine", 
"- tsx_aka-kasuri", 
"- tsx_awtt", 
"- tsx_cinshot", 
"- tsx_d_wave", 
"- tsx_evac01", 
"- tsx_evac02", 
"- tsx_evac07", 
"- tsx_gedo", 
"- tsx_hx", 
"- tsx_kiero", 
"- tsx_kohaku_first", 
"- tsx_mimir", 
"- tsx_musi4boss", 
"- tsx_proto01", 
"- tsx_proto02", 
"- tsx_proto03", 
"- tsx_proto04", 
"- tsx_proto05", 
"- tsx_proto06", 
"- tsx_proto11", 
"- tsx_rand", 
"- tsx_sanada", 
"- tsx_seseribaz", 
"- tsx_spin", 
"- tsx_thtt", 
"- tsx_wh", 
"- tsx_x1", 
}; 

void genBulletFunc_2210912da37b53466f865e2967b71866(FixedPointNum, FixedPointNum); 
void genBulletFunc_1f97d15e30ffa659583524ad548fb5af(FixedPointNum, FixedPointNum); 
void genBulletFunc_a70e1dbe51a8b7eab8535a6307b414be(FixedPointNum, FixedPointNum); 
void genBulletFunc_1814bab23eb42fd0229bc0c3c3d34010(FixedPointNum, FixedPointNum); 
void genBulletFunc_9873e665589d2e08a9528043de88928c(FixedPointNum, FixedPointNum); 
void genBulletFunc_a035eb5f08a276f17db8a8a2bfc4ce79(FixedPointNum, FixedPointNum); 
void genBulletFunc_de989563fec143fec79bea0c220592d2(FixedPointNum, FixedPointNum); 
void genBulletFunc_ea5bbbc7ecc0578fd9a21f0a193735e1(FixedPointNum, FixedPointNum); 
void genBulletFunc_c2840f94d8496664252fca440d6b6db8(FixedPointNum, FixedPointNum); 
void genBulletFunc_1b6ece292bd07ef0f5f993a075363670(FixedPointNum, FixedPointNum); 
void genBulletFunc_269b6a5419d16e17e755e9c3b96c75b9(FixedPointNum, FixedPointNum); 
void genBulletFunc_9baeb10b619a9434d45da296752e5266(FixedPointNum, FixedPointNum); 
void genBulletFunc_2905f517a6bef596ee2a4ad9e27c30c7(FixedPointNum, FixedPointNum); 
void genBulletFunc_bcb192ec030d0207ff44d53f4b2ed5c6(FixedPointNum, FixedPointNum); 
void genBulletFunc_2475f6c410fe569a82c0424a62fcd7ae(FixedPointNum, FixedPointNum); 
void genBulletFunc_ddfcf7a5d57c18c4654bb96d1a275f37(FixedPointNum, FixedPointNum); 
void genBulletFunc_c0a4449d4688ade296a17ee87bf22ad9(FixedPointNum, FixedPointNum); 
void genBulletFunc_13ee68bfba54bf3ffb651d3d415639e0(FixedPointNum, FixedPointNum); 
void genBulletFunc_a482d06a5e18a335ec48c1e49d0b1f04(FixedPointNum, FixedPointNum); 
void genBulletFunc_0f878170050f2aad58c858675c5a68fb(FixedPointNum, FixedPointNum); 
void genBulletFunc_dda8ad0c40a4471fafb906091a6f2c8d(FixedPointNum, FixedPointNum); 
void genBulletFunc_bd30d00a742f43ebc8e9d619a1bf9750(FixedPointNum, FixedPointNum); 
void genBulletFunc_75d2ef04570be8b35e19251ec493ae8a(FixedPointNum, FixedPointNum); 
void genBulletFunc_861a2402e6c2490fd9779ae45a31d87d(FixedPointNum, FixedPointNum); 
void genBulletFunc_fea26560be0cc6087fa39f009151c461(FixedPointNum, FixedPointNum); 
void genBulletFunc_54e3ac1c7d8719e6c08417ece9d0a581(FixedPointNum, FixedPointNum); 
void genBulletFunc_0725c5e4d4d2abbcb82a03dd1770004e(FixedPointNum, FixedPointNum); 
void genBulletFunc_926ed90fbe351431b58c45ee1800e8d4(FixedPointNum, FixedPointNum); 
void genBulletFunc_39bd603988f2c68039deb4546e5e2eff(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_mda[] = { 
genBulletFunc_2210912da37b53466f865e2967b71866, 
genBulletFunc_1f97d15e30ffa659583524ad548fb5af, 
genBulletFunc_a70e1dbe51a8b7eab8535a6307b414be, 
genBulletFunc_1814bab23eb42fd0229bc0c3c3d34010, 
genBulletFunc_9873e665589d2e08a9528043de88928c, 
genBulletFunc_a035eb5f08a276f17db8a8a2bfc4ce79, 
genBulletFunc_de989563fec143fec79bea0c220592d2, 
genBulletFunc_ea5bbbc7ecc0578fd9a21f0a193735e1, 
genBulletFunc_c2840f94d8496664252fca440d6b6db8, 
genBulletFunc_1b6ece292bd07ef0f5f993a075363670, 
genBulletFunc_269b6a5419d16e17e755e9c3b96c75b9, 
genBulletFunc_9baeb10b619a9434d45da296752e5266, 
genBulletFunc_2905f517a6bef596ee2a4ad9e27c30c7, 
genBulletFunc_bcb192ec030d0207ff44d53f4b2ed5c6, 
genBulletFunc_2475f6c410fe569a82c0424a62fcd7ae, 
genBulletFunc_ddfcf7a5d57c18c4654bb96d1a275f37, 
genBulletFunc_c0a4449d4688ade296a17ee87bf22ad9, 
genBulletFunc_13ee68bfba54bf3ffb651d3d415639e0, 
genBulletFunc_a482d06a5e18a335ec48c1e49d0b1f04, 
genBulletFunc_0f878170050f2aad58c858675c5a68fb, 
genBulletFunc_dda8ad0c40a4471fafb906091a6f2c8d, 
genBulletFunc_bd30d00a742f43ebc8e9d619a1bf9750, 
genBulletFunc_75d2ef04570be8b35e19251ec493ae8a, 
genBulletFunc_861a2402e6c2490fd9779ae45a31d87d, 
genBulletFunc_fea26560be0cc6087fa39f009151c461, 
genBulletFunc_54e3ac1c7d8719e6c08417ece9d0a581, 
genBulletFunc_0725c5e4d4d2abbcb82a03dd1770004e, 
genBulletFunc_926ed90fbe351431b58c45ee1800e8d4, 
genBulletFunc_39bd603988f2c68039deb4546e5e2eff, 
}; 

static const char *listBulletNames_mda[] = { 
"- 10flower_2", 
"- 14b_2-3w", 
"- 2f", 
"- acc_n_dec", 
"- circular", 
"- circular_model", 
"- circular_sun", 
"- double_w", 
"- fukuro", 
"- gnnnyari", 
"- gnnnyari_a", 
"- mda_179-10", 
"- mda_fasa", 
"- mda_gnnny_2xa", 
"- mda_gnnny_2xb", 
"- mda_gnnny_3c", 
"- mda_n-b-2", 
"- mda_n-b", 
"- mda_nejiri", 
"- mda_potduet", 
"- mda_r106-7", 
"- mda_scales9", 
"- mda_time_a", 
"- mda_time_b", 
"- mda_uneune", 
"- mojya", 
"- mossari", 
"- wheel_30", 
"- wind_cl", 
}; 

void genBulletFunc_172bec91e10e4758f81dce13764b7a71(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_misc[] = { 
genBulletFunc_172bec91e10e4758f81dce13764b7a71, 
}; 

static const char *listBulletNames_misc[] = { 
"- border_down_6a_boss_", 
}; 

void genBulletFunc_c2c47400df9ae71a1d69660749eba9ed(FixedPointNum, FixedPointNum); 
void genBulletFunc_2ddf9d45e7a255c90492240084b58d7a(FixedPointNum, FixedPointNum); 
void genBulletFunc_598b170395bc7aa260fd9bd90e228f22(FixedPointNum, FixedPointNum); 
void genBulletFunc_a21d5895bccae1c7be811431625e8bf5(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_noiz2sa[] = { 
genBulletFunc_c2c47400df9ae71a1d69660749eba9ed, 
genBulletFunc_2ddf9d45e7a255c90492240084b58d7a, 
genBulletFunc_598b170395bc7aa260fd9bd90e228f22, 
genBulletFunc_a21d5895bccae1c7be811431625e8bf5, 
}; 

static const char *listBulletNames_noiz2sa[] = { 
"- 5_players", 
"- 88way", 
"- bit", 
"- rollbar", 
}; 

void genBulletFunc_8f7b58edbc0ea04356e9d3c88b492ca0(FixedPointNum, FixedPointNum); 
void genBulletFunc_e427021c3ca1ade00d8fc3e5829096c3(FixedPointNum, FixedPointNum); 
void genBulletFunc_c3e9c6057367d8278c302a5bb8d39939(FixedPointNum, FixedPointNum); 
void genBulletFunc_68c9e1b753ff7fd272472dc4d3eeef4c(FixedPointNum, FixedPointNum); 
void genBulletFunc_f50dfaed4062c0592738dfd60353cc43(FixedPointNum, FixedPointNum); 
void genBulletFunc_b77e9bf846db43e71a6bc0295d4c65c1(FixedPointNum, FixedPointNum); 
void genBulletFunc_39ae97c337a2efe3d3e8dd47997da374(FixedPointNum, FixedPointNum); 
void genBulletFunc_7268525aebfd62674e5f16dc9c85b2d8(FixedPointNum, FixedPointNum); 
void genBulletFunc_4af91a51c5a2cede2451232d44189dcf(FixedPointNum, FixedPointNum); 
void genBulletFunc_2df25b32494d9cf7d17581306e0ba012(FixedPointNum, FixedPointNum); 
void genBulletFunc_a0af817c2ad1ad48948b272adbc1cffe(FixedPointNum, FixedPointNum); 
void genBulletFunc_49c166ad74593dd22d6c045c331f00b3(FixedPointNum, FixedPointNum); 
void genBulletFunc_186f9d1d3b5e03cb34933af9e40d973f(FixedPointNum, FixedPointNum); 
void genBulletFunc_7b603ab4da83bda23d1c1a71e724bb06(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_oohara[] = { 
genBulletFunc_8f7b58edbc0ea04356e9d3c88b492ca0, 
genBulletFunc_e427021c3ca1ade00d8fc3e5829096c3, 
genBulletFunc_c3e9c6057367d8278c302a5bb8d39939, 
genBulletFunc_68c9e1b753ff7fd272472dc4d3eeef4c, 
genBulletFunc_f50dfaed4062c0592738dfd60353cc43, 
genBulletFunc_b77e9bf846db43e71a6bc0295d4c65c1, 
genBulletFunc_39ae97c337a2efe3d3e8dd47997da374, 
genBulletFunc_7268525aebfd62674e5f16dc9c85b2d8, 
genBulletFunc_4af91a51c5a2cede2451232d44189dcf, 
genBulletFunc_2df25b32494d9cf7d17581306e0ba012, 
genBulletFunc_a0af817c2ad1ad48948b272adbc1cffe, 
genBulletFunc_49c166ad74593dd22d6c045c331f00b3, 
genBulletFunc_186f9d1d3b5e03cb34933af9e40d973f, 
genBulletFunc_7b603ab4da83bda23d1c1a71e724bb06, 
}; 

static const char *listBulletNames_oohara[] = { 
"- a", 
"- celestial_thought", 
"- cheeky_nway", 
"- cutting_edge_of_noti", 
"- first_class_nway", 
"- flat_nway", 
"- green_thought", 
"- innovation_nway", 
"- my_boom", 
"- nopida_crying_dance", 
"- recommended_nway", 
"- stockholders_meeting", 
"- stockholders_meeting", 
"- the_43rd_sunset", 
}; 

void genBulletFunc_0da31e2f3027b772f92c415b826e5dda(FixedPointNum, FixedPointNum); 
void genBulletFunc_b44dbec62b2b86f34cb4657c468eea7c(FixedPointNum, FixedPointNum); 
void genBulletFunc_526555bad717a27ce6ac8e64de6be89f(FixedPointNum, FixedPointNum); 
void genBulletFunc_f700ef18cb2543cadbf8f5a5256a4e8e(FixedPointNum, FixedPointNum); 
void genBulletFunc_84c6fdff4c7605b653026925948c7148(FixedPointNum, FixedPointNum); 
void genBulletFunc_baa24048519e6ac92ef4a825be02bd7b(FixedPointNum, FixedPointNum); 
void genBulletFunc_3ce4bdcec1f779d04c6aa53122d8cabd(FixedPointNum, FixedPointNum); 
void genBulletFunc_ba72053026dfb1a5ee8ac4e26a64ff33(FixedPointNum, FixedPointNum); 
void genBulletFunc_87122448ec6df0d767ef71c25445c6fe(FixedPointNum, FixedPointNum); 
void genBulletFunc_7c04c8ddb4cc59ec98fcfa85b44b9f3b(FixedPointNum, FixedPointNum); 
void genBulletFunc_ee1ce5b7918235a33acb76d1768d16b8(FixedPointNum, FixedPointNum); 
void genBulletFunc_12acb97956d2d2e64bce021bd4d52c4b(FixedPointNum, FixedPointNum); 
void genBulletFunc_8e105821f987f05263cddee5d18d0f17(FixedPointNum, FixedPointNum); 
void genBulletFunc_7522d6bc61c86bf18c83dc71022a0e3a(FixedPointNum, FixedPointNum); 
void genBulletFunc_c9f77400f1af8612bb0971eb7fd23d81(FixedPointNum, FixedPointNum); 
void genBulletFunc_5f22d513e685dec43f037958f9df4526(FixedPointNum, FixedPointNum); 
void genBulletFunc_6b198a53e46dd5a9ae9c95b17978cac1(FixedPointNum, FixedPointNum); 
void genBulletFunc_04f2d3447ad6a60cb93761f53f824f9c(FixedPointNum, FixedPointNum); 
void genBulletFunc_966b5e3a47b35af13949f7f098192d53(FixedPointNum, FixedPointNum); 
void genBulletFunc_063f60ff52999f3ef4dcd603079d3ed6(FixedPointNum, FixedPointNum); 
void genBulletFunc_088d78ce9c4d0c8b9731ca6164bf5f45(FixedPointNum, FixedPointNum); 
void genBulletFunc_6a58f27f4c8f88ab6bf5124031d47b7d(FixedPointNum, FixedPointNum); 
void genBulletFunc_b4af424c733d0893b63852d0b177e45e(FixedPointNum, FixedPointNum); 
void genBulletFunc_b408189c86cb3fff44ded7d6fb37f1c3(FixedPointNum, FixedPointNum); 
void genBulletFunc_cbe8c85d45047f76af83c300b2c43635(FixedPointNum, FixedPointNum); 
void genBulletFunc_5c6f3a7287741774ecf1789cbd3b4182(FixedPointNum, FixedPointNum); 
void genBulletFunc_2e744d6cf664d5d5dd26fa37314a268f(FixedPointNum, FixedPointNum); 
void genBulletFunc_7906827b2cbab9249f1c1739b9e180c0(FixedPointNum, FixedPointNum); 
void genBulletFunc_62f61c50105329b76fb757a0e3192165(FixedPointNum, FixedPointNum); 
void genBulletFunc_e573dfcbe939f3d9d82c31155e82fb3b(FixedPointNum, FixedPointNum); 
void genBulletFunc_304f30b475c3860a2217a3a12206354e(FixedPointNum, FixedPointNum); 
void genBulletFunc_53c13894eae8edf5506d14ddfc5e8ca0(FixedPointNum, FixedPointNum); 
void genBulletFunc_85eeda4eace880b8e329efcf1292109c(FixedPointNum, FixedPointNum); 
void genBulletFunc_5aed262dedd00908faa5c8f94a1d6502(FixedPointNum, FixedPointNum); 
void genBulletFunc_0b3c637bdc5e779e2bb21428ce9678ef(FixedPointNum, FixedPointNum); 
void genBulletFunc_515f6916f9e44cb2756bcbe1dfdc8cf0(FixedPointNum, FixedPointNum); 
void genBulletFunc_166534cf168e8b836ac3e870ea6569b4(FixedPointNum, FixedPointNum); 
void genBulletFunc_26ac35c0676d1df8e7d09766c7598fd1(FixedPointNum, FixedPointNum); 
void genBulletFunc_6c91af4c9dee2a3d569c4993b91e9d96(FixedPointNum, FixedPointNum); 
void genBulletFunc_a31962fe52d720689b3dd12bbeeeb803(FixedPointNum, FixedPointNum); 
void genBulletFunc_e2c43bcad49d54b79b5ee9290a001562(FixedPointNum, FixedPointNum); 
void genBulletFunc_e943dc47df78934e82183460e3af54f9(FixedPointNum, FixedPointNum); 
void genBulletFunc_82ab405be2a9c242c7f32fbaf0801b2e(FixedPointNum, FixedPointNum); 
void genBulletFunc_824fc8bed22ea707ec3f888b92fac0b0(FixedPointNum, FixedPointNum); 
void genBulletFunc_a983a30a9e511187154a54717c0143ea(FixedPointNum, FixedPointNum); 
void genBulletFunc_6ccd7c3646ac0a28d28cff4ff6d6663a(FixedPointNum, FixedPointNum); 
void genBulletFunc_678552a9c843e4bbefa5595ee3896ade(FixedPointNum, FixedPointNum); 
void genBulletFunc_f82916e91b844aa7200eeaebbd9b25c8(FixedPointNum, FixedPointNum); 
void genBulletFunc_787632bc0978ee85cd7e72568d477922(FixedPointNum, FixedPointNum); 
void genBulletFunc_31f7d852540ff65e2a09f118d80bb291(FixedPointNum, FixedPointNum); 
void genBulletFunc_f19cda06e1325845d5e3f1c33ee5df51(FixedPointNum, FixedPointNum); 
void genBulletFunc_054304476395db4730d32082eb1547d5(FixedPointNum, FixedPointNum); 
void genBulletFunc_b745da1e97fe21aaba580867de0b09d6(FixedPointNum, FixedPointNum); 
void genBulletFunc_49c777a07e5ff5012ab8673422373223(FixedPointNum, FixedPointNum); 
void genBulletFunc_ff5d676f0146ba5d96a2ec30cb82728b(FixedPointNum, FixedPointNum); 
void genBulletFunc_04db868b07ae624fec8214f68ad240c3(FixedPointNum, FixedPointNum); 
void genBulletFunc_cdae837fce0bbbb51c4fb751ecb58d59(FixedPointNum, FixedPointNum); 
void genBulletFunc_aeda02d2842247faab6ce97e63b143b9(FixedPointNum, FixedPointNum); 
void genBulletFunc_ee86adac8dc14e80ab23623426f8977c(FixedPointNum, FixedPointNum); 
void genBulletFunc_fd48d3c6b8f3482811b47d8555006071(FixedPointNum, FixedPointNum); 
void genBulletFunc_3f087fd3b8a03665e7ef101f9c2b8023(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_original[] = { 
genBulletFunc_0da31e2f3027b772f92c415b826e5dda, 
genBulletFunc_b44dbec62b2b86f34cb4657c468eea7c, 
genBulletFunc_526555bad717a27ce6ac8e64de6be89f, 
genBulletFunc_f700ef18cb2543cadbf8f5a5256a4e8e, 
genBulletFunc_84c6fdff4c7605b653026925948c7148, 
genBulletFunc_baa24048519e6ac92ef4a825be02bd7b, 
genBulletFunc_3ce4bdcec1f779d04c6aa53122d8cabd, 
genBulletFunc_ba72053026dfb1a5ee8ac4e26a64ff33, 
genBulletFunc_87122448ec6df0d767ef71c25445c6fe, 
genBulletFunc_7c04c8ddb4cc59ec98fcfa85b44b9f3b, 
genBulletFunc_ee1ce5b7918235a33acb76d1768d16b8, 
genBulletFunc_12acb97956d2d2e64bce021bd4d52c4b, 
genBulletFunc_8e105821f987f05263cddee5d18d0f17, 
genBulletFunc_7522d6bc61c86bf18c83dc71022a0e3a, 
genBulletFunc_c9f77400f1af8612bb0971eb7fd23d81, 
genBulletFunc_5f22d513e685dec43f037958f9df4526, 
genBulletFunc_6b198a53e46dd5a9ae9c95b17978cac1, 
genBulletFunc_04f2d3447ad6a60cb93761f53f824f9c, 
genBulletFunc_966b5e3a47b35af13949f7f098192d53, 
genBulletFunc_063f60ff52999f3ef4dcd603079d3ed6, 
genBulletFunc_088d78ce9c4d0c8b9731ca6164bf5f45, 
genBulletFunc_6a58f27f4c8f88ab6bf5124031d47b7d, 
genBulletFunc_b4af424c733d0893b63852d0b177e45e, 
genBulletFunc_b408189c86cb3fff44ded7d6fb37f1c3, 
genBulletFunc_cbe8c85d45047f76af83c300b2c43635, 
genBulletFunc_5c6f3a7287741774ecf1789cbd3b4182, 
genBulletFunc_2e744d6cf664d5d5dd26fa37314a268f, 
genBulletFunc_7906827b2cbab9249f1c1739b9e180c0, 
genBulletFunc_62f61c50105329b76fb757a0e3192165, 
genBulletFunc_e573dfcbe939f3d9d82c31155e82fb3b, 
genBulletFunc_304f30b475c3860a2217a3a12206354e, 
genBulletFunc_53c13894eae8edf5506d14ddfc5e8ca0, 
genBulletFunc_85eeda4eace880b8e329efcf1292109c, 
genBulletFunc_5aed262dedd00908faa5c8f94a1d6502, 
genBulletFunc_0b3c637bdc5e779e2bb21428ce9678ef, 
genBulletFunc_515f6916f9e44cb2756bcbe1dfdc8cf0, 
genBulletFunc_166534cf168e8b836ac3e870ea6569b4, 
genBulletFunc_26ac35c0676d1df8e7d09766c7598fd1, 
genBulletFunc_6c91af4c9dee2a3d569c4993b91e9d96, 
genBulletFunc_a31962fe52d720689b3dd12bbeeeb803, 
genBulletFunc_e2c43bcad49d54b79b5ee9290a001562, 
genBulletFunc_e943dc47df78934e82183460e3af54f9, 
genBulletFunc_82ab405be2a9c242c7f32fbaf0801b2e, 
genBulletFunc_824fc8bed22ea707ec3f888b92fac0b0, 
genBulletFunc_a983a30a9e511187154a54717c0143ea, 
genBulletFunc_6ccd7c3646ac0a28d28cff4ff6d6663a, 
genBulletFunc_678552a9c843e4bbefa5595ee3896ade, 
genBulletFunc_f82916e91b844aa7200eeaebbd9b25c8, 
genBulletFunc_787632bc0978ee85cd7e72568d477922, 
genBulletFunc_31f7d852540ff65e2a09f118d80bb291, 
genBulletFunc_f19cda06e1325845d5e3f1c33ee5df51, 
genBulletFunc_054304476395db4730d32082eb1547d5, 
genBulletFunc_b745da1e97fe21aaba580867de0b09d6, 
genBulletFunc_49c777a07e5ff5012ab8673422373223, 
genBulletFunc_ff5d676f0146ba5d96a2ec30cb82728b, 
genBulletFunc_04db868b07ae624fec8214f68ad240c3, 
genBulletFunc_cdae837fce0bbbb51c4fb751ecb58d59, 
genBulletFunc_aeda02d2842247faab6ce97e63b143b9, 
genBulletFunc_ee86adac8dc14e80ab23623426f8977c, 
genBulletFunc_fd48d3c6b8f3482811b47d8555006071, 
genBulletFunc_3f087fd3b8a03665e7ef101f9c2b8023, 
}; 

static const char *listBulletNames_original[] = { 
"- accusation", 
"- air_elemental", 
"- aja3", 
"- backfire", 
"- balloon_bomb", 
"- btb_1", 
"- btb_2", 
"- btb_3", 
"- btb_4", 
"- btb_5", 
"- btb_6", 
"- censored", 
"- chimera", 
"- circle", 
"- dandecrazy", 
"- dokkaan", 
"- ellipse_bomb", 
"- entangled_space", 
"- eternal", 
"- evil_eye", 
"- extinction", 
"- fujin_ranbu_fake", 
"- fujin_ranbu_true", 
"- goku", 
"- guruguru", 
"- gurutyo", 
"- gyakuhunsya", 
"- hajike", 
"- hasami", 
"- hirahira", 
"- housya", 
"- iciclenorm", 
"- kagome", 
"- kedama", 
"- knight_1", 
"- knight_2", 
"- knight_3", 
"- knight_4", 
"- kokusi", 
"- kotai", 
"- kujira", 
"- nbird", 
"- oogi_hutatsu", 
"- optic_seeker", 
"- pan", 
"- progear_cheap_fake", 
"- sakuretudan", 
"- senkosinen", 
"- shooting_star", 
"- sikigami5boss2", 
"- spidercat", 
"- star_in_the_sky", 
"- stone6", 
"- time_twist", 
"- tsunami", 
"- two_cross", 
"- uneri", 
"- unilateral", 
"- wana", 
"- water_max", 
"- zako_atack", 
}; 

void genBulletFunc_8209009d12b99144cbb738942bdd2e92(FixedPointNum, FixedPointNum); 
void genBulletFunc_439c1fd102aafc34114001e70cc098e4(FixedPointNum, FixedPointNum); 
void genBulletFunc_a895bfa7f4abda02a4a7b7cefe25880b(FixedPointNum, FixedPointNum); 
void genBulletFunc_2a5b53cf4a91b0ed8ce425ce3b27bf54(FixedPointNum, FixedPointNum); 
void genBulletFunc_a8d45d83cd82ff7b58b026289f02ec31(FixedPointNum, FixedPointNum); 
void genBulletFunc_a138b8adb748c0a01f4cfb4316cb6de0(FixedPointNum, FixedPointNum); 
void genBulletFunc_23aa4094f4b093b4006e386ed6704165(FixedPointNum, FixedPointNum); 
void genBulletFunc_bdda80179c2aecc6b03ea1bfd7b21fe4(FixedPointNum, FixedPointNum); 
void genBulletFunc_571c6cec5f50063a04343c93622d18e0(FixedPointNum, FixedPointNum); 
void genBulletFunc_62c8cf18db1a2f5deea5be6982682736(FixedPointNum, FixedPointNum); 
void genBulletFunc_d01c89e2e47ae155913320765cde4918(FixedPointNum, FixedPointNum); 
void genBulletFunc_b64cde9889ca052221223c8156ba0b0f(FixedPointNum, FixedPointNum); 
void genBulletFunc_b99a295bf9a1ad70f9d77289ef618984(FixedPointNum, FixedPointNum); 
void genBulletFunc_ddd5ccc571c59139bcdd5d904219aa0b(FixedPointNum, FixedPointNum); 
void genBulletFunc_2fa969eb96f21bcfd1993be700d4a1a9(FixedPointNum, FixedPointNum); 
void genBulletFunc_212728316761d2b29e56d79e0d0a4b40(FixedPointNum, FixedPointNum); 
void genBulletFunc_8a46beb9a499a80ca6da63154bb67cd5(FixedPointNum, FixedPointNum); 
void genBulletFunc_5f4134b2cd129f37d4da7471e40b6620(FixedPointNum, FixedPointNum); 
void genBulletFunc_608e90aa4eeb20aa378957a78c13c68e(FixedPointNum, FixedPointNum); 
void genBulletFunc_5f91261b15da0e9236858427539cbd6f(FixedPointNum, FixedPointNum); 
void genBulletFunc_d35b47229547a2b018558227dc6a025c(FixedPointNum, FixedPointNum); 
void genBulletFunc_3dffec8f6a5e3f9f9c7ddd8a7aa025d0(FixedPointNum, FixedPointNum); 
void genBulletFunc_5e1cabfb623d6899cfd0e8318603e0f1(FixedPointNum, FixedPointNum); 
void genBulletFunc_97aa0fe39ec405d10d3b952528927fac(FixedPointNum, FixedPointNum); 
void genBulletFunc_a6d5bb33187ce8ba0fddeb84413586f2(FixedPointNum, FixedPointNum); 
void genBulletFunc_211870273682e98b27fe9860e549f55d(FixedPointNum, FixedPointNum); 
void genBulletFunc_c05c4b846fdfae2c41bebf0ca5935fe9(FixedPointNum, FixedPointNum); 
void genBulletFunc_8c97c234ebb54e46e87f2f1565f8c29e(FixedPointNum, FixedPointNum); 
void genBulletFunc_398b085dc18d7091be3d4a94988fc738(FixedPointNum, FixedPointNum); 
void genBulletFunc_ced0f8dee35035babebeb62710b14290(FixedPointNum, FixedPointNum); 
void genBulletFunc_8bc72083ba7198d43f8ed151e75f545b(FixedPointNum, FixedPointNum); 
void genBulletFunc_85add43fa08c6bfc414f8b71e638f7d7(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_otakutwo[] = { 
genBulletFunc_8209009d12b99144cbb738942bdd2e92, 
genBulletFunc_439c1fd102aafc34114001e70cc098e4, 
genBulletFunc_a895bfa7f4abda02a4a7b7cefe25880b, 
genBulletFunc_2a5b53cf4a91b0ed8ce425ce3b27bf54, 
genBulletFunc_a8d45d83cd82ff7b58b026289f02ec31, 
genBulletFunc_a138b8adb748c0a01f4cfb4316cb6de0, 
genBulletFunc_23aa4094f4b093b4006e386ed6704165, 
genBulletFunc_bdda80179c2aecc6b03ea1bfd7b21fe4, 
genBulletFunc_571c6cec5f50063a04343c93622d18e0, 
genBulletFunc_62c8cf18db1a2f5deea5be6982682736, 
genBulletFunc_d01c89e2e47ae155913320765cde4918, 
genBulletFunc_b64cde9889ca052221223c8156ba0b0f, 
genBulletFunc_b99a295bf9a1ad70f9d77289ef618984, 
genBulletFunc_ddd5ccc571c59139bcdd5d904219aa0b, 
genBulletFunc_2fa969eb96f21bcfd1993be700d4a1a9, 
genBulletFunc_212728316761d2b29e56d79e0d0a4b40, 
genBulletFunc_8a46beb9a499a80ca6da63154bb67cd5, 
genBulletFunc_5f4134b2cd129f37d4da7471e40b6620, 
genBulletFunc_608e90aa4eeb20aa378957a78c13c68e, 
genBulletFunc_5f91261b15da0e9236858427539cbd6f, 
genBulletFunc_d35b47229547a2b018558227dc6a025c, 
genBulletFunc_3dffec8f6a5e3f9f9c7ddd8a7aa025d0, 
genBulletFunc_5e1cabfb623d6899cfd0e8318603e0f1, 
genBulletFunc_97aa0fe39ec405d10d3b952528927fac, 
genBulletFunc_a6d5bb33187ce8ba0fddeb84413586f2, 
genBulletFunc_211870273682e98b27fe9860e549f55d, 
genBulletFunc_c05c4b846fdfae2c41bebf0ca5935fe9, 
genBulletFunc_8c97c234ebb54e46e87f2f1565f8c29e, 
genBulletFunc_398b085dc18d7091be3d4a94988fc738, 
genBulletFunc_ced0f8dee35035babebeb62710b14290, 
genBulletFunc_8bc72083ba7198d43f8ed151e75f545b, 
genBulletFunc_85add43fa08c6bfc414f8b71e638f7d7, 
}; 

static const char *listBulletNames_otakutwo[] = { 
"- circle_fireworks", 
"- circle_fireworks2", 
"- circle_roll", 
"- circle_trap", 
"- dis_bee_1", 
"- dis_bee_2", 
"- dis_bee_hakkyou", 
"- mushihime_ultra5midb", 
"- otk2-doom", 
"- otk2-forgotten1", 
"- otk2-hanabi", 
"- otk2-hidden", 
"- restriction_stasis", 
"- roll_misago", 
"- self-0012", 
"- self-0034", 
"- self-0036", 
"- self-0062", 
"- self-0063", 
"- self-0071", 
"- self-1010", 
"- self-1011", 
"- self-1020", 
"- self-1021", 
"- self-1022", 
"- self-2010", 
"- self-2011", 
"- self-2020", 
"- self-3020", 
"- self-3021", 
"- self-mis02", 
"- slow_move", 
}; 

void genBulletFunc_3b5cfdec6ef57720d3281dac727d8a73(FixedPointNum, FixedPointNum); 
void genBulletFunc_f97912752dcec024056e0e3a2d4af247(FixedPointNum, FixedPointNum); 
void genBulletFunc_14cc3234507e5204963436ed1e480621(FixedPointNum, FixedPointNum); 
void genBulletFunc_0aea836693ce4cf4a450551a49e4d927(FixedPointNum, FixedPointNum); 
void genBulletFunc_11d0572a5be6d4d2ef1b5bdfe40ce9e6(FixedPointNum, FixedPointNum); 
void genBulletFunc_0fa8595ef545e3a73b227efab34c2dbe(FixedPointNum, FixedPointNum); 
void genBulletFunc_864de2eaa571ffb87ac03e2547d30f97(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_progear[] = { 
genBulletFunc_3b5cfdec6ef57720d3281dac727d8a73, 
genBulletFunc_f97912752dcec024056e0e3a2d4af247, 
genBulletFunc_14cc3234507e5204963436ed1e480621, 
genBulletFunc_0aea836693ce4cf4a450551a49e4d927, 
genBulletFunc_11d0572a5be6d4d2ef1b5bdfe40ce9e6, 
genBulletFunc_0fa8595ef545e3a73b227efab34c2dbe, 
genBulletFunc_864de2eaa571ffb87ac03e2547d30f97, 
}; 

static const char *listBulletNames_progear[] = { 
"- round_10_boss_before", 
"- round_1_boss_grow_bu", 
"- round_2_boss_struggl", 
"- round_3_boss_wave_bu", 
"- round_5_boss_last_ro", 
"- round_5_middle_boss_", 
"- round_9_boss", 
}; 

void genBulletFunc_9b7fe0bd1aade6e478c9ba05edbb32cd(FixedPointNum, FixedPointNum); 
void genBulletFunc_1534a5a36264742c24e860cd68365b08(FixedPointNum, FixedPointNum); 
void genBulletFunc_a749a8afb3b9290182f718da7926ba76(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_psyvariar[] = { 
genBulletFunc_9b7fe0bd1aade6e478c9ba05edbb32cd, 
genBulletFunc_1534a5a36264742c24e860cd68365b08, 
genBulletFunc_a749a8afb3b9290182f718da7926ba76, 
}; 

static const char *listBulletNames_psyvariar[] = { 
"- 4-d_boss_mziq", 
"- x-a_boss_opening", 
"- x-a_boss_winder", 
}; 

void genBulletFunc_9977f0e26eca83e388ddce37d0f9723a(FixedPointNum, FixedPointNum); 
void genBulletFunc_237f6e0284685d6720998145dff44980(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_seiho[] = { 
genBulletFunc_9977f0e26eca83e388ddce37d0f9723a, 
genBulletFunc_237f6e0284685d6720998145dff44980, 
}; 

static const char *listBulletNames_seiho[] = { 
"- syusogyoku_exreimu_3", 
"- syusogyoku_exreimu_f", 
}; 

void genBulletFunc_d052cba2cf63e24d1b0eefaed94b609b(FixedPointNum, FixedPointNum); 
void genBulletFunc_6231f76d00374aa65c2905853983c3e1(FixedPointNum, FixedPointNum); 
void genBulletFunc_29d5de7ce6895fd35007993beaa2dcad(FixedPointNum, FixedPointNum); 
void genBulletFunc_a0c65070336f057cddc047d7ab471d1a(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_shinichiro_h[] = { 
genBulletFunc_d052cba2cf63e24d1b0eefaed94b609b, 
genBulletFunc_6231f76d00374aa65c2905853983c3e1, 
genBulletFunc_29d5de7ce6895fd35007993beaa2dcad, 
genBulletFunc_a0c65070336f057cddc047d7ab471d1a, 
}; 

static const char *listBulletNames_shinichiro_h[] = { 
"- original_bluff", 
"- original_flower", 
"- original_no_bluff", 
"- original_uzuga", 
}; 

void genBulletFunc_948070fa84b86d5dead36e488a7960b6(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_silvergun[] = { 
genBulletFunc_948070fa84b86d5dead36e488a7960b6, 
}; 

static const char *listBulletNames_silvergun[] = { 
"- 4d_boss_penta", 
}; 

void genBulletFunc_f656953a443b25ad58edbea7fc6194c3(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_storm_calibar[] = { 
genBulletFunc_f656953a443b25ad58edbea7fc6194c3, 
}; 

static const char *listBulletNames_storm_calibar[] = { 
"- last_boss_double_rol", 
}; 

void genBulletFunc_ca9bfa1c9b8c3ba9968a9e2100e3c9a6(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_strikers1999[] = { 
genBulletFunc_ca9bfa1c9b8c3ba9968a9e2100e3c9a6, 
}; 

static const char *listBulletNames_strikers1999[] = { 
"- hanabi", 
}; 

void genBulletFunc_607cbe61726dd0f19d985d6de791c202(FixedPointNum, FixedPointNum); 
void genBulletFunc_599f386a5184f9d204fc27e71dd21206(FixedPointNum, FixedPointNum); 
void genBulletFunc_1b7e354019aaae1c0f5fd693c17983f9(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_tenmado[] = { 
genBulletFunc_607cbe61726dd0f19d985d6de791c202, 
genBulletFunc_599f386a5184f9d204fc27e71dd21206, 
genBulletFunc_1b7e354019aaae1c0f5fd693c17983f9, 
}; 

static const char *listBulletNames_tenmado[] = { 
"- 3_boss_2", 
"- 5_boss_1", 
"- 5_boss_3", 
}; 

void genBulletFunc_b0115792693451f1b0019a70da665614(FixedPointNum, FixedPointNum); 
void genBulletFunc_bcb81c8e9f78aeb9ae0864b00adb1ba9(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_toho[] = { 
genBulletFunc_b0115792693451f1b0019a70da665614, 
genBulletFunc_bcb81c8e9f78aeb9ae0864b00adb1ba9, 
}; 

static const char *listBulletNames_toho[] = { 
"- yomu-bungaku-nise", 
"- youmu_hououtenshi_lu", 
}; 

void genBulletFunc_1c5db90e1aa57a8ad7d41913e20a872a(FixedPointNum, FixedPointNum); 
void genBulletFunc_2f3c3182b4dc212d7b2473c7bc749169(FixedPointNum, FixedPointNum); 
void genBulletFunc_f2d3a4d65ecadde74dc447798842dcd8(FixedPointNum, FixedPointNum); 
void genBulletFunc_c32cdd0beb253d82279cdf73c7393e2b(FixedPointNum, FixedPointNum); 
void genBulletFunc_2537698eac11c082007c464ef41a8efa(FixedPointNum, FixedPointNum); 
void genBulletFunc_e86fa611c61e1cd7ab55716328a3d91d(FixedPointNum, FixedPointNum); 
void genBulletFunc_dfbbe0cc7b71b534de16295c2238563a(FixedPointNum, FixedPointNum); 
void genBulletFunc_1149f116b0a988d47aa6550165fedf28(FixedPointNum, FixedPointNum); 
void genBulletFunc_17548fe11dbe2378b60738f0f1365da1(FixedPointNum, FixedPointNum); 
void genBulletFunc_a44897ca7e8e6ee7532f44d02a34ab1b(FixedPointNum, FixedPointNum); 
void genBulletFunc_3caa604825bdbe6232d3b649682cbb4b(FixedPointNum, FixedPointNum); 
void genBulletFunc_4d54b99f228d34c6a3214beb383bfd68(FixedPointNum, FixedPointNum); 
void genBulletFunc_5f629037eb4406baad41ea314056b759(FixedPointNum, FixedPointNum); 
void genBulletFunc_342716fb0ab5a7cebb61f2792f3809eb(FixedPointNum, FixedPointNum); 
void genBulletFunc_8feb267b299d391c6e296ee211d4bbf8(FixedPointNum, FixedPointNum); 
void genBulletFunc_262e2b98fa981a25d3d0165580487e9e(FixedPointNum, FixedPointNum); 
void genBulletFunc_a606f01d6fe30ab0973549b9b1d1838d(FixedPointNum, FixedPointNum); 
void genBulletFunc_b9d043a64aceec96f59ebcf37a2363f7(FixedPointNum, FixedPointNum); 
void genBulletFunc_f917950c540d69b2ce49e994ea879638(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_user[] = { 
genBulletFunc_1c5db90e1aa57a8ad7d41913e20a872a, 
genBulletFunc_2f3c3182b4dc212d7b2473c7bc749169, 
genBulletFunc_f2d3a4d65ecadde74dc447798842dcd8, 
genBulletFunc_c32cdd0beb253d82279cdf73c7393e2b, 
genBulletFunc_2537698eac11c082007c464ef41a8efa, 
genBulletFunc_e86fa611c61e1cd7ab55716328a3d91d, 
genBulletFunc_dfbbe0cc7b71b534de16295c2238563a, 
genBulletFunc_1149f116b0a988d47aa6550165fedf28, 
genBulletFunc_17548fe11dbe2378b60738f0f1365da1, 
genBulletFunc_a44897ca7e8e6ee7532f44d02a34ab1b, 
genBulletFunc_3caa604825bdbe6232d3b649682cbb4b, 
genBulletFunc_4d54b99f228d34c6a3214beb383bfd68, 
genBulletFunc_5f629037eb4406baad41ea314056b759, 
genBulletFunc_342716fb0ab5a7cebb61f2792f3809eb, 
genBulletFunc_8feb267b299d391c6e296ee211d4bbf8, 
genBulletFunc_262e2b98fa981a25d3d0165580487e9e, 
genBulletFunc_a606f01d6fe30ab0973549b9b1d1838d, 
genBulletFunc_b9d043a64aceec96f59ebcf37a2363f7, 
genBulletFunc_f917950c540d69b2ce49e994ea879638, 
}; 

static const char *listBulletNames_user[] = { 
"- danmaku-wall", 
"- danmakuart_togenomab", 
"- danmakuart_wing_of_p", 
"- espg2_4wehha_last", 
"- espg2_5ikare_hidarit", 
"- espg2_5keshitobe", 
"- hunsui", 
"- katam", 
"- ketsui_4boss_pack", 
"- ketsui_5middleboss_f", 
"- ketsui_doom2", 
"- ketsui_doom6", 
"- ketsui_doom_final", 
"- mou_test1", 
"- move_winder", 
"- notflower", 
"- senkoro_burstballa", 
"- test", 
"- tidoriasi", 
}; 

void genBulletFunc_cf4971c6c64fffa461a3c9d1fa7afe24(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_xevious[] = { 
genBulletFunc_cf4971c6c64fffa461a3c9d1fa7afe24, 
}; 

static const char *listBulletNames_xevious[] = { 
"- garu_zakato", 
}; 

void genBulletFunc_2b1ce1ae9e66fb64478306a082ed09ba(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_xii_stag[] = { 
genBulletFunc_2b1ce1ae9e66fb64478306a082ed09ba, 
}; 

static const char *listBulletNames_xii_stag[] = { 
"- 3b", 
}; 

void genBulletFunc_9d32276a9219bbdf02cfeba1e1302f74(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_xin[] = { 
genBulletFunc_9d32276a9219bbdf02cfeba1e1302f74, 
}; 

static const char *listBulletNames_xin[] = { 
"- 04b", 
}; 

void genBulletFunc_66106ace9263b71d4eff02df277ef3c1(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_xsoldier[] = { 
genBulletFunc_66106ace9263b71d4eff02df277ef3c1, 
}; 

static const char *listBulletNames_xsoldier[] = { 
"- 8_boss_main", 
}; 

void genBulletFunc_623c2a951b80c07695d7cad2448421d3(FixedPointNum, FixedPointNum); 

static const BulletGenerateFunc listBulletFuncs_yutchi[] = { 
genBulletFunc_623c2a951b80c07695d7cad2448421d3, 
}; 

static const char *listBulletNames_yutchi[] = { 
"- ytbullet016", 
}; 

static const char *listBulletGroups[] = {
"= Bulletgba", 
"= Bulletsmorph", 
"= Bwda", 
"= Chaosseed", 
"= Daiouzyou", 
"= Dodonpachi", 
"= Dragonblaze", 
"= Esp_galuda_lt", 
"= Esp_rade", 
"= G-wange", 
"= G_darius", 
"= Garegga", 
"= Gigawing2", 
"= Guwange", 
"= Ketui_lt", 
"= Kotuanzenx", 
"= Mda", 
"= Misc", 
"= Noiz2sa", 
"= Oohara", 
"= Original", 
"= Otakutwo", 
"= Progear", 
"= Psyvariar", 
"= Seiho", 
"= Shinichiro_h", 
"= Silvergun", 
"= Storm_calibar", 
"= Strikers1999", 
"= Tenmado", 
"= Toho", 
"= User", 
"= Xevious", 
"= Xii_stag", 
"= Xin", 
"= Xsoldier", 
"= Yutchi", 
}; 

static const int listBulletGroupsSize = 37; 

static const BulletGenerateFunc *listBulletGroupsFuncs[] = {
listBulletFuncs_bulletgba, 
listBulletFuncs_bulletsmorph, 
listBulletFuncs_bwda, 
listBulletFuncs_chaosseed, 
listBulletFuncs_daiouzyou, 
listBulletFuncs_dodonpachi, 
listBulletFuncs_dragonblaze, 
listBulletFuncs_esp_galuda_lt, 
listBulletFuncs_esp_rade, 
listBulletFuncs_g_wange, 
listBulletFuncs_g_darius, 
listBulletFuncs_garegga, 
listBulletFuncs_gigawing2, 
listBulletFuncs_guwange, 
listBulletFuncs_ketui_lt, 
listBulletFuncs_kotuanzenx, 
listBulletFuncs_mda, 
listBulletFuncs_misc, 
listBulletFuncs_noiz2sa, 
listBulletFuncs_oohara, 
listBulletFuncs_original, 
listBulletFuncs_otakutwo, 
listBulletFuncs_progear, 
listBulletFuncs_psyvariar, 
listBulletFuncs_seiho, 
listBulletFuncs_shinichiro_h, 
listBulletFuncs_silvergun, 
listBulletFuncs_storm_calibar, 
listBulletFuncs_strikers1999, 
listBulletFuncs_tenmado, 
listBulletFuncs_toho, 
listBulletFuncs_user, 
listBulletFuncs_xevious, 
listBulletFuncs_xii_stag, 
listBulletFuncs_xin, 
listBulletFuncs_xsoldier, 
listBulletFuncs_yutchi, 
}; 

const char **listBulletGroupsNames[] = {
listBulletNames_bulletgba, 
listBulletNames_bulletsmorph, 
listBulletNames_bwda, 
listBulletNames_chaosseed, 
listBulletNames_daiouzyou, 
listBulletNames_dodonpachi, 
listBulletNames_dragonblaze, 
listBulletNames_esp_galuda_lt, 
listBulletNames_esp_rade, 
listBulletNames_g_wange, 
listBulletNames_g_darius, 
listBulletNames_garegga, 
listBulletNames_gigawing2, 
listBulletNames_guwange, 
listBulletNames_ketui_lt, 
listBulletNames_kotuanzenx, 
listBulletNames_mda, 
listBulletNames_misc, 
listBulletNames_noiz2sa, 
listBulletNames_oohara, 
listBulletNames_original, 
listBulletNames_otakutwo, 
listBulletNames_progear, 
listBulletNames_psyvariar, 
listBulletNames_seiho, 
listBulletNames_shinichiro_h, 
listBulletNames_silvergun, 
listBulletNames_storm_calibar, 
listBulletNames_strikers1999, 
listBulletNames_tenmado, 
listBulletNames_toho, 
listBulletNames_user, 
listBulletNames_xevious, 
listBulletNames_xii_stag, 
listBulletNames_xin, 
listBulletNames_xsoldier, 
listBulletNames_yutchi, 
}; 

const int listBulletGroupsNamesSize[] = {
3, 
12, 
9, 
1, 
22, 
5, 
1, 
9, 
12, 
5, 
1, 
1, 
1, 
3, 
3, 
39, 
29, 
1, 
4, 
14, 
61, 
32, 
7, 
3, 
2, 
4, 
1, 
1, 
1, 
3, 
2, 
19, 
1, 
1, 
1, 
1, 
1, 
}; 

