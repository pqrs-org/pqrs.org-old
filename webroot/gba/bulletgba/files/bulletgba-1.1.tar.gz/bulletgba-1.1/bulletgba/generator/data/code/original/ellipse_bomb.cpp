// XXX uniqID XXX 6b198a53e46dd5a9ae9c95b17978cac1 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p); 
static void stepfunc_c6352b69aad7ae6d449db499cb6edb29(BulletInfo *p); 
static void stepfunc_6df17069af5a291a7b0bbcb0c0e9fe36(BulletInfo *p); 
static void stepfunc_e75d2417135c595defffbca85f2c48a8(BulletInfo *p); 
static void stepfunc_92b417273d7c928b6289a50fb21135ab(BulletInfo *p); 
static void stepfunc_33c6918a05d72c1d3d265c747eb2a66d(BulletInfo *p); 
static void stepfunc_3a03794f8bd6249a101fcb5506df9e76(BulletInfo *p); 
static void stepfunc_75ebf3ceef810af54f4b30621e9e9784(BulletInfo *p); 
static void stepfunc_4c605a451fdca27e44c3d359cd4ff90d(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_dc67874200ef13ad9f9c8ba8e6e22104(BulletInfo *p); 
static void stepfunc_5141677ced7d93c881aca1376bc411b8(BulletInfo *p); 
static void stepfunc_774a00138abcee76a359ea42d37a6f32(BulletInfo *p); 
static void stepfunc_64a17a7c1f8ce60cd6e4f1dde9262cd5(BulletInfo *p); 
static void stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f(BulletInfo *p); 
static void stepfunc_7374132d16f77fdfe437e94831e36355(BulletInfo *p); 
static void stepfunc_b58e08659acf2dd9e4341bdec7a80900(BulletInfo *p); 
static void stepfunc_a64d8746cbd02702fb97cc75f502dd01(BulletInfo *p); 


static const BulletStepFunc bullet_9a05edf6b07b375306c7ca46e6a9a9ec[] = {
stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9,
stepfunc_c6352b69aad7ae6d449db499cb6edb29,
stepfunc_6df17069af5a291a7b0bbcb0c0e9fe36,
NULL}; 
static const BulletStepFunc bullet_370432c46b147eb14af0e032a49f2fe8[] = {
stepfunc_e75d2417135c595defffbca85f2c48a8,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_33c6918a05d72c1d3d265c747eb2a66d,
stepfunc_33c6918a05d72c1d3d265c747eb2a66d,
stepfunc_3a03794f8bd6249a101fcb5506df9e76,
stepfunc_75ebf3ceef810af54f4b30621e9e9784,
stepfunc_75ebf3ceef810af54f4b30621e9e9784,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_3a03794f8bd6249a101fcb5506df9e76,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_92b417273d7c928b6289a50fb21135ab,
stepfunc_33c6918a05d72c1d3d265c747eb2a66d,
stepfunc_33c6918a05d72c1d3d265c747eb2a66d,
stepfunc_3a03794f8bd6249a101fcb5506df9e76,
stepfunc_75ebf3ceef810af54f4b30621e9e9784,
stepfunc_75ebf3ceef810af54f4b30621e9e9784,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_4c605a451fdca27e44c3d359cd4ff90d,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_0bc2422f213c331feb8eeeabf1559d0c[] = {
stepfunc_dc67874200ef13ad9f9c8ba8e6e22104,
stepfunc_5141677ced7d93c881aca1376bc411b8,
stepfunc_774a00138abcee76a359ea42d37a6f32,
stepfunc_64a17a7c1f8ce60cd6e4f1dde9262cd5,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_a25db21586c1097f615fbd0675cec4de[] = {
stepfunc_7374132d16f77fdfe437e94831e36355,
stepfunc_b58e08659acf2dd9e4341bdec7a80900,
stepfunc_a64d8746cbd02702fb97cc75f502dd01,
NULL}; 
static void stepfunc_1c29c0423b1ce73b2dd9c8298b984f7f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(497, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(4, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 10; 
}
static void stepfunc_dc67874200ef13ad9f9c8ba8e6e22104(BulletInfo *p) { 
p->wait = 35; 
}
static void stepfunc_5141677ced7d93c881aca1376bc411b8(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_774a00138abcee76a359ea42d37a6f32(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_64a17a7c1f8ce60cd6e4f1dde9262cd5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(9955, 100));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 10; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_4c605a451fdca27e44c3d359cd4ff90d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(3, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0bc2422f213c331feb8eeeabf1559d0c;  }
}
}
static void stepfunc_75ebf3ceef810af54f4b30621e9e9784(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0bc2422f213c331feb8eeeabf1559d0c;  }
}
}
static void stepfunc_33c6918a05d72c1d3d265c747eb2a66d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0bc2422f213c331feb8eeeabf1559d0c;  }
}
}
static void stepfunc_92b417273d7c928b6289a50fb21135ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-3, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0bc2422f213c331feb8eeeabf1559d0c;  }
}
}
static void stepfunc_e75d2417135c595defffbca85f2c48a8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(355, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0bc2422f213c331feb8eeeabf1559d0c;  }
}
}
static void stepfunc_3a03794f8bd6249a101fcb5506df9e76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0bc2422f213c331feb8eeeabf1559d0c;  }
}
}
static void stepfunc_b1238107a2a5cb0b4a6d3bbc640397a9(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_c6352b69aad7ae6d449db499cb6edb29(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 15; 
}
static void stepfunc_6df17069af5a291a7b0bbcb0c0e9fe36(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_370432c46b147eb14af0e032a49f2fe8;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_7374132d16f77fdfe437e94831e36355(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(15288, 100) + FixedPointNum(1422, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9a05edf6b07b375306c7ca46e6a9a9ec;  }
}
p->wait = 40; 
}
static void stepfunc_b58e08659acf2dd9e4341bdec7a80900(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(10311, 100) - FixedPointNum(1422, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9a05edf6b07b375306c7ca46e6a9a9ec;  }
}
p->wait = 40; 
}
static void stepfunc_a64d8746cbd02702fb97cc75f502dd01(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(12088, 100) + FixedPointNum(1422, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9a05edf6b07b375306c7ca46e6a9a9ec;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_6b198a53e46dd5a9ae9c95b17978cac1(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_a25db21586c1097f615fbd0675cec4de; }}


