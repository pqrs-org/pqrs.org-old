// XXX uniqID XXX 87122448ec6df0d767ef71c25445c6fe XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_bbc45c26a46aea7481c075238476b8c6(BulletInfo *p); 
static void stepfunc_5d3b5b5cff394c6eff0b616ab2641f42(BulletInfo *p); 
static void stepfunc_432dbef940b1bcbec17909a0024329e1(BulletInfo *p); 
static void stepfunc_607c320e037191d914ad7c7685520c8d(BulletInfo *p); 
static void stepfunc_22da5409c6af9b97ac52ee19a24bc782(BulletInfo *p); 
static void stepfunc_4ac65590e7e146a5c7532b818b3f43dc(BulletInfo *p); 
static void stepfunc_15a49b3921d168e67acf93c51665747d(BulletInfo *p); 
static void stepfunc_2787fa474cf745dd393cfa79ae2acd98(BulletInfo *p); 
static void stepfunc_779c1bf8f977e0375f7ae443d591b4e1(BulletInfo *p); 
static void stepfunc_80b09eac6af7f7a1a9f854c6db9980d0(BulletInfo *p); 
static void stepfunc_c58971aaff0c7db9194ae07c2da3c479(BulletInfo *p); 
static void stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_d52e09f381baf6675905703481ba9a8a(BulletInfo *p); 
static void stepfunc_f2330ac0a031b6f0a32a0c76f367f19d(BulletInfo *p); 
static void stepfunc_73ff4f485a355cb24dac8e236e42c9e3(BulletInfo *p); 
static void stepfunc_0de5624849f904abe5d6885d87ecbdbb(BulletInfo *p); 
static void stepfunc_343c23591719b14ddd7ef1adedc15033(BulletInfo *p); 
static void stepfunc_c8fe708bb65e6caa17ce150e2261f058(BulletInfo *p); 
static void stepfunc_1a37ca2e6921ccc25558578c4644de3f(BulletInfo *p); 
static void stepfunc_4a148268601bcddae9619cab9b71ea1b(BulletInfo *p); 
static void stepfunc_f67e362b0ceab3e84852f9840f5fcea9(BulletInfo *p); 
static void stepfunc_eb30b95d88f8e5f868f290ea267bf71b(BulletInfo *p); 
static void stepfunc_2668983dd83b5916a67062cfe4adbc30(BulletInfo *p); 


static const BulletStepFunc bullet_c86f7c5fccfeed909533c720ec0082d7[] = {
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_bbc45c26a46aea7481c075238476b8c6,
stepfunc_5d3b5b5cff394c6eff0b616ab2641f42,
#if 0
stepfunc_432dbef940b1bcbec17909a0024329e1,
#endif
stepfunc_607c320e037191d914ad7c7685520c8d,
stepfunc_22da5409c6af9b97ac52ee19a24bc782,
#if 0
stepfunc_4ac65590e7e146a5c7532b818b3f43dc,
#endif
stepfunc_15a49b3921d168e67acf93c51665747d,
stepfunc_2787fa474cf745dd393cfa79ae2acd98,
#if 0
stepfunc_779c1bf8f977e0375f7ae443d591b4e1,
#endif
stepfunc_80b09eac6af7f7a1a9f854c6db9980d0,
stepfunc_c58971aaff0c7db9194ae07c2da3c479,
#if 0
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3754854b02e211668a793e4419772739[] = {
stepfunc_d52e09f381baf6675905703481ba9a8a,
#if 0
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d,
#endif
NULL}; 
static const BulletStepFunc bullet_7f45b724d9d5d2f275bdb12936cb983f[] = {
stepfunc_73ff4f485a355cb24dac8e236e42c9e3,
#if 0
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d,
#endif
NULL}; 
static const BulletStepFunc bullet_b701e098668127b2253b83de3e0c5391[] = {
stepfunc_0de5624849f904abe5d6885d87ecbdbb,
#if 0
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d,
#endif
NULL}; 
static const BulletStepFunc bullet_34973640719b9dfad5286d9aa3dc6708[] = {
stepfunc_343c23591719b14ddd7ef1adedc15033,
#if 0
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d,
#endif
NULL}; 
static const BulletStepFunc bullet_0ec47c9d3fb5cece867a0eb9efbe8b1f[] = {
stepfunc_c8fe708bb65e6caa17ce150e2261f058,
#if 0
stepfunc_1a37ca2e6921ccc25558578c4644de3f,
#endif
NULL}; 
static const BulletStepFunc bullet_01aa83274198e2c78883fb9c3d3cad15[] = {
stepfunc_4a148268601bcddae9619cab9b71ea1b,
#if 0
stepfunc_1a37ca2e6921ccc25558578c4644de3f,
#endif
NULL}; 
static const BulletStepFunc bullet_5dbf95752d439e586502f4923de937e8[] = {
stepfunc_f67e362b0ceab3e84852f9840f5fcea9,
#if 0
stepfunc_1a37ca2e6921ccc25558578c4644de3f,
#endif
NULL}; 
static const BulletStepFunc bullet_85fe57605300c1ee2e461b05a1845b60[] = {
stepfunc_eb30b95d88f8e5f868f290ea267bf71b,
#if 0
stepfunc_1a37ca2e6921ccc25558578c4644de3f,
#endif
NULL}; 
static const BulletStepFunc bullet_c726815670b532b4ff7023689b94cb0d[] = {
stepfunc_2668983dd83b5916a67062cfe4adbc30,
NULL}; 
static void stepfunc_1a37ca2e6921ccc25558578c4644de3f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((
    FixedPointNum(2133, 100) + FixedPointNum(284, 100) * (-FixedPointNum(71, 100) + FixedPointNum(142, 100) * FixedPointNum::random())
   ));    p->lastBulletSpeed = ((FixedPointNum(150, 100) * (FixedPointNum(90, 100) + FixedPointNum(40, 100) * FixedPointNum::random())));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_eb30b95d88f8e5f868f290ea267bf71b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(750, 100));    p->lastBulletSpeed = ((FixedPointNum(150, 100) * (FixedPointNum(90, 100) + FixedPointNum(40, 100) * FixedPointNum::random())));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 12; ++i) { 
stepfunc_1a37ca2e6921ccc25558578c4644de3f(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_85fe57605300c1ee2e461b05a1845b60;  }
}
}
static void stepfunc_f2330ac0a031b6f0a32a0c76f367f19d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((
    FixedPointNum(10) + FixedPointNum(284, 100) * (-FixedPointNum(71, 100) + FixedPointNum(142, 100) * FixedPointNum::random())
   ));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d52e09f381baf6675905703481ba9a8a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(750, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f67e362b0ceab3e84852f9840f5fcea9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (15);    p->lastBulletSpeed = ((FixedPointNum(150, 100) * (FixedPointNum(90, 100) + FixedPointNum(40, 100) * FixedPointNum::random())));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 12; ++i) { 
stepfunc_1a37ca2e6921ccc25558578c4644de3f(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_779c1bf8f977e0375f7ae443d591b4e1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5dbf95752d439e586502f4923de937e8;  }
}
}
static void stepfunc_73ff4f485a355cb24dac8e236e42c9e3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (5);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4a148268601bcddae9619cab9b71ea1b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2250, 100));    p->lastBulletSpeed = ((FixedPointNum(150, 100) * (FixedPointNum(90, 100) + FixedPointNum(40, 100) * FixedPointNum::random())));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 12; ++i) { 
stepfunc_1a37ca2e6921ccc25558578c4644de3f(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4ac65590e7e146a5c7532b818b3f43dc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_01aa83274198e2c78883fb9c3d3cad15;  }
}
}
static void stepfunc_0de5624849f904abe5d6885d87ecbdbb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(250, 100));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c8fe708bb65e6caa17ce150e2261f058(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (30);    p->lastBulletSpeed = ((FixedPointNum(150, 100) * (FixedPointNum(90, 100) + FixedPointNum(40, 100) * FixedPointNum::random())));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 12; ++i) { 
stepfunc_1a37ca2e6921ccc25558578c4644de3f(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_432dbef940b1bcbec17909a0024329e1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0ec47c9d3fb5cece867a0eb9efbe8b1f;  }
}
}
static void stepfunc_343c23591719b14ddd7ef1adedc15033(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 36; ++i) { 
stepfunc_f2330ac0a031b6f0a32a0c76f367f19d(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_bbc45c26a46aea7481c075238476b8c6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_34973640719b9dfad5286d9aa3dc6708;  }
}
p->wait = 3; 
}
static void stepfunc_5d3b5b5cff394c6eff0b616ab2641f42(BulletInfo *p) { 
for (u32 i = 0; i < 5; ++i) { 
stepfunc_432dbef940b1bcbec17909a0024329e1(p);}
p->wait = 3; 
}
static void stepfunc_607c320e037191d914ad7c7685520c8d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b701e098668127b2253b83de3e0c5391;  }
}
p->wait = 3; 
}
static void stepfunc_22da5409c6af9b97ac52ee19a24bc782(BulletInfo *p) { 
for (u32 i = 0; i < 5; ++i) { 
stepfunc_4ac65590e7e146a5c7532b818b3f43dc(p);}
p->wait = 3; 
}
static void stepfunc_15a49b3921d168e67acf93c51665747d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7f45b724d9d5d2f275bdb12936cb983f;  }
}
p->wait = 3; 
}
static void stepfunc_2787fa474cf745dd393cfa79ae2acd98(BulletInfo *p) { 
for (u32 i = 0; i < 5; ++i) { 
stepfunc_779c1bf8f977e0375f7ae443d591b4e1(p);}
p->wait = 3; 
}
static void stepfunc_80b09eac6af7f7a1a9f854c6db9980d0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3754854b02e211668a793e4419772739;  }
}
p->wait = 3; 
}
static void stepfunc_c58971aaff0c7db9194ae07c2da3c479(BulletInfo *p) { 
for (u32 i = 0; i < 5; ++i) { 
stepfunc_cfc5bc0266f202f310d57e2b2e4ae56c(p);}
p->wait = 3; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_2668983dd83b5916a67062cfe4adbc30(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_c86f7c5fccfeed909533c720ec0082d7;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_87122448ec6df0d767ef71c25445c6fe(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_c726815670b532b4ff7023689b94cb0d; }}


