// XXX uniqID XXX 063f60ff52999f3ef4dcd603079d3ed6 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p); 
static void stepfunc_bee0c0433fae57be95cce016f40c7c59(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p); 
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p); 
static void stepfunc_a59714e8824890cf85cbd4db0a2e9002(BulletInfo *p); 
static void stepfunc_8c2be1a8bfb56a21afe28d443fa94338(BulletInfo *p); 
static void stepfunc_6ae0e168422266a98ad7054ac1946add(BulletInfo *p); 
static void stepfunc_6ed7b9c7316b106894662d85324de074(BulletInfo *p); 
static void stepfunc_6f9224c03dc12b63223c014c42514fc0(BulletInfo *p); 
static void stepfunc_37ecaa860fe97b4647513b2cc38ffa40(BulletInfo *p); 
static void stepfunc_5ab6570a0d63b43823cc5b66ee4ed532(BulletInfo *p); 
static void stepfunc_3a0b70040e66b5a188bf1d47c1107ebf(BulletInfo *p); 
static void stepfunc_b7aa47505a1a4f70a252e67c66232b51(BulletInfo *p); 
static void stepfunc_0a8feeb50101685c1afab0bcd234c85d(BulletInfo *p); 
static void stepfunc_27a7d178e031084e3111b10ea45a5e9a(BulletInfo *p); 
static void stepfunc_ae50bd3ff2f77d1539719eef75d56a68(BulletInfo *p); 
static void stepfunc_c206d570d61250d7c5d07f173c7c4a6f(BulletInfo *p); 


static const BulletStepFunc bullet_747b09bd1466673b89a1c0417965765e[] = {
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_bee0c0433fae57be95cce016f40c7c59,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_e9555f68b1cdc1df0bb1fc637f839304[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_7e58eb18321df372dfffd217d5e0ec8b[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_a59714e8824890cf85cbd4db0a2e9002,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_d86ae0fa7d0576a44bcae8b95bf9e20b[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_6ae0e168422266a98ad7054ac1946add,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_3f68a88550c6ece4172e7d69d24b0677[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_6ed7b9c7316b106894662d85324de074,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_07b73a6e9cea693fcfc13fe4b730fdde[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_6f9224c03dc12b63223c014c42514fc0,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_1ba93b84dc631f462bfd4c1bde3d414e[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_37ecaa860fe97b4647513b2cc38ffa40,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_bf26bf755b093884a7807a3cedd6c1a4[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_5ab6570a0d63b43823cc5b66ee4ed532,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_f62276de2e4f2a1dd73565f93aff7a42[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_3a0b70040e66b5a188bf1d47c1107ebf,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_a10c4501812b5a44cb4fd1b46831fc3f[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_b7aa47505a1a4f70a252e67c66232b51,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_4d2bdf850ee6ee3379f4af7604539e53[] = {
stepfunc_95874c360a4c89e01fddd0381e0669e0,
stepfunc_0a8feeb50101685c1afab0bcd234c85d,
#if 0
stepfunc_8c2be1a8bfb56a21afe28d443fa94338,
#endif
NULL}; 
static const BulletStepFunc bullet_5ddbd1661115f0bea5a82691460fe01a[] = {
stepfunc_27a7d178e031084e3111b10ea45a5e9a,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_ae50bd3ff2f77d1539719eef75d56a68,
stepfunc_c206d570d61250d7c5d07f173c7c4a6f,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_8c2be1a8bfb56a21afe28d443fa94338(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_95874c360a4c89e01fddd0381e0669e0(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_a59714e8824890cf85cbd4db0a2e9002(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((-FixedPointNum(2022, 100)) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_6ae0e168422266a98ad7054ac1946add(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((-FixedPointNum(1011, 100)) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_6ed7b9c7316b106894662d85324de074(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((FixedPointNum(0) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_6f9224c03dc12b63223c014c42514fc0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((FixedPointNum(1011, 100) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_37ecaa860fe97b4647513b2cc38ffa40(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((FixedPointNum(2022, 100) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_5ab6570a0d63b43823cc5b66ee4ed532(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((-FixedPointNum(3034, 100)) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_3a0b70040e66b5a188bf1d47c1107ebf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((-FixedPointNum(1517, 100)) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random());    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_b7aa47505a1a4f70a252e67c66232b51(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((FixedPointNum(1517, 100) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_0a8feeb50101685c1afab0bcd234c85d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((FixedPointNum(3034, 100) - FixedPointNum(1066, 100) + FixedPointNum(2133, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_8c2be1a8bfb56a21afe28d443fa94338(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ae50bd3ff2f77d1539719eef75d56a68(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3034, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4d2bdf850ee6ee3379f4af7604539e53;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1517, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a10c4501812b5a44cb4fd1b46831fc3f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3f68a88550c6ece4172e7d69d24b0677;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1517, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f62276de2e4f2a1dd73565f93aff7a42;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3034, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bf26bf755b093884a7807a3cedd6c1a4;  }
}
p->wait = 7; 
}
static void stepfunc_c206d570d61250d7c5d07f173c7c4a6f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2022, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1ba93b84dc631f462bfd4c1bde3d414e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_07b73a6e9cea693fcfc13fe4b730fdde;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3f68a88550c6ece4172e7d69d24b0677;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d86ae0fa7d0576a44bcae8b95bf9e20b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2022, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7e58eb18321df372dfffd217d5e0ec8b;  }
}
p->wait = 7; 
}
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_bee0c0433fae57be95cce016f40c7c59(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = ((FixedPointNum(0, 100) + FixedPointNum(12) * FixedPointNum::random()));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e9555f68b1cdc1df0bb1fc637f839304;  }
}
}
static void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_27a7d178e031084e3111b10ea45a5e9a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(2, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_747b09bd1466673b89a1c0417965765e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(6, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_747b09bd1466673b89a1c0417965765e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_747b09bd1466673b89a1c0417965765e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-64);    p->lastBulletSpeed = (FixedPointNum(2, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_747b09bd1466673b89a1c0417965765e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-64);    p->lastBulletSpeed = (FixedPointNum(6, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_747b09bd1466673b89a1c0417965765e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (-64);    p->lastBulletSpeed = (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_747b09bd1466673b89a1c0417965765e;  }
}
p->wait = 120; 
}


void genBulletFunc_063f60ff52999f3ef4dcd603079d3ed6(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_5ddbd1661115f0bea5a82691460fe01a; }}


