// XXX uniqID XXX 2c8f182176a3c5058da240439be6598a XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e8aaf99d4a0c256ef209e3334563fe7e(BulletInfo *p); 
static void stepfunc_835bcb667d669face180a7fe42e9dd28(BulletInfo *p); 
static void stepfunc_c90cfa75d14dca74a2cfe87799af47cf(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_7567649eaa53af6625953aa88cba6b22(BulletInfo *p); 
static void stepfunc_799f01ba9eeb252c62bb33bc439b4760(BulletInfo *p); 


static const BulletStepFunc bullet_89ff10edda89d78a8bc7886f7d5b5578[] = {
stepfunc_e8aaf99d4a0c256ef209e3334563fe7e,
stepfunc_835bcb667d669face180a7fe42e9dd28,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_c90cfa75d14dca74a2cfe87799af47cf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_0f5dfa9b08395f8f893080f0e6d6943a[] = {
stepfunc_e8aaf99d4a0c256ef209e3334563fe7e,
stepfunc_835bcb667d669face180a7fe42e9dd28,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_7567649eaa53af6625953aa88cba6b22,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_5a7c3838d073443b8dd32cf62bf6062c[] = {
stepfunc_799f01ba9eeb252c62bb33bc439b4760,
NULL}; 
static void stepfunc_c90cfa75d14dca74a2cfe87799af47cf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-353, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 6; 
}
static void stepfunc_e8aaf99d4a0c256ef209e3334563fe7e(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 59; 
}
static void stepfunc_835bcb667d669face180a7fe42e9dd28(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 6; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_7567649eaa53af6625953aa88cba6b22(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(353, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 6; 
}
static void stepfunc_799f01ba9eeb252c62bb33bc439b4760(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4266, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10666, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14933, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (192);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(21333, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(23466, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f5dfa9b08395f8f893080f0e6d6943a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4266, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10666, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14933, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (192);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(21333, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(23466, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89ff10edda89d78a8bc7886f7d5b5578;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_2c8f182176a3c5058da240439be6598a(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_5a7c3838d073443b8dd32cf62bf6062c; }}


