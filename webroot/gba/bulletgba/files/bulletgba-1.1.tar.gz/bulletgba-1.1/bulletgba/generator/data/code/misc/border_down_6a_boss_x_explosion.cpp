// XXX uniqID XXX 172bec91e10e4758f81dce13764b7a71 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p); 
static void stepfunc_4fc39e92360478aed68777bd40eda960(BulletInfo *p); 
static void stepfunc_c1639cf2b8981847eb566053bcb93578(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p); 
static void stepfunc_f828d6ab286193b69f72fd2f3ec374a6(BulletInfo *p); 
static void stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5(BulletInfo *p); 
static void stepfunc_f463ff547edafe86798b1ff5eebdae91(BulletInfo *p); 
static void stepfunc_c35e4c59880b88f616e718d53aefa09c(BulletInfo *p); 
static void stepfunc_c16c66ac7f3426bd3c3704a45a5651f9(BulletInfo *p); 
static void stepfunc_657d6ce3f368a15a9f9d42acfe682ab8(BulletInfo *p); 
static void stepfunc_1f3f989e3f42f85673cda7c4848092b7(BulletInfo *p); 
static void stepfunc_a4531213a24e321c64e01f39fc74f19b(BulletInfo *p); 
static void stepfunc_aafac0a49d07e9c8f9da617438c03920(BulletInfo *p); 
static void stepfunc_64b931bb07c0a0dee1653344f0f24b26(BulletInfo *p); 
static void stepfunc_08fed69f5e8af05627036554b914ba34(BulletInfo *p); 
static void stepfunc_1bea5d99c60a486ddc9720036f47764e(BulletInfo *p); 
static void stepfunc_0c1d8794ce02fd8cb42f25deacf44578(BulletInfo *p); 
static void stepfunc_9d6677843bfbd8707ee2ad4ebabfd123(BulletInfo *p); 
static void stepfunc_c0966141963b38107e80728482fdb026(BulletInfo *p); 
static void stepfunc_c14f89d102faf722e713ce3a3cb95aeb(BulletInfo *p); 
static void stepfunc_c20ec2e3a5fc5550fe75109f34903d64(BulletInfo *p); 
static void stepfunc_304518c4001d369b3d393bcf1673519b(BulletInfo *p); 
static void stepfunc_42c8d13d6ebc6f1db808b4306867b10e(BulletInfo *p); 
static void stepfunc_83324d96cb4882d59062539d305b6e4e(BulletInfo *p); 
static void stepfunc_1896ce13561c51f8907aaf365863dd7e(BulletInfo *p); 
static void stepfunc_cb40a64af194b3fb26ee6aaf05f5bbdb(BulletInfo *p); 
static void stepfunc_892c2efc7053764d5054b5a9306a9bca(BulletInfo *p); 
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p); 
static void stepfunc_382ba6be7e5acac245f83f756f1cf930(BulletInfo *p); 


static const BulletStepFunc bullet_39dfb851ef4d8211f2166d359bb2e9a8[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_4fc39e92360478aed68777bd40eda960,
stepfunc_c1639cf2b8981847eb566053bcb93578,
stepfunc_c1639cf2b8981847eb566053bcb93578,
stepfunc_c1639cf2b8981847eb566053bcb93578,
stepfunc_c1639cf2b8981847eb566053bcb93578,
stepfunc_c1639cf2b8981847eb566053bcb93578,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_51bba2ce0eca6c397b001ca565d7b6a2[] = {
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_f828d6ab286193b69f72fd2f3ec374a6,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_f463ff547edafe86798b1ff5eebdae91,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5,
NULL}; 
static const BulletStepFunc bullet_24f6ed7b7df789b5bec7f615d150fe63[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_4fc39e92360478aed68777bd40eda960,
stepfunc_c35e4c59880b88f616e718d53aefa09c,
NULL}; 
static const BulletStepFunc bullet_2b3082b4f18ff89a823e98265c055eda[] = {
stepfunc_faeb9ac81b7a64ffed123259883c3994,
stepfunc_4fc39e92360478aed68777bd40eda960,
stepfunc_c16c66ac7f3426bd3c3704a45a5651f9,
NULL}; 
static const BulletStepFunc bullet_aeccf043d3a5c3b742bdc0331a971ed5[] = {
stepfunc_657d6ce3f368a15a9f9d42acfe682ab8,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_3c63c8df87b0a8b95c36e204ab22d782[] = {
stepfunc_a4531213a24e321c64e01f39fc74f19b,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_4f55b090c0eed14212d8e1a1ba1a950a[] = {
stepfunc_aafac0a49d07e9c8f9da617438c03920,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_6c4f8f0e8c6957ca2aa5d9224f31161f[] = {
stepfunc_64b931bb07c0a0dee1653344f0f24b26,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_fdf3c6970b21aa7d46aeb602276698ab[] = {
stepfunc_08fed69f5e8af05627036554b914ba34,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_2fb9210c69df9eb1bd2c5e04b6c75bc7[] = {
stepfunc_1bea5d99c60a486ddc9720036f47764e,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_6c0da63ea925c2693829343d87c2f1c8[] = {
stepfunc_0c1d8794ce02fd8cb42f25deacf44578,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_5863db018c4efe2acaed768661419b07[] = {
stepfunc_9d6677843bfbd8707ee2ad4ebabfd123,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_0d3ee36dec9fcacc501624cbc44200f1[] = {
stepfunc_c0966141963b38107e80728482fdb026,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_e6a68161d96acb94a908d2293e012658[] = {
stepfunc_c14f89d102faf722e713ce3a3cb95aeb,
stepfunc_1f3f989e3f42f85673cda7c4848092b7,
NULL}; 
static const BulletStepFunc bullet_a0713f45cd7697fddfd40be3060d91fd[] = {
stepfunc_c20ec2e3a5fc5550fe75109f34903d64,
NULL}; 
static const BulletStepFunc bullet_9e90c1a642805c7a6a0b642769418fbe[] = {
stepfunc_304518c4001d369b3d393bcf1673519b,
stepfunc_42c8d13d6ebc6f1db808b4306867b10e,
stepfunc_83324d96cb4882d59062539d305b6e4e,
stepfunc_1896ce13561c51f8907aaf365863dd7e,
stepfunc_cb40a64af194b3fb26ee6aaf05f5bbdb,
stepfunc_892c2efc7053764d5054b5a9306a9bca,
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_382ba6be7e5acac245f83f756f1cf930,
stepfunc_304518c4001d369b3d393bcf1673519b,
stepfunc_42c8d13d6ebc6f1db808b4306867b10e,
stepfunc_83324d96cb4882d59062539d305b6e4e,
stepfunc_1896ce13561c51f8907aaf365863dd7e,
stepfunc_cb40a64af194b3fb26ee6aaf05f5bbdb,
stepfunc_892c2efc7053764d5054b5a9306a9bca,
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_382ba6be7e5acac245f83f756f1cf930,
stepfunc_304518c4001d369b3d393bcf1673519b,
stepfunc_42c8d13d6ebc6f1db808b4306867b10e,
stepfunc_83324d96cb4882d59062539d305b6e4e,
stepfunc_1896ce13561c51f8907aaf365863dd7e,
stepfunc_cb40a64af194b3fb26ee6aaf05f5bbdb,
stepfunc_892c2efc7053764d5054b5a9306a9bca,
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_382ba6be7e5acac245f83f756f1cf930,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_382ba6be7e5acac245f83f756f1cf930(BulletInfo *p) { 
p->wait = 200; 
}
static void stepfunc_c20ec2e3a5fc5550fe75109f34903d64(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (0) - p->getAngle();p->setRound(speed, life);}
}
static void stepfunc_657d6ce3f368a15a9f9d42acfe682ab8(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_1f3f989e3f42f85673cda7c4848092b7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (32);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a0713f45cd7697fddfd40be3060d91fd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a0713f45cd7697fddfd40be3060d91fd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a0713f45cd7697fddfd40be3060d91fd;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (224);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a0713f45cd7697fddfd40be3060d91fd;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_a4531213a24e321c64e01f39fc74f19b(BulletInfo *p) { 
p->wait = 65; 
}
static void stepfunc_aafac0a49d07e9c8f9da617438c03920(BulletInfo *p) { 
p->wait = 70; 
}
static void stepfunc_64b931bb07c0a0dee1653344f0f24b26(BulletInfo *p) { 
p->wait = 75; 
}
static void stepfunc_08fed69f5e8af05627036554b914ba34(BulletInfo *p) { 
p->wait = 80; 
}
static void stepfunc_1bea5d99c60a486ddc9720036f47764e(BulletInfo *p) { 
p->wait = 85; 
}
static void stepfunc_0c1d8794ce02fd8cb42f25deacf44578(BulletInfo *p) { 
p->wait = 90; 
}
static void stepfunc_9d6677843bfbd8707ee2ad4ebabfd123(BulletInfo *p) { 
p->wait = 95; 
}
static void stepfunc_c0966141963b38107e80728482fdb026(BulletInfo *p) { 
p->wait = 100; 
}
static void stepfunc_c14f89d102faf722e713ce3a3cb95aeb(BulletInfo *p) { 
p->wait = 105; 
}
static void stepfunc_faeb9ac81b7a64ffed123259883c3994(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_4fc39e92360478aed68777bd40eda960(BulletInfo *p) { 
{
  u16 life = 9;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 15; 
}
static void stepfunc_c16c66ac7f3426bd3c3704a45a5651f9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(9, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e6a68161d96acb94a908d2293e012658;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(38, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0d3ee36dec9fcacc501624cbc44200f1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(67, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5863db018c4efe2acaed768661419b07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(96, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6c0da63ea925c2693829343d87c2f1c8;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(125, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2fb9210c69df9eb1bd2c5e04b6c75bc7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(154, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fdf3c6970b21aa7d46aeb602276698ab;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(183, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6c4f8f0e8c6957ca2aa5d9224f31161f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4f55b090c0eed14212d8e1a1ba1a950a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(241, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3c63c8df87b0a8b95c36e204ab22d782;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_aeccf043d3a5c3b742bdc0331a971ed5;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_892c2efc7053764d5054b5a9306a9bca(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(24604, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2b3082b4f18ff89a823e98265c055eda;  }
}
}
static void stepfunc_cb40a64af194b3fb26ee6aaf05f5bbdb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15502, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2b3082b4f18ff89a823e98265c055eda;  }
}
}
static void stepfunc_c35e4c59880b88f616e718d53aefa09c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (FixedPointNum(240, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1896ce13561c51f8907aaf365863dd7e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(24604, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_24f6ed7b7df789b5bec7f615d150fe63;  }
}
}
static void stepfunc_83324d96cb4882d59062539d305b6e4e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15502, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_24f6ed7b7df789b5bec7f615d150fe63;  }
}
}
static void stepfunc_a8c63e79ac2ce06375a9d13c0b2430e5(BulletInfo *p) { 
{
  u16 life = 4;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 2; 
}
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_f463ff547edafe86798b1ff5eebdae91(BulletInfo *p) { 
{
  u16 life = 50;  FixedPointNum speed = FixedPointNum(FixedPointNum(390, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_f828d6ab286193b69f72fd2f3ec374a6(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(FixedPointNum(10, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_c1639cf2b8981847eb566053bcb93578(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_51bba2ce0eca6c397b001ca565d7b6a2;  }
}
p->wait = 2; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_42c8d13d6ebc6f1db808b4306867b10e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(24604, 100));    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_39dfb851ef4d8211f2166d359bb2e9a8;  }
}
}
static void stepfunc_304518c4001d369b3d393bcf1673519b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15502, 100));    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_39dfb851ef4d8211f2166d359bb2e9a8;  }
}
}


void genBulletFunc_172bec91e10e4758f81dce13764b7a71(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_9e90c1a642805c7a6a0b642769418fbe; }}


