// XXX uniqID XXX 7522d6bc61c86bf18c83dc71022a0e3a XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e21082ee40b82aedbeec42b710beb3e8(BulletInfo *p); 
static void stepfunc_e4cb145d2d635759eb80d0642289f4e6(BulletInfo *p); 
static void stepfunc_ef2dca927cb221e20245efe0e0366a2b(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_6dc7c322b3a2b1bc99e9db87cf6b6bec(BulletInfo *p); 


static const BulletStepFunc bullet_ff866557f89336dec7e24bbf77836b72[] = {
stepfunc_e21082ee40b82aedbeec42b710beb3e8,
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_e4cb145d2d635759eb80d0642289f4e6,
#if 0
stepfunc_ef2dca927cb221e20245efe0e0366a2b,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_f2b4c91c9a93d5c76c5c3d7bd3aad39b[] = {
stepfunc_6dc7c322b3a2b1bc99e9db87cf6b6bec,
NULL}; 
static void stepfunc_ef2dca927cb221e20245efe0e0366a2b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(40, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e4cb145d2d635759eb80d0642289f4e6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_ef2dca927cb221e20245efe0e0366a2b(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_ef2dca927cb221e20245efe0e0366a2b(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 3; ++i) { 
stepfunc_ef2dca927cb221e20245efe0e0366a2b(p);}
p->wait = 3; 
}
static void stepfunc_e21082ee40b82aedbeec42b710beb3e8(BulletInfo *p) { 
{
  u16 life = 1000;  FixedPointNum speed = FixedPointNum(284, 100);p->setRound(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_6dc7c322b3a2b1bc99e9db87cf6b6bec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ff866557f89336dec7e24bbf77836b72;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_7522d6bc61c86bf18c83dc71022a0e3a(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_f2b4c91c9a93d5c76c5c3d7bd3aad39b; }}


