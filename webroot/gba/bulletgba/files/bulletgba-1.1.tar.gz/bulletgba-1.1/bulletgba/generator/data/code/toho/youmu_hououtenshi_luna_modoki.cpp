// XXX uniqID XXX bcb81c8e9f78aeb9ae0864b00adb1ba9 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_2ba1bc811dfe9a2516cb9ef97488da42(BulletInfo *p); 
static void stepfunc_ad81ffe5cebc6a9c03b25ebf88eb22f9(BulletInfo *p); 
static void stepfunc_a426f668c9ecc81dd6da89adcee32b5f(BulletInfo *p); 
static void stepfunc_f046a5c52a1bd0350ec6eeeb74452e58(BulletInfo *p); 
static void stepfunc_eccc557996a05ad8da21b6be0180ba28(BulletInfo *p); 
static void stepfunc_c6afa81579373047309184833d0d04b0(BulletInfo *p); 
static void stepfunc_a3da249e9b2967f5ea6e82cc8149954f(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_d84e9ad1e34f67b79eb1179da83c034c(BulletInfo *p); 
static void stepfunc_68bb930384224996469dc7edeaed51d9(BulletInfo *p); 
static void stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b(BulletInfo *p); 
static void stepfunc_2d30b00d87b24e7c8160f6c947e0f887(BulletInfo *p); 
static void stepfunc_fa5adbdbbe9de633d382e95cbe1d3136(BulletInfo *p); 
static void stepfunc_f2d23c6784413b9f1d6f133b25ac9362(BulletInfo *p); 
static void stepfunc_c83e7499ee15aa1d85af4a09f56884bc(BulletInfo *p); 
static void stepfunc_7e43bdac08d71788d0b3605848d4a101(BulletInfo *p); 
static void stepfunc_b09be07c469186e9ccf76ac73d0bf974(BulletInfo *p); 
static void stepfunc_7b2c4beb9b7ad2994727f21d2c162da8(BulletInfo *p); 
static void stepfunc_50159ad5dce655cadc8652e282e6b5a8(BulletInfo *p); 
static void stepfunc_e586b326e1ce07177c8297012714695c(BulletInfo *p); 


static const BulletStepFunc bullet_8365c68ea21ad9a3e7f1bf4fa623b16f[] = {
stepfunc_2ba1bc811dfe9a2516cb9ef97488da42,
stepfunc_ad81ffe5cebc6a9c03b25ebf88eb22f9,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_a426f668c9ecc81dd6da89adcee32b5f,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_f046a5c52a1bd0350ec6eeeb74452e58,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_eccc557996a05ad8da21b6be0180ba28,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_c6afa81579373047309184833d0d04b0,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_a3da249e9b2967f5ea6e82cc8149954f,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_4364fe7125285b137bd3728164c1527c[] = {
stepfunc_2ba1bc811dfe9a2516cb9ef97488da42,
stepfunc_d84e9ad1e34f67b79eb1179da83c034c,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_68bb930384224996469dc7edeaed51d9,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_a1d0a3dee342b380cda0905992792d19[] = {
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b,
stepfunc_2d30b00d87b24e7c8160f6c947e0f887,
#if 0
stepfunc_fa5adbdbbe9de633d382e95cbe1d3136,
#endif
NULL}; 
static const BulletStepFunc bullet_d11adc4523f0db99788bb3dc5283c400[] = {
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b,
stepfunc_f2d23c6784413b9f1d6f133b25ac9362,
NULL}; 
static const BulletStepFunc bullet_0a6bae8d90d0217c535c573f21a20516[] = {
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b,
stepfunc_c83e7499ee15aa1d85af4a09f56884bc,
NULL}; 
static const BulletStepFunc bullet_16045efc8fe38d28a77e05a73678cb6c[] = {
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b,
stepfunc_7e43bdac08d71788d0b3605848d4a101,
NULL}; 
static const BulletStepFunc bullet_201abb94e2ddd68ffd74577376222dbd[] = {
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b,
stepfunc_b09be07c469186e9ccf76ac73d0bf974,
NULL}; 
static const BulletStepFunc bullet_15a318adca056b87494c74904c7097d9[] = {
stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b,
stepfunc_7b2c4beb9b7ad2994727f21d2c162da8,
NULL}; 
static const BulletStepFunc bullet_8ce761e10b43a2f052743bcfa005ddd9[] = {
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_50159ad5dce655cadc8652e282e6b5a8,
stepfunc_e586b326e1ce07177c8297012714695c,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_6fd1efbc7f2328193a5e34a08ff7a34b(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(FixedPointNum(1, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 60; 
}
static void stepfunc_7b2c4beb9b7ad2994727f21d2c162da8(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-3539, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(80, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_a3da249e9b2967f5ea6e82cc8149954f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_15a318adca056b87494c74904c7097d9;  }
}
}
static void stepfunc_b09be07c469186e9ccf76ac73d0bf974(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-3792, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(75, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_c6afa81579373047309184833d0d04b0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_201abb94e2ddd68ffd74577376222dbd;  }
}
}
static void stepfunc_7e43bdac08d71788d0b3605848d4a101(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4045, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(70, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_eccc557996a05ad8da21b6be0180ba28(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_16045efc8fe38d28a77e05a73678cb6c;  }
}
}
static void stepfunc_c83e7499ee15aa1d85af4a09f56884bc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4298, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(65, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_f046a5c52a1bd0350ec6eeeb74452e58(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0a6bae8d90d0217c535c573f21a20516;  }
}
}
static void stepfunc_f2d23c6784413b9f1d6f133b25ac9362(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + (FixedPointNum(-4551, 100)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(60, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_a426f668c9ecc81dd6da89adcee32b5f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1285, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d11adc4523f0db99788bb3dc5283c400;  }
}
}
static void stepfunc_2ba1bc811dfe9a2516cb9ef97488da42(BulletInfo *p) { 
p->wait = (FixedPointNum::random()*FixedPointNum(30)); 
}
static void stepfunc_ad81ffe5cebc6a9c03b25ebf88eb22f9(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 2; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_fa5adbdbbe9de633d382e95cbe1d3136(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-252, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_2d30b00d87b24e7c8160f6c947e0f887(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(4551, 100));    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_fa5adbdbbe9de633d382e95cbe1d3136(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_68bb930384224996469dc7edeaed51d9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1636, 100));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a1d0a3dee342b380cda0905992792d19;  }
}
}
static void stepfunc_d84e9ad1e34f67b79eb1179da83c034c(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_50159ad5dce655cadc8652e282e6b5a8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum::random()*FixedPointNum(17066, 100))+FixedPointNum(4266, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4364fe7125285b137bd3728164c1527c;  }
}
p->wait = 20; 
}
static void stepfunc_e586b326e1ce07177c8297012714695c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum::random()*FixedPointNum(17066, 100))+FixedPointNum(4266, 100));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8365c68ea21ad9a3e7f1bf4fa623b16f;  }
}
p->wait = 60; 
}


void genBulletFunc_bcb81c8e9f78aeb9ae0864b00adb1ba9(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_8ce761e10b43a2f052743bcfa005ddd9; }}


