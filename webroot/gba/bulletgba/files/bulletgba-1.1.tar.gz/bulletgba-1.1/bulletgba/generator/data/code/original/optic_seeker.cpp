// XXX uniqID XXX 824fc8bed22ea707ec3f888b92fac0b0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_318e1284ce6ddbc4f93941ef3107dbf7(BulletInfo *p); 
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p); 
static void stepfunc_3ae7307199909e0fe209ca5fd0f30dad(BulletInfo *p); 
static void stepfunc_7ccd6fc14366e07362b9d6436cbf65f2(BulletInfo *p); 
static void stepfunc_d59289a9aa1223d9754c55d997588be0(BulletInfo *p); 
static void stepfunc_79cc519c7b6ced12120f33a36b9df51c(BulletInfo *p); 
static void stepfunc_017e9d80da28506d4296d7078d4c780a(BulletInfo *p); 
static void stepfunc_78dcc07966aba929c2019300302fb6ef(BulletInfo *p); 
static void stepfunc_4c633c2f879138d849624e4dc53783a9(BulletInfo *p); 
static void stepfunc_43d5d0d7a5352805b2ced3bc8c11498a(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_78d8968e67ce44b8a0ebddfe0be55bee[] = {
stepfunc_318e1284ce6ddbc4f93941ef3107dbf7,
stepfunc_142b983889f08346cc7f29996da6f2b3,
stepfunc_3ae7307199909e0fe209ca5fd0f30dad,
stepfunc_7ccd6fc14366e07362b9d6436cbf65f2,
stepfunc_7ccd6fc14366e07362b9d6436cbf65f2,
stepfunc_7ccd6fc14366e07362b9d6436cbf65f2,
stepfunc_7ccd6fc14366e07362b9d6436cbf65f2,
stepfunc_7ccd6fc14366e07362b9d6436cbf65f2,
stepfunc_7ccd6fc14366e07362b9d6436cbf65f2,
stepfunc_7ccd6fc14366e07362b9d6436cbf65f2,
stepfunc_d59289a9aa1223d9754c55d997588be0,
NULL}; 
static const BulletStepFunc bullet_5bd6f2d0900534b5d7844ee9b3524f75[] = {
stepfunc_79cc519c7b6ced12120f33a36b9df51c,
stepfunc_017e9d80da28506d4296d7078d4c780a,
stepfunc_017e9d80da28506d4296d7078d4c780a,
stepfunc_017e9d80da28506d4296d7078d4c780a,
stepfunc_78dcc07966aba929c2019300302fb6ef,
NULL}; 
static const BulletStepFunc bullet_5edfd9bd7ae1e5427ca166688a2038c0[] = {
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_4c633c2f879138d849624e4dc53783a9,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_43d5d0d7a5352805b2ced3bc8c11498a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_017e9d80da28506d4296d7078d4c780a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + ((FixedPointNum(4266, 100) + FixedPointNum(17066, 100) * FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
p->wait = (FixedPointNum(10) + FixedPointNum(10) * FixedPointNum::random()) * FixedPointNum(50, 100); 
}
static void stepfunc_79cc519c7b6ced12120f33a36b9df51c(BulletInfo *p) { 
p->wait = (FixedPointNum(30) + FixedPointNum(20) * FixedPointNum::random()) * FixedPointNum(50, 100); 
}
static void stepfunc_78dcc07966aba929c2019300302fb6ef(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (0) - p->getAngle();p->setRound(speed, life);}
}
static void stepfunc_43d5d0d7a5352805b2ced3bc8c11498a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(4266, 100) + FixedPointNum(8533, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5bd6f2d0900534b5d7844ee9b3524f75;  }
}
p->wait = 5; 
}
static void stepfunc_7ccd6fc14366e07362b9d6436cbf65f2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (32);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_318e1284ce6ddbc4f93941ef3107dbf7(BulletInfo *p) { 
p->wait = (FixedPointNum(10) + FixedPointNum(10) * FixedPointNum::random()); 
}
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_3ae7307199909e0fe209ca5fd0f30dad(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_d59289a9aa1223d9754c55d997588be0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4c633c2f879138d849624e4dc53783a9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(2133, 100) + FixedPointNum(4266, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_78d8968e67ce44b8a0ebddfe0be55bee;  }
}
p->wait = 5; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_824fc8bed22ea707ec3f888b92fac0b0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_5edfd9bd7ae1e5427ca166688a2038c0; }}


