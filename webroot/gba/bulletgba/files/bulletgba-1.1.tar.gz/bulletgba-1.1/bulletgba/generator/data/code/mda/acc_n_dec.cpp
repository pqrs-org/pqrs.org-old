// XXX uniqID XXX 1814bab23eb42fd0229bc0c3c3d34010 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_8f67076238570ce89fac133b88df2340(BulletInfo *p); 
static void stepfunc_fc53655ace0a377e8ebcdf29286cf232(BulletInfo *p); 
static void stepfunc_0eb897dca1a2deef36b96f5520b6217d(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_dc2737e3c80f4d2dc64bb37911e2dc57(BulletInfo *p); 
static void stepfunc_3944f3e4e41c9d577917ebc1b17c1f13(BulletInfo *p); 
static void stepfunc_369035c037a51051d527157c67115461(BulletInfo *p); 
static void stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3(BulletInfo *p); 


static const BulletStepFunc bullet_bc843a8b659de0b7810586f040523541[] = {
stepfunc_8f67076238570ce89fac133b88df2340,
stepfunc_fc53655ace0a377e8ebcdf29286cf232,
stepfunc_0eb897dca1a2deef36b96f5520b6217d,
stepfunc_0eb897dca1a2deef36b96f5520b6217d,
stepfunc_0eb897dca1a2deef36b96f5520b6217d,
stepfunc_0eb897dca1a2deef36b96f5520b6217d,
stepfunc_0eb897dca1a2deef36b96f5520b6217d,
stepfunc_0eb897dca1a2deef36b96f5520b6217d,
stepfunc_0eb897dca1a2deef36b96f5520b6217d,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_87e44e3631450148518901b32295b940[] = {
stepfunc_dc2737e3c80f4d2dc64bb37911e2dc57,
NULL}; 
static const BulletStepFunc bullet_9020a4202d3941344bf2d9effcdaa695[] = {
stepfunc_3944f3e4e41c9d577917ebc1b17c1f13,
stepfunc_369035c037a51051d527157c67115461,
NULL}; 
static const BulletStepFunc bullet_7059f83486824cab8add14c7e00574d0[] = {
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_dc2737e3c80f4d2dc64bb37911e2dc57(BulletInfo *p) { 
{
  u16 life = 25;  FixedPointNum speed = FixedPointNum(FixedPointNum(105, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_3944f3e4e41c9d577917ebc1b17c1f13(BulletInfo *p) { 
{
  u16 life = 150;  FixedPointNum speed = FixedPointNum(FixedPointNum(840, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 9999; 
}
static void stepfunc_369035c037a51051d527157c67115461(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_0eb897dca1a2deef36b96f5520b6217d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(604, 100));    p->lastBulletSpeed = (FixedPointNum(105, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9020a4202d3941344bf2d9effcdaa695;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(604, 100));    p->lastBulletSpeed = (FixedPointNum(420, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87e44e3631450148518901b32295b940;  }
}
}
static void stepfunc_8f67076238570ce89fac133b88df2340(BulletInfo *p) { 
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 20; 
}
static void stepfunc_fc53655ace0a377e8ebcdf29286cf232(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum::random()*FixedPointNum(4266, 100)-FixedPointNum(2133, 100)-FixedPointNum(4977, 100)));    p->lastBulletSpeed = (FixedPointNum(420, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_87e44e3631450148518901b32295b940;  }
}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_d9379ff04c64f637b3ec01eb5fa71ff3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc843a8b659de0b7810586f040523541;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (192);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_bc843a8b659de0b7810586f040523541;  }
}
p->wait = 25; 
}


void genBulletFunc_1814bab23eb42fd0229bc0c3c3d34010(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_7059f83486824cab8add14c7e00574d0; }}


