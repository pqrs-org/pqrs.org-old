// XXX uniqID XXX 84c6fdff4c7605b653026925948c7148 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p); 
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p); 
static void stepfunc_21e682c541a61e7c29738df78b2b241b(BulletInfo *p); 
static void stepfunc_609da54d1688f83653abb5fd662eefb5(BulletInfo *p); 
static void stepfunc_dc74be2879509476daa2b4b74c47ef58(BulletInfo *p); 
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p); 
static void stepfunc_a03191b05841ee04a61b2d9c562dad48(BulletInfo *p); 
static void stepfunc_2a5fa7625b35ee4c6d920bd17a4bc5fc(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f(BulletInfo *p); 
static void stepfunc_b9bf0eb5b101b00ba9031a26075b49b4(BulletInfo *p); 
static void stepfunc_f4be09dc944074e6b648295e0d99bff2(BulletInfo *p); 
static void stepfunc_e8bbf69ad7a7c5b8c7c213ec4001cdab(BulletInfo *p); 
static void stepfunc_c542a8e14fc863ea633d7630a401a8c6(BulletInfo *p); 
static void stepfunc_b32d000fa4a2d6c765ff51e8de3427f2(BulletInfo *p); 
static void stepfunc_ca840ecef809fe2d1ce293904aeef6d6(BulletInfo *p); 
static void stepfunc_4bced0513b18ab5c5e1492b7cae69d8a(BulletInfo *p); 


static const BulletStepFunc bullet_0e3f5fedb6d37491a5400e3da21f13b2[] = {
stepfunc_d63f935eaeadb4a3f83557ae10cc6a28,
stepfunc_142b983889f08346cc7f29996da6f2b3,
stepfunc_21e682c541a61e7c29738df78b2b241b,
stepfunc_609da54d1688f83653abb5fd662eefb5,
stepfunc_609da54d1688f83653abb5fd662eefb5,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_a03191b05841ee04a61b2d9c562dad48,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_dc74be2879509476daa2b4b74c47ef58,
stepfunc_2a5fa7625b35ee4c6d920bd17a4bc5fc,
stepfunc_609da54d1688f83653abb5fd662eefb5,
stepfunc_609da54d1688f83653abb5fd662eefb5,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_f78a6346ffd23add1e2ef2af9489f600[] = {
stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f,
stepfunc_b9bf0eb5b101b00ba9031a26075b49b4,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_f4be09dc944074e6b648295e0d99bff2,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_a4110448d18190b63d08495a56f1c592[] = {
stepfunc_e8bbf69ad7a7c5b8c7c213ec4001cdab,
stepfunc_c542a8e14fc863ea633d7630a401a8c6,
NULL}; 
static const BulletStepFunc bullet_524b8d3b6be054d203f8dd997780ed7f[] = {
stepfunc_b32d000fa4a2d6c765ff51e8de3427f2,
stepfunc_ca840ecef809fe2d1ce293904aeef6d6,
NULL}; 
static const BulletStepFunc bullet_b530dbcfb7d43dcd9ec5250c03ae4a82[] = {
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_4bced0513b18ab5c5e1492b7cae69d8a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_b32d000fa4a2d6c765ff51e8de3427f2(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_ca840ecef809fe2d1ce293904aeef6d6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3555, 100));    p->lastBulletSpeed = (FixedPointNum(158, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f4be09dc944074e6b648295e0d99bff2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(924, 100));    p->lastBulletSpeed = (FixedPointNum(158, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_524b8d3b6be054d203f8dd997780ed7f;  }
}
}
static void stepfunc_8d569dd0ecd3d44c9b5ec5c9639d502f(BulletInfo *p) { 
p->wait = 4; 
}
static void stepfunc_b9bf0eb5b101b00ba9031a26075b49b4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4266, 100));    p->lastBulletSpeed = (FixedPointNum(158, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_524b8d3b6be054d203f8dd997780ed7f;  }
}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_609da54d1688f83653abb5fd662eefb5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(158, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f78a6346ffd23add1e2ef2af9489f600;  }
}
}
static void stepfunc_e8bbf69ad7a7c5b8c7c213ec4001cdab(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_c542a8e14fc863ea633d7630a401a8c6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_dc74be2879509476daa2b4b74c47ef58(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1066, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a4110448d18190b63d08495a56f1c592;  }
}
}
static void stepfunc_d63f935eaeadb4a3f83557ae10cc6a28(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_142b983889f08346cc7f29996da6f2b3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_21e682c541a61e7c29738df78b2b241b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(158, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f78a6346ffd23add1e2ef2af9489f600;  }
}
}
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_a03191b05841ee04a61b2d9c562dad48(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a4110448d18190b63d08495a56f1c592;  }
}
}
static void stepfunc_2a5fa7625b35ee4c6d920bd17a4bc5fc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-213, 100));    p->lastBulletSpeed = (FixedPointNum(158, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f78a6346ffd23add1e2ef2af9489f600;  }
}
}
static void stepfunc_4bced0513b18ab5c5e1492b7cae69d8a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(8533, 100) + FixedPointNum(8533, 100) * FixedPointNum::random()));    p->lastBulletSpeed = ((FixedPointNum(1) + FixedPointNum(30, 100) * FixedPointNum::random()));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e3f5fedb6d37491a5400e3da21f13b2;  }
}
p->wait = 13; 
}


void genBulletFunc_84c6fdff4c7605b653026925948c7148(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_b530dbcfb7d43dcd9ec5250c03ae4a82; }}


