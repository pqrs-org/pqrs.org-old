// XXX uniqID XXX b13faf00331510c39ba0cf76a794d963 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_c172a15bb6eca889f748350b364028cc(BulletInfo *p); 
static void stepfunc_176314d2ba36a7280e2399c20a4d3772(BulletInfo *p); 
static void stepfunc_c0c09b023a7c2b95fa658481862481de(BulletInfo *p); 
static void stepfunc_b9f3746024faf71a948d02a3f58cba12(BulletInfo *p); 
static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p); 
static void stepfunc_a28cd147b42d4c4733373a0cacdb33ce(BulletInfo *p); 
static void stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84(BulletInfo *p); 
static void stepfunc_5b17df237cea305ffccefce169ada8ed(BulletInfo *p); 
static void stepfunc_91c8fbb49855bdcb26e359162a821ef0(BulletInfo *p); 
static void stepfunc_c4d38a72b7e1ecc912d750a3d1066940(BulletInfo *p); 
static void stepfunc_a865c6c8b44585d6739ff7b1938fd90f(BulletInfo *p); 
static void stepfunc_282af7128f958234fcead78af8f77162(BulletInfo *p); 
static void stepfunc_a3a897c8160713fd874566a816f11df8(BulletInfo *p); 
static void stepfunc_ccea2eb178a32635cebde8abe3449975(BulletInfo *p); 
static void stepfunc_824d3f1a7fb62dc33630e5413875d612(BulletInfo *p); 
static void stepfunc_1f8f9493d984c5245f32e70ccc8bc434(BulletInfo *p); 
static void stepfunc_655fd0b2377a859fd835562851c5262e(BulletInfo *p); 
static void stepfunc_c81adf7df8bd376b67b691ecd5270b79(BulletInfo *p); 
static void stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4(BulletInfo *p); 
static void stepfunc_5e26bb17821117982ec83caf3e8e5025(BulletInfo *p); 
static void stepfunc_fcacbf508b0a28a8ee270e0e51a47d76(BulletInfo *p); 
static void stepfunc_9342daff220220b3de27416170902881(BulletInfo *p); 
static void stepfunc_a3bff8bf932cfa4bbf32d10d08cc4e56(BulletInfo *p); 


static const BulletStepFunc bullet_5e801d6d9480bd7b49a1ec01a6aaae69[] = {
stepfunc_c172a15bb6eca889f748350b364028cc,
stepfunc_176314d2ba36a7280e2399c20a4d3772,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_b9f3746024faf71a948d02a3f58cba12,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_b9f3746024faf71a948d02a3f58cba12,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_b9f3746024faf71a948d02a3f58cba12,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_b9f3746024faf71a948d02a3f58cba12,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_c0c09b023a7c2b95fa658481862481de,
stepfunc_b9f3746024faf71a948d02a3f58cba12,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_f73519751afda31db2f68efdf09cbd3b[] = {
stepfunc_a28cd147b42d4c4733373a0cacdb33ce,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_122c5d75c8cf64929cb6a60fd1345529[] = {
stepfunc_5b17df237cea305ffccefce169ada8ed,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_91c8fbb49855bdcb26e359162a821ef0,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_7f3bbcdc1ea9c17789acf2877928933b[] = {
stepfunc_c4d38a72b7e1ecc912d750a3d1066940,
NULL}; 
static const BulletStepFunc bullet_a0c2439ed1ef29b50d6afdc165067679[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_282af7128f958234fcead78af8f77162,
#if 0
stepfunc_a3a897c8160713fd874566a816f11df8,
#endif
stepfunc_282af7128f958234fcead78af8f77162,
#if 0
stepfunc_ccea2eb178a32635cebde8abe3449975,
#endif
NULL}; 
static const BulletStepFunc bullet_8d7d43ad0c55e9e98858f94599c668b1[] = {
stepfunc_a865c6c8b44585d6739ff7b1938fd90f,
stepfunc_824d3f1a7fb62dc33630e5413875d612,
#if 0
stepfunc_1f8f9493d984c5245f32e70ccc8bc434,
#endif
stepfunc_824d3f1a7fb62dc33630e5413875d612,
#if 0
stepfunc_655fd0b2377a859fd835562851c5262e,
#endif
NULL}; 
static const BulletStepFunc bullet_4d00b275a990b0b4f61729dc565a375a[] = {
stepfunc_c81adf7df8bd376b67b691ecd5270b79,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static const BulletStepFunc bullet_135d8b9d72f162b8a465537a896dda55[] = {
stepfunc_5e26bb17821117982ec83caf3e8e5025,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_fcacbf508b0a28a8ee270e0e51a47d76,
stepfunc_9342daff220220b3de27416170902881,
stepfunc_9342daff220220b3de27416170902881,
stepfunc_9342daff220220b3de27416170902881,
stepfunc_9342daff220220b3de27416170902881,
stepfunc_a3bff8bf932cfa4bbf32d10d08cc4e56,
stepfunc_a3bff8bf932cfa4bbf32d10d08cc4e56,
stepfunc_a3bff8bf932cfa4bbf32d10d08cc4e56,
stepfunc_a3bff8bf932cfa4bbf32d10d08cc4e56,
stepfunc_a3bff8bf932cfa4bbf32d10d08cc4e56,
stepfunc_dae2cf81747ffb5070f05c8837b1d568,
NULL}; 
static void stepfunc_2df381fd69d5ade8ecfecacf02f4b8f4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(355, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_c81adf7df8bd376b67b691ecd5270b79(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_dae2cf81747ffb5070f05c8837b1d568(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_a3bff8bf932cfa4bbf32d10d08cc4e56(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4d00b275a990b0b4f61729dc565a375a;  }
}
p->wait = 3; 
}
static void stepfunc_ccea2eb178a32635cebde8abe3449975(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1066, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a3a897c8160713fd874566a816f11df8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a865c6c8b44585d6739ff7b1938fd90f(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_282af7128f958234fcead78af8f77162(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-711, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a3a897c8160713fd874566a816f11df8(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1066, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_ccea2eb178a32635cebde8abe3449975(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_655fd0b2377a859fd835562851c5262e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1066, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1f8f9493d984c5245f32e70ccc8bc434(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(20, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_824d3f1a7fb62dc33630e5413875d612(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(711, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_1f8f9493d984c5245f32e70ccc8bc434(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1066, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_655fd0b2377a859fd835562851c5262e(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_c4d38a72b7e1ecc912d750a3d1066940(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d7d43ad0c55e9e98858f94599c668b1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(2133, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a0c2439ed1ef29b50d6afdc165067679;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9342daff220220b3de27416170902881(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7f3bbcdc1ea9c17789acf2877928933b;  }
}
p->wait = 10; 
}
static void stepfunc_fcacbf508b0a28a8ee270e0e51a47d76(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7f3bbcdc1ea9c17789acf2877928933b;  }
}
p->wait = 20; 
}
static void stepfunc_c0c09b023a7c2b95fa658481862481de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_b9f3746024faf71a948d02a3f58cba12(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_c4fbf2eeeaf52a99a7ac49ee06ce8c84(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(355, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_a28cd147b42d4c4733373a0cacdb33ce(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(355, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_91c8fbb49855bdcb26e359162a821ef0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-355, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 1; 
}
static void stepfunc_5b17df237cea305ffccefce169ada8ed(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-355, 100));    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_c172a15bb6eca889f748350b364028cc(BulletInfo *p) { 
p->wait = 20; 
}
static void stepfunc_176314d2ba36a7280e2399c20a4d3772(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_122c5d75c8cf64929cb6a60fd1345529;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_f73519751afda31db2f68efdf09cbd3b;  }
}
p->wait = 40; 
}
static void stepfunc_5e26bb17821117982ec83caf3e8e5025(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(4977, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5e801d6d9480bd7b49a1ec01a6aaae69;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5e801d6d9480bd7b49a1ec01a6aaae69;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-4977, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5e801d6d9480bd7b49a1ec01a6aaae69;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(-8533, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5e801d6d9480bd7b49a1ec01a6aaae69;  }
}
p->wait = 50; 
}


void genBulletFunc_b13faf00331510c39ba0cf76a794d963(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_135d8b9d72f162b8a465537a896dda55; }}


