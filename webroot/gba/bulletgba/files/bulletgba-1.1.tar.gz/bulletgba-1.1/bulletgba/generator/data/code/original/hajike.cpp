// XXX uniqID XXX 7906827b2cbab9249f1c1739b9e180c0 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_a24779ed5eb453e3112fed2e64e92d18(BulletInfo *p); 
static void stepfunc_1ec5944be8330d63214b0f6cf50044fd(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_d248bdbcebc15e08c3b81ecbb813ca34(BulletInfo *p); 
static void stepfunc_33080dea5f169b84a0f54f38d3c91fb1(BulletInfo *p); 
static void stepfunc_b7a9912790b675d6f9361a71dac5107d(BulletInfo *p); 
static void stepfunc_b239e00d8a26d744e3cbc9625195716c(BulletInfo *p); 
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p); 
static void stepfunc_fb72828abf0aac784f615afde7f8e53b(BulletInfo *p); 
static void stepfunc_333ff85a111d0c2a37986f215d166c86(BulletInfo *p); 
static void stepfunc_9bc2d2066670be697b30ca88fc30bb3c(BulletInfo *p); 
static void stepfunc_bfacb2b2df7a1ec6e6a9558e4c296df4(BulletInfo *p); 
static void stepfunc_c22fe506f5071b5c60e8dba17f38a70a(BulletInfo *p); 
static void stepfunc_f9aba315476ef73ee193d76cda758543(BulletInfo *p); 
static void stepfunc_78d1c4da5cea7fd60799758b7d86c57b(BulletInfo *p); 


static const BulletStepFunc bullet_851c7ff09fa7e48142ddec9c3fcc4cb7[] = {
stepfunc_a24779ed5eb453e3112fed2e64e92d18,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_d540bbe8a2f1d3152fa334e2dcfb2b07[] = {
stepfunc_d248bdbcebc15e08c3b81ecbb813ca34,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_da999334ef06c4351f29eae4c5368e4c[] = {
stepfunc_b7a9912790b675d6f9361a71dac5107d,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_1ec5944be8330d63214b0f6cf50044fd,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_8ab9e68198e968cf7a72ba6b21f097ba[] = {
stepfunc_b239e00d8a26d744e3cbc9625195716c,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_33080dea5f169b84a0f54f38d3c91fb1,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_48c785894946da658b99df9ab8189690[] = {
stepfunc_97e8979d1a7c719f55deab0bdea20675,
stepfunc_fb72828abf0aac784f615afde7f8e53b,
NULL}; 
static const BulletStepFunc bullet_d44070fb6136d96ea3fa0cb524aba518[] = {
stepfunc_333ff85a111d0c2a37986f215d166c86,
stepfunc_9bc2d2066670be697b30ca88fc30bb3c,
stepfunc_bfacb2b2df7a1ec6e6a9558e4c296df4,
stepfunc_c22fe506f5071b5c60e8dba17f38a70a,
stepfunc_f9aba315476ef73ee193d76cda758543,
stepfunc_78d1c4da5cea7fd60799758b7d86c57b,
stepfunc_333ff85a111d0c2a37986f215d166c86,
stepfunc_9bc2d2066670be697b30ca88fc30bb3c,
stepfunc_bfacb2b2df7a1ec6e6a9558e4c296df4,
stepfunc_c22fe506f5071b5c60e8dba17f38a70a,
stepfunc_f9aba315476ef73ee193d76cda758543,
stepfunc_78d1c4da5cea7fd60799758b7d86c57b,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_97e8979d1a7c719f55deab0bdea20675(BulletInfo *p) { 
p->wait = 100; 
}
static void stepfunc_fb72828abf0aac784f615afde7f8e53b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (64);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (128);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (192);    p->lastBulletSpeed = p->getSpeed() + (FixedPointNum(60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_1ec5944be8330d63214b0f6cf50044fd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-355, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_48c785894946da658b99df9ab8189690;  }
}
p->wait = 3; 
}
static void stepfunc_a24779ed5eb453e3112fed2e64e92d18(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2844, 100));    p->lastBulletSpeed = (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_48c785894946da658b99df9ab8189690;  }
}
p->wait = 3; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_33080dea5f169b84a0f54f38d3c91fb1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(355, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_48c785894946da658b99df9ab8189690;  }
}
p->wait = 3; 
}
static void stepfunc_d248bdbcebc15e08c3b81ecbb813ca34(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_48c785894946da658b99df9ab8189690;  }
}
p->wait = 3; 
}
static void stepfunc_b7a9912790b675d6f9361a71dac5107d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2986, 100));    p->lastBulletSpeed = (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_48c785894946da658b99df9ab8189690;  }
}
p->wait = 3; 
}
static void stepfunc_b239e00d8a26d744e3cbc9625195716c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(2986, 100));    p->lastBulletSpeed = (FixedPointNum(30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_48c785894946da658b99df9ab8189690;  }
}
p->wait = 3; 
}
static void stepfunc_333ff85a111d0c2a37986f215d166c86(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ab9e68198e968cf7a72ba6b21f097ba;  }
}
p->wait = 15; 
}
static void stepfunc_9bc2d2066670be697b30ca88fc30bb3c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_da999334ef06c4351f29eae4c5368e4c;  }
}
p->wait = 15; 
}
static void stepfunc_bfacb2b2df7a1ec6e6a9558e4c296df4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8391, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d540bbe8a2f1d3152fa334e2dcfb2b07;  }
}
p->wait = 15; 
}
static void stepfunc_c22fe506f5071b5c60e8dba17f38a70a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17208, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_851c7ff09fa7e48142ddec9c3fcc4cb7;  }
}
p->wait = 15; 
}
static void stepfunc_f9aba315476ef73ee193d76cda758543(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8675, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d540bbe8a2f1d3152fa334e2dcfb2b07;  }
}
p->wait = 15; 
}
static void stepfunc_78d1c4da5cea7fd60799758b7d86c57b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(16924, 100));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_851c7ff09fa7e48142ddec9c3fcc4cb7;  }
}
p->wait = 15; 
}


void genBulletFunc_7906827b2cbab9249f1c1739b9e180c0(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_d44070fb6136d96ea3fa0cb524aba518; }}


