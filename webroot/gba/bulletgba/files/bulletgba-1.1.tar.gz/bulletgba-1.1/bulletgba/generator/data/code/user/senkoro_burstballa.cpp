// XXX uniqID XXX a606f01d6fe30ab0973549b9b1d1838d XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_145aca95c4c74c5624f5d8b513f5b416(BulletInfo *p); 
static void stepfunc_2bfeb18ecdad70b4c34eea4691e9682b(BulletInfo *p); 
static void stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057(BulletInfo *p); 
static void stepfunc_56dff1464ae76a21656345accd84ae74(BulletInfo *p); 
static void stepfunc_c42a08ec47a44ac336f5de8ad2ffcf82(BulletInfo *p); 
static void stepfunc_457436a10b999fed4fd8b35b8678c502(BulletInfo *p); 
static void stepfunc_3ae91687fcd6be207e26c49ad3da69c5(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_952a935627c23e404f66d7bf7966176f(BulletInfo *p); 
static void stepfunc_c9fe7ac3908e134223183c010f326619(BulletInfo *p); 
static void stepfunc_bf071a562da520155046174066a2c4ad(BulletInfo *p); 
static void stepfunc_b8d5556c0012a7480d76c8c8de523d2a(BulletInfo *p); 
static void stepfunc_ec67755e2cbf03e3280eca56cf8b8f36(BulletInfo *p); 
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p); 
static void stepfunc_30eb5b90fec1634e5c736eded3426405(BulletInfo *p); 
static void stepfunc_c536286494ab4e638e5709b93759a2fd(BulletInfo *p); 
static void stepfunc_0ce2d240b4eba445cb9f77a741570c50(BulletInfo *p); 
static void stepfunc_19f0795d12f474824a4dbc767f11c899(BulletInfo *p); 


static const BulletStepFunc bullet_89a5de64bb7ce5583a79d1689b61f7af[] = {
stepfunc_145aca95c4c74c5624f5d8b513f5b416,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_2bfeb18ecdad70b4c34eea4691e9682b,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057,
stepfunc_56dff1464ae76a21656345accd84ae74,
stepfunc_c42a08ec47a44ac336f5de8ad2ffcf82,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_3ae91687fcd6be207e26c49ad3da69c5,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_3ae91687fcd6be207e26c49ad3da69c5,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_3ae91687fcd6be207e26c49ad3da69c5,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_457436a10b999fed4fd8b35b8678c502,
stepfunc_3ae91687fcd6be207e26c49ad3da69c5,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_8d314febe3e9284250bd064ab01f72cf[] = {
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_80d5b4f5a346f5ccf10b6da52e227926[] = {
stepfunc_952a935627c23e404f66d7bf7966176f,
stepfunc_c9fe7ac3908e134223183c010f326619,
NULL}; 
static const BulletStepFunc bullet_78e29f37abb2f748371bad58eb44da2e[] = {
stepfunc_bf071a562da520155046174066a2c4ad,
stepfunc_b8d5556c0012a7480d76c8c8de523d2a,
NULL}; 
static const BulletStepFunc bullet_96485fc01901ae7960c4b007d6026fb8[] = {
stepfunc_ec67755e2cbf03e3280eca56cf8b8f36,
stepfunc_ec67755e2cbf03e3280eca56cf8b8f36,
stepfunc_ec67755e2cbf03e3280eca56cf8b8f36,
stepfunc_ec67755e2cbf03e3280eca56cf8b8f36,
stepfunc_ec67755e2cbf03e3280eca56cf8b8f36,
stepfunc_ec67755e2cbf03e3280eca56cf8b8f36,
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_c536286494ab4e638e5709b93759a2fd,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_c536286494ab4e638e5709b93759a2fd,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_c536286494ab4e638e5709b93759a2fd,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_c536286494ab4e638e5709b93759a2fd,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_30eb5b90fec1634e5c736eded3426405,
stepfunc_c536286494ab4e638e5709b93759a2fd,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_19f0795d12f474824a4dbc767f11c899,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_0ce2d240b4eba445cb9f77a741570c50(BulletInfo *p) { 
p->wait = 4; 
}
static void stepfunc_19f0795d12f474824a4dbc767f11c899(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_30eb5b90fec1634e5c736eded3426405(BulletInfo *p) { 
p->wait = 15; 
}
static void stepfunc_c536286494ab4e638e5709b93759a2fd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_952a935627c23e404f66d7bf7966176f(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(FixedPointNum(250, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(-303, 100);p->setRound(speed, life);}
p->wait = 60; 
}
static void stepfunc_c9fe7ac3908e134223183c010f326619(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(-101, 100);p->setRound(speed, life);}
}
static void stepfunc_bf071a562da520155046174066a2c4ad(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(FixedPointNum(250, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(303, 100);p->setRound(speed, life);}
p->wait = 60; 
}
static void stepfunc_b8d5556c0012a7480d76c8c8de523d2a(BulletInfo *p) { 
{
  u16 life = 60;  FixedPointNum speed = FixedPointNum(101, 100);p->setRound(speed, life);}
}
static void stepfunc_457436a10b999fed4fd8b35b8678c502(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2133, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_78e29f37abb2f748371bad58eb44da2e;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_80d5b4f5a346f5ccf10b6da52e227926;  }
}
}
static void stepfunc_3ae91687fcd6be207e26c49ad3da69c5(BulletInfo *p) { 
p->wait = 2; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_f0a2afaf20d5c2aa0e16d5fe3b965057(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 5; 
}
static void stepfunc_2bfeb18ecdad70b4c34eea4691e9682b(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 5; 
}
static void stepfunc_145aca95c4c74c5624f5d8b513f5b416(BulletInfo *p) { 
{
  u16 life = (FixedPointNum(10)+(FixedPointNum(5)+FixedPointNum::random()*FixedPointNum(5)))*FixedPointNum(5);  FixedPointNum speed = FixedPointNum(FixedPointNum(150, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_56dff1464ae76a21656345accd84ae74(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
static void stepfunc_c42a08ec47a44ac336f5de8ad2ffcf82(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + ((FixedPointNum::random()*FixedPointNum(256)));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d314febe3e9284250bd064ab01f72cf;  }
}
}
static void stepfunc_ec67755e2cbf03e3280eca56cf8b8f36(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(11377, 100)+FixedPointNum::random()*FixedPointNum(2844, 100)));    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_89a5de64bb7ce5583a79d1689b61f7af;  }
}
p->wait = 30; 
}
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p) { 
p->wait = 30; 
}


void genBulletFunc_a606f01d6fe30ab0973549b9b1d1838d(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_96485fc01901ae7960c4b007d6026fb8; }}


