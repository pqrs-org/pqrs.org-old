// XXX uniqID XXX 9af899c5b076bb7e647cbf738a6cc70f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_453f28457e53efee416f87dac69b3445(BulletInfo *p); 
static void stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575(BulletInfo *p); 
static void stepfunc_7543937edc007b1a7b28f28904bc1589(BulletInfo *p); 
static void stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60(BulletInfo *p); 
static void stepfunc_1b8a83447a223cdc11ebd05822f1d043(BulletInfo *p); 
static void stepfunc_1416b5473ba63e42b2265ecb93832804(BulletInfo *p); 
static void stepfunc_6be70b7ba2b4a347c2f50d0bcc834da8(BulletInfo *p); 


static const BulletStepFunc bullet_00c2ce75bdfc018e50eb8fab18703b21[] = {
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
stepfunc_453f28457e53efee416f87dac69b3445,
#if 0
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575,
#endif
NULL}; 
static const BulletStepFunc bullet_7b0be5e9f72a6fc8078cae2c1399811f[] = {
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
stepfunc_7543937edc007b1a7b28f28904bc1589,
#if 0
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60,
#endif
NULL}; 
static const BulletStepFunc bullet_1dbd0677911ededa8c69ea68f0966c4d[] = {
stepfunc_1b8a83447a223cdc11ebd05822f1d043,
#if 0
stepfunc_1416b5473ba63e42b2265ecb93832804,
#endif
NULL}; 
static const BulletStepFunc bullet_37aed3a6633d4d776ddebb02ee9437af[] = {
stepfunc_6be70b7ba2b4a347c2f50d0bcc834da8,
NULL}; 
static void stepfunc_1416b5473ba63e42b2265ecb93832804(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-71, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1b8a83447a223cdc11ebd05822f1d043(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(782, 100));    p->lastBulletSpeed = p->getSpeed() + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 22; ++i) { 
stepfunc_1416b5473ba63e42b2265ecb93832804(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (32);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
}
static void stepfunc_453f28457e53efee416f87dac69b3445(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_2bfbfda9a84e6b29e1551bf4a05ac575(p);}
p->wait = 30; 
}
static void stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (32);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
}
static void stepfunc_7543937edc007b1a7b28f28904bc1589(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (16);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dbd0677911ededa8c69ea68f0966c4d;  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_4c44c11b3b2cccc6d7e68967c5c75c60(p);}
p->wait = 30; 
}
static void stepfunc_6be70b7ba2b4a347c2f50d0bcc834da8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7b0be5e9f72a6fc8078cae2c1399811f;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_00c2ce75bdfc018e50eb8fab18703b21;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_9af899c5b076bb7e647cbf738a6cc70f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_37aed3a6633d4d776ddebb02ee9437af; }}


