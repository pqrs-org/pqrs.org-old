// XXX uniqID XXX 5f22d513e685dec43f037958f9df4526 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_1a4e7513a57ad4cd31a00e5b613fd4b5(BulletInfo *p); 
static void stepfunc_0329b7d9c5092f66b697afa9489fe7f5(BulletInfo *p); 


static const BulletStepFunc bullet_5b4e63b759db6fe025f200cfd5013a5a[] = {
stepfunc_1a4e7513a57ad4cd31a00e5b613fd4b5,
#if 0
stepfunc_0329b7d9c5092f66b697afa9489fe7f5,
#endif
NULL}; 
static void stepfunc_0329b7d9c5092f66b697afa9489fe7f5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(8533, 100)*FixedPointNum::random()-FixedPointNum(4266, 100)));    p->lastBulletSpeed = ((FixedPointNum(50, 100)+FixedPointNum::random()*FixedPointNum(2)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_1a4e7513a57ad4cd31a00e5b613fd4b5(BulletInfo *p) { 
for (u32 i = 0; i < 400; ++i) { 
stepfunc_0329b7d9c5092f66b697afa9489fe7f5(p);}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_5f22d513e685dec43f037958f9df4526(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_5b4e63b759db6fe025f200cfd5013a5a; }}


