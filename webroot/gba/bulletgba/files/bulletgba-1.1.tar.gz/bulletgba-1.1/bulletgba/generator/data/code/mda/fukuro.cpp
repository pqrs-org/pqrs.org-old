// XXX uniqID XXX c2840f94d8496664252fca440d6b6db8 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p); 
static void stepfunc_c3bf4755b70750d382579361405ea55a(BulletInfo *p); 
static void stepfunc_5732e8ab172826e0938463c0af53c81f(BulletInfo *p); 
static void stepfunc_132ec58c6b508eeaa618398c709e7c77(BulletInfo *p); 
static void stepfunc_198031dab59773a3d31e0f1322b0b68d(BulletInfo *p); 
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p); 
static void stepfunc_cc640c72c7237dea8372c4439c04f091(BulletInfo *p); 
static void stepfunc_321a52b2346256b63ef1feb5f226c156(BulletInfo *p); 
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p); 
static void stepfunc_35fe6379fc6de0ff4972da994874ab7d(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_d3fd4d82581ccb83d36bdd0914c5d5f4[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_c3bf4755b70750d382579361405ea55a,
stepfunc_5732e8ab172826e0938463c0af53c81f,
NULL}; 
static const BulletStepFunc bullet_3426b944c540c1162cc1d9b1778e1289[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_132ec58c6b508eeaa618398c709e7c77,
stepfunc_5732e8ab172826e0938463c0af53c81f,
NULL}; 
static const BulletStepFunc bullet_e04cfd82867d6475b8795c9990b87dd6[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_198031dab59773a3d31e0f1322b0b68d,
stepfunc_5732e8ab172826e0938463c0af53c81f,
NULL}; 
static const BulletStepFunc bullet_6746a320b44e426b00510f5e23004620[] = {
stepfunc_e4513e546a161d1e0107d0ea1b54e073,
stepfunc_cc640c72c7237dea8372c4439c04f091,
NULL}; 
static const BulletStepFunc bullet_e8d104ed5e4c01b900e3d63ebec55509[] = {
stepfunc_321a52b2346256b63ef1feb5f226c156,
stepfunc_769bdefb02579aa79348dd03cdd26c8a,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_35fe6379fc6de0ff4972da994874ab7d,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_e4513e546a161d1e0107d0ea1b54e073(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_cc640c72c7237dea8372c4439c04f091(BulletInfo *p) { 
{
  u16 life = 5;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_c3bf4755b70750d382579361405ea55a(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_5732e8ab172826e0938463c0af53c81f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-4266, 100));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3733, 100));    p->lastBulletSpeed = (FixedPointNum(328, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3733, 100));    p->lastBulletSpeed = (FixedPointNum(328, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (32);    p->lastBulletSpeed = (FixedPointNum(282, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-32);    p->lastBulletSpeed = (FixedPointNum(282, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2133, 100));    p->lastBulletSpeed = (FixedPointNum(231, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2133, 100));    p->lastBulletSpeed = (FixedPointNum(231, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1066, 100));    p->lastBulletSpeed = (FixedPointNum(208, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1066, 100));    p->lastBulletSpeed = (FixedPointNum(208, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6746a320b44e426b00510f5e23004620;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_132ec58c6b508eeaa618398c709e7c77(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 220; 
}
static void stepfunc_198031dab59773a3d31e0f1322b0b68d(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 410; 
}
static void stepfunc_35fe6379fc6de0ff4972da994874ab7d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(888, 100));    p->lastBulletSpeed = (FixedPointNum(525, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e04cfd82867d6475b8795c9990b87dd6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(888, 100));    p->lastBulletSpeed = (FixedPointNum(350, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3426b944c540c1162cc1d9b1778e1289;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(888, 100));    p->lastBulletSpeed = (FixedPointNum(175, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d3fd4d82581ccb83d36bdd0914c5d5f4;  }
}
p->wait = 10; 
}
static void stepfunc_321a52b2346256b63ef1feb5f226c156(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (128) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_769bdefb02579aa79348dd03cdd26c8a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_c2840f94d8496664252fca440d6b6db8(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_e8d104ed5e4c01b900e3d63ebec55509; }}


