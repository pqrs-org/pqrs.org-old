// XXX uniqID XXX 2210912da37b53466f865e2967b71866 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_0278c826776c7643b1eb4805896cbdf1(BulletInfo *p); 
static void stepfunc_69b692aa851c8b1d8cf92fcff09ccdce(BulletInfo *p); 
static void stepfunc_d8f7364428204f1a0519a5dc2172f4fc(BulletInfo *p); 
static void stepfunc_bfe44cc4814a15f8356f53cb0118214b(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_288598262f8bb9b4a4b98ed0184a7e63(BulletInfo *p); 
static void stepfunc_82df5f3f53a437435dd341a53dd8e8df(BulletInfo *p); 
static void stepfunc_275b005b46b8dbe0d967e2be02c2608d(BulletInfo *p); 
static void stepfunc_7f85caac3ebc9d9bc546b28f773543cb(BulletInfo *p); 


static const BulletStepFunc bullet_9bf26a073df5f45b68f9f23c96cb21b0[] = {
stepfunc_0278c826776c7643b1eb4805896cbdf1,
stepfunc_69b692aa851c8b1d8cf92fcff09ccdce,
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_d8f7364428204f1a0519a5dc2172f4fc,
#if 0
stepfunc_bfe44cc4814a15f8356f53cb0118214b,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_beab9ce3607706de0ad6c8137aa5a2d9[] = {
stepfunc_0278c826776c7643b1eb4805896cbdf1,
stepfunc_288598262f8bb9b4a4b98ed0184a7e63,
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_82df5f3f53a437435dd341a53dd8e8df,
#if 0
stepfunc_275b005b46b8dbe0d967e2be02c2608d,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_3dd93423e7fd8a39ed06741148e3c47b[] = {
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_784e56997d6cb51da62504a6d2412004[] = {
stepfunc_7f85caac3ebc9d9bc546b28f773543cb,
NULL}; 
static void stepfunc_bfe44cc4814a15f8356f53cb0118214b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-2588, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_d8f7364428204f1a0519a5dc2172f4fc(BulletInfo *p) { 
for (u32 i = 0; i < 10; ++i) { 
stepfunc_bfe44cc4814a15f8356f53cb0118214b(p);}
p->wait = 4; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_0278c826776c7643b1eb4805896cbdf1(BulletInfo *p) { 
{
  u16 life = 4;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 4; 
}
static void stepfunc_69b692aa851c8b1d8cf92fcff09ccdce(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10481, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
}
static void stepfunc_275b005b46b8dbe0d967e2be02c2608d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2567, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_82df5f3f53a437435dd341a53dd8e8df(BulletInfo *p) { 
for (u32 i = 0; i < 10; ++i) { 
stepfunc_275b005b46b8dbe0d967e2be02c2608d(p);}
p->wait = 4; 
}
static void stepfunc_288598262f8bb9b4a4b98ed0184a7e63(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(10240, 100));    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3dd93423e7fd8a39ed06741148e3c47b;  }
}
}
static void stepfunc_7f85caac3ebc9d9bc546b28f773543cb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_beab9ce3607706de0ad6c8137aa5a2d9;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9bf26a073df5f45b68f9f23c96cb21b0;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_2210912da37b53466f865e2967b71866(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_784e56997d6cb51da62504a6d2412004; }}


