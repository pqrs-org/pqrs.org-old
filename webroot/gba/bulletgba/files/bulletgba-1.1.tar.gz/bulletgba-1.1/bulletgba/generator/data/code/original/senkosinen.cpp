// XXX uniqID XXX f82916e91b844aa7200eeaebbd9b25c8 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p); 
static void stepfunc_9a5b608b325c44e5f40af1f25e99e079(BulletInfo *p); 
static void stepfunc_eafeb9f79b0569ad2deeb51b9878f5e2(BulletInfo *p); 
static void stepfunc_b8fe7940b8760d4acd1f43af012fdcf0(BulletInfo *p); 
static void stepfunc_a12f6867d2110dd0498a6f288296dd01(BulletInfo *p); 
static void stepfunc_6ad1a5e0289335a0fdf5136aa61613b5(BulletInfo *p); 
static void stepfunc_d7af4feeb05173f282d69db8e7faf95e(BulletInfo *p); 
static void stepfunc_771e12220f040b9009a6f94d32ea98fb(BulletInfo *p); 
static void stepfunc_82952d7a49fc41b362576fe42b33e86d(BulletInfo *p); 
static void stepfunc_4be4286b1d452a5de0de6ca9ce41d6ab(BulletInfo *p); 
static void stepfunc_cceedc51895268394438a69362b143c6(BulletInfo *p); 
static void stepfunc_9cf5e3f6c5b5e2de3c70e51b4dda9536(BulletInfo *p); 
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d(BulletInfo *p); 
static void stepfunc_d07e51e18b9846f0cf36c3e5b5deda43(BulletInfo *p); 
static void stepfunc_e264ed39f5b94b6bfbca035133c800a5(BulletInfo *p); 
static void stepfunc_f44021a0918385b933d01e5c25dc0670(BulletInfo *p); 
static void stepfunc_0ce2d240b4eba445cb9f77a741570c50(BulletInfo *p); 
static void stepfunc_cde6c9a729123e6c4b97af4ef50dbfa5(BulletInfo *p); 
static void stepfunc_3ae91687fcd6be207e26c49ad3da69c5(BulletInfo *p); 
static void stepfunc_67239efb7723ea7960b8af175def8777(BulletInfo *p); 
static void stepfunc_ea4dc0d25440da61c270f6263ec4cf39(BulletInfo *p); 


static const BulletStepFunc bullet_ca9e635923de67e3c6183f83d6e9e9b5[] = {
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_9a5b608b325c44e5f40af1f25e99e079,
stepfunc_eafeb9f79b0569ad2deeb51b9878f5e2,
stepfunc_b8fe7940b8760d4acd1f43af012fdcf0,
stepfunc_b8fe7940b8760d4acd1f43af012fdcf0,
stepfunc_b8fe7940b8760d4acd1f43af012fdcf0,
stepfunc_a12f6867d2110dd0498a6f288296dd01,
stepfunc_a12f6867d2110dd0498a6f288296dd01,
stepfunc_a12f6867d2110dd0498a6f288296dd01,
stepfunc_a12f6867d2110dd0498a6f288296dd01,
stepfunc_6ad1a5e0289335a0fdf5136aa61613b5,
stepfunc_6ad1a5e0289335a0fdf5136aa61613b5,
stepfunc_6ad1a5e0289335a0fdf5136aa61613b5,
stepfunc_6ad1a5e0289335a0fdf5136aa61613b5,
stepfunc_d7af4feeb05173f282d69db8e7faf95e,
stepfunc_771e12220f040b9009a6f94d32ea98fb,
stepfunc_771e12220f040b9009a6f94d32ea98fb,
stepfunc_771e12220f040b9009a6f94d32ea98fb,
stepfunc_82952d7a49fc41b362576fe42b33e86d,
stepfunc_4be4286b1d452a5de0de6ca9ce41d6ab,
stepfunc_4be4286b1d452a5de0de6ca9ce41d6ab,
stepfunc_4be4286b1d452a5de0de6ca9ce41d6ab,
stepfunc_cceedc51895268394438a69362b143c6,
stepfunc_9cf5e3f6c5b5e2de3c70e51b4dda9536,
stepfunc_9cf5e3f6c5b5e2de3c70e51b4dda9536,
stepfunc_9cf5e3f6c5b5e2de3c70e51b4dda9536,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_a31fa488d53a3675539520bbce710b15[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_d07e51e18b9846f0cf36c3e5b5deda43,
#if 0
stepfunc_e264ed39f5b94b6bfbca035133c800a5,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_272e965573907f902148183bdc480030[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_f44021a0918385b933d01e5c25dc0670,
#if 0
stepfunc_e264ed39f5b94b6bfbca035133c800a5,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_94fad0439097d4f3d83451e86422c09b[] = {
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_cde6c9a729123e6c4b97af4ef50dbfa5,
#if 0
stepfunc_e264ed39f5b94b6bfbca035133c800a5,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_cba72353af52c003b19edeef989df670[] = {
stepfunc_3ae91687fcd6be207e26c49ad3da69c5,
stepfunc_67239efb7723ea7960b8af175def8777,
#if 0
stepfunc_e264ed39f5b94b6bfbca035133c800a5,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_1dd0460cc04dcee0f991f4cb119d6800[] = {
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d,
stepfunc_67239efb7723ea7960b8af175def8777,
#if 0
stepfunc_e264ed39f5b94b6bfbca035133c800a5,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_37cbaf2870d44aae3b0ccbec387c3a51[] = {
stepfunc_ea4dc0d25440da61c270f6263ec4cf39,
stepfunc_ea4dc0d25440da61c270f6263ec4cf39,
stepfunc_ea4dc0d25440da61c270f6263ec4cf39,
stepfunc_ea4dc0d25440da61c270f6263ec4cf39,
stepfunc_ea4dc0d25440da61c270f6263ec4cf39,
stepfunc_ea4dc0d25440da61c270f6263ec4cf39,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_e264ed39f5b94b6bfbca035133c800a5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (32);    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d(BulletInfo *p) { 
p->wait = 6; 
}
static void stepfunc_d07e51e18b9846f0cf36c3e5b5deda43(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(1848, 100));    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_e264ed39f5b94b6bfbca035133c800a5(p);}
p->wait = 1; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_9cf5e3f6c5b5e2de3c70e51b4dda9536(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (64);    p->lastBulletSpeed = (FixedPointNum(372, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a31fa488d53a3675539520bbce710b15;  }
}
}
static void stepfunc_f44021a0918385b933d01e5c25dc0670(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1848, 100));    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_e264ed39f5b94b6bfbca035133c800a5(p);}
p->wait = 1; 
}
static void stepfunc_4be4286b1d452a5de0de6ca9ce41d6ab(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (64);    p->lastBulletSpeed = (FixedPointNum(372, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_272e965573907f902148183bdc480030;  }
}
}
static void stepfunc_0ce2d240b4eba445cb9f77a741570c50(BulletInfo *p) { 
p->wait = 4; 
}
static void stepfunc_cde6c9a729123e6c4b97af4ef50dbfa5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_e264ed39f5b94b6bfbca035133c800a5(p);}
p->wait = FixedPointNum(75, 100); 
}
static void stepfunc_771e12220f040b9009a6f94d32ea98fb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (64);    p->lastBulletSpeed = (FixedPointNum(353, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_94fad0439097d4f3d83451e86422c09b;  }
}
}
static void stepfunc_67239efb7723ea7960b8af175def8777(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(75, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_e264ed39f5b94b6bfbca035133c800a5(p);}
p->wait = 1; 
}
static void stepfunc_6ad1a5e0289335a0fdf5136aa61613b5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (64);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1dd0460cc04dcee0f991f4cb119d6800;  }
}
}
static void stepfunc_a12f6867d2110dd0498a6f288296dd01(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (64);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_94fad0439097d4f3d83451e86422c09b;  }
}
}
static void stepfunc_3ae91687fcd6be207e26c49ad3da69c5(BulletInfo *p) { 
p->wait = 2; 
}
static void stepfunc_b8fe7940b8760d4acd1f43af012fdcf0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (64);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cba72353af52c003b19edeef989df670;  }
}
}
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_9a5b608b325c44e5f40af1f25e99e079(BulletInfo *p) { 
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(FixedPointNum(10, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_eafeb9f79b0569ad2deeb51b9878f5e2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (5);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cba72353af52c003b19edeef989df670;  }
}
}
static void stepfunc_d7af4feeb05173f282d69db8e7faf95e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (32);    p->lastBulletSpeed = (FixedPointNum(353, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_94fad0439097d4f3d83451e86422c09b;  }
}
}
static void stepfunc_82952d7a49fc41b362576fe42b33e86d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1848, 100));    p->lastBulletSpeed = (FixedPointNum(372, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_272e965573907f902148183bdc480030;  }
}
}
static void stepfunc_cceedc51895268394438a69362b143c6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1848, 100));    p->lastBulletSpeed = (FixedPointNum(372, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a31fa488d53a3675539520bbce710b15;  }
}
}
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_ea4dc0d25440da61c270f6263ec4cf39(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(10666, 100)+FixedPointNum(4266, 100)*FixedPointNum::random()));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ca9e635923de67e3c6183f83d6e9e9b5;  }
}
p->wait = 120; 
}


void genBulletFunc_f82916e91b844aa7200eeaebbd9b25c8(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_37cbaf2870d44aae3b0ccbec387c3a51; }}


