// XXX uniqID XXX 26ac35c0676d1df8e7d09766c7598fd1 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_9c133fab9f6c50e8637456711cfc6df7(BulletInfo *p); 
static void stepfunc_0623808f737686ba2c54df8149d8ce6d(BulletInfo *p); 
static void stepfunc_f75041243c4ff3ff73a7579ff9d8673a(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p); 
static void stepfunc_5dae280ad8aa9479f3436a1db4ae00da(BulletInfo *p); 
static void stepfunc_8e619f89af0f112c2174c8c3f3911be9(BulletInfo *p); 
static void stepfunc_95663f3346757d5b33df0c141119f436(BulletInfo *p); 
static void stepfunc_3980d358c2e85008001b92c99b35668a(BulletInfo *p); 


static const BulletStepFunc bullet_0e8b0cf3439b1b020d85551af0ae4bc5[] = {
stepfunc_9c133fab9f6c50e8637456711cfc6df7,
stepfunc_0623808f737686ba2c54df8149d8ce6d,
stepfunc_f75041243c4ff3ff73a7579ff9d8673a,
stepfunc_0623808f737686ba2c54df8149d8ce6d,
stepfunc_f75041243c4ff3ff73a7579ff9d8673a,
stepfunc_0623808f737686ba2c54df8149d8ce6d,
stepfunc_f75041243c4ff3ff73a7579ff9d8673a,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_1d45dd9b1cec2eb422f28f3c71746c81[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_8e619f89af0f112c2174c8c3f3911be9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_de7fcfa87774d7e285dd07694447591a[] = {
stepfunc_19821f11904f21483bbc290f3f120b00,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_95663f3346757d5b33df0c141119f436,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b0777c4cb283391b7ca23f0f462ae220[] = {
stepfunc_3980d358c2e85008001b92c99b35668a,
NULL}; 
static void stepfunc_8e619f89af0f112c2174c8c3f3911be9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(8533, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_19821f11904f21483bbc290f3f120b00(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_5dae280ad8aa9479f3436a1db4ae00da(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_95663f3346757d5b33df0c141119f436(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-8533, 100));    p->lastBulletSpeed = (FixedPointNum(160, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 5; 
}
static void stepfunc_0623808f737686ba2c54df8149d8ce6d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_de7fcfa87774d7e285dd07694447591a;  }
}
p->wait = 10; 
}
static void stepfunc_f75041243c4ff3ff73a7579ff9d8673a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4266, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1d45dd9b1cec2eb422f28f3c71746c81;  }
}
p->wait = 10; 
}
static void stepfunc_9c133fab9f6c50e8637456711cfc6df7(BulletInfo *p) { 
p->wait = (FixedPointNum(20) + FixedPointNum(10) * FixedPointNum::random()); 
}
static void stepfunc_3980d358c2e85008001b92c99b35668a(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0e8b0cf3439b1b020d85551af0ae4bc5;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_26ac35c0676d1df8e7d09766c7598fd1(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_b0777c4cb283391b7ca23f0f462ae220; }}


