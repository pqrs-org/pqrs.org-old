// XXX uniqID XXX e573dfcbe939f3d9d82c31155e82fb3b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_2738f675646ea94a8dda3df7296ec342(BulletInfo *p); 
static void stepfunc_3b7379817f321b22fcd543bb23b2dae7(BulletInfo *p); 
static void stepfunc_843f3d7623e58f48ee0ed459de0d4b6b(BulletInfo *p); 
static void stepfunc_0fb541a5eddf4321f8599ce8239a7169(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_83e5485fcc28bb6fc69e7fa519fcf141(BulletInfo *p); 
static void stepfunc_ae5221cff49dd6e76f158e88042a1c8c(BulletInfo *p); 


static const BulletStepFunc bullet_b723e9bc2cca3eb1b8e8eefe48ea9b72[] = {
stepfunc_2738f675646ea94a8dda3df7296ec342,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_0fb541a5eddf4321f8599ce8239a7169,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_b3a6280b756e1d64325291a8dd6268cb[] = {
stepfunc_83e5485fcc28bb6fc69e7fa519fcf141,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_843f3d7623e58f48ee0ed459de0d4b6b,
stepfunc_ae5221cff49dd6e76f158e88042a1c8c,
#if 0
stepfunc_3b7379817f321b22fcd543bb23b2dae7,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_3b7379817f321b22fcd543bb23b2dae7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1422, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_843f3d7623e58f48ee0ed459de0d4b6b(BulletInfo *p) { 
p->wait = 6; 
}
static void stepfunc_0fb541a5eddf4321f8599ce8239a7169(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((-FixedPointNum(5688, 100)-FixedPointNum(101, 100)+FixedPointNum::random()-FixedPointNum(35, 100)));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_3b7379817f321b22fcd543bb23b2dae7(p);}
}
static void stepfunc_2738f675646ea94a8dda3df7296ec342(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(189, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_3b7379817f321b22fcd543bb23b2dae7(p);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_ae5221cff49dd6e76f158e88042a1c8c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((-FixedPointNum(5688, 100)-(-FixedPointNum(71, 100))*FixedPointNum(142, 100)+FixedPointNum::random()-FixedPointNum(35, 100)));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_3b7379817f321b22fcd543bb23b2dae7(p);}
}
static void stepfunc_83e5485fcc28bb6fc69e7fa519fcf141(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-5878, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 4; ++i) { 
stepfunc_3b7379817f321b22fcd543bb23b2dae7(p);}
}


void genBulletFunc_e573dfcbe939f3d9d82c31155e82fb3b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_b3a6280b756e1d64325291a8dd6268cb; }  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_b723e9bc2cca3eb1b8e8eefe48ea9b72; }}


