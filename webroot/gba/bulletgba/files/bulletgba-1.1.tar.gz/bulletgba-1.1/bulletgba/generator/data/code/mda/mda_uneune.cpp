// XXX uniqID XXX fea26560be0cc6087fa39f009151c461 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_18064ce06d1489c819af3deed34a6cb9(BulletInfo *p); 
static void stepfunc_834b2628a81310801acc7d201e5eea6b(BulletInfo *p); 
static void stepfunc_7170921f96b6f610359f79cef8e071be(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_cf98393ac7c05656fa2760aca568b963(BulletInfo *p); 
static void stepfunc_b4b77eb147861988160d907e694d1516(BulletInfo *p); 
static void stepfunc_adaff5f0c74ded8e05453ebb7a0a0818(BulletInfo *p); 
static void stepfunc_f249d8e31162778ffa2bcda577a428c8(BulletInfo *p); 
static void stepfunc_02e2d20c4f445fb707d72e2f0bf075cf(BulletInfo *p); 
static void stepfunc_6b596df631db6879e6463073082c17c4(BulletInfo *p); 
static void stepfunc_5df75a1b0160d7da461d24cf5a01e643(BulletInfo *p); 
static void stepfunc_0472cbf66635cb84a25e1ac031f579c7(BulletInfo *p); 


static const BulletStepFunc bullet_7dcf2484bbea80ae790a618716640129[] = {
stepfunc_18064ce06d1489c819af3deed34a6cb9,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_7170921f96b6f610359f79cef8e071be,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_834b2628a81310801acc7d201e5eea6b,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_a0dfd1356d3eda4dca5665a3c844a24c[] = {
stepfunc_cf98393ac7c05656fa2760aca568b963,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_adaff5f0c74ded8e05453ebb7a0a0818,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_b4b77eb147861988160d907e694d1516,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_488f97258934e07c6ae8685338ba33bc[] = {
stepfunc_f249d8e31162778ffa2bcda577a428c8,
stepfunc_02e2d20c4f445fb707d72e2f0bf075cf,
stepfunc_6b596df631db6879e6463073082c17c4,
stepfunc_6b596df631db6879e6463073082c17c4,
stepfunc_6b596df631db6879e6463073082c17c4,
stepfunc_6b596df631db6879e6463073082c17c4,
stepfunc_6b596df631db6879e6463073082c17c4,
stepfunc_6b596df631db6879e6463073082c17c4,
stepfunc_6b596df631db6879e6463073082c17c4,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_5d29de46387d6b2e9125250f897590a9[] = {
stepfunc_f249d8e31162778ffa2bcda577a428c8,
stepfunc_02e2d20c4f445fb707d72e2f0bf075cf,
stepfunc_5df75a1b0160d7da461d24cf5a01e643,
stepfunc_5df75a1b0160d7da461d24cf5a01e643,
stepfunc_5df75a1b0160d7da461d24cf5a01e643,
stepfunc_5df75a1b0160d7da461d24cf5a01e643,
stepfunc_5df75a1b0160d7da461d24cf5a01e643,
stepfunc_5df75a1b0160d7da461d24cf5a01e643,
stepfunc_5df75a1b0160d7da461d24cf5a01e643,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_8d314febe3e9284250bd064ab01f72cf[] = {
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_e06c81873882198489ef17bcf39e3641[] = {
stepfunc_0472cbf66635cb84a25e1ac031f579c7,
NULL}; 
static void stepfunc_5df75a1b0160d7da461d24cf5a01e643(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(3912, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_f249d8e31162778ffa2bcda577a428c8(BulletInfo *p) { 
p->wait = 90; 
}
static void stepfunc_02e2d20c4f445fb707d72e2f0bf075cf(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d314febe3e9284250bd064ab01f72cf;  }
}
}
static void stepfunc_834b2628a81310801acc7d201e5eea6b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5d29de46387d6b2e9125250f897590a9;  }
}
p->wait = 4; 
}
static void stepfunc_18064ce06d1489c819af3deed34a6cb9(BulletInfo *p) { 
{
  u16 life = 21;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(64)*(-FixedPointNum(71, 100))*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_7170921f96b6f610359f79cef8e071be(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(128)*(-FixedPointNum(71, 100))*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_6b596df631db6879e6463073082c17c4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4620, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
p->wait = 3; 
}
static void stepfunc_b4b77eb147861988160d907e694d1516(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_488f97258934e07c6ae8685338ba33bc;  }
}
p->wait = 4; 
}
static void stepfunc_cf98393ac7c05656fa2760aca568b963(BulletInfo *p) { 
{
  u16 life = 21;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(4551, 100)*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_adaff5f0c74ded8e05453ebb7a0a0818(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(9102, 100)*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_0472cbf66635cb84a25e1ac031f579c7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128)-FixedPointNum(1011, 100)+(FixedPointNum(3034, 100)*FixedPointNum::random())));    p->lastBulletSpeed = (FixedPointNum(135, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a0dfd1356d3eda4dca5665a3c844a24c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128)-(-FixedPointNum(1011, 100))+((-FixedPointNum(71, 100))*FixedPointNum(4266, 100)*FixedPointNum::random())));    p->lastBulletSpeed = (FixedPointNum(135, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7dcf2484bbea80ae790a618716640129;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_fea26560be0cc6087fa39f009151c461(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_e06c81873882198489ef17bcf39e3641; }}


