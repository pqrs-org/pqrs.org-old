// XXX uniqID XXX 71f30ece3e8720a6ebd291232949bb0f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_ff0a11128094ea71bbc55be56a3b2643(BulletInfo *p); 
static void stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c(BulletInfo *p); 
static void stepfunc_c2e590ae7f13483ef87bda76a5531342(BulletInfo *p); 
static void stepfunc_2d8d20189622e956f048cb5da553d994(BulletInfo *p); 
static void stepfunc_14cc6b3827b90413720c8e9a83ae50dd(BulletInfo *p); 
static void stepfunc_c3b756461ba1f824d06b0d5c9b42b398(BulletInfo *p); 
static void stepfunc_639e647cae7980e67b0da4d5014e27e3(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_0509de70a2de21f6c64b7a042f6b633f[] = {
stepfunc_ff0a11128094ea71bbc55be56a3b2643,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_2d8d20189622e956f048cb5da553d994,
stepfunc_14cc6b3827b90413720c8e9a83ae50dd,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_639e647cae7980e67b0da4d5014e27e3,
#if 0
stepfunc_c3b756461ba1f824d06b0d5c9b42b398,
#endif
stepfunc_2d8d20189622e956f048cb5da553d994,
stepfunc_ff0a11128094ea71bbc55be56a3b2643,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_c2e590ae7f13483ef87bda76a5531342,
#if 0
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1137, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_c2e590ae7f13483ef87bda76a5531342(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1289, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c(p);}
p->wait = 3; 
}
static void stepfunc_c3b756461ba1f824d06b0d5c9b42b398(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1137, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_639e647cae7980e67b0da4d5014e27e3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1289, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(10, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_c3b756461ba1f824d06b0d5c9b42b398(p);}
p->wait = 3; 
}
static void stepfunc_ff0a11128094ea71bbc55be56a3b2643(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(32)+FixedPointNum::random()*FixedPointNum(64)));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_1a8eb525df67a4832ec0c0ff2df07a6c(p);}
p->wait = 3; 
}
static void stepfunc_2d8d20189622e956f048cb5da553d994(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_14cc6b3827b90413720c8e9a83ae50dd(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(32)+FixedPointNum::random()*FixedPointNum(64)));    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_c3b756461ba1f824d06b0d5c9b42b398(p);}
p->wait = 3; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_71f30ece3e8720a6ebd291232949bb0f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_0509de70a2de21f6c64b7a042f6b633f; }}


