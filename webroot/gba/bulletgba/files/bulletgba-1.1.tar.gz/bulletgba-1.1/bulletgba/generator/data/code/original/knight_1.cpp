// XXX uniqID XXX 0b3c637bdc5e779e2bb21428ce9678ef XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_f4323c2faff95e5d43596ceb701f1f8c(BulletInfo *p); 
static void stepfunc_88c4465addc145d8adda1ea89d637145(BulletInfo *p); 
static void stepfunc_f1fca155eb99c7d0712c35b74e0e79b9(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 
static void stepfunc_af6f30095ad202a2168cf8abd106b5ca(BulletInfo *p); 
static void stepfunc_9e95b4e0bc3d774fdaaa8b17e43477e3(BulletInfo *p); 
static void stepfunc_5a736959fe69f8a1a8d5854c75dc9df7(BulletInfo *p); 
static void stepfunc_6e895e2dd05a396b4dcb8b431374d990(BulletInfo *p); 
static void stepfunc_ccbd694f29ed6a052bf21f0f27a517de(BulletInfo *p); 
static void stepfunc_a2eb5a8bddd219fae11915f737e719a5(BulletInfo *p); 
static void stepfunc_38eb9d19e1217c0be83606377463f25d(BulletInfo *p); 


static const BulletStepFunc bullet_ed515be477261083fd2a5a4ccf5bc1fc[] = {
stepfunc_f4323c2faff95e5d43596ceb701f1f8c,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_f1fca155eb99c7d0712c35b74e0e79b9,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_f1fca155eb99c7d0712c35b74e0e79b9,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_f1fca155eb99c7d0712c35b74e0e79b9,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_88c4465addc145d8adda1ea89d637145,
stepfunc_f1fca155eb99c7d0712c35b74e0e79b9,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static const BulletStepFunc bullet_6d1cf317cf010177aaeafd4fa9c0d180[] = {
stepfunc_af6f30095ad202a2168cf8abd106b5ca,
stepfunc_9e95b4e0bc3d774fdaaa8b17e43477e3,
stepfunc_5a736959fe69f8a1a8d5854c75dc9df7,
#if 0
stepfunc_6e895e2dd05a396b4dcb8b431374d990,
#endif
stepfunc_ccbd694f29ed6a052bf21f0f27a517de,
#if 0
stepfunc_6e895e2dd05a396b4dcb8b431374d990,
#endif
stepfunc_a2eb5a8bddd219fae11915f737e719a5,
#if 0
stepfunc_6e895e2dd05a396b4dcb8b431374d990,
#endif
NULL}; 
static const BulletStepFunc bullet_4bef6bdd15b311dc63f82a1c8236eb11[] = {
stepfunc_38eb9d19e1217c0be83606377463f25d,
NULL}; 
static void stepfunc_6e895e2dd05a396b4dcb8b431374d990(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(142, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_af6f30095ad202a2168cf8abd106b5ca(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(FixedPointNum(0, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_9e95b4e0bc3d774fdaaa8b17e43477e3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = SelfPos::getAngle(p) + (0) - p->getAngle();p->setRound(speed, life);}
p->wait = 5; 
}
static void stepfunc_5a736959fe69f8a1a8d5854c75dc9df7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1422, 100));    p->lastBulletSpeed = (FixedPointNum(70, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_6e895e2dd05a396b4dcb8b431374d990(p);}
p->wait = 10; 
}
static void stepfunc_ccbd694f29ed6a052bf21f0f27a517de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(70, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_6e895e2dd05a396b4dcb8b431374d990(p);}
p->wait = 10; 
}
static void stepfunc_a2eb5a8bddd219fae11915f737e719a5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(1422, 100));    p->lastBulletSpeed = (FixedPointNum(70, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 29; ++i) { 
stepfunc_6e895e2dd05a396b4dcb8b431374d990(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_88c4465addc145d8adda1ea89d637145(BulletInfo *p) { 
{
  u16 life = 10;  FixedPointNum speed = FixedPointNum(SelfPos::getAngle(p) + (0) - p->getAngle(), life);;p->setRound(speed, life);}
p->wait = 10; 
}
static void stepfunc_f1fca155eb99c7d0712c35b74e0e79b9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(4977, 100) + FixedPointNum(1422, 100) * FixedPointNum::random()));    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6d1cf317cf010177aaeafd4fa9c0d180;  }
}
}
static void stepfunc_f4323c2faff95e5d43596ceb701f1f8c(BulletInfo *p) { 
{
  u16 life = 120;  FixedPointNum speed = FixedPointNum(FixedPointNum(110, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_38eb9d19e1217c0be83606377463f25d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ed515be477261083fd2a5a4ccf5bc1fc;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_0b3c637bdc5e779e2bb21428ce9678ef(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_4bef6bdd15b311dc63f82a1c8236eb11; }}


