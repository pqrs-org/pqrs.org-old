// XXX uniqID XXX 237f6e0284685d6720998145dff44980 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p); 
static void stepfunc_f2d413d1604a79e445357cd400d8e5ff(BulletInfo *p); 
static void stepfunc_3d4e34759e599158efb21c50772fcb17(BulletInfo *p); 
static void stepfunc_84f2be655857612d5169ed4cfb7a86b8(BulletInfo *p); 
static void stepfunc_38419e2dd8a5b7a032aac14364321eda(BulletInfo *p); 
static void stepfunc_0701168a11814cb2f70da92a859015a7(BulletInfo *p); 
static void stepfunc_ace464d569c8a01b493351f3e5fc0fac(BulletInfo *p); 
static void stepfunc_b3edefc550666210caccd41201030309(BulletInfo *p); 
static void stepfunc_de0bdff43bc90d4c37534d7ccd2bc311(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_d8c2421fd9e64305fc123f0d9579ada8(BulletInfo *p); 
static void stepfunc_238081522080fdc09930fb597091ad79(BulletInfo *p); 
static void stepfunc_26db99d796c45027cb7d765111e2ed07(BulletInfo *p); 
static void stepfunc_a390213b5fbf0bb17e157a63e4489372(BulletInfo *p); 
static void stepfunc_a80062749f6fd3b6bbd923963a09ae0f(BulletInfo *p); 
static void stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d(BulletInfo *p); 
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p); 
static void stepfunc_52c56020ae2227220fa9c14ae75de9de(BulletInfo *p); 
static void stepfunc_ef1a5ba005566479275407b199131902(BulletInfo *p); 
static void stepfunc_5291b2b7efcbc87685689dfe99c2cc88(BulletInfo *p); 
static void stepfunc_4d35a33aa01e8988a1ed839aa8a2855c(BulletInfo *p); 
static void stepfunc_4ae3450aa718aac4d25cfde7440ed647(BulletInfo *p); 
static void stepfunc_33693b80193b8067ceae31d21dcb335e(BulletInfo *p); 
static void stepfunc_8a8bcd844943eca73be887717fefc02f(BulletInfo *p); 
static void stepfunc_f44f08ec4c4fdaec515fbcc163428007(BulletInfo *p); 
static void stepfunc_ecb098c42548be047b73bc49af2ca8f0(BulletInfo *p); 
static void stepfunc_59d5cb5189699d007271f4f297e302d3(BulletInfo *p); 
static void stepfunc_b33910e7b7a046cc975198fc600914ce(BulletInfo *p); 
static void stepfunc_24fd4c8d1ab32e9d0048ccf0e67e7ec9(BulletInfo *p); 
static void stepfunc_fba73ec45c42559deb7ec866f1c1c340(BulletInfo *p); 
static void stepfunc_4e18e85568131b2cb98051010f792d1d(BulletInfo *p); 
static void stepfunc_b58836e150d97b24af37643594483317(BulletInfo *p); 
static void stepfunc_f499e1169d686e00d501c6aab697ea9d(BulletInfo *p); 
static void stepfunc_b96f474db687c647f60faa132c441e6f(BulletInfo *p); 
static void stepfunc_18267b9db3b79d4a7b28676eafebaeee(BulletInfo *p); 
static void stepfunc_1f7470c99a2c14f6f4c7486a43ca734f(BulletInfo *p); 
static void stepfunc_5192f691b0eba9b3288ae1bb8118b144(BulletInfo *p); 
static void stepfunc_07a4ee3b374c48122b953341717fc9ed(BulletInfo *p); 
static void stepfunc_8fdeb0bfc72576c447b4b7a50931b9b9(BulletInfo *p); 
static void stepfunc_ce321827d006c81c85cc42bb369417da(BulletInfo *p); 
static void stepfunc_018e613baffa9e0e665fc0519acc2a7c(BulletInfo *p); 
static void stepfunc_313ea45bfd43742bb4708911d54dfe8a(BulletInfo *p); 
static void stepfunc_094822c75463703ae6ce0ae155293ebc(BulletInfo *p); 
static void stepfunc_a5213b024e6ece0456faaf2c1d48ba66(BulletInfo *p); 
static void stepfunc_01a5424f0919326d4411c24853440c25(BulletInfo *p); 
static void stepfunc_43f0909f3ee1b16d0b939ab03f38373d(BulletInfo *p); 
static void stepfunc_bb67c9502feaaa59b85d4002259e1032(BulletInfo *p); 


static const BulletStepFunc bullet_ee69e181e08c5f003e54f68737b1ce4d[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_f2d413d1604a79e445357cd400d8e5ff,
stepfunc_3d4e34759e599158efb21c50772fcb17,
stepfunc_84f2be655857612d5169ed4cfb7a86b8,
stepfunc_38419e2dd8a5b7a032aac14364321eda,
stepfunc_0701168a11814cb2f70da92a859015a7,
stepfunc_ace464d569c8a01b493351f3e5fc0fac,
stepfunc_b3edefc550666210caccd41201030309,
stepfunc_b3edefc550666210caccd41201030309,
stepfunc_b3edefc550666210caccd41201030309,
stepfunc_b3edefc550666210caccd41201030309,
stepfunc_de0bdff43bc90d4c37534d7ccd2bc311,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_469ea02e69dd42a0caa9be655e89e829[] = {
stepfunc_d8c2421fd9e64305fc123f0d9579ada8,
NULL}; 
static const BulletStepFunc bullet_e00798121ef7289f4f6793bde182d86e[] = {
stepfunc_238081522080fdc09930fb597091ad79,
stepfunc_26db99d796c45027cb7d765111e2ed07,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_26db99d796c45027cb7d765111e2ed07,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d,
#if 0
stepfunc_a80062749f6fd3b6bbd923963a09ae0f,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_026502f62c0feda611f9edfaa6eea61d[] = {
stepfunc_238081522080fdc09930fb597091ad79,
stepfunc_52c56020ae2227220fa9c14ae75de9de,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_52c56020ae2227220fa9c14ae75de9de,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
stepfunc_5291b2b7efcbc87685689dfe99c2cc88,
#if 0
stepfunc_ef1a5ba005566479275407b199131902,
#if 0
stepfunc_a390213b5fbf0bb17e157a63e4489372,
#endif
#endif
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_5c0e76300f9b12245b43fddcee204859[] = {
stepfunc_4d35a33aa01e8988a1ed839aa8a2855c,
stepfunc_4ae3450aa718aac4d25cfde7440ed647,
stepfunc_4ae3450aa718aac4d25cfde7440ed647,
stepfunc_4ae3450aa718aac4d25cfde7440ed647,
stepfunc_4ae3450aa718aac4d25cfde7440ed647,
stepfunc_4ae3450aa718aac4d25cfde7440ed647,
stepfunc_4ae3450aa718aac4d25cfde7440ed647,
stepfunc_4ae3450aa718aac4d25cfde7440ed647,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_d01403525c7602ade6781dcc4e5b294e[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_8a8bcd844943eca73be887717fefc02f,
stepfunc_f44f08ec4c4fdaec515fbcc163428007,
NULL}; 
static const BulletStepFunc bullet_74801642e1d5ea13205a072104527510[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_8a8bcd844943eca73be887717fefc02f,
stepfunc_ecb098c42548be047b73bc49af2ca8f0,
NULL}; 
static const BulletStepFunc bullet_22aae5a95d26da46b4211c0067adc64d[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_8a8bcd844943eca73be887717fefc02f,
stepfunc_59d5cb5189699d007271f4f297e302d3,
NULL}; 
static const BulletStepFunc bullet_8ad7c49c740762ec8a6d600a5d7983bb[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_8a8bcd844943eca73be887717fefc02f,
stepfunc_b33910e7b7a046cc975198fc600914ce,
NULL}; 
static const BulletStepFunc bullet_0f7e9cb4b179e13f661c5cc08b7d3d82[] = {
stepfunc_24fd4c8d1ab32e9d0048ccf0e67e7ec9,
stepfunc_fba73ec45c42559deb7ec866f1c1c340,
stepfunc_4e18e85568131b2cb98051010f792d1d,
NULL}; 
static const BulletStepFunc bullet_4ef3bee31021e2ba3b39893334da615a[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_f499e1169d686e00d501c6aab697ea9d,
NULL}; 
static const BulletStepFunc bullet_4a2f39b09d2a9d12dd3b8cf0f155b5d9[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_b96f474db687c647f60faa132c441e6f,
NULL}; 
static const BulletStepFunc bullet_9259611fb23a40cd80ad850ba3bfaa73[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_18267b9db3b79d4a7b28676eafebaeee,
NULL}; 
static const BulletStepFunc bullet_a9062b2687cc293a98f051830f0aaec6[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_1f7470c99a2c14f6f4c7486a43ca734f,
NULL}; 
static const BulletStepFunc bullet_6c7680ad94ccf18173b6647ff239159a[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_5192f691b0eba9b3288ae1bb8118b144,
NULL}; 
static const BulletStepFunc bullet_5784031a889eada8b3ba0ed93ddcef0b[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_07a4ee3b374c48122b953341717fc9ed,
NULL}; 
static const BulletStepFunc bullet_3299d1534a998a362b6224c8c8eb5c23[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_8fdeb0bfc72576c447b4b7a50931b9b9,
NULL}; 
static const BulletStepFunc bullet_946de7c73383519141c2af8ae3f0ab0a[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_ce321827d006c81c85cc42bb369417da,
NULL}; 
static const BulletStepFunc bullet_4c770b310d8a2f48c9b14f22e3fdce03[] = {
stepfunc_33693b80193b8067ceae31d21dcb335e,
stepfunc_b58836e150d97b24af37643594483317,
stepfunc_018e613baffa9e0e665fc0519acc2a7c,
NULL}; 
static const BulletStepFunc bullet_fabd378733959db3e0dd4d3bf97597f1[] = {
stepfunc_24fd4c8d1ab32e9d0048ccf0e67e7ec9,
stepfunc_313ea45bfd43742bb4708911d54dfe8a,
stepfunc_094822c75463703ae6ce0ae155293ebc,
NULL}; 
static const BulletStepFunc bullet_bfee399bfcc01b6c8b37e1fd0485699a[] = {
stepfunc_a5213b024e6ece0456faaf2c1d48ba66,
stepfunc_01a5424f0919326d4411c24853440c25,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_43f0909f3ee1b16d0b939ab03f38373d,
stepfunc_bb67c9502feaaa59b85d4002259e1032,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_bb67c9502feaaa59b85d4002259e1032(BulletInfo *p) { 
p->wait = 150; 
}
static void stepfunc_33693b80193b8067ceae31d21dcb335e(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_b58836e150d97b24af37643594483317(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 6; 
}
static void stepfunc_f499e1169d686e00d501c6aab697ea9d(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-82, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_b96f474db687c647f60faa132c441e6f(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-134, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_18267b9db3b79d4a7b28676eafebaeee(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-186, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_1f7470c99a2c14f6f4c7486a43ca734f(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-238, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_5192f691b0eba9b3288ae1bb8118b144(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-290, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_07a4ee3b374c48122b953341717fc9ed(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-342, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_8fdeb0bfc72576c447b4b7a50931b9b9(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-394, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_ce321827d006c81c85cc42bb369417da(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-446, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_018e613baffa9e0e665fc0519acc2a7c(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-498, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_24fd4c8d1ab32e9d0048ccf0e67e7ec9(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_313ea45bfd43742bb4708911d54dfe8a(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 6; 
}
static void stepfunc_094822c75463703ae6ce0ae155293ebc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-550, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_d8c2421fd9e64305fc123f0d9579ada8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (128);    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_fabd378733959db3e0dd4d3bf97597f1;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4c770b310d8a2f48c9b14f22e3fdce03;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_946de7c73383519141c2af8ae3f0ab0a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_3299d1534a998a362b6224c8c8eb5c23;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5784031a889eada8b3ba0ed93ddcef0b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6c7680ad94ccf18173b6647ff239159a;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_a9062b2687cc293a98f051830f0aaec6;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9259611fb23a40cd80ad850ba3bfaa73;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4a2f39b09d2a9d12dd3b8cf0f155b5d9;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-30, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_4ef3bee31021e2ba3b39893334da615a;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_a390213b5fbf0bb17e157a63e4489372(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-60, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a80062749f6fd3b6bbd923963a09ae0f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-202, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a390213b5fbf0bb17e157a63e4489372(p);}
}
static void stepfunc_bb1a47d212e3cd883cfb0f83f7eba80d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1123, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a390213b5fbf0bb17e157a63e4489372(p);}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a80062749f6fd3b6bbd923963a09ae0f(p);}
}
static void stepfunc_238081522080fdc09930fb597091ad79(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 12; 
}
static void stepfunc_26db99d796c45027cb7d765111e2ed07(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13634, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a390213b5fbf0bb17e157a63e4489372(p);}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a80062749f6fd3b6bbd923963a09ae0f(p);}
p->wait = 1; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_ef1a5ba005566479275407b199131902(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(202, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a390213b5fbf0bb17e157a63e4489372(p);}
}
static void stepfunc_5291b2b7efcbc87685689dfe99c2cc88(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1123, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a390213b5fbf0bb17e157a63e4489372(p);}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_ef1a5ba005566479275407b199131902(p);}
}
static void stepfunc_52c56020ae2227220fa9c14ae75de9de(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11965, 100));    p->lastBulletSpeed = (7);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_a390213b5fbf0bb17e157a63e4489372(p);}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_ef1a5ba005566479275407b199131902(p);}
p->wait = 1; 
}
static void stepfunc_8a8bcd844943eca73be887717fefc02f(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_f44f08ec4c4fdaec515fbcc163428007(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-52, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_ecb098c42548be047b73bc49af2ca8f0(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-89, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_59d5cb5189699d007271f4f297e302d3(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-126, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_b33910e7b7a046cc975198fc600914ce(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(-163, 100) - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_fba73ec45c42559deb7ec866f1c1c340(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_4e18e85568131b2cb98051010f792d1d(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = -2 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_4ae3450aa718aac4d25cfde7440ed647(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (28);    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f7e9cb4b179e13f661c5cc08b7d3d82;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ad7c49c740762ec8a6d600a5d7983bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_22aae5a95d26da46b4211c0067adc64d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_74801642e1d5ea13205a072104527510;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d01403525c7602ade6781dcc4e5b294e;  }
}
}
static void stepfunc_4d35a33aa01e8988a1ed839aa8a2855c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (30);    p->lastBulletSpeed = (4);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_0f7e9cb4b179e13f661c5cc08b7d3d82;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8ad7c49c740762ec8a6d600a5d7983bb;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_22aae5a95d26da46b4211c0067adc64d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_74801642e1d5ea13205a072104527510;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-50, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d01403525c7602ade6781dcc4e5b294e;  }
}
}
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_f2d413d1604a79e445357cd400d8e5ff(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_3d4e34759e599158efb21c50772fcb17(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + ((-FixedPointNum(128)-FixedPointNum(32)+FixedPointNum(64)*FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 5 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}
static void stepfunc_84f2be655857612d5169ed4cfb7a86b8(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c0e76300f9b12245b43fddcee204859;  }
}
p->wait = 10; 
}
static void stepfunc_38419e2dd8a5b7a032aac14364321eda(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5c0e76300f9b12245b43fddcee204859;  }
}
p->wait = 1; 
}
static void stepfunc_0701168a11814cb2f70da92a859015a7(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (64);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_026502f62c0feda611f9edfaa6eea61d;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (-64);    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e00798121ef7289f4f6793bde182d86e;  }
}
p->wait = 0; 
}
static void stepfunc_ace464d569c8a01b493351f3e5fc0fac(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = p->getAngle() + ((FixedPointNum(128)-FixedPointNum(4266, 100)+FixedPointNum(8533, 100)*FixedPointNum::random())) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 5 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
static void stepfunc_b3edefc550666210caccd41201030309(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_469ea02e69dd42a0caa9be655e89e829;  }
}
p->wait = 5; 
}
static void stepfunc_de0bdff43bc90d4c37534d7ccd2bc311(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_469ea02e69dd42a0caa9be655e89e829;  }
}
p->wait = 10; 
}
static void stepfunc_43f0909f3ee1b16d0b939ab03f38373d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256)*FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(270, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_ee69e181e08c5f003e54f68737b1ce4d;  }
}
}
static void stepfunc_a5213b024e6ece0456faaf2c1d48ba66(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (128) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 16; 
}
static void stepfunc_01a5424f0919326d4411c24853440c25(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}


void genBulletFunc_237f6e0284685d6720998145dff44980(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_bfee399bfcc01b6c8b37e1fd0485699a; }}


