// XXX uniqID XXX c9f77400f1af8612bb0971eb7fd23d81 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_15c084e5082c56f0a1e56ddb3380d015(BulletInfo *p); 
static void stepfunc_bd859d74cd13224690c038e8028512e3(BulletInfo *p); 
static void stepfunc_8e225106a4a734a0eb5ef3e2b4bc2d22(BulletInfo *p); 
static void stepfunc_9e209ed60be8392850347cd0e5320231(BulletInfo *p); 
static void stepfunc_cf00ae1f1b4112a53d7daff156c51ab2(BulletInfo *p); 
static void stepfunc_a3e8bc6d395e1f559b1435dd06c4e2f0(BulletInfo *p); 
static void stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329(BulletInfo *p); 
static void stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13(BulletInfo *p); 
static void stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_2bfa32d749a801f0c70d7372ef88de6b[] = {
stepfunc_15c084e5082c56f0a1e56ddb3380d015,
stepfunc_bd859d74cd13224690c038e8028512e3,
#if 0
stepfunc_8e225106a4a734a0eb5ef3e2b4bc2d22,
#endif
stepfunc_bd859d74cd13224690c038e8028512e3,
#if 0
stepfunc_9e209ed60be8392850347cd0e5320231,
#endif
stepfunc_bd859d74cd13224690c038e8028512e3,
#if 0
stepfunc_cf00ae1f1b4112a53d7daff156c51ab2,
#endif
stepfunc_bd859d74cd13224690c038e8028512e3,
#if 0
stepfunc_a3e8bc6d395e1f559b1435dd06c4e2f0,
#endif
NULL}; 
static const BulletStepFunc bullet_7ee7a5c44b0c9eb70f6ef86de1290739[] = {
stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf,
stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf,
stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf,
stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf,
stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf,
stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13,
stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_c9ce1d16e6927c1b0db26a5ffece2ddf(BulletInfo *p) { 
p->wait = 100; 
}
static void stepfunc_a3e8bc6d395e1f559b1435dd06c4e2f0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (16);    p->lastBulletSpeed = (FixedPointNum(90, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_cf00ae1f1b4112a53d7daff156c51ab2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (16);    p->lastBulletSpeed = (FixedPointNum(110, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9e209ed60be8392850347cd0e5320231(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (16);    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_8e225106a4a734a0eb5ef3e2b4bc2d22(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (16);    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_15c084e5082c56f0a1e56ddb3380d015(BulletInfo *p) { 
p->wait = 35; 
}
static void stepfunc_bd859d74cd13224690c038e8028512e3(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256)*FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(150, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 15; ++i) { 
stepfunc_8e225106a4a734a0eb5ef3e2b4bc2d22(p);}
for (u32 i = 0; i < 16; ++i) { 
stepfunc_9e209ed60be8392850347cd0e5320231(p);}
for (u32 i = 0; i < 16; ++i) { 
stepfunc_cf00ae1f1b4112a53d7daff156c51ab2(p);}
for (u32 i = 0; i < 16; ++i) { 
stepfunc_a3e8bc6d395e1f559b1435dd06c4e2f0(p);}
}
static void stepfunc_1bb9046e36fd93a0cfe41a98f1ef5b13(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1422, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2bfa32d749a801f0c70d7372ef88de6b;  }
}
p->wait = 0; 
}
static void stepfunc_d7940ce60fe8a87f0e2ea1441b6d4329(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3555, 100));    p->lastBulletSpeed = (FixedPointNum(250, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2bfa32d749a801f0c70d7372ef88de6b;  }
}
p->wait = 0; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_c9f77400f1af8612bb0971eb7fd23d81(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_7ee7a5c44b0c9eb70f6ef86de1290739; }}


