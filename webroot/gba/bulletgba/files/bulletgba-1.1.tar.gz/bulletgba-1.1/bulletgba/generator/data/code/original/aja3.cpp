// XXX uniqID XXX 526555bad717a27ce6ac8e64de6be89f XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e9975110ae887004b7f0ebc8a71940ed(BulletInfo *p); 
static void stepfunc_c9964d943844c79757b1364dd42d4d42(BulletInfo *p); 
static void stepfunc_b925b712a591a5a8e7c30ce919ce6420(BulletInfo *p); 
static void stepfunc_8e45cf31097dac7153fd76c46501b160(BulletInfo *p); 
static void stepfunc_d999f5e2d4c6f7bb3622ae7218c91777(BulletInfo *p); 
static void stepfunc_9604d530b79210bcb56507e3e9836fc6(BulletInfo *p); 
static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p); 
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p); 
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p); 
static void stepfunc_70abeb66cf8ca6f7a3f32ac9da274cb6(BulletInfo *p); 
static void stepfunc_0ce2d240b4eba445cb9f77a741570c50(BulletInfo *p); 
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p); 
static void stepfunc_97b0e9d2783130918fd822363a2502b5(BulletInfo *p); 
static void stepfunc_6f4601da7d31ad6bee0d38daffb976d0(BulletInfo *p); 
static void stepfunc_04d2a48b677fab8d2e7c97449751d116(BulletInfo *p); 
static void stepfunc_b695771ad1e39371469eed83efa5ce72(BulletInfo *p); 
static void stepfunc_efd4e4cc5048d613c3afa5f28824340e(BulletInfo *p); 
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p); 
static void stepfunc_ec82fded06dddbf4f40194b5af981ba4(BulletInfo *p); 
static void stepfunc_e4937190a3c362c9a910153c7ddddd26(BulletInfo *p); 
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p); 
static void stepfunc_8a0e475e4b25a2591b0e3b0e882be656(BulletInfo *p); 
static void stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7(BulletInfo *p); 
static void stepfunc_f0a7891aeb14395331227e17249d5a1e(BulletInfo *p); 
static void stepfunc_d2adc42b618adc5f0a04be3c060fbbf9(BulletInfo *p); 
static void stepfunc_9f69f6c5a875216b8b892b1f224f4102(BulletInfo *p); 
static void stepfunc_290db841e27459026bf88a0ded9dc875(BulletInfo *p); 
static void stepfunc_87fa0c022a58312fd091ea35e8ff05bc(BulletInfo *p); 
static void stepfunc_83f7605d547df866a6109ad17879176c(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 


static const BulletStepFunc bullet_b2f2a53a29465f607d329aa03f935de0[] = {
stepfunc_e9975110ae887004b7f0ebc8a71940ed,
stepfunc_c9964d943844c79757b1364dd42d4d42,
stepfunc_b925b712a591a5a8e7c30ce919ce6420,
NULL}; 
static const BulletStepFunc bullet_b7a93030ebfd1d52f80f45baad268f5f[] = {
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_70abeb66cf8ca6f7a3f32ac9da274cb6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_04d2a48b677fab8d2e7c97449751d116,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b695771ad1e39371469eed83efa5ce72,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_efd4e4cc5048d613c3afa5f28824340e,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_70abeb66cf8ca6f7a3f32ac9da274cb6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_04d2a48b677fab8d2e7c97449751d116,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b695771ad1e39371469eed83efa5ce72,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_efd4e4cc5048d613c3afa5f28824340e,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_70abeb66cf8ca6f7a3f32ac9da274cb6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_04d2a48b677fab8d2e7c97449751d116,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b695771ad1e39371469eed83efa5ce72,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_efd4e4cc5048d613c3afa5f28824340e,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_70abeb66cf8ca6f7a3f32ac9da274cb6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_9604d530b79210bcb56507e3e9836fc6,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_91968ac4485dd4878f96d725a8b7e45b,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_10c3a88a8e44bab5c0812abd588467e2,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b6b69e12e8029e011df31946bab3914a,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_0ce2d240b4eba445cb9f77a741570c50,
stepfunc_04d2a48b677fab8d2e7c97449751d116,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_b695771ad1e39371469eed83efa5ce72,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_efd4e4cc5048d613c3afa5f28824340e,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_d999f5e2d4c6f7bb3622ae7218c91777,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_97b0e9d2783130918fd822363a2502b5,
stepfunc_8e45cf31097dac7153fd76c46501b160,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
NULL}; 
static const BulletStepFunc bullet_459137ec233127dca13bef3c07155b52[] = {
stepfunc_d7428c9dcd26fea74995c38e49dc4220,
stepfunc_ec82fded06dddbf4f40194b5af981ba4,
NULL}; 
static const BulletStepFunc bullet_a0d987fd23a2d8795574308e7c23036a[] = {
stepfunc_e4937190a3c362c9a910153c7ddddd26,
stepfunc_5b502751f1728a011324a94f95d35d7d,
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_8a0e475e4b25a2591b0e3b0e882be656,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_f0a7891aeb14395331227e17249d5a1e,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_d2adc42b618adc5f0a04be3c060fbbf9,
#if 0
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7,
#endif
stepfunc_9f69f6c5a875216b8b892b1f224f4102,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_87fa0c022a58312fd091ea35e8ff05bc,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_83f7605d547df866a6109ad17879176c,
#if 0
stepfunc_290db841e27459026bf88a0ded9dc875,
#endif
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_290db841e27459026bf88a0ded9dc875(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-1208, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1208, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_8a0e475e4b25a2591b0e3b0e882be656(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3484, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7(p);}
p->wait = 2; 
}
static void stepfunc_f0a7891aeb14395331227e17249d5a1e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3271, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7(p);}
p->wait = 2; 
}
static void stepfunc_d2adc42b618adc5f0a04be3c060fbbf9(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-3057, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_e891ba7eb44bcad90a5a3ecc408e40d7(p);}
p->wait = 40; 
}
static void stepfunc_9f69f6c5a875216b8b892b1f224f4102(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3484, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_290db841e27459026bf88a0ded9dc875(p);}
p->wait = 2; 
}
static void stepfunc_87fa0c022a58312fd091ea35e8ff05bc(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3271, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_290db841e27459026bf88a0ded9dc875(p);}
p->wait = 2; 
}
static void stepfunc_83f7605d547df866a6109ad17879176c(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3057, 100));    p->lastBulletSpeed = (3);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_290db841e27459026bf88a0ded9dc875(p);}
p->wait = 50; 
}
static void stepfunc_d7428c9dcd26fea74995c38e49dc4220(BulletInfo *p) { 
p->wait = 30; 
}
static void stepfunc_ec82fded06dddbf4f40194b5af981ba4(BulletInfo *p) { 
{
  u16 life = (FixedPointNum(10)*(FixedPointNum(1)+FixedPointNum(5)*FixedPointNum::random()));  FixedPointNum speed = FixedPointNum((FixedPointNum(2)+FixedPointNum::random())*FixedPointNum(75, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
static void stepfunc_8e45cf31097dac7153fd76c46501b160(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = ((FixedPointNum(2)*FixedPointNum::random()));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_459137ec233127dca13bef3c07155b52;  }
}
}
static void stepfunc_d999f5e2d4c6f7bb3622ae7218c91777(BulletInfo *p) { 
p->wait = 7; 
}
static void stepfunc_9604d530b79210bcb56507e3e9836fc6(BulletInfo *p) { 
p->wait = 8; 
}
static void stepfunc_10c3a88a8e44bab5c0812abd588467e2(BulletInfo *p) { 
p->wait = 9; 
}
static void stepfunc_91968ac4485dd4878f96d725a8b7e45b(BulletInfo *p) { 
p->wait = 10; 
}
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_70abeb66cf8ca6f7a3f32ac9da274cb6(BulletInfo *p) { 
{
  u16 life = 0;  FixedPointNum speed = FixedPointNum((192) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_0ce2d240b4eba445cb9f77a741570c50(BulletInfo *p) { 
p->wait = 4; 
}
static void stepfunc_b6b69e12e8029e011df31946bab3914a(BulletInfo *p) { 
p->wait = 5; 
}
static void stepfunc_97b0e9d2783130918fd822363a2502b5(BulletInfo *p) { 
p->wait = 11; 
}
static void stepfunc_6f4601da7d31ad6bee0d38daffb976d0(BulletInfo *p) { 
p->wait = 3; 
}
static void stepfunc_04d2a48b677fab8d2e7c97449751d116(BulletInfo *p) { 
{
  u16 life = 0;  FixedPointNum speed = FixedPointNum((64) - p->getAngle(), life);;p->setRound(speed, life);}
}
static void stepfunc_b695771ad1e39371469eed83efa5ce72(BulletInfo *p) { 
p->wait = 0; 
}
static void stepfunc_efd4e4cc5048d613c3afa5f28824340e(BulletInfo *p) { 
p->wait = 21; 
}
static void stepfunc_e9975110ae887004b7f0ebc8a71940ed(BulletInfo *p) { 
p->wait = 70; 
}
static void stepfunc_c9964d943844c79757b1364dd42d4d42(BulletInfo *p) { 
{
  u16 life = 37;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 40; 
}
static void stepfunc_b925b712a591a5a8e7c30ce919ce6420(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b7a93030ebfd1d52f80f45baad268f5f;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e4937190a3c362c9a910153c7ddddd26(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b2f2a53a29465f607d329aa03f935de0;  }
}
}
static void stepfunc_5b502751f1728a011324a94f95d35d7d(BulletInfo *p) { 
p->wait = 60; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_526555bad717a27ce6ac8e64de6be89f(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_a0d987fd23a2d8795574308e7c23036a; }}


