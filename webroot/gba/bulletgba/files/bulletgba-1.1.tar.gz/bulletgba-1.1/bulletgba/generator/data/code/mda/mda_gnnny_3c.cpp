// XXX uniqID XXX ddfcf7a5d57c18c4654bb96d1a275f37 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_e6e13a34a96b7a5c155da4ace63f2a13(BulletInfo *p); 
static void stepfunc_6f4601da7d31ad6bee0d38daffb976d0(BulletInfo *p); 
static void stepfunc_14af4e73b2d83bbb72addc10b13ebf40(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_9c70c340e418a39fb62bccae470dd2c1(BulletInfo *p); 
static void stepfunc_9dfb4eced1c317914245c4148d5f0f6b(BulletInfo *p); 
static void stepfunc_9605d0d50de5acebe0ae96d42b1e8f21(BulletInfo *p); 
static void stepfunc_b686f1f82d712ba49ba4dcec7416584e(BulletInfo *p); 
static void stepfunc_424c2a05f54e55835ab3d89f5d0b1684(BulletInfo *p); 
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p); 
static void stepfunc_b264011bf2b510fb4a5d4259a7a23746(BulletInfo *p); 
static void stepfunc_53f3c2164da91fc044b1de39d549ab79(BulletInfo *p); 
static void stepfunc_436fc8623b1f14e8e34696739dfe6594(BulletInfo *p); 
static void stepfunc_b564130c03a523255a01ce65a6bf68ac(BulletInfo *p); 
static void stepfunc_93dc3ed94ad91dc0c31aad7a4a70615d(BulletInfo *p); 
static void stepfunc_0670bcca362e6d9b29d35451c329e464(BulletInfo *p); 


static const BulletStepFunc bullet_afcd3d21f2a2201e8fa86a6e511a151f[] = {
stepfunc_e6e13a34a96b7a5c155da4ace63f2a13,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_14af4e73b2d83bbb72addc10b13ebf40,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_1b148c92ccd5d40fd754599849cf5651[] = {
stepfunc_e6e13a34a96b7a5c155da4ace63f2a13,
stepfunc_6f4601da7d31ad6bee0d38daffb976d0,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_9c70c340e418a39fb62bccae470dd2c1,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_354fa98756eb575002e1a27d35138725[] = {
stepfunc_e6e13a34a96b7a5c155da4ace63f2a13,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_9dfb4eced1c317914245c4148d5f0f6b,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_edb2012a6db687cde52fad0739c81fe8[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_b686f1f82d712ba49ba4dcec7416584e,
stepfunc_424c2a05f54e55835ab3d89f5d0b1684,
stepfunc_424c2a05f54e55835ab3d89f5d0b1684,
stepfunc_424c2a05f54e55835ab3d89f5d0b1684,
stepfunc_424c2a05f54e55835ab3d89f5d0b1684,
stepfunc_424c2a05f54e55835ab3d89f5d0b1684,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_b54f3fc87502395b1a400de49cdef861[] = {
stepfunc_4e1882c6d575977071f0893527d2e423,
stepfunc_b264011bf2b510fb4a5d4259a7a23746,
NULL}; 
static const BulletStepFunc bullet_9f75ab0674a519dca74e4c0d92fb6fb4[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_53f3c2164da91fc044b1de39d549ab79,
#if 0
stepfunc_436fc8623b1f14e8e34696739dfe6594,
#endif
NULL}; 
static const BulletStepFunc bullet_8d314febe3e9284250bd064ab01f72cf[] = {
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_cd189dbc80586c29064e3db3c02bbd1e[] = {
stepfunc_9605d0d50de5acebe0ae96d42b1e8f21,
stepfunc_b564130c03a523255a01ce65a6bf68ac,
#if 0
stepfunc_93dc3ed94ad91dc0c31aad7a4a70615d,
#endif
NULL}; 
static const BulletStepFunc bullet_cf0b2ebd765ee60a96ffc46a40ae6f39[] = {
stepfunc_0670bcca362e6d9b29d35451c329e464,
NULL}; 
static void stepfunc_93dc3ed94ad91dc0c31aad7a4a70615d(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((((FixedPointNum::random()*FixedPointNum(4622, 100))+FixedPointNum(355, 100))));    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9605d0d50de5acebe0ae96d42b1e8f21(BulletInfo *p) { 
p->wait = 12; 
}
static void stepfunc_b564130c03a523255a01ce65a6bf68ac(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(140, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_93dc3ed94ad91dc0c31aad7a4a70615d(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_14af4e73b2d83bbb72addc10b13ebf40(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (((FixedPointNum::random()*FixedPointNum(10311, 100))+FixedPointNum(213, 100)));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(180, 100))+FixedPointNum(20, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_cd189dbc80586c29064e3db3c02bbd1e;  }
}
p->wait = 3; 
}
static void stepfunc_6f4601da7d31ad6bee0d38daffb976d0(BulletInfo *p) { 
p->wait = 3; 
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_e6e13a34a96b7a5c155da4ace63f2a13(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum::random()*FixedPointNum(256)));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_8d314febe3e9284250bd064ab01f72cf;  }
}
}
static void stepfunc_436fc8623b1f14e8e34696739dfe6594(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((((FixedPointNum::random()*FixedPointNum(4622, 100))+FixedPointNum(355, 100))));    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_53f3c2164da91fc044b1de39d549ab79(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(120, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
for (u32 i = 0; i < 5; ++i) { 
stepfunc_436fc8623b1f14e8e34696739dfe6594(p);}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9c70c340e418a39fb62bccae470dd2c1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (((FixedPointNum::random()*FixedPointNum(10311, 100))+FixedPointNum(213, 100)));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(180, 100))+FixedPointNum(20, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_9f75ab0674a519dca74e4c0d92fb6fb4;  }
}
p->wait = 3; 
}
static void stepfunc_4e1882c6d575977071f0893527d2e423(BulletInfo *p) { 
p->wait = 1; 
}
static void stepfunc_b264011bf2b510fb4a5d4259a7a23746(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_424c2a05f54e55835ab3d89f5d0b1684(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((((FixedPointNum::random()*FixedPointNum(4622, 100))+FixedPointNum(355, 100))));    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b54f3fc87502395b1a400de49cdef861;  }
}
}
static void stepfunc_b686f1f82d712ba49ba4dcec7416584e(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (1);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_b54f3fc87502395b1a400de49cdef861;  }
}
}
static void stepfunc_9dfb4eced1c317914245c4148d5f0f6b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (((FixedPointNum::random()*FixedPointNum(10311, 100))+FixedPointNum(213, 100)));    p->lastBulletSpeed = (((FixedPointNum::random()*FixedPointNum(180, 100))+FixedPointNum(20, 100)));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_edb2012a6db687cde52fad0739c81fe8;  }
}
p->wait = 3; 
}
static void stepfunc_0670bcca362e6d9b29d35451c329e464(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_354fa98756eb575002e1a27d35138725;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1b148c92ccd5d40fd754599849cf5651;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_afcd3d21f2a2201e8fa86a6e511a151f;  }
}
ListBullets::stepFuncDrop(p);}


void genBulletFunc_ddfcf7a5d57c18c4654bb96d1a275f37(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_cf0b2ebd765ee60a96ffc46a40ae6f39; }}


