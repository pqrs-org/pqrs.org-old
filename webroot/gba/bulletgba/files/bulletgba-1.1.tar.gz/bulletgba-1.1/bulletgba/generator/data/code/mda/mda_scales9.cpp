// XXX uniqID XXX bd30d00a742f43ebc8e9d619a1bf9750 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_4c0e2b84feeb8afea531fd65df047e0c(BulletInfo *p); 
static void stepfunc_01a5424f0919326d4411c24853440c25(BulletInfo *p); 
static void stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e(BulletInfo *p); 
static void stepfunc_4e2974225d93e1839dc7bb04ae7130d6(BulletInfo *p); 
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p); 
static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p); 
static void stepfunc_7d93d98970ae3fea204b996f74061f55(BulletInfo *p); 
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p); 
static void stepfunc_821c4fc8fbce0a717239e6d304d2a899(BulletInfo *p); 
static void stepfunc_ca6d0cbf1bd9a7e4cfb10de8818247c0(BulletInfo *p); 
static void stepfunc_59aa0061be0cd99196cf36fd54835ad2(BulletInfo *p); 
static void stepfunc_f1138b3710948cac5ea27e237fd3d397(BulletInfo *p); 
static void stepfunc_38fa6a82aa6d769277f9f10913e59284(BulletInfo *p); 
static void stepfunc_4e813190ac14f560ec4b5cf30f3eebce(BulletInfo *p); 
static void stepfunc_3b1dfa2378490216010c0f72118826d1(BulletInfo *p); 
static void stepfunc_e00f9f4b8c05c813ae36003707bb54cb(BulletInfo *p); 
static void stepfunc_8945e804362975d27d4bbe1b37643c24(BulletInfo *p); 
static void stepfunc_0934a905ba8ba872b2f82b4995ad46cc(BulletInfo *p); 
static void stepfunc_26af5a0a4fb27518925f2890780d80f5(BulletInfo *p); 


static const BulletStepFunc bullet_6763dfde7fd0995b52a3d7088c53582c[] = {
stepfunc_4c0e2b84feeb8afea531fd65df047e0c,
stepfunc_01a5424f0919326d4411c24853440c25,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static const BulletStepFunc bullet_d040bb841c9854ba6607c392cac2f7b6[] = {
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324,
stepfunc_7d93d98970ae3fea204b996f74061f55,
NULL}; 
static const BulletStepFunc bullet_2d9cc9f4a561661de0f4ce528778ba2a[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_821c4fc8fbce0a717239e6d304d2a899,
NULL}; 
static const BulletStepFunc bullet_32575af3dff81ec22c9c1fdca8133e8b[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_ca6d0cbf1bd9a7e4cfb10de8818247c0,
NULL}; 
static const BulletStepFunc bullet_5a9b90d07a52201da724bbaacf084296[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_59aa0061be0cd99196cf36fd54835ad2,
NULL}; 
static const BulletStepFunc bullet_1fc2d174ae39488433f6986bf11195f0[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_f1138b3710948cac5ea27e237fd3d397,
NULL}; 
static const BulletStepFunc bullet_e15bd5cfcbbcb17856de4694c10b8f07[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_38fa6a82aa6d769277f9f10913e59284,
NULL}; 
static const BulletStepFunc bullet_d69a762448bc87239d2bb892f6ef020b[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_4e813190ac14f560ec4b5cf30f3eebce,
NULL}; 
static const BulletStepFunc bullet_512c7dc4c4a58922a7768d73f4baa457[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_3b1dfa2378490216010c0f72118826d1,
NULL}; 
static const BulletStepFunc bullet_7b03dcae32642c85ffaa3948fa7a6148[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_e00f9f4b8c05c813ae36003707bb54cb,
NULL}; 
static const BulletStepFunc bullet_837e61c7e276661f17e53b8a1c074ca7[] = {
stepfunc_8c6b914b881b0800d2914da88568f3d6,
stepfunc_8945e804362975d27d4bbe1b37643c24,
NULL}; 
static const BulletStepFunc bullet_232bc0380598a7dfdd28b6b56add6110[] = {
stepfunc_0934a905ba8ba872b2f82b4995ad46cc,
stepfunc_26af5a0a4fb27518925f2890780d80f5,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e,
stepfunc_4e2974225d93e1839dc7bb04ae7130d6,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf,
NULL}; 
static void stepfunc_8c6b914b881b0800d2914da88568f3d6(BulletInfo *p) { 
p->wait = 40; 
}
static void stepfunc_821c4fc8fbce0a717239e6d304d2a899(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-14159, 100));    p->lastBulletSpeed = (FixedPointNum(206, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_ca6d0cbf1bd9a7e4cfb10de8818247c0(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-15170, 100));    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_59aa0061be0cd99196cf36fd54835ad2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-16181, 100));    p->lastBulletSpeed = (FixedPointNum(218, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_f1138b3710948cac5ea27e237fd3d397(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-17193, 100));    p->lastBulletSpeed = (FixedPointNum(224, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_38fa6a82aa6d769277f9f10913e59284(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_4e813190ac14f560ec4b5cf30f3eebce(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(224, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_3b1dfa2378490216010c0f72118826d1(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2022, 100));    p->lastBulletSpeed = (FixedPointNum(218, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_e00f9f4b8c05c813ae36003707bb54cb(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3034, 100));    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_8945e804362975d27d4bbe1b37643c24(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4045, 100));    p->lastBulletSpeed = (FixedPointNum(206, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_7d93d98970ae3fea204b996f74061f55(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4969, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_837e61c7e276661f17e53b8a1c074ca7;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3958, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_7b03dcae32642c85ffaa3948fa7a6148;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2947, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_512c7dc4c4a58922a7768d73f4baa457;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1935, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d69a762448bc87239d2bb892f6ef020b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(924, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_e15bd5cfcbbcb17856de4694c10b8f07;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(18117, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_1fc2d174ae39488433f6986bf11195f0;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17106, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_5a9b90d07a52201da724bbaacf084296;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16094, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_32575af3dff81ec22c9c1fdca8133e8b;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15083, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_2d9cc9f4a561661de0f4ce528778ba2a;  }
}
ListBullets::stepFuncDrop(p);}
static void stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e(BulletInfo *p) { 
p->wait = (FixedPointNum(60)*(FixedPointNum(90, 100)+(FixedPointNum::random()*FixedPointNum(20, 100)))); 
}
static void stepfunc_4e2974225d93e1839dc7bb04ae7130d6(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_d040bb841c9854ba6607c392cac2f7b6;  }
}
}
static void stepfunc_4c0e2b84feeb8afea531fd65df047e0c(BulletInfo *p) { 
p->wait = 35; 
}
static void stepfunc_01a5424f0919326d4411c24853440c25(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
static void stepfunc_ae9f735c6401a821cc04ce1cd68278bf(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
static void stepfunc_0934a905ba8ba872b2f82b4995ad46cc(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (128) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
static void stepfunc_26af5a0a4fb27518925f2890780d80f5(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (192);    p->lastBulletSpeed = (2);    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (32);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = (224);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  bi->stepFuncList = bullet_6763dfde7fd0995b52a3d7088c53582c;  }
}
p->wait = 35; 
}


void genBulletFunc_bd30d00a742f43ebc8e9d619a1bf9750(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_232bc0380598a7dfdd28b6b56add6110; }}


