// XXX uniqID XXX 304f30b475c3860a2217a3a12206354e XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"




static void stepfunc_7ff273ad70784c5e3e9158ce8f32e9a5(BulletInfo *p); 
static void stepfunc_a5a36e010068c2736ae2680f966b280f(BulletInfo *p); 
static void stepfunc_500c3dca6866a431a21b00e22a31d33f(BulletInfo *p); 
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p); 


static const BulletStepFunc bullet_4a196ddfe474ac4fa92b5cc49f2279c0[] = {
stepfunc_7ff273ad70784c5e3e9158ce8f32e9a5,
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_a5a36e010068c2736ae2680f966b280f,
#if 0
stepfunc_500c3dca6866a431a21b00e22a31d33f,
#endif
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017,
NULL}; 
static void stepfunc_500c3dca6866a431a21b00e22a31d33f(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + ((FixedPointNum::random()*FixedPointNum(1422, 100)-FixedPointNum(640, 100))/FixedPointNum(135, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(0, 100));    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_a5a36e010068c2736ae2680f966b280f(BulletInfo *p) { 
for (u32 i = 0; i < 4; ++i) { 
stepfunc_500c3dca6866a431a21b00e22a31d33f(p);}
p->wait = 1; 
}
static void stepfunc_7ff273ad70784c5e3e9158ce8f32e9a5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet(p->posx, p->posy, p);  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-5688, 100));    p->lastBulletSpeed = 1;    bi->setAngleSpeed(p->lastBulletAngle, p->lastBulletSpeed);  }
}
}
static void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


void genBulletFunc_304f30b475c3860a2217a3a12206354e(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet(posx, posy, NULL);if (bi) { bi->setAngleSpeed(192, 0); bi->stepFuncList = bullet_4a196ddfe474ac4fa92b5cc49f2279c0; }}


