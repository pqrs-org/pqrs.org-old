#ifndef GENERATED_4c7926d523a191a0daea09d31675a5bb_HPP 
#define GENERATED_4c7926d523a191a0daea09d31675a5bb_HPP 

#include "bullet.hpp" 

void stepfunc_a3d275f187c432a463ff6c126932b043_96182ad433257a2dc7ee6908dde0e137(BulletInfo *p); 
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_96182ad433257a2dc7ee6908dde0e137(BulletInfo *p); 


extern const BulletStepFunc bullet_b835643462389a224a7d7f6374ec509f_96182ad433257a2dc7ee6908dde0e137[]; 
const unsigned int bullet_b835643462389a224a7d7f6374ec509f_96182ad433257a2dc7ee6908dde0e137_size = 602; 


#endif 

