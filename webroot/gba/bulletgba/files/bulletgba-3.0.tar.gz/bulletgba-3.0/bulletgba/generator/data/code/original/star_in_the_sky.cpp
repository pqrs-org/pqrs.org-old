// XXX uniqID XXX f1edbf31a233fc0b0674eaa1e2fd7539 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "original/star_in_the_sky.hpp" 

extern const BulletStepFunc bullet_237d7b6fe4d90dbdd00b35e2f753a9ff_f1edbf31a233fc0b0674eaa1e2fd7539[] = { 
stepfunc_4f9d194870b20115ff0ddbf3b59da5bd_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_f1edbf31a233fc0b0674eaa1e2fd7539,
NULL}; 
extern const BulletStepFunc bullet_f21c4b8ac2f2e0eea89df13152f4c869_f1edbf31a233fc0b0674eaa1e2fd7539[] = { 
stepfunc_203adc5b640dde8e3db296386931859c_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_5dae280ad8aa9479f3436a1db4ae00da_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_ec9996148bf423f9f565c5981a0ee58f_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_f1edbf31a233fc0b0674eaa1e2fd7539,
NULL}; 
extern const BulletStepFunc bullet_c97db494cf079162bea653acdac55138_f1edbf31a233fc0b0674eaa1e2fd7539[] = { 
stepfunc_6ce558d47a717d3ce03a04cec7def3f1_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_f1edbf31a233fc0b0674eaa1e2fd7539,
NULL}; 
void stepfunc_87b99481751b22356c9fcac9066725db_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(782, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 5; 
}
void stepfunc_203adc5b640dde8e3db296386931859c_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
p->wait = 55; 
}
void stepfunc_5dae280ad8aa9479f3436a1db4ae00da_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = FixedPointNum(0, 100) - p->getSpeed();p->setAccel(speed, life);}
p->wait = 5; 
}
void stepfunc_ec9996148bf423f9f565c5981a0ee58f_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-12088, 100));    p->lastBulletSpeed = (FixedPointNum(130, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 5; 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_79c732364849af7af95a71cbe40b248f_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(-497, 100));    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(5, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f21c4b8ac2f2e0eea89df13152f4c869_f1edbf31a233fc0b0674eaa1e2fd7539); 
  }
}
p->wait = 2; 
}
void stepfunc_4f9d194870b20115ff0ddbf3b59da5bd_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(60, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f21c4b8ac2f2e0eea89df13152f4c869_f1edbf31a233fc0b0674eaa1e2fd7539); 
  }
}
p->wait = 2; 
}
void stepfunc_a1a7dcf0af7025ea8a6d3a4d9c5b4640_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2133, 100));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_237d7b6fe4d90dbdd00b35e2f753a9ff_f1edbf31a233fc0b0674eaa1e2fd7539); 
  }
}
}
void stepfunc_6ce558d47a717d3ce03a04cec7def3f1_f1edbf31a233fc0b0674eaa1e2fd7539(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(256) * FixedPointNum::random()));    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_237d7b6fe4d90dbdd00b35e2f753a9ff_f1edbf31a233fc0b0674eaa1e2fd7539); 
  }
}
}


BulletInfo *genBulletFunc_f1edbf31a233fc0b0674eaa1e2fd7539(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_c97db494cf079162bea653acdac55138_f1edbf31a233fc0b0674eaa1e2fd7539); 
  }
return bi;}


