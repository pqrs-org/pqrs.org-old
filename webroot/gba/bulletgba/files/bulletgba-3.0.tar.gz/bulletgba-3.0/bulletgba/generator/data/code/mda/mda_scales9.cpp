// XXX uniqID XXX cc30176beb96f593a7d8a17495949ed4 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/mda_scales9.hpp" 

extern const BulletStepFunc bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_4c0e2b84feeb8afea531fd65df047e0c_cc30176beb96f593a7d8a17495949ed4,
stepfunc_01a5424f0919326d4411c24853440c25_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_4a4d58d0bb6d00fdd1d17dca14d6178a_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_cc30176beb96f593a7d8a17495949ed4,
stepfunc_2d81cecfc260c02c8dbedea0aae317f5_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_868fafe302d0f7b39ac40b6c0c7d8c02_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_821c4fc8fbce0a717239e6d304d2a899_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_b2cf9469dc658debe8eded29266bc93b_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_ca6d0cbf1bd9a7e4cfb10de8818247c0_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_38092a9c4abcf6033bb2e78fbada15f8_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_59aa0061be0cd99196cf36fd54835ad2_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_39fa5a59d9f2c29ccadb22c9145f7bf7_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_f1138b3710948cac5ea27e237fd3d397_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_c90d4fe45045cba0453273046340d337_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_38fa6a82aa6d769277f9f10913e59284_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_6ddae2f8019ae837fc455c3c637b41a6_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_4e813190ac14f560ec4b5cf30f3eebce_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_5465b255a2e01fd58331b12c61d2e40e_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3b1dfa2378490216010c0f72118826d1_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_85afd8ece0699f9f5ea412e0c78ccafd_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_e00f9f4b8c05c813ae36003707bb54cb_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_5791f7eb4518f5bfc9937e83b15fd2b4_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4,
stepfunc_8945e804362975d27d4bbe1b37643c24_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
extern const BulletStepFunc bullet_1c13d1634f6b5f8a42d675a64dc6caab_cc30176beb96f593a7d8a17495949ed4[] = { 
stepfunc_0934a905ba8ba872b2f82b4995ad46cc_cc30176beb96f593a7d8a17495949ed4,
stepfunc_ae927a13084b25f7bf3ac63855412356_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4,
stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_cc30176beb96f593a7d8a17495949ed4,
NULL}; 
void stepfunc_8c6b914b881b0800d2914da88568f3d6_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
p->wait = 40; 
}
void stepfunc_821c4fc8fbce0a717239e6d304d2a899_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-14159, 100));    p->lastBulletSpeed = (FixedPointNum(206, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_ca6d0cbf1bd9a7e4cfb10de8818247c0_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-15170, 100));    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_59aa0061be0cd99196cf36fd54835ad2_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-16181, 100));    p->lastBulletSpeed = (FixedPointNum(218, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_f1138b3710948cac5ea27e237fd3d397_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-17193, 100));    p->lastBulletSpeed = (FixedPointNum(224, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_38fa6a82aa6d769277f9f10913e59284_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(229, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_4e813190ac14f560ec4b5cf30f3eebce_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(224, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_3b1dfa2378490216010c0f72118826d1_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2022, 100));    p->lastBulletSpeed = (FixedPointNum(218, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_e00f9f4b8c05c813ae36003707bb54cb_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3034, 100));    p->lastBulletSpeed = (FixedPointNum(212, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_8945e804362975d27d4bbe1b37643c24_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4045, 100));    p->lastBulletSpeed = (FixedPointNum(206, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
void stepfunc_2d81cecfc260c02c8dbedea0aae317f5_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4969, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5791f7eb4518f5bfc9937e83b15fd2b4_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3958, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_85afd8ece0699f9f5ea412e0c78ccafd_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2947, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5465b255a2e01fd58331b12c61d2e40e_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1935, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6ddae2f8019ae837fc455c3c637b41a6_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(924, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c90d4fe45045cba0453273046340d337_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(18117, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_39fa5a59d9f2c29ccadb22c9145f7bf7_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17106, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_38092a9c4abcf6033bb2e78fbada15f8_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16094, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b2cf9469dc658debe8eded29266bc93b_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15083, 100));    p->lastBulletSpeed = (FixedPointNum(25, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_868fafe302d0f7b39ac40b6c0c7d8c02_cc30176beb96f593a7d8a17495949ed4); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_3f133b1c92d7923a2b7da3a91c41bc4e_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
p->wait = ((FixedPointNum(60)*(FixedPointNum(90, 100)+(FixedPointNum::random()*FixedPointNum(20, 100))))).toInt(); 
}
void stepfunc_010ace5b894a66cd47669d13355e3ca8_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (0);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4a4d58d0bb6d00fdd1d17dca14d6178a_cc30176beb96f593a7d8a17495949ed4); 
  }
}
}
void stepfunc_4c0e2b84feeb8afea531fd65df047e0c_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
p->wait = 35; 
}
void stepfunc_01a5424f0919326d4411c24853440c25_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_0934a905ba8ba872b2f82b4995ad46cc_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = (128) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 30; 
}
void stepfunc_ae927a13084b25f7bf3ac63855412356_cc30176beb96f593a7d8a17495949ed4(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (0);    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (192);    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (32);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (96);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (160);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (224);    p->lastBulletSpeed = (FixedPointNum(280, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_577f4da8075d3fe5f576b3b9b0667abe_cc30176beb96f593a7d8a17495949ed4); 
  }
}
p->wait = 35; 
}


BulletInfo *genBulletFunc_cc30176beb96f593a7d8a17495949ed4(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_1c13d1634f6b5f8a42d675a64dc6caab_cc30176beb96f593a7d8a17495949ed4); 
  }
return bi;}


