// XXX uniqID XXX 1d488413464bde8778c4446dec3d2c53 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/mda_uneune.hpp" 

extern const BulletStepFunc bullet_0d0e5a7aaac18a6784d762b938379701_1d488413464bde8778c4446dec3d2c53[] = { 
stepfunc_18064ce06d1489c819af3deed34a6cb9_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7170921f96b6f610359f79cef8e071be_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_1d488413464bde8778c4446dec3d2c53,
NULL}; 
extern const BulletStepFunc bullet_d5df699393baf2f483f2a7a44e734c0c_1d488413464bde8778c4446dec3d2c53[] = { 
stepfunc_cf98393ac7c05656fa2760aca568b963_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_adaff5f0c74ded8e05453ebb7a0a0818_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_1d488413464bde8778c4446dec3d2c53,
NULL}; 
extern const BulletStepFunc bullet_7bdb84eb0bf9e46307cf16264cff8750_1d488413464bde8778c4446dec3d2c53[] = { 
stepfunc_f249d8e31162778ffa2bcda577a428c8_1d488413464bde8778c4446dec3d2c53,
stepfunc_ad846b9c1b21abcefeb296333db19085_1d488413464bde8778c4446dec3d2c53,
stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53,
stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53,
stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53,
stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53,
stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53,
stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53,
stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_1d488413464bde8778c4446dec3d2c53,
NULL}; 
extern const BulletStepFunc bullet_b6cd98e1f8ae1433e087bc888d8ca247_1d488413464bde8778c4446dec3d2c53[] = { 
stepfunc_f249d8e31162778ffa2bcda577a428c8_1d488413464bde8778c4446dec3d2c53,
stepfunc_ad846b9c1b21abcefeb296333db19085_1d488413464bde8778c4446dec3d2c53,
stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53,
stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53,
stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53,
stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53,
stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53,
stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53,
stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_1d488413464bde8778c4446dec3d2c53,
NULL}; 
extern const BulletStepFunc bullet_b2ff5c2c5f68036e99ee975c067cdda2_1d488413464bde8778c4446dec3d2c53[] = { 
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_1d488413464bde8778c4446dec3d2c53,
NULL}; 
extern const BulletStepFunc bullet_4b8055b45c716d43052dddfc420406c7_1d488413464bde8778c4446dec3d2c53[] = { 
stepfunc_9c01cb441fd0517984200adce9a1d9fe_1d488413464bde8778c4446dec3d2c53,
NULL}; 
void stepfunc_5df75a1b0160d7da461d24cf5a01e643_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(3912, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 3; 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_f249d8e31162778ffa2bcda577a428c8_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
p->wait = 90; 
}
void stepfunc_ad846b9c1b21abcefeb296333db19085_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (0);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b2ff5c2c5f68036e99ee975c067cdda2_1d488413464bde8778c4446dec3d2c53); 
  }
}
}
void stepfunc_7ec1a3c7804019699ec9e029a5ca9f6d_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b6cd98e1f8ae1433e087bc888d8ca247_1d488413464bde8778c4446dec3d2c53); 
  }
}
p->wait = 4; 
}
void stepfunc_18064ce06d1489c819af3deed34a6cb9_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{
  u16 life = 21;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(64)*(-FixedPointNum(71, 100))*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
void stepfunc_7170921f96b6f610359f79cef8e071be_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(128)*(-FixedPointNum(71, 100))*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
void stepfunc_6b596df631db6879e6463073082c17c4_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4266, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(4620, 100));    p->lastBulletSpeed = (FixedPointNum(180, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
p->wait = 3; 
}
void stepfunc_e5fefcea6dd475cfb3be763826dc8ed4_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(0, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7bdb84eb0bf9e46307cf16264cff8750_1d488413464bde8778c4446dec3d2c53); 
  }
}
p->wait = 4; 
}
void stepfunc_cf98393ac7c05656fa2760aca568b963_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{
  u16 life = 21;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(4551, 100)*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
void stepfunc_adaff5f0c74ded8e05453ebb7a0a0818_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(p->getAngle() + ((FixedPointNum(9102, 100)*(FixedPointNum(71, 100)+FixedPointNum::random()))) - p->getAngle(), life);;p->setRound(speed, life);}
}
void stepfunc_9c01cb441fd0517984200adce9a1d9fe_1d488413464bde8778c4446dec3d2c53(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128)-FixedPointNum(1011, 100)+(FixedPointNum(3034, 100)*FixedPointNum::random())));    p->lastBulletSpeed = (FixedPointNum(135, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d5df699393baf2f483f2a7a44e734c0c_1d488413464bde8778c4446dec3d2c53); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = ((FixedPointNum(128)-(-FixedPointNum(1011, 100))+((-FixedPointNum(71, 100))*FixedPointNum(4266, 100)*FixedPointNum::random())));    p->lastBulletSpeed = (FixedPointNum(135, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_0d0e5a7aaac18a6784d762b938379701_1d488413464bde8778c4446dec3d2c53); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_1d488413464bde8778c4446dec3d2c53(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_4b8055b45c716d43052dddfc420406c7_1d488413464bde8778c4446dec3d2c53); 
  }
return bi;}


