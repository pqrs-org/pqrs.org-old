// XXX uniqID XXX e66798cfbf690cb56564d01c1a2988be XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/mojya.hpp" 

extern const BulletStepFunc bullet_d89662b7c5c86cd0493b900c2e0f766c_e66798cfbf690cb56564d01c1a2988be[] = { 
stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca_e66798cfbf690cb56564d01c1a2988be,
stepfunc_eb8ca55bd7482524ff07b7027aa0ddc4_e66798cfbf690cb56564d01c1a2988be,
NULL}; 
extern const BulletStepFunc bullet_c079373b928acb9a6000cc40025d7f81_e66798cfbf690cb56564d01c1a2988be[] = { 
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_e66798cfbf690cb56564d01c1a2988be,
NULL}; 
void stepfunc_3d96ffb925ca1ff7d71ef8155601f8ca_e66798cfbf690cb56564d01c1a2988be(BulletInfo *p) { 
p->wait = 60; 
}
void stepfunc_eb8ca55bd7482524ff07b7027aa0ddc4_e66798cfbf690cb56564d01c1a2988be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(1493, 100)+FixedPointNum::random()*FixedPointNum(5973, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(1493, 100)-FixedPointNum::random()*FixedPointNum(5973, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(497, 100)+FixedPointNum::random()*FixedPointNum(1991, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((-FixedPointNum(497, 100)-FixedPointNum::random()*FixedPointNum(1991, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum::random()*FixedPointNum(995, 100)));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum::random()*(-FixedPointNum(995, 100))));    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = ((FixedPointNum(40, 100)+FixedPointNum::random()*FixedPointNum(140, 100)));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_38c696cb54a824459b669b579f3c2896_e66798cfbf690cb56564d01c1a2988be(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(1066, 100));    p->lastBulletSpeed = (FixedPointNum(54, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d89662b7c5c86cd0493b900c2e0f766c_e66798cfbf690cb56564d01c1a2988be); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(10880, 100));    p->lastBulletSpeed = (FixedPointNum(54, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_d89662b7c5c86cd0493b900c2e0f766c_e66798cfbf690cb56564d01c1a2988be); 
  }
}
p->wait = 3; 
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_e66798cfbf690cb56564d01c1a2988be(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_e66798cfbf690cb56564d01c1a2988be(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_c079373b928acb9a6000cc40025d7f81_e66798cfbf690cb56564d01c1a2988be); 
  }
return bi;}


