// XXX uniqID XXX 6f1e3a35fd6ae168e14297335ead8d15 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/mda_nejiri.hpp" 

extern const BulletStepFunc bullet_649b4efd95bafd446be380e600a80409_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_f9ab83325ddd1ffb36aa79be4a63e439_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_a4b8e3c4b454653dde5a1fd514eedb6c_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_4d638cf302d481c38df5925554076250_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_123e13bd246ddd75f5a979200fa71075_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_bbd84dad317cc2172ada307b6fc9663a_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_c19057e9dd8958d6ae866f54cc775eec_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_5d00a11d508c8b6fc586bffb6a115218_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_f594786d9bc3f6991e2fdce89c594e74_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_57ff1ff1077c2b7f8aa419b2d2967822_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_ae3ba1d5b3548a524be72d2b587b799c_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_eeceda2bd7239833f0155a6b84b06324_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_6f911ce243936cab3223d8fd9cc971be_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_77d70ea44f34eda4dae47c94e8fbac9e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_77d70ea44f34eda4dae47c94e8fbac9e_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_30c86e0844517386eeba4fd4b25dc1b2_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_91d296d638179d5f0d6dd51358ed74e3_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_91d296d638179d5f0d6dd51358ed74e3_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_21f6fdb0e33018fa82ef1095300022f0_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_4e56a66f3e4a1139276ab1bccd3633a4_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_4e56a66f3e4a1139276ab1bccd3633a4_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_7b7b9874181d6b22865fb70873838a08_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_9f557dd903c455da3a4d2dcde021e5fb_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_9f557dd903c455da3a4d2dcde021e5fb_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_6ff11f0f64f744a11bd802ce21fb353c_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_69fe924b1a1b455c81a9fd8fa7357db8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_69fe924b1a1b455c81a9fd8fa7357db8_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_f1d7517224a0459bad0c16af6ab6a755_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_4043b1e1b67f3ee66aa50c1c55d13f5d_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_4043b1e1b67f3ee66aa50c1c55d13f5d_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_1c97087c76823b9b890123dedddf0b1f_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_cafdabc2faff20525f6a40b6e71198d0_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_cafdabc2faff20525f6a40b6e71198d0_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_25f1f9a3d29d94f7108ab0443601f25e_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
extern const BulletStepFunc bullet_e22168ed7391a71b3de0c5b699a52830_6f1e3a35fd6ae168e14297335ead8d15[] = { 
stepfunc_98603baff29a6af6a4e6058787364eb0_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_cc3b0a1c5cd588bff351f203602ec63b_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15,
stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6f1e3a35fd6ae168e14297335ead8d15,
NULL}; 
void stepfunc_25f1f9a3d29d94f7108ab0443601f25e_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
p->wait = 9999; 
}
void stepfunc_ae9f735c6401a821cc04ce1cd68278bf_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_d4abb34975f2910ec47c4a562addd23e_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(-20, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_91968ac4485dd4878f96d725a8b7e45b_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
p->wait = 10; 
}
void stepfunc_6536e4546bdcfcf651852434db03b678_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 1; 
}
void stepfunc_f9ab83325ddd1ffb36aa79be4a63e439_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_a4b8e3c4b454653dde5a1fd514eedb6c_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_123e13bd246ddd75f5a979200fa71075_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_bbd84dad317cc2172ada307b6fc9663a_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_5d00a11d508c8b6fc586bffb6a115218_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_f594786d9bc3f6991e2fdce89c594e74_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(88, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_ae3ba1d5b3548a524be72d2b587b799c_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_eeceda2bd7239833f0155a6b84b06324_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(265, 100));    p->lastBulletSpeed = (FixedPointNum(310, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_06c263ea3bed13e635cb42be084134a9_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
}
void stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (0);    p->lastBulletSpeed = p->lastBulletSpeed + (FixedPointNum(15, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_77d70ea44f34eda4dae47c94e8fbac9e_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_91d296d638179d5f0d6dd51358ed74e3_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_4e56a66f3e4a1139276ab1bccd3633a4_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_9f557dd903c455da3a4d2dcde021e5fb_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_69fe924b1a1b455c81a9fd8fa7357db8_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_4043b1e1b67f3ee66aa50c1c55d13f5d_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1820, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_cafdabc2faff20525f6a40b6e71198d0_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2427, 100));    p->lastBulletSpeed = (FixedPointNum(80, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 7; ++i) { 
stepfunc_afcc82cb706c3bd18e61d1c047961ae2_6f1e3a35fd6ae168e14297335ead8d15(p);}
ListBullets::stepFuncDrop(p);}
void stepfunc_6934a66bf930c3ba5e94aae1bbbd6048_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(4266, 100)-FixedPointNum(2133, 100)+(FixedPointNum::random()*FixedPointNum(14933, 100))));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1c97087c76823b9b890123dedddf0b1f_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_f1d7517224a0459bad0c16af6ab6a755_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6ff11f0f64f744a11bd802ce21fb353c_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_7b7b9874181d6b22865fb70873838a08_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_21f6fdb0e33018fa82ef1095300022f0_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_30c86e0844517386eeba4fd4b25dc1b2_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(711, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6f911ce243936cab3223d8fd9cc971be_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
p->wait = 30; 
}
void stepfunc_c9c93f1481d707f7f3054abbc49c12b8_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum(7466, 100)-FixedPointNum(2844, 100)-(FixedPointNum::random()*FixedPointNum(14933, 100))));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_57ff1ff1077c2b7f8aa419b2d2967822_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c19057e9dd8958d6ae866f54cc775eec_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_4d638cf302d481c38df5925554076250_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(2844, 100));    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_649b4efd95bafd446be380e600a80409_6f1e3a35fd6ae168e14297335ead8d15); 
  }
}
p->wait = 60; 
}
void stepfunc_98603baff29a6af6a4e6058787364eb0_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
{
  u16 life = 1;  FixedPointNum speed = (128) - p->getAngle();p->setRound(speed, life);}
p->wait = 10; 
}
void stepfunc_cc3b0a1c5cd588bff351f203602ec63b_6f1e3a35fd6ae168e14297335ead8d15(BulletInfo *p) { 
{
  u16 life = 1;  FixedPointNum speed = 0 - p->getSpeed();p->setAccel(speed, life);}
p->wait = 10; 
}


BulletInfo *genBulletFunc_6f1e3a35fd6ae168e14297335ead8d15(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_e22168ed7391a71b3de0c5b699a52830_6f1e3a35fd6ae168e14297335ead8d15); 
  }
return bi;}


