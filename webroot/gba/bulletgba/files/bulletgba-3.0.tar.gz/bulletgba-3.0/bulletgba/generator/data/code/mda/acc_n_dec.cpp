// XXX uniqID XXX b9f6ac0fadba820201e21b8fdea1f360 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/acc_n_dec.hpp" 

extern const BulletStepFunc bullet_08b9018a2a78e3f022931da5eb22bcae_b9f6ac0fadba820201e21b8fdea1f360[] = { 
stepfunc_8f67076238570ce89fac133b88df2340_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_775f039356c501e9ae5a55d7bd39534c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_b9f6ac0fadba820201e21b8fdea1f360,
NULL}; 
extern const BulletStepFunc bullet_22b5ba1fa991922e53a146371c3caf95_b9f6ac0fadba820201e21b8fdea1f360[] = { 
stepfunc_dc2737e3c80f4d2dc64bb37911e2dc57_b9f6ac0fadba820201e21b8fdea1f360,
NULL}; 
extern const BulletStepFunc bullet_8d9b6b98c9b39f56bd81bd6786911e4e_b9f6ac0fadba820201e21b8fdea1f360[] = { 
stepfunc_3944f3e4e41c9d577917ebc1b17c1f13_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_369035c037a51051d527157c67115461_b9f6ac0fadba820201e21b8fdea1f360,
NULL}; 
extern const BulletStepFunc bullet_b30b7595751ecd5274cb03cd4a23050f_b9f6ac0fadba820201e21b8fdea1f360[] = { 
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360,
stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_b9f6ac0fadba820201e21b8fdea1f360,
NULL}; 
void stepfunc_dc2737e3c80f4d2dc64bb37911e2dc57_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
{
  u16 life = 25;  FixedPointNum speed = FixedPointNum(FixedPointNum(105, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_3944f3e4e41c9d577917ebc1b17c1f13_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
{
  u16 life = 150;  FixedPointNum speed = FixedPointNum(FixedPointNum(840, 100) - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 9999; 
}
void stepfunc_369035c037a51051d527157c67115461_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (SelfPos::getAngle(p));    p->lastBulletSpeed = 1;    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_e2ae9512140ff2a5efff6ef404b12a8c_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(604, 100));    p->lastBulletSpeed = (FixedPointNum(105, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8d9b6b98c9b39f56bd81bd6786911e4e_b9f6ac0fadba820201e21b8fdea1f360); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->lastBulletAngle + (FixedPointNum(604, 100));    p->lastBulletSpeed = (FixedPointNum(420, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_22b5ba1fa991922e53a146371c3caf95_b9f6ac0fadba820201e21b8fdea1f360); 
  }
}
}
void stepfunc_8f67076238570ce89fac133b88df2340_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
{
  u16 life = 20;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 20; 
}
void stepfunc_775f039356c501e9ae5a55d7bd39534c_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + ((FixedPointNum::random()*FixedPointNum(4266, 100)-FixedPointNum(2133, 100)-FixedPointNum(4977, 100)));    p->lastBulletSpeed = (FixedPointNum(420, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_22b5ba1fa991922e53a146371c3caf95_b9f6ac0fadba820201e21b8fdea1f360); 
  }
}
}
void stepfunc_9a262eab9bee9a27b0f4b6d72eb6d017_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}
void stepfunc_d7f30aee842354aab266569414b3bf44_b9f6ac0fadba820201e21b8fdea1f360(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (64);    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_08b9018a2a78e3f022931da5eb22bcae_b9f6ac0fadba820201e21b8fdea1f360); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (192);    p->lastBulletSpeed = (2);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_08b9018a2a78e3f022931da5eb22bcae_b9f6ac0fadba820201e21b8fdea1f360); 
  }
}
p->wait = 25; 
}


BulletInfo *genBulletFunc_b9f6ac0fadba820201e21b8fdea1f360(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_b30b7595751ecd5274cb03cd4a23050f_b9f6ac0fadba820201e21b8fdea1f360); 
  }
return bi;}


