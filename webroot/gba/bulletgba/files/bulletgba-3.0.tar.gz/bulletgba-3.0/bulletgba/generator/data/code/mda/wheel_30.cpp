// XXX uniqID XXX 1d64cc15a4d1d24008e0e1bff2c10dff XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "mda/wheel_30.hpp" 

extern const BulletStepFunc bullet_8af5042e1d8055bb1b7e46cd3c65c0d5_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_7dce517a8077f8433328429e7dcb11a4_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_73a9a1b3827e93639e5dcc85013afe7b_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_532524aef7818b746dd52350a6fa9c22_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_c4b82f60d16878c2f14ec6e4cb89568c_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_91429ad116db812169e890c22074270e_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_a1498e6b91dcabf4c70cfc9c2f699ef2_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_e8d0fbd4c7b44e013912f253a24d4baf_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_c7504e52f7308ed30fcfc75d48b79fb8_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_966b38f9f879b35f429b0896100cbc9f_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_fb0a55aa3fe3fbb47d882619bf2418ea_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_807898767ec5204e207c6e60b30dc56a_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_77ec464b56c45a312b81c8c9da73e3fa_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_359334354a1127016592de11163fc77e_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_347c6c03c70c5269ae50dd3d6395e81d_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_f3c199e65a63974868b5391d9e1b49af_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_32a8677137e1a2ec2e9a85eaf03513a8_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_85515dd70dc458ae263f06cd09f65ac7_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_07b73879f29bd95c68f1e78515d88df0_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_622aefeef52215fd845a803c09714494_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_c669a5fdadfb2ca60d2c4af579485594_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_fcf7dff9ffece8cade2eadcdb6882bc3_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_1e62ea53c7b7981bcbac0d82426a46de_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_35b7ee7ee9c4cf70cb421a8c520c3b21_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_96f605d8054988f55889ead75d772209_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_b31a9b5164c91ecce15ee6ed61d1fea5_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_179fb78047161d6ed267adc4e64393b0_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_f2f4d31a45613fc4f2e6651e8640be7f_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_66fb9dfc6a40ea6f48f3544efb9c0056_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_009d109532e5bfaad127c4d681017430_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_ab6bbe922eacfc5e14803ed668f7c729_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_8f4efb5ba66e5da032d2b670ff1f231b_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_224c1fe22fa4675ff096d91f1c910c6a_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_d7e79ed62981d23b3d8a3a2632efeeea_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_c8bba62aa6d5f597602c4a863d61d39c_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_5a940b249c416e852acd04f23317b70d_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_b51c142c9330693fb2a08bdbf57a0780_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_a1d272d5d2cd571f8068704d0c9ed5f0_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_6b98733661ae41e64c41fe71773daa97_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_89c7d86fd00acdc215e14b20d197f6d7_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_25f1c868f0930cf225051e4dc0f24d55_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_63eff9ef0340422c33a331becf55e52c_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_5b1abd2397128094363962be1f7c8894_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_2e8599351dd28b4b047329010d1c85d0_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_075e7a85da475eb9403b404c3ed64570_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_0ac405ce1d26eff7a586861f5f147afb_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
extern const BulletStepFunc bullet_b581fbee31d9ea1b91e19c6ca83ebd5b_1d64cc15a4d1d24008e0e1bff2c10dff[] = { 
stepfunc_c7e89f8aa0cd931b07ff77b457b3264b_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_5c9b45e429afb4831f4cef711fecdf63_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_1aeaa7723bb45bdb976326c324c72be2_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_ab0945bd6d7dbc52c46984b686713b0e_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_f998a196d33da38e7b0b5e3a051001fa_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_e9a161bd845aca55d4b26896c4bab173_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_c42936a8df14fc0e7ee3706262ef8247_1d64cc15a4d1d24008e0e1bff2c10dff,
stepfunc_8e717af94e3c04b13c7a691b23224d1d_1d64cc15a4d1d24008e0e1bff2c10dff,
NULL}; 
void stepfunc_6bfeeb730858a53bb1e0f32f02bd5f7d_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
p->wait = 6; 
}
void stepfunc_807898767ec5204e207c6e60b30dc56a_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-17193, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_359334354a1127016592de11163fc77e_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-16181, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_f3c199e65a63974868b5391d9e1b49af_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-15170, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_85515dd70dc458ae263f06cd09f65ac7_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-14159, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_622aefeef52215fd845a803c09714494_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-13147, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_fcf7dff9ffece8cade2eadcdb6882bc3_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-12136, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_35b7ee7ee9c4cf70cb421a8c520c3b21_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-11124, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_b31a9b5164c91ecce15ee6ed61d1fea5_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-10113, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_f2f4d31a45613fc4f2e6651e8640be7f_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-9102, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_009d109532e5bfaad127c4d681017430_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-8090, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_8f4efb5ba66e5da032d2b670ff1f231b_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-7079, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_d7e79ed62981d23b3d8a3a2632efeeea_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-6068, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_5a940b249c416e852acd04f23317b70d_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-5056, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_a1d272d5d2cd571f8068704d0c9ed5f0_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-4045, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_89c7d86fd00acdc215e14b20d197f6d7_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-3034, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_63eff9ef0340422c33a331becf55e52c_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-2022, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_2e8599351dd28b4b047329010d1c85d0_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (FixedPointNum(-1011, 100));    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_0ac405ce1d26eff7a586861f5f147afb_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = p->getAngle() + (0);    p->lastBulletSpeed = (FixedPointNum(409, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, BulletInfo::nullStepFuncList); 
  }
}
}
void stepfunc_9ddc4354b3b6352fd89ab4e2f0c31324_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{
  u16 life = 30;  FixedPointNum speed = FixedPointNum(0 - p->getSpeed(), life);p->setAccel(speed, life);}
p->wait = 30; 
}
void stepfunc_7dce517a8077f8433328429e7dcb11a4_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1314, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_075e7a85da475eb9403b404c3ed64570_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2326, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5b1abd2397128094363962be1f7c8894_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3337, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_25f1c868f0930cf225051e4dc0f24d55_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4348, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6b98733661ae41e64c41fe71773daa97_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5360, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b51c142c9330693fb2a08bdbf57a0780_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6371, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c8bba62aa6d5f597602c4a863d61d39c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7382, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_224c1fe22fa4675ff096d91f1c910c6a_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8394, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ab6bbe922eacfc5e14803ed668f7c729_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9405, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_66fb9dfc6a40ea6f48f3544efb9c0056_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10416, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_179fb78047161d6ed267adc4e64393b0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11428, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_96f605d8054988f55889ead75d772209_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12439, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1e62ea53c7b7981bcbac0d82426a46de_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13451, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c669a5fdadfb2ca60d2c4af579485594_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14462, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_07b73879f29bd95c68f1e78515d88df0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15473, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_32a8677137e1a2ec2e9a85eaf03513a8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16485, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_347c6c03c70c5269ae50dd3d6395e81d_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17496, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_77ec464b56c45a312b81c8c9da73e3fa_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(18507, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb0a55aa3fe3fbb47d882619bf2418ea_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_532524aef7818b746dd52350a6fa9c22_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(657, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_075e7a85da475eb9403b404c3ed64570_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1668, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5b1abd2397128094363962be1f7c8894_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2680, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_25f1c868f0930cf225051e4dc0f24d55_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3691, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6b98733661ae41e64c41fe71773daa97_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4702, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b51c142c9330693fb2a08bdbf57a0780_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5714, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c8bba62aa6d5f597602c4a863d61d39c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6725, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_224c1fe22fa4675ff096d91f1c910c6a_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7736, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ab6bbe922eacfc5e14803ed668f7c729_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8748, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_66fb9dfc6a40ea6f48f3544efb9c0056_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9759, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_179fb78047161d6ed267adc4e64393b0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10770, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_96f605d8054988f55889ead75d772209_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11782, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1e62ea53c7b7981bcbac0d82426a46de_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12793, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c669a5fdadfb2ca60d2c4af579485594_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13805, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_07b73879f29bd95c68f1e78515d88df0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14816, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_32a8677137e1a2ec2e9a85eaf03513a8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15827, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_347c6c03c70c5269ae50dd3d6395e81d_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16839, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_77ec464b56c45a312b81c8c9da73e3fa_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17850, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb0a55aa3fe3fbb47d882619bf2418ea_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_91429ad116db812169e890c22074270e_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (0);    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_075e7a85da475eb9403b404c3ed64570_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1011, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5b1abd2397128094363962be1f7c8894_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2022, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_25f1c868f0930cf225051e4dc0f24d55_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3034, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6b98733661ae41e64c41fe71773daa97_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4045, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b51c142c9330693fb2a08bdbf57a0780_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5056, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c8bba62aa6d5f597602c4a863d61d39c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6068, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_224c1fe22fa4675ff096d91f1c910c6a_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7079, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ab6bbe922eacfc5e14803ed668f7c729_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8090, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_66fb9dfc6a40ea6f48f3544efb9c0056_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9102, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_179fb78047161d6ed267adc4e64393b0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10113, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_96f605d8054988f55889ead75d772209_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11124, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1e62ea53c7b7981bcbac0d82426a46de_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12136, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c669a5fdadfb2ca60d2c4af579485594_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13147, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_07b73879f29bd95c68f1e78515d88df0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14159, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_32a8677137e1a2ec2e9a85eaf03513a8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15170, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_347c6c03c70c5269ae50dd3d6395e81d_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16181, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_77ec464b56c45a312b81c8c9da73e3fa_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(17193, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb0a55aa3fe3fbb47d882619bf2418ea_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_e8d0fbd4c7b44e013912f253a24d4baf_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-657, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_075e7a85da475eb9403b404c3ed64570_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(353, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5b1abd2397128094363962be1f7c8894_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1365, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_25f1c868f0930cf225051e4dc0f24d55_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2376, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6b98733661ae41e64c41fe71773daa97_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3388, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b51c142c9330693fb2a08bdbf57a0780_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4399, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c8bba62aa6d5f597602c4a863d61d39c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5410, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_224c1fe22fa4675ff096d91f1c910c6a_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6422, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ab6bbe922eacfc5e14803ed668f7c729_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7433, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_66fb9dfc6a40ea6f48f3544efb9c0056_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8444, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_179fb78047161d6ed267adc4e64393b0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9456, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_96f605d8054988f55889ead75d772209_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10467, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1e62ea53c7b7981bcbac0d82426a46de_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11478, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c669a5fdadfb2ca60d2c4af579485594_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12490, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_07b73879f29bd95c68f1e78515d88df0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13501, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_32a8677137e1a2ec2e9a85eaf03513a8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14512, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_347c6c03c70c5269ae50dd3d6395e81d_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15524, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_77ec464b56c45a312b81c8c9da73e3fa_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(16535, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb0a55aa3fe3fbb47d882619bf2418ea_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_966b38f9f879b35f429b0896100cbc9f_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-1314, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_075e7a85da475eb9403b404c3ed64570_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(-303, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_5b1abd2397128094363962be1f7c8894_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(707, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_25f1c868f0930cf225051e4dc0f24d55_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(1719, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6b98733661ae41e64c41fe71773daa97_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(2730, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_b51c142c9330693fb2a08bdbf57a0780_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(3742, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c8bba62aa6d5f597602c4a863d61d39c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(4753, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_224c1fe22fa4675ff096d91f1c910c6a_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(5764, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_ab6bbe922eacfc5e14803ed668f7c729_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(6776, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_66fb9dfc6a40ea6f48f3544efb9c0056_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(7787, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_179fb78047161d6ed267adc4e64393b0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(8798, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_96f605d8054988f55889ead75d772209_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(9810, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_1e62ea53c7b7981bcbac0d82426a46de_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(10821, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c669a5fdadfb2ca60d2c4af579485594_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(11832, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_07b73879f29bd95c68f1e78515d88df0_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(12844, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_32a8677137e1a2ec2e9a85eaf03513a8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(13855, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_347c6c03c70c5269ae50dd3d6395e81d_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(14866, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_77ec464b56c45a312b81c8c9da73e3fa_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = SelfPos::getAngle(p) + (FixedPointNum(15878, 100));    p->lastBulletSpeed = (FixedPointNum(210, 100));    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb0a55aa3fe3fbb47d882619bf2418ea_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
ListBullets::stepFuncDrop(p);}
void stepfunc_c7e89f8aa0cd931b07ff77b457b3264b_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(18488, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8af5042e1d8055bb1b7e46cd3c65c0d5_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15644, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c4b82f60d16878c2f14ec6e4cb89568c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c7504e52f7308ed30fcfc75d48b79fb8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
p->wait = 30; 
}
void stepfunc_5c9b45e429afb4831f4cef711fecdf63_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8af5042e1d8055bb1b7e46cd3c65c0d5_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9955, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c4b82f60d16878c2f14ec6e4cb89568c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7111, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c7504e52f7308ed30fcfc75d48b79fb8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
p->wait = 30; 
}
void stepfunc_1aeaa7723bb45bdb976326c324c72be2_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a1498e6b91dcabf4c70cfc9c2f699ef2_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14222, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_73a9a1b3827e93639e5dcc85013afe7b_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
p->wait = 30; 
}
void stepfunc_ab0945bd6d7dbc52c46984b686713b0e_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(11377, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a1498e6b91dcabf4c70cfc9c2f699ef2_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_73a9a1b3827e93639e5dcc85013afe7b_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
p->wait = 60; 
}
void stepfunc_f998a196d33da38e7b0b5e3a051001fa_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(18488, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8af5042e1d8055bb1b7e46cd3c65c0d5_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_73a9a1b3827e93639e5dcc85013afe7b_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15644, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c4b82f60d16878c2f14ec6e4cb89568c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14222, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a1498e6b91dcabf4c70cfc9c2f699ef2_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c7504e52f7308ed30fcfc75d48b79fb8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
p->wait = 40; 
}
void stepfunc_e9a161bd845aca55d4b26896c4bab173_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8af5042e1d8055bb1b7e46cd3c65c0d5_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(11377, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_73a9a1b3827e93639e5dcc85013afe7b_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9955, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c4b82f60d16878c2f14ec6e4cb89568c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a1498e6b91dcabf4c70cfc9c2f699ef2_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7111, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c7504e52f7308ed30fcfc75d48b79fb8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
p->wait = 40; 
}
void stepfunc_c42936a8df14fc0e7ee3706262ef8247_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(18488, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c7504e52f7308ed30fcfc75d48b79fb8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(17066, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a1498e6b91dcabf4c70cfc9c2f699ef2_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(15644, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c4b82f60d16878c2f14ec6e4cb89568c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(14222, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_73a9a1b3827e93639e5dcc85013afe7b_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8af5042e1d8055bb1b7e46cd3c65c0d5_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
p->wait = 40; 
}
void stepfunc_8e717af94e3c04b13c7a691b23224d1d_1d64cc15a4d1d24008e0e1bff2c10dff(BulletInfo *p) { 
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (128);    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c7504e52f7308ed30fcfc75d48b79fb8_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(11377, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_a1498e6b91dcabf4c70cfc9c2f699ef2_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(9955, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c4b82f60d16878c2f14ec6e4cb89568c_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(8533, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_73a9a1b3827e93639e5dcc85013afe7b_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
{ 
  BulletInfo *bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    p->lastBulletAngle = (FixedPointNum(7111, 100));    p->lastBulletSpeed = (3);    bi->initialize(p->getDepth() + 1, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_8af5042e1d8055bb1b7e46cd3c65c0d5_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
}
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_1d64cc15a4d1d24008e0e1bff2c10dff(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(0, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_b581fbee31d9ea1b91e19c6ca83ebd5b_1d64cc15a4d1d24008e0e1bff2c10dff); 
  }
return bi;}


