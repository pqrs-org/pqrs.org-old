#ifndef GENERATED_3700f38cce5f83bdde728427c95115a1_HPP 
#define GENERATED_3700f38cce5f83bdde728427c95115a1_HPP 

#include "bullet.hpp" 

void stepfunc_d51c12748c59a4b79115fd413e988880_09bfd4e879c0988929257729c81f9c4c(BulletInfo *p); 
void stepfunc_6ba9703189746a284b35c2be3b6f8005_09bfd4e879c0988929257729c81f9c4c(BulletInfo *p); 
void stepfunc_22b547e792b3eb30918822b358b0eaf5_09bfd4e879c0988929257729c81f9c4c(BulletInfo *p); 


extern const BulletStepFunc bullet_a6a7b4134fce4987c3e0694674040be2_09bfd4e879c0988929257729c81f9c4c[]; 
const unsigned int bullet_a6a7b4134fce4987c3e0694674040be2_09bfd4e879c0988929257729c81f9c4c_size = 11; 


#endif 

