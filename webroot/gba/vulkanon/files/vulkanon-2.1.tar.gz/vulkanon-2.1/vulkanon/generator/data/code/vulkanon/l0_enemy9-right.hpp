#ifndef GENERATED_2adb0eacf00d2636f7f8b32a81b8b69f_HPP 
#define GENERATED_2adb0eacf00d2636f7f8b32a81b8b69f_HPP 

#include "bullet.hpp" 

void stepfunc_a8039100d814a18bac47c45ffcba8e1f_444e03c42d0db749411ffb80b473544e(BulletInfo *p); 
void stepfunc_c5a85e076c4034d7e927399b715db7d3_444e03c42d0db749411ffb80b473544e(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_444e03c42d0db749411ffb80b473544e(BulletInfo *p); 


extern const BulletStepFunc bullet_8a0704ffc1a026725ca3cfa9bc986f73_444e03c42d0db749411ffb80b473544e[]; 
const unsigned int bullet_8a0704ffc1a026725ca3cfa9bc986f73_444e03c42d0db749411ffb80b473544e_size = 23; 


#endif 

