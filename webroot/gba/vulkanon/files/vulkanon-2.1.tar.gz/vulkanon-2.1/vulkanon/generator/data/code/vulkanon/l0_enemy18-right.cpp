// XXX uniqID XXX 237614aaec8157c2c678e39a91b6f99b XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "vulkanon/l0_enemy18-right.hpp" 

extern const BulletStepFunc bullet_66a2f95601e784c18e0dab7a14ea58ac_237614aaec8157c2c678e39a91b6f99b[] = { 
stepfunc_456753c9ab23d0c18884db48a58a16e6_237614aaec8157c2c678e39a91b6f99b,
stepfunc_30a5b118867561f3ad2802c148f182e3_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_237614aaec8157c2c678e39a91b6f99b,
NULL}; 
void stepfunc_fc499abee849ad3ec48ab61df1d3ae95_237614aaec8157c2c678e39a91b6f99b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((3 * 1.0 * 256 / 360));  p->lastBulletSpeed = (3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(1); 
}
void stepfunc_456753c9ab23d0c18884db48a58a16e6_237614aaec8157c2c678e39a91b6f99b(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = (256 * -90 / 360) + ((180 * 1.0 * 256 / 360)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = 0.5 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(2); 
}
void stepfunc_30a5b118867561f3ad2802c148f182e3_237614aaec8157c2c678e39a91b6f99b(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = (3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_237614aaec8157c2c678e39a91b6f99b(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_237614aaec8157c2c678e39a91b6f99b(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_66a2f95601e784c18e0dab7a14ea58ac_237614aaec8157c2c678e39a91b6f99b); 
  }
return bi;}


