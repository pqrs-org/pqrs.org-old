// XXX uniqID XXX 12db626e647961ec34505eb6a92413f2 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "vulkanon/l0_enemy10.hpp" 

extern const BulletStepFunc bullet_6f16f013dd5a1d9df1a8ec2e906a4918_12db626e647961ec34505eb6a92413f2[] = { 
stepfunc_1c34f3a349a116f9c1a61f9c6aa70d1f_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_12db626e647961ec34505eb6a92413f2,
NULL}; 
void stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((130 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((130 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((130 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((130 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((130 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((130 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((150 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((150 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((150 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((150 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((150 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((150 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((170 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((170 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((170 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((170 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((170 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((170 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((190 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((190 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((190 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((190 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((190 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((190 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((210 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((210 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((210 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((210 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((210 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((210 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((230 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((230 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((230 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((230 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((230 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((230 * 1.0 * 256 / 360))));  p->lastBulletSpeed = p->lastBulletSpeed + (0.25);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(30); 
}
void stepfunc_1c34f3a349a116f9c1a61f9c6aa70d1f_12db626e647961ec34505eb6a92413f2(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = (256 * -90 / 360) + ((180 * 1.0 * 256 / 360)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(20); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_12db626e647961ec34505eb6a92413f2(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_6f16f013dd5a1d9df1a8ec2e906a4918_12db626e647961ec34505eb6a92413f2); 
  }
return bi;}


