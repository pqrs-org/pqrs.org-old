// XXX uniqID XXX fedd858a2a4d5e35be3ee22ffc073e03 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "vulkanon/l0_enemy13-right.hpp" 

extern const BulletStepFunc bullet_32454d22b7489d48267f520406715b9a_fedd858a2a4d5e35be3ee22ffc073e03[] = { 
stepfunc_b5ccdb55b1c6958c7330d2c4b2466f1c_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_278b619bac05feae137452d0b23ccc87_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03,
stepfunc_fddccad3a4269a6062fda865a05f419c_fedd858a2a4d5e35be3ee22ffc073e03,
NULL}; 
void stepfunc_a867206a5bde2a9109dacde62b183d10_fedd858a2a4d5e35be3ee22ffc073e03(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + ((90 * 1.0 * 256 / 360));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (-(90 * 1.0 * 256 / 360));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(3); 
}
void stepfunc_b5ccdb55b1c6958c7330d2c4b2466f1c_fedd858a2a4d5e35be3ee22ffc073e03(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = (256 * -90 / 360) + (FixedPointNum::random()*(360 * 1.0 * 256 / 360)) - p->getAngle();p->setRound(speed, life);}
p->wait = static_cast<u16>(2); 
}
void stepfunc_278b619bac05feae137452d0b23ccc87_fedd858a2a4d5e35be3ee22ffc073e03(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(9999);  FixedPointNum speed = (3 * 1.0 * 256 / 360);p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(100);  FixedPointNum speed = FixedPointNum(4 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_fddccad3a4269a6062fda865a05f419c_fedd858a2a4d5e35be3ee22ffc073e03(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_fedd858a2a4d5e35be3ee22ffc073e03(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_32454d22b7489d48267f520406715b9a_fedd858a2a4d5e35be3ee22ffc073e03); 
  }
return bi;}


