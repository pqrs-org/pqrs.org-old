#ifndef GENERATED_0136208fc6eddf99418fa1eea2c760de_HPP 
#define GENERATED_0136208fc6eddf99418fa1eea2c760de_HPP 

#include "bullet.hpp" 

void stepfunc_f9e9b65e67c0cff38a77ad9208706601_725cf8416eb13190489c86a3a093aae1(BulletInfo *p); 
void stepfunc_1c2f36b0f1cb222136412eec6bf95e4b_725cf8416eb13190489c86a3a093aae1(BulletInfo *p); 
void stepfunc_fddccad3a4269a6062fda865a05f419c_725cf8416eb13190489c86a3a093aae1(BulletInfo *p); 


extern const BulletStepFunc bullet_ac7bb767b751e789736ad9222d6197c8_725cf8416eb13190489c86a3a093aae1[]; 
const unsigned int bullet_ac7bb767b751e789736ad9222d6197c8_725cf8416eb13190489c86a3a093aae1_size = 303; 


#endif 

