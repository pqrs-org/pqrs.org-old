#ifndef GENERATED_c55bf0dbe0caf9e2425636a62384014c_HPP 
#define GENERATED_c55bf0dbe0caf9e2425636a62384014c_HPP 

#include "bullet.hpp" 

void stepfunc_9feee3686dcc5c059cca60a536f73d06_857ffb30df4ae1219f2f94987d8254da(BulletInfo *p); 
void stepfunc_d84b07229ec55c3a27aa155672956fb2_857ffb30df4ae1219f2f94987d8254da(BulletInfo *p); 
void stepfunc_fddccad3a4269a6062fda865a05f419c_857ffb30df4ae1219f2f94987d8254da(BulletInfo *p); 


extern const BulletStepFunc bullet_a12c906962df10f2fff3b9d43962a732_857ffb30df4ae1219f2f94987d8254da[]; 
const unsigned int bullet_a12c906962df10f2fff3b9d43962a732_857ffb30df4ae1219f2f94987d8254da_size = 303; 


#endif 

