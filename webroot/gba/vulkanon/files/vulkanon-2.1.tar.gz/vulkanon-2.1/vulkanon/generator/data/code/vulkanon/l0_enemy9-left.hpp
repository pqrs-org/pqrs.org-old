#ifndef GENERATED_7ce6163812596ebbe247bd41a8e4dd9f_HPP 
#define GENERATED_7ce6163812596ebbe247bd41a8e4dd9f_HPP 

#include "bullet.hpp" 

void stepfunc_e02265704f533da974de467a0920f619_f107c17d1c894e586e7489862f23d92e(BulletInfo *p); 
void stepfunc_05aab8796018ef0a8d1c895b1dbed717_f107c17d1c894e586e7489862f23d92e(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_f107c17d1c894e586e7489862f23d92e(BulletInfo *p); 


extern const BulletStepFunc bullet_6bc9aeb041719d9dcbdb390d5bc1bc85_f107c17d1c894e586e7489862f23d92e[]; 
const unsigned int bullet_6bc9aeb041719d9dcbdb390d5bc1bc85_f107c17d1c894e586e7489862f23d92e_size = 23; 


#endif 

