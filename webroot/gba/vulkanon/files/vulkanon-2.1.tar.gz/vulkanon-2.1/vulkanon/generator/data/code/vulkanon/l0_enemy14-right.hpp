#ifndef GENERATED_359058423136dacc908ed9892b9a4d69_HPP 
#define GENERATED_359058423136dacc908ed9892b9a4d69_HPP 

#include "bullet.hpp" 

void stepfunc_9ccb48cbc8f3511cfff65c38a7359ab8_d5b50d066fb77c09379b2ecff4c01376(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_d5b50d066fb77c09379b2ecff4c01376(BulletInfo *p); 


extern const BulletStepFunc bullet_5d09d53130e02d1824ef11f985d532d2_d5b50d066fb77c09379b2ecff4c01376[]; 
const unsigned int bullet_5d09d53130e02d1824ef11f985d532d2_d5b50d066fb77c09379b2ecff4c01376_size = 102; 


#endif 

