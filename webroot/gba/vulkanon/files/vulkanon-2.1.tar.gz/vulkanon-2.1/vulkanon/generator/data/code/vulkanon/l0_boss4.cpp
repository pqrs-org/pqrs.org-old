// XXX uniqID XXX bd7f7947863a9dae4991e3f4e756c141 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "vulkanon/l0_boss4.hpp" 

extern const BulletStepFunc bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141[] = { 
stepfunc_edad9eb0530cd8f1854627ea7800ba42_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_b012f165c3ed92badaf5fbdde484e240_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_d8c03b6b121b1cc1078c96a88e554964_bd7f7947863a9dae4991e3f4e756c141,
NULL}; 
extern const BulletStepFunc bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141[] = { 
stepfunc_bc22530ba7cc7020d0e2d282fa281479_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_b012f165c3ed92badaf5fbdde484e240_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_d8c03b6b121b1cc1078c96a88e554964_bd7f7947863a9dae4991e3f4e756c141,
NULL}; 
extern const BulletStepFunc bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141[] = { 
stepfunc_4abf70eeed0113d66a150639bd1666ec_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_b012f165c3ed92badaf5fbdde484e240_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_d8c03b6b121b1cc1078c96a88e554964_bd7f7947863a9dae4991e3f4e756c141,
NULL}; 
extern const BulletStepFunc bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141[] = { 
stepfunc_e104953b37e2f94e6c6ca77b6ad7d99b_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_b012f165c3ed92badaf5fbdde484e240_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_d8c03b6b121b1cc1078c96a88e554964_bd7f7947863a9dae4991e3f4e756c141,
NULL}; 
extern const BulletStepFunc bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141[] = { 
stepfunc_787c9289c54883ed836a061a169f9db0_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_b012f165c3ed92badaf5fbdde484e240_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_d8c03b6b121b1cc1078c96a88e554964_bd7f7947863a9dae4991e3f4e756c141,
NULL}; 
extern const BulletStepFunc bullet_80d24ef212420a948cbbb71834b07362_bd7f7947863a9dae4991e3f4e756c141[] = { 
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_bd7f7947863a9dae4991e3f4e756c141,
NULL}; 
void stepfunc_edad9eb0530cd8f1854627ea7800ba42_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
p->wait = static_cast<u16>((5)*2); 
}
void stepfunc_b012f165c3ed92badaf5fbdde484e240_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = 2 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(30); 
}
void stepfunc_d8c03b6b121b1cc1078c96a88e554964_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = SelfPos::getAngle(p) + ((0 * 1.0 * 256 / 360)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = 4 - p->getSpeed();p->setAccel(speed, life);}
}
void stepfunc_bc22530ba7cc7020d0e2d282fa281479_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
p->wait = static_cast<u16>((4)*2); 
}
void stepfunc_4abf70eeed0113d66a150639bd1666ec_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
p->wait = static_cast<u16>((3)*2); 
}
void stepfunc_e104953b37e2f94e6c6ca77b6ad7d99b_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
p->wait = static_cast<u16>((2)*2); 
}
void stepfunc_787c9289c54883ed836a061a169f9db0_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
p->wait = static_cast<u16>((1)*2); 
}
void stepfunc_780b4b175b9d41de4f52574855de3519_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((120 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((120 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((120 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((120 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((120 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((120 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((140 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((140 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((140 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((140 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((140 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((140 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((160 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((160 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((160 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((160 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((160 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((160 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((180 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((180 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((180 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((180 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((180 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((180 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((200 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((200 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((200 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((200 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((200 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((200 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((220 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((220 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((220 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((220 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((220 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((220 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + (((240 * 1.0 * 256 / 360)));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((240 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_c14591504d46feb5183b04dde6a629e0_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((240 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_fb017cff06553e78056155bfee976341_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((240 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_aaa56f971396af7dcab9753fa9f39973_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((240 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_6022fe41498322d7403839e9dab5c319_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((((240 * 1.0 * 256 / 360))));  p->lastBulletSpeed = (0.1);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, bullet_9bf54119cb69d6c1ae966de6239697dc_bd7f7947863a9dae4991e3f4e756c141); 
  }
}
p->wait = static_cast<u16>(30); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_bd7f7947863a9dae4991e3f4e756c141(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_bd7f7947863a9dae4991e3f4e756c141(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_80d24ef212420a948cbbb71834b07362_bd7f7947863a9dae4991e3f4e756c141); 
  }
return bi;}


