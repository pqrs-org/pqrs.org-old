#ifndef GENERATED_6228c3cc54b0b4807cfe6774d8115d02_HPP 
#define GENERATED_6228c3cc54b0b4807cfe6774d8115d02_HPP 

#include "bullet.hpp" 

void stepfunc_bed8dda85fc60ff8f3f2ddb90c504bf2_f62ae716ff689b0db49490423ea6e1db(BulletInfo *p); 
void stepfunc_0a6845cafd76c4a05ea987f76f120ed0_f62ae716ff689b0db49490423ea6e1db(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_f62ae716ff689b0db49490423ea6e1db(BulletInfo *p); 


extern const BulletStepFunc bullet_928102754cc08638c5a2b32559877673_f62ae716ff689b0db49490423ea6e1db[]; 
const unsigned int bullet_928102754cc08638c5a2b32559877673_f62ae716ff689b0db49490423ea6e1db_size = 63; 


#endif 

