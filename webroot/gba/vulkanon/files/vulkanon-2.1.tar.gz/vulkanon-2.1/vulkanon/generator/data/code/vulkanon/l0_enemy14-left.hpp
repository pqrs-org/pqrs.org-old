#ifndef GENERATED_eb1392a78c28bb3b8696f9d3cec50823_HPP 
#define GENERATED_eb1392a78c28bb3b8696f9d3cec50823_HPP 

#include "bullet.hpp" 

void stepfunc_0e7e891abd29f1eaf35bdcb6417b2a86_394cea4d77e9d333c235108b5dbc5c88(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_394cea4d77e9d333c235108b5dbc5c88(BulletInfo *p); 


extern const BulletStepFunc bullet_47c67eb6c29816a4036c5d8c6c6884ec_394cea4d77e9d333c235108b5dbc5c88[]; 
const unsigned int bullet_47c67eb6c29816a4036c5d8c6c6884ec_394cea4d77e9d333c235108b5dbc5c88_size = 102; 


#endif 

