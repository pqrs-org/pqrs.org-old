#ifndef GENERATED_7674a4cc9bd3ca83cb4d6147940c0e3f_HPP 
#define GENERATED_7674a4cc9bd3ca83cb4d6147940c0e3f_HPP 

#include "bullet.hpp" 

void stepfunc_1c34f3a349a116f9c1a61f9c6aa70d1f_12db626e647961ec34505eb6a92413f2(BulletInfo *p); 
void stepfunc_69ac1643fc27b9dc6c77d31852cfdf82_12db626e647961ec34505eb6a92413f2(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_12db626e647961ec34505eb6a92413f2(BulletInfo *p); 


extern const BulletStepFunc bullet_6f16f013dd5a1d9df1a8ec2e906a4918_12db626e647961ec34505eb6a92413f2[]; 
const unsigned int bullet_6f16f013dd5a1d9df1a8ec2e906a4918_12db626e647961ec34505eb6a92413f2_size = 13; 


#endif 

