#ifndef BARRAGELIST_HPP
#define BARRAGELIST_HPP
#include "bullet.hpp"

BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L0_1[] = { 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 90, 4, genBulletFunc_93f0c952a1e5c566defd84f3fa39b3a3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10000 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_BOSS_ENABLE, 0 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_09bfd4e879c0988929257729c81f9c4c(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L0_2[] = { 
{ 32, 10, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 20, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 20, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 30, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 30, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 40, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 40, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 50, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 50, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 60, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 60, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 70, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 70, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 80, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 80, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 90, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 90, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 100, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 100, 1, genBulletFunc_09bfd4e879c0988929257729c81f9c4c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_318a5e347d432a1a29542cd45457692a(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L0_3[] = { 
{ 72, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 102, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 52, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 92, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 72, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 32, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 102, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 30, 32, genBulletFunc_318a5e347d432a1a29542cd45457692a, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L0_4[] = { 
{ 52, 50, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 50, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 1000 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L0_5[] = { 
{ 22, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 32, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 42, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 52, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 62, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 210, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 200, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 190, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 180, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 170, 0, 8, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

const BarrageInfo * const listBarrage_L0_all[] = { 
  listBarrage_L0_1,   listBarrage_L0_2,   listBarrage_L0_3,   listBarrage_L0_4,   listBarrage_L0_5, NULL, }; 

BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_45873150e5988b429bcb0292a3ef221c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9e086ca75252f14be2079197f41e0a5f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_45873150e5988b429bcb0292a3ef221c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9e086ca75252f14be2079197f41e0a5f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_45873150e5988b429bcb0292a3ef221c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9e086ca75252f14be2079197f41e0a5f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_45873150e5988b429bcb0292a3ef221c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9e086ca75252f14be2079197f41e0a5f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_34ea1a195216339fa1c1aeb217396b04(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L1_1[] = { 
{ 12, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 32, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 52, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 72, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 92, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 112, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 132, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 152, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 172, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 192, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 212, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 220, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 200, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 180, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 160, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 140, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 120, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 100, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 80, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 60, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 40, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 20, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 232, 16, 16, genBulletFunc_45873150e5988b429bcb0292a3ef221c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 0, 32, 16, genBulletFunc_9e086ca75252f14be2079197f41e0a5f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 232, 48, 16, genBulletFunc_45873150e5988b429bcb0292a3ef221c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 0, 64, 16, genBulletFunc_9e086ca75252f14be2079197f41e0a5f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 232, 80, 16, genBulletFunc_45873150e5988b429bcb0292a3ef221c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 0, 96, 16, genBulletFunc_9e086ca75252f14be2079197f41e0a5f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 232, 112, 16, genBulletFunc_45873150e5988b429bcb0292a3ef221c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 0, 128, 16, genBulletFunc_9e086ca75252f14be2079197f41e0a5f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 1000 }, 
{ 106, 10, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 10, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 10, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 10, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 10, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 10, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 20, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 20, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 20, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 20, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 20, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 20, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 30, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 30, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 30, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 30, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 30, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 30, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 40, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 40, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 40, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 40, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 40, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 40, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 50, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 50, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 50, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 50, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 50, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 50, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 60, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 60, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 60, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 60, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 60, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 60, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 70, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 70, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 70, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 70, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 70, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 70, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 80, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 80, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 80, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 80, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 80, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 80, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 90, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 90, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 90, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 90, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 90, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 90, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 106, 100, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 126, 100, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 96, 100, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 136, 100, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 86, 100, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 146, 100, 1, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 116, 80, 64, genBulletFunc_34ea1a195216339fa1c1aeb217396b04, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 2000 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_BOSS_ENABLE, 0 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L1_2[] = { 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 160, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 72, 10, 4, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_9e086ca75252f14be2079197f41e0a5f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_45873150e5988b429bcb0292a3ef221c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9e086ca75252f14be2079197f41e0a5f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_45873150e5988b429bcb0292a3ef221c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9e086ca75252f14be2079197f41e0a5f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L1_3[] = { 
{ 0, 40, 32, genBulletFunc_9e086ca75252f14be2079197f41e0a5f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 232, 100, 32, genBulletFunc_45873150e5988b429bcb0292a3ef221c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 0, 80, 32, genBulletFunc_9e086ca75252f14be2079197f41e0a5f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 232, 120, 32, genBulletFunc_45873150e5988b429bcb0292a3ef221c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 0, 100, 32, genBulletFunc_9e086ca75252f14be2079197f41e0a5f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 12, 0, 32, genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 32, genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_c787821cbc147550a9bd0da97aff775e(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L1_4[] = { 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 4, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 400 }, 
{ 12, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 2, genBulletFunc_c787821cbc147550a9bd0da97aff775e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_36341c0e8b8dd3b18492fefc828e7390(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_36341c0e8b8dd3b18492fefc828e7390(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L1_5[] = { 
{ 32, 0, 8, genBulletFunc_36341c0e8b8dd3b18492fefc828e7390, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 8, genBulletFunc_36341c0e8b8dd3b18492fefc828e7390, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 800 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

const BarrageInfo * const listBarrage_L1_all[] = { 
  listBarrage_L1_1,   listBarrage_L1_2,   listBarrage_L1_3,   listBarrage_L1_4,   listBarrage_L1_5, NULL, }; 

BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d5b50d066fb77c09379b2ecff4c01376(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_394cea4d77e9d333c235108b5dbc5c88(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_7964c56f54d5225e5f62ad03d1bd17a1(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_b96cacf384b7371a18153dbb611dbf2f(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f62ae716ff689b0db49490423ea6e1db(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L2_1[] = { 
{ 116, 30, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 40, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 40, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 50, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 50, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 60, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 60, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 70, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 70, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 80, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 80, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 90, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 90, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 100, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 100, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 110, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 110, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 120, 4, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 120, 4, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 20, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 20, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 30, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 30, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 40, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 40, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 50, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 50, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 60, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 60, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 70, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 70, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 80, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 80, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 90, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 90, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 100, 3, genBulletFunc_d5b50d066fb77c09379b2ecff4c01376, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 100, 3, genBulletFunc_394cea4d77e9d333c235108b5dbc5c88, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 116, 30, 32, genBulletFunc_7964c56f54d5225e5f62ad03d1bd17a1, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 78, 40, 8, genBulletFunc_b96cacf384b7371a18153dbb611dbf2f, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 40 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 400 }, 
{ 14, 10, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 218, 10, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 16, 20, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 216, 20, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 18, 30, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 214, 30, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 20, 40, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 212, 40, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 22, 50, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 50, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 24, 60, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 208, 60, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 26, 70, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 206, 70, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 28, 80, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 204, 80, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 30, 90, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 202, 90, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 100, 4, genBulletFunc_8f6ee947ca2e017e9dee903bc37f6f73, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 100, 4, genBulletFunc_f62ae716ff689b0db49490423ea6e1db, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 500 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_BOSS_ENABLE, 0 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_bf44993c7032c5f5ff2e199bd34b2b7d(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L2_2[] = { 
{ 116, 40, 16, genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 10, 40, 64, genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 222, 40, 64, genBulletFunc_1ca95cbf6fecc58fbb1e3f826fc3545b, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 1200 }, 
{ 116, 40, 16, genBulletFunc_bf44993c7032c5f5ff2e199bd34b2b7d, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 100 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d616ce17dab7949731bdeb5fbace6e10(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L2_3[] = { 
{ 12, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_d616ce17dab7949731bdeb5fbace6e10, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_857ffb30df4ae1219f2f94987d8254da(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_725cf8416eb13190489c86a3a093aae1(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_857ffb30df4ae1219f2f94987d8254da(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_725cf8416eb13190489c86a3a093aae1(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_857ffb30df4ae1219f2f94987d8254da(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_725cf8416eb13190489c86a3a093aae1(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_857ffb30df4ae1219f2f94987d8254da(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_725cf8416eb13190489c86a3a093aae1(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_857ffb30df4ae1219f2f94987d8254da(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_725cf8416eb13190489c86a3a093aae1(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_444e03c42d0db749411ffb80b473544e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f107c17d1c894e586e7489862f23d92e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L2_4[] = { 
{ 60, 80, 4, genBulletFunc_857ffb30df4ae1219f2f94987d8254da, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 172, 80, 1, genBulletFunc_725cf8416eb13190489c86a3a093aae1, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 60, 80, 4, genBulletFunc_857ffb30df4ae1219f2f94987d8254da, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 172, 80, 1, genBulletFunc_725cf8416eb13190489c86a3a093aae1, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 60, 80, 4, genBulletFunc_857ffb30df4ae1219f2f94987d8254da, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 172, 80, 1, genBulletFunc_725cf8416eb13190489c86a3a093aae1, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 60, 80, 4, genBulletFunc_857ffb30df4ae1219f2f94987d8254da, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 172, 80, 1, genBulletFunc_725cf8416eb13190489c86a3a093aae1, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 60, 80, 4, genBulletFunc_857ffb30df4ae1219f2f94987d8254da, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 172, 80, 1, genBulletFunc_725cf8416eb13190489c86a3a093aae1, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 200 }, 
{ 12, 30, 32, genBulletFunc_444e03c42d0db749411ffb80b473544e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 30, 32, genBulletFunc_f107c17d1c894e586e7489862f23d92e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 100 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_d2333f29a4c9742a90a78c7706523640(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9d6b1ba2c20c012b7d7b7fad6fdc0ee3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_237614aaec8157c2c678e39a91b6f99b(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_9a82ad8bbb831832e2c899e19daaa0d5(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_02dd1bd4f9776189a750840ac63a62e3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_02dd1bd4f9776189a750840ac63a62e3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L2_5[] = { 
{ 32, 0, 16, genBulletFunc_d2333f29a4c9742a90a78c7706523640, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 16, genBulletFunc_9d6b1ba2c20c012b7d7b7fad6fdc0ee3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 12, 0, 16, genBulletFunc_237614aaec8157c2c678e39a91b6f99b, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 16, genBulletFunc_9a82ad8bbb831832e2c899e19daaa0d5, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 32, 50, 4, genBulletFunc_02dd1bd4f9776189a750840ac63a62e3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 50, 4, genBulletFunc_02dd1bd4f9776189a750840ac63a62e3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 22, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 42, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 52, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 62, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 72, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 82, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 92, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 102, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 100 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

const BarrageInfo * const listBarrage_L2_all[] = { 
  listBarrage_L2_1,   listBarrage_L2_2,   listBarrage_L2_3,   listBarrage_L2_4,   listBarrage_L2_5, NULL, }; 

BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_36341c0e8b8dd3b18492fefc828e7390(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_36341c0e8b8dd3b18492fefc828e7390(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_7964c56f54d5225e5f62ad03d1bd17a1(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_1dce9b78d98783de77dd9c4da10bc546(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_06bbe9313d42a45857295f64293f5f93(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_06bbe9313d42a45857295f64293f5f93(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_2c0732a900d9b3e707056d6023b22ceb(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_59b8e2343c4e9df70d90f97eb1458c37(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_02dd1bd4f9776189a750840ac63a62e3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_02dd1bd4f9776189a750840ac63a62e3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_dec11e16a9f1150c45961315fc55e25c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L3_1[] = { 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 12, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 3, genBulletFunc_2efa80d88730bc60d4dd12b0afe3afde, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 32, 0, 16, genBulletFunc_36341c0e8b8dd3b18492fefc828e7390, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 16, genBulletFunc_36341c0e8b8dd3b18492fefc828e7390, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 400 }, 
{ 116, 30, 32, genBulletFunc_7964c56f54d5225e5f62ad03d1bd17a1, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 232, 20, 8, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 60, 8, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 232, 20, 8, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 60, 8, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 232, 20, 8, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 60, 8, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 232, 20, 8, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 60, 8, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 232, 20, 8, genBulletFunc_d04a564664a6c54b8eb787ed27fb12b0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 60, 8, genBulletFunc_19e22a748dbd8fdfb82d14d4fef2c47c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 200 }, 
{ 12, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 22, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 32, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 42, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 52, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 62, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 72, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 82, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 92, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 102, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 0, 8, genBulletFunc_1dce9b78d98783de77dd9c4da10bc546, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 32, 0, 16, genBulletFunc_06bbe9313d42a45857295f64293f5f93, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 16, genBulletFunc_06bbe9313d42a45857295f64293f5f93, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 40, 16, genBulletFunc_2c0732a900d9b3e707056d6023b22ceb, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 40, 16, genBulletFunc_59b8e2343c4e9df70d90f97eb1458c37, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 400 }, 
{ 32, 20, 8, genBulletFunc_02dd1bd4f9776189a750840ac63a62e3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 20, 8, genBulletFunc_02dd1bd4f9776189a750840ac63a62e3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 200 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 200 }, 
{ 52, 20, 16, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 20, 16, genBulletFunc_dec11e16a9f1150c45961315fc55e25c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 100 }, 
{ 10, 50, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 222, 50, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 10, 90, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 222, 90, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 10, 130, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 222, 130, 4, genBulletFunc_4b2dc6f3a66d16b089e4ecdb71e96d99, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 400 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_BOSS_ENABLE, 0 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_8992f4049185e5d6d49bff5730ce81d7(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_5db72b392e4f591ce2f87d39746f9aec(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_444e03c42d0db749411ffb80b473544e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_f107c17d1c894e586e7489862f23d92e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_02dd1bd4f9776189a750840ac63a62e3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_02dd1bd4f9776189a750840ac63a62e3(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L3_2[] = { 
{ 116, 40, 8, genBulletFunc_8992f4049185e5d6d49bff5730ce81d7, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 116, 60, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 116, 75, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 116, 90, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 116, 105, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 116, 120, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 116, 135, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 20 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 200 }, 
{ 12, 35, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 228, 35, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 60, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 228, 60, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 85, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 228, 85, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 110, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 228, 110, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 135, 8, genBulletFunc_5db72b392e4f591ce2f87d39746f9aec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 228, 135, 8, genBulletFunc_afbc3f1599e7eb57bfa4eb2b00bb820c, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 12, 30, 32, genBulletFunc_444e03c42d0db749411ffb80b473544e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 30, 32, genBulletFunc_f107c17d1c894e586e7489862f23d92e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 100 }, 
{ 12, 40, 8, genBulletFunc_02dd1bd4f9776189a750840ac63a62e3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 40, 8, genBulletFunc_02dd1bd4f9776189a750840ac63a62e3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 300 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_c163d0c1eca8e02c382ac06659364b34(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_325b426ff585d06f988aa36ec8788a1e(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_bd7f7947863a9dae4991e3f4e756c141(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_12db626e647961ec34505eb6a92413f2(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8aedc8195754c4dd651f0a2a5a887566(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L3_3[] = { 
{ 12, 40, 8, genBulletFunc_c163d0c1eca8e02c382ac06659364b34, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 40, 8, genBulletFunc_325b426ff585d06f988aa36ec8788a1e, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 450 }, 
{ 116, 40, 32, genBulletFunc_bd7f7947863a9dae4991e3f4e756c141, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 32, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 0, 4, genBulletFunc_12db626e647961ec34505eb6a92413f2, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 12, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 4, genBulletFunc_8aedc8195754c4dd651f0a2a5a887566, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 120 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_da3c2a55b270cbe61ada2649019872a0(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_8bfcd38de5961107785fdc25e687ca15(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_aa380a2a544f70146f42c48fb87db420(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L3_4[] = { 
{ 12, 40, 16, genBulletFunc_da3c2a55b270cbe61ada2649019872a0, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 40, 16, genBulletFunc_8bfcd38de5961107785fdc25e687ca15, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 100 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 116, 30, 16, genBulletFunc_aa380a2a544f70146f42c48fb87db420, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 116, 30, 16, genBulletFunc_65e68c740ee2a220ba8c5031c4b6d1b3, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 30 }, 
{ 102, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 92, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 82, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 72, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 62, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 52, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 42, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 22, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 102, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 92, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 82, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 72, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 62, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 52, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 42, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 22, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 102, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 92, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 82, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 72, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 62, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 52, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 42, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 22, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 102, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 92, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 82, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 72, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 62, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 52, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 42, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 22, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 102, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 92, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 82, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 72, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 62, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 52, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 42, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 22, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 12, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 220, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 22, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 210, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 32, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 200, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 42, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 190, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 52, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 62, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 170, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 72, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 160, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 82, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 150, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 92, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 140, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 102, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 130, 10, 16, genBulletFunc_fd52ad7c32cd66562d39fa277c4b3797, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 60 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

BulletInfo *genBulletFunc_fedd858a2a4d5e35be3ee22ffc073e03(FixedPointNum posx, FixedPointNum posy);
BulletInfo *genBulletFunc_fef1923156fe801e24fe2bce452dbdec(FixedPointNum posx, FixedPointNum posy);
const BarrageInfo listBarrage_L3_5[] = { 
{ 52, 40, 2, genBulletFunc_fedd858a2a4d5e35be3ee22ffc073e03, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 180, 40, 2, genBulletFunc_fef1923156fe801e24fe2bce452dbdec, ACTIONTYPE_BULLET_NORMAL, 0 }, 
{ 0, 0, 0, NULL, ACTIONTYPE_WAIT, 10 }, 
{ 0, 0, 0, NULL, END_OF_ACTIONTYPE, 0 }, }; 

const BarrageInfo * const listBarrage_L3_all[] = { 
  listBarrage_L3_1,   listBarrage_L3_2,   listBarrage_L3_3,   listBarrage_L3_4,   listBarrage_L3_5, NULL, }; 

#endif
