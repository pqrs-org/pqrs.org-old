// XXX uniqID XXX 36341c0e8b8dd3b18492fefc828e7390 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "vulkanon/l0_boss0.hpp" 

extern const BulletStepFunc bullet_f133cfe56d797d92d8aa9c816c67fc6d_36341c0e8b8dd3b18492fefc828e7390[] = { 
stepfunc_b587d9b658e1574698c1f30e2a9ced3c_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_ab5073b1a6350cc9ffeec0330d39224a_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_36341c0e8b8dd3b18492fefc828e7390,
NULL}; 
void stepfunc_90cd1ede31c644b457c84fe448ce7e6e_36341c0e8b8dd3b18492fefc828e7390(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + ((-(20 * 1.0 * 256 / 360)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + ((-(20 * 1.0 * 256 / 360))+(2 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + ((-(20 * 1.0 * 256 / 360))-(2 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (((20 * 1.0 * 256 / 360)));  p->lastBulletSpeed = p->lastBulletSpeed + (0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (((20 * 1.0 * 256 / 360))+(2 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + (((20 * 1.0 * 256 / 360))-(2 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (0);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_0cde516a188577029bf4338e5541bbcc_36341c0e8b8dd3b18492fefc828e7390(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((10 * 1.0 * 256 / 360));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_d3e4d3d17cf2345eb8dbd615c1d4ea80_36341c0e8b8dd3b18492fefc828e7390(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = SelfPos::getAngle(p) + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
for (u32 i = 0; i < 35; ++i) { 
stepfunc_0cde516a188577029bf4338e5541bbcc_36341c0e8b8dd3b18492fefc828e7390(p);}
p->wait = static_cast<u16>(2); 
}
void stepfunc_5653a4ee143c51c2b5b3c8994b157d16_36341c0e8b8dd3b18492fefc828e7390(BulletInfo *p) { 
for (u32 i = 0; i < 5; ++i) { 
stepfunc_90cd1ede31c644b457c84fe448ce7e6e_36341c0e8b8dd3b18492fefc828e7390(p);}
p->wait = static_cast<u16>(30); 
}
void stepfunc_b587d9b658e1574698c1f30e2a9ced3c_36341c0e8b8dd3b18492fefc828e7390(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = (256 * -90 / 360) + ((180 * 1.0 * 256 / 360)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = 1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(40); 
}
void stepfunc_ab5073b1a6350cc9ffeec0330d39224a_36341c0e8b8dd3b18492fefc828e7390(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = 0.1 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(1); 
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_36341c0e8b8dd3b18492fefc828e7390(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_36341c0e8b8dd3b18492fefc828e7390(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_f133cfe56d797d92d8aa9c816c67fc6d_36341c0e8b8dd3b18492fefc828e7390); 
  }
return bi;}


