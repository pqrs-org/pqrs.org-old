// XXX uniqID XXX fef1923156fe801e24fe2bce452dbdec XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "vulkanon/l0_enemy13-left.hpp" 

extern const BulletStepFunc bullet_104eeeaa56e2bf430117bef58ddc7a9d_fef1923156fe801e24fe2bce452dbdec[] = { 
stepfunc_b5ccdb55b1c6958c7330d2c4b2466f1c_fef1923156fe801e24fe2bce452dbdec,
stepfunc_8c4041f942f600e94991c394939a804c_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec,
stepfunc_fddccad3a4269a6062fda865a05f419c_fef1923156fe801e24fe2bce452dbdec,
NULL}; 
void stepfunc_a867206a5bde2a9109dacde62b183d10_fef1923156fe801e24fe2bce452dbdec(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + ((90 * 1.0 * 256 / 360));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->getAngle() + (-(90 * 1.0 * 256 / 360));  p->lastBulletSpeed = (2);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(3); 
}
void stepfunc_b5ccdb55b1c6958c7330d2c4b2466f1c_fef1923156fe801e24fe2bce452dbdec(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = (256 * -90 / 360) + (FixedPointNum::random()*(360 * 1.0 * 256 / 360)) - p->getAngle();p->setRound(speed, life);}
p->wait = static_cast<u16>(2); 
}
void stepfunc_8c4041f942f600e94991c394939a804c_fef1923156fe801e24fe2bce452dbdec(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(9999);  FixedPointNum speed = -(3 * 1.0 * 256 / 360);p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(100);  FixedPointNum speed = FixedPointNum(4 - p->getSpeed(), life);p->setAccel(speed, life);}
}
void stepfunc_fddccad3a4269a6062fda865a05f419c_fef1923156fe801e24fe2bce452dbdec(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_fef1923156fe801e24fe2bce452dbdec(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_104eeeaa56e2bf430117bef58ddc7a9d_fef1923156fe801e24fe2bce452dbdec); 
  }
return bi;}


