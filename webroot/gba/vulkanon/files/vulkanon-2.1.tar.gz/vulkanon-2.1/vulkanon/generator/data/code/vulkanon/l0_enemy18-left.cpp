// XXX uniqID XXX 9a82ad8bbb831832e2c899e19daaa0d5 XXX 

#include <gba_types.h>
#include "bullet.hpp"
#include "fixed.hpp"


#include "vulkanon/l0_enemy18-left.hpp" 

extern const BulletStepFunc bullet_47361c68a13624703595a204db243d6b_9a82ad8bbb831832e2c899e19daaa0d5[] = { 
stepfunc_456753c9ab23d0c18884db48a58a16e6_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_30a5b118867561f3ad2802c148f182e3_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5,
stepfunc_dae2cf81747ffb5070f05c8837b1d568_9a82ad8bbb831832e2c899e19daaa0d5,
NULL}; 
void stepfunc_95f0e8f6018ee98f0e5e2282a88f0e9f_9a82ad8bbb831832e2c899e19daaa0d5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + (-(3 * 1.0 * 256 / 360));  p->lastBulletSpeed = (3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
{ 
  BulletInfo *bi;  p->lastBulletAngle = p->lastBulletAngle + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = p->lastBulletSpeed + (-0.5);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
p->wait = static_cast<u16>(1); 
}
void stepfunc_456753c9ab23d0c18884db48a58a16e6_9a82ad8bbb831832e2c899e19daaa0d5(BulletInfo *p) { 
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = (256 * -90 / 360) + ((180 * 1.0 * 256 / 360)) - p->getAngle();p->setRound(speed, life);}
{
  u16 life = static_cast<u16>(1);  FixedPointNum speed = 0.5 - p->getSpeed();p->setAccel(speed, life);}
p->wait = static_cast<u16>(2); 
}
void stepfunc_30a5b118867561f3ad2802c148f182e3_9a82ad8bbb831832e2c899e19daaa0d5(BulletInfo *p) { 
{ 
  BulletInfo *bi;  p->lastBulletAngle = (256 * -90 / 360) + ((0 * 1.0 * 256 / 360));  p->lastBulletSpeed = (3);  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_NORMAL, p->getPosX(), p->getPosY(), p->lastBulletAngle, p->lastBulletSpeed, StepFunc::nullStepFuncList); 
  }
}
}
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_9a82ad8bbb831832e2c899e19daaa0d5(BulletInfo *p) { 
ListBullets::stepFuncDrop(p);}


BulletInfo *genBulletFunc_9a82ad8bbb831832e2c899e19daaa0d5(FixedPointNum posx, FixedPointNum posy) {  BulletInfo * bi;  bi = ListBullets::makeNewBullet();  if (bi != NULL) {    bi->initialize(BULLET_TYPE_ROOT, posx, posy, BulletInfo::DEFAULT_ANGLE, 0, bullet_47361c68a13624703595a204db243d6b_9a82ad8bbb831832e2c899e19daaa0d5); 
  }
return bi;}


