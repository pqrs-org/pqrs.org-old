#ifndef GENERATED_a4212426e09163426c813cbc2dfeb844_HPP 
#define GENERATED_a4212426e09163426c813cbc2dfeb844_HPP 

#include "bullet.hpp" 

void stepfunc_828aad5c654f274364631801f59cac21_b96cacf384b7371a18153dbb611dbf2f(BulletInfo *p); 
void stepfunc_f8401db310e724958a9f137cd0d4f8f8_b96cacf384b7371a18153dbb611dbf2f(BulletInfo *p); 
void stepfunc_fddccad3a4269a6062fda865a05f419c_b96cacf384b7371a18153dbb611dbf2f(BulletInfo *p); 


extern const BulletStepFunc bullet_80777900aecda62db38f30ea0d3dd424_b96cacf384b7371a18153dbb611dbf2f[]; 
const unsigned int bullet_80777900aecda62db38f30ea0d3dd424_b96cacf384b7371a18153dbb611dbf2f_size = 303; 


#endif 

