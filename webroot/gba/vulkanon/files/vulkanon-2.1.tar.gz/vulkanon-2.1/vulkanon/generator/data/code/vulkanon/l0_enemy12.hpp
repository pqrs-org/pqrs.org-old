#ifndef GENERATED_52b5fd9cebd5643b97a2ce1a2b00ea0c_HPP 
#define GENERATED_52b5fd9cebd5643b97a2ce1a2b00ea0c_HPP 

#include "bullet.hpp" 

void stepfunc_d5b50929d4498db95fe3b57b9c6c8094_fd52ad7c32cd66562d39fa277c4b3797(BulletInfo *p); 
void stepfunc_e1cb05365e955e6c9fc4a42f10774254_fd52ad7c32cd66562d39fa277c4b3797(BulletInfo *p); 


extern const BulletStepFunc bullet_ad17e24e2aa20f678a19b17be5213ea0_fd52ad7c32cd66562d39fa277c4b3797[]; 
const unsigned int bullet_ad17e24e2aa20f678a19b17be5213ea0_fd52ad7c32cd66562d39fa277c4b3797_size = 2; 


#endif 

