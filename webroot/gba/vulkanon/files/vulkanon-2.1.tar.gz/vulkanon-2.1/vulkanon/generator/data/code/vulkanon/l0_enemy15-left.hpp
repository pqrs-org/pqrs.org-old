#ifndef GENERATED_48c32fac5cf257f6aa4f4d552cac8a6f_HPP 
#define GENERATED_48c32fac5cf257f6aa4f4d552cac8a6f_HPP 

#include "bullet.hpp" 

void stepfunc_bed8dda85fc60ff8f3f2ddb90c504bf2_8f6ee947ca2e017e9dee903bc37f6f73(BulletInfo *p); 
void stepfunc_080b1eb42fb42892af9d6ff05dd94667_8f6ee947ca2e017e9dee903bc37f6f73(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_8f6ee947ca2e017e9dee903bc37f6f73(BulletInfo *p); 


extern const BulletStepFunc bullet_8142b7ea14e8d500940695bd4dbc8958_8f6ee947ca2e017e9dee903bc37f6f73[]; 
const unsigned int bullet_8142b7ea14e8d500940695bd4dbc8958_8f6ee947ca2e017e9dee903bc37f6f73_size = 63; 


#endif 

