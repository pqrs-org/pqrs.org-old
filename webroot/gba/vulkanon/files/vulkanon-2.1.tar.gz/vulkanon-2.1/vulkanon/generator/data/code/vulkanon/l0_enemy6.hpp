#ifndef GENERATED_96fb4f69067a5860bc3adec24d3cd984_HPP 
#define GENERATED_96fb4f69067a5860bc3adec24d3cd984_HPP 

#include "bullet.hpp" 

void stepfunc_10750c37326115a8f97cd844e93d5b79_02dd1bd4f9776189a750840ac63a62e3(BulletInfo *p); 
void stepfunc_dae2cf81747ffb5070f05c8837b1d568_02dd1bd4f9776189a750840ac63a62e3(BulletInfo *p); 


extern const BulletStepFunc bullet_1bf5b6d52633688731bc37f215e484cb_02dd1bd4f9776189a750840ac63a62e3[]; 
const unsigned int bullet_1bf5b6d52633688731bc37f215e484cb_02dd1bd4f9776189a750840ac63a62e3_size = 1002; 


#endif 

