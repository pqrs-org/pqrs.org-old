#include "soundhandler.hpp"

SoundCore<true> SoundHandler::soundCoreMusic;
SoundCore<false> SoundHandler::soundCoreSE;
