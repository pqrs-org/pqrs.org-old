#ifndef AUDIODEF_HPP
#define AUDIODEF_HPP

extern const char _binary_music01_raw_start[];
extern const char _binary_music01_raw_end[];
extern const char _binary_music01_raw_size[];
const int _filesize_music01_raw = 99723;

extern const char _binary_music02_raw_start[];
extern const char _binary_music02_raw_end[];
extern const char _binary_music02_raw_size[];
const int _filesize_music02_raw = 138242;

extern const char _binary_music03_raw_start[];
extern const char _binary_music03_raw_end[];
extern const char _binary_music03_raw_size[];
const int _filesize_music03_raw = 197732;

extern const char _binary_se01_raw_start[];
extern const char _binary_se01_raw_end[];
extern const char _binary_se01_raw_size[];
const int _filesize_se01_raw = 33812;

extern const char _binary_se02_raw_start[];
extern const char _binary_se02_raw_end[];
extern const char _binary_se02_raw_size[];
const int _filesize_se02_raw = 23112;

#endif

