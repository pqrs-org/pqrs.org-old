#include "libgbakey.hpp"

u16 GBAKey::up;
u16 GBAKey::down;
u16 GBAKey::held;
u16 GBAKey::last;
