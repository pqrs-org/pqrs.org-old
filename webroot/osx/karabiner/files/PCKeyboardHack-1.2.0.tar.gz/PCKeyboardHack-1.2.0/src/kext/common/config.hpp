#ifndef CONFIG_HPP
#define CONFIG_HPP

#include "keymap.hpp"

namespace org_pqrs_PCKeyboardHack {
  class Config {
  public:
    int enable_jis_xfer;
    int enable_jis_nfer;
    int enable_jis_kana;
    int keycode_jis_xfer;
    int keycode_jis_nfer;
    int keycode_jis_kana;

    Config(void) {
      keycode_jis_xfer = KeyMapCode::JIS_KANA;
      keycode_jis_nfer = KeyMapCode::JIS_EISUU;
      keycode_jis_kana = KeyMapCode::COMMAND_R;
    }
  };
  extern Config config;

  void sysctl_register(void);
  void sysctl_unregister(void);
}

#endif
