#ifndef KEYMAP_HPP
#define KEYMAP_HPP

namespace org_pqrs_PCKeyboardHack {
  namespace KeyMapIndex {
    // see IOHIDUsageTables.h
    enum KeyMapIndex {
      A = 0x04,
      E = 0x08,
      JIS_KANA = 0x88,
      JIS_XFER = 0x8a,
      JIS_NFER = 0x8b,
    };
  }
  namespace KeyMapCode {
    // see Cosmo_USB2ADB.c
    enum KeyMapCode {
      A = 0x00,
      E = 0x0e,
      FORWARD_DELETE = 0x75,
      COMMAND_R = 0x36,
      JIS_KANA = 0x68,
      JIS_EISUU = 0x66,
    };
  }
}

#endif
