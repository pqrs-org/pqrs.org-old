// -*- Mode: objc -*-
//
// KeyResponder.h
//

#import <Cocoa/Cocoa.h>

@interface KeyResponder : NSImageView
{
  IBOutlet id _result;
}
@end
