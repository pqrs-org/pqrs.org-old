char * const config_version = "2.0.0-Leopard";
