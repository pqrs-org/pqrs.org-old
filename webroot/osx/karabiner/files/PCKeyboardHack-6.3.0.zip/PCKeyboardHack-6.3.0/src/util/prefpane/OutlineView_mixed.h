// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-
#import <Cocoa/Cocoa.h>

@interface org_pqrs_PCKeyboardHack_OutlineView_mixed : NSObject
{
  IBOutlet id _outlineView_mixed;
}

@end
