NoEjectDelay
============

NoEjectDelay clears the eject key delay.
Use this software when you change the eject key behavior in KeyRemap4MacBook.


System requirements
-------------------
Mac OS X 10.6 or higher.

If you require NoEjectDelay for Mac OS X 10.5.x, use NoEjectDelay 1.1.0.
