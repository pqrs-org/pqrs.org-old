// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-
#import <Cocoa/Cocoa.h>

@interface org_pqrs_KeyRemap4MacBook_OutlineView_number : NSObject
{
  IBOutlet id _outlineView_number;
}

@end
