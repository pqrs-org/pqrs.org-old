#!/bin/sh

/sbin/kextunload -b org.pqrs.driver.KeyRemap4MacBook
exit 0
