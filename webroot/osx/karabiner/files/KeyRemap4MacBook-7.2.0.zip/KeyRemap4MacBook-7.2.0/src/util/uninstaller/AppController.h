// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-

#import <Cocoa/Cocoa.h>

@interface AppController : NSObject {
  IBOutlet id _message;
}

- (IBAction) uninstall:(id)sender;

@end
