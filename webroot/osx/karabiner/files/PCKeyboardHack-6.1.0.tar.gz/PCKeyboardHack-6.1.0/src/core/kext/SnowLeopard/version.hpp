char config_version[] = "6.1.0-SnowLeopard";
