char config_version[] = "6.6.0";
