void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = KeyCode::VK_NONE;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = KeyCode::VK_NONE;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = KeyCode::VK_NONE;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = KeyCode::VK_NONE;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = KeyCode::VK_NONE;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = KeyCode::VK_NONE;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = KeyCode::VK_NONE;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = KeyCode::VK_NONE;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = KeyCode::VK_NONE;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = KeyCode::VK_NONE;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5, Flags toFlags5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = toFlags5;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4, Flags toFlags4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = toFlags4;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3, Flags toFlags3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = toFlags3;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2, Flags toFlags2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = toFlags2;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1, Flags toFlags1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = toFlags1;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
void initialize(KeyCode virtualKeyCode, KeyCode fromKeyCode1, KeyCode fromKeyCode2,
                KeyCode toKeyCode1,
                KeyCode toKeyCode2,
                KeyCode toKeyCode3,
                KeyCode toKeyCode4,
                KeyCode toKeyCode5)
{
  virtualKeyCode_ = virtualKeyCode;

  fromKeyCode1_ = fromKeyCode1;
  fromKeyCode2_ = fromKeyCode2;

  toKeyCode1_ = toKeyCode1;
  toFlags1_ = ModifierFlag::NONE;

  toKeyCode2_ = toKeyCode2;
  toFlags2_ = ModifierFlag::NONE;

  toKeyCode3_ = toKeyCode3;
  toFlags3_ = ModifierFlag::NONE;

  toKeyCode4_ = toKeyCode4;
  toFlags4_ = ModifierFlag::NONE;

  toKeyCode5_ = toKeyCode5;
  toFlags5_ = ModifierFlag::NONE;

  active1_ = false;
  active2_ = false;
}
