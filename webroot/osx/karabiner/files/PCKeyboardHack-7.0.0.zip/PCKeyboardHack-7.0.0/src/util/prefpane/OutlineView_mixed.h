// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-
#import <Cocoa/Cocoa.h>
#import "PCKeyboardHackClient.h"

@interface org_pqrs_PCKeyboardHack_OutlineView_mixed : NSObject
{
  IBOutlet id _outlineView_mixed;
  IBOutlet org_pqrs_PCKeyboardHack_Client* client_;
}

@end
