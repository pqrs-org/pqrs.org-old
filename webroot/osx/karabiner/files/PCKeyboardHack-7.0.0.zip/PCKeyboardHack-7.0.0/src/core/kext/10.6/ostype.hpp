#ifndef OSTYPE_HPP
#define OSTYPE_HPP

const char* const ostype = "10.6";

#endif
