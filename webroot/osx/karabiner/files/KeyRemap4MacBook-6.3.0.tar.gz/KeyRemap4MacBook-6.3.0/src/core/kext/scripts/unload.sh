#!/bin/sh

sudo /bin/echo
sleep 1
sudo kextunload -b org.pqrs.driver.KeyRemap4MacBook
