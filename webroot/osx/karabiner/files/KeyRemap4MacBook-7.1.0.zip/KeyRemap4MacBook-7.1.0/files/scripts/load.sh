#!/bin/sh

/sbin/kextload /Library/org.pqrs/KeyRemap4MacBook/KeyRemap4MacBook.kext
exit 0
