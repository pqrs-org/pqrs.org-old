//
//  DumpInputModeToConsoleAppDelegate.h
//  DumpInputModeToConsole
//
//  Created by Takayama Fumihiko on 09/11/07.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DumpInputModeToConsoleAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
