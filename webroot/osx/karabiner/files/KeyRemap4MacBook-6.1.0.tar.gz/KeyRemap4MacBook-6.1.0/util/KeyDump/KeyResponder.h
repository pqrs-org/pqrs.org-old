// -*- Mode: objc -*-
//
// KeyResponder.h
//

#import <Cocoa/Cocoa.h>

@interface KeyResponder : NSResponder
{
  IBOutlet id _result;
}
@end
