char config_version[] = "2.0.0-SnowLeopard";
