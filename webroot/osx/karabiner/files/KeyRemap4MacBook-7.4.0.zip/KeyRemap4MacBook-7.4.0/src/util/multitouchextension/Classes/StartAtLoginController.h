// -*- Mode: objc -*-

#import <Cocoa/Cocoa.h>

@interface StartAtLoginController : NSObject

+ (BOOL) isStartAtLogin;
+ (void) setStartAtLogin:(BOOL)newvalue;

@end
