#ifndef VIRTUALKEY_VK_LOCK_HPP
#define VIRTUALKEY_VK_LOCK_HPP

namespace org_pqrs_KeyRemap4MacBook {
  namespace VirtualKey {
    class VK_LOCK {
    public:
      static bool handle(const Params_KeyboardEventCallBack& params);
    };
  }
}

#endif
