#ifndef VIRTUALKEY_VK_JIS_YEN_HPP
#define VIRTUALKEY_VK_JIS_YEN_HPP

namespace org_pqrs_KeyRemap4MacBook {
  namespace VirtualKey {
    class VK_JIS_YEN {
    public:
      static bool handle(const Params_KeyboardEventCallBack& params);
    };
  }
}

#endif
