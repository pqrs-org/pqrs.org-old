#ifndef VIRTUALKEY_VK_STICKY_HPP
#define VIRTUALKEY_VK_STICKY_HPP

namespace org_pqrs_KeyRemap4MacBook {
  namespace VirtualKey {
    class VK_STICKY {
    public:
      static bool handle(const Params_KeyboardEventCallBack& params);
    };
  }
}

#endif
