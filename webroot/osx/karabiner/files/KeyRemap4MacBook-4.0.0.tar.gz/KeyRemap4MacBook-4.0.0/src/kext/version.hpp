char * const config_version = "4.0.0";
