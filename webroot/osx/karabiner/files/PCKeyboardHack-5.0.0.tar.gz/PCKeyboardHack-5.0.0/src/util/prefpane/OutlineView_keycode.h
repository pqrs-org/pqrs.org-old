// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-
#import <Cocoa/Cocoa.h>

@interface org_pqrs_PCKeyboardHack_OutlineView_keycode : NSObject
{
  IBOutlet id _outlineView_keycode;
}

@end
