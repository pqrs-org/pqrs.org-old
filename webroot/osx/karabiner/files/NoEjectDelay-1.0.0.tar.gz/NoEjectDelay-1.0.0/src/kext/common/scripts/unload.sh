#!/bin/sh

sudo kextunload -b org.pqrs.driver.NoEjectDelay
