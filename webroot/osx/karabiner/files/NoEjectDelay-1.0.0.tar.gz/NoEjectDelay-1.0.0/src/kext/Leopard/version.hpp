char * const config_version = "1.0.0-Leopard";
