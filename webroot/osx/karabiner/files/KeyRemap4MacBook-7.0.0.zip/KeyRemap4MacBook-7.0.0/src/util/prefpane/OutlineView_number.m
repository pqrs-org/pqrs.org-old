/* -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*- */

#import "OutlineView_number.h"

@implementation org_pqrs_KeyRemap4MacBook_OutlineView_number

- (id) init
{
  [super init];

  ischeckbox_ = NO;

  return self;
}

@end
