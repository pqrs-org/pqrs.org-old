#!/bin/sh

sudo /bin/echo
sudo kextunload -b org.pqrs.driver.KeyRemap4MacBook
exit 0
