char config_version[] = "7.0.0";
