#!/bin/sh

/Library/org.pqrs/KeyRemap4MacBook/extra/uninstall_core.sh

rm -f /var/db/receipts/org.pqrs.driver.KeyRemap4MacBook.*

exit 0
