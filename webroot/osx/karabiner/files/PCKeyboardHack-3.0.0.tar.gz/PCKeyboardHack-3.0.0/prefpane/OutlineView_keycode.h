// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-
#import <Cocoa/Cocoa.h>
#import "XMLTreeWrapper.h"

@interface OutlineView_keycode : NSObject
{
  XMLTreeWrapper *_xmlTreeWrapper;

  IBOutlet id _outlineView;
}

@end
