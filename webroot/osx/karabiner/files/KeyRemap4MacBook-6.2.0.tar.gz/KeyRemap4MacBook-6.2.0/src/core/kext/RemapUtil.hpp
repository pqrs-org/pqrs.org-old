#ifndef REMAPUTIL_HPP
#define REMAPUTIL_HPP

#include <IOKit/hidsystem/IOHIKeyboard.h>
#include "remap.hpp"
#include "keycode.hpp"
#include "util/FlagStatus.hpp"
#include "util/PressDownKeys.hpp"
#include "util/ListFireExtraKey.hpp"
#include "util/ListFireConsumerKey.hpp"
#include "util/ListFireRelativePointer.hpp"
#include "util/IntervalChecker.hpp"
#include "util/ClickWatcher.hpp"

namespace org_pqrs_KeyRemap4MacBook {
  namespace RemapUtil {
    enum {
      // see IOHIPointing.cpp in darwin.
      POINTING_FIXED_SCALE = 65536, // (== << 16)
      POINTING_POINT_SCALE = 10, // (== SCROLL_WHEEL_TO_PIXEL_SCALE >> 16)
    };

    inline bool isKey(const RemapParams &remapParams, unsigned int keyCode) {
      return remapParams.ex_origKey == keyCode && (remapParams.params)->key == keyCode;
    }
    inline bool isKey(const RemapConsumerParams &remapParams, ConsumerKeyCode::ConsumerKeyCode keyCode) {
      return (remapParams.params)->key == static_cast<unsigned int>(keyCode);
    }
    inline bool isEvent_Down(const RemapParams &remapParams) {
      return (remapParams.params)->eventType == KeyEvent::DOWN;
    }
    inline bool isEvent_Up(const RemapParams &remapParams) {
      return (remapParams.params)->eventType == KeyEvent::UP;
    }
    inline bool isEvent_Modify(const RemapParams &remapParams) {
      return (remapParams.params)->eventType == KeyEvent::MODIFY;
    }
    inline void drop(const RemapParams &remapParams) {
      (remapParams.params)->key = KeyCode::NONE;
    }

    inline bool isModifierOn(unsigned int flags, ModifierFlag::ModifierFlag f) {
      return ((flags & f) == static_cast<unsigned int>(f));
    }
    inline bool isModifierOn(const RemapParams &remapParams, ModifierFlag::ModifierFlag flag) {
      return isModifierOn((remapParams.params)->flags, flag);
    }

    KeyCode::KeyCode getModifierKeyCode(ModifierFlag::ModifierFlag flag);
    ModifierFlag::ModifierFlag getKeyCodeModifier(unsigned int keycode);

    inline bool isKeyDown(const RemapParams &remapParams, unsigned int keyCode) {
      if (isEvent_Down(remapParams)) {
        return isKey(remapParams, keyCode);
      } else if (isEvent_Modify(remapParams)) {
        return isModifierOn(remapParams, getKeyCodeModifier(keyCode));
      } else {
        return false;
      }
    }

    bool isInternalKeyboard(unsigned int keyboardType);

    bool keyToKey(const RemapParams &remapParams, KeyCode::KeyCode fromKeyCode, unsigned int fromFlags, KeyCode::KeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE);
    inline bool keyToKey(const RemapParams &remapParams, KeyCode::KeyCode fromKeyCode, KeyCode::KeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE) {
      return keyToKey(remapParams, fromKeyCode, 0, toKeyCode, toFlags);
    }
    bool keyToKey(const RemapParams& remapParams, KeyCode::KeyCode fromKeyCode, unsigned int fromFlags,
                  KeyCode::KeyCode toKeyCode1, unsigned int toFlags1,
                  KeyCode::KeyCode toKeyCode2, unsigned int toFlags2 = ModifierFlag::NONE);
    inline bool keyToKey(const RemapParams& remapParams, KeyCode::KeyCode fromKeyCode, unsigned int fromFlags,
                         KeyCode::KeyCode toKeyCode1,
                         KeyCode::KeyCode toKeyCode2, unsigned int toFlags2 = ModifierFlag::NONE) {
      return keyToKey(remapParams, fromKeyCode, fromFlags, toKeyCode1, ModifierFlag::NONE, toKeyCode2, toFlags2);
    }

    bool keyToKey_dependingShift(const RemapParams &remapParams, KeyCode::KeyCode fromKeyCode,
                                 KeyCode::KeyCode toKeyCode_noflag1, CharCode::CharCode toCharCode_noflag1,
                                 KeyCode::KeyCode toKeyCode_noflag2, CharCode::CharCode toCharCode_noflag2,
                                 KeyCode::KeyCode toKeyCode_shiftL1, CharCode::CharCode toCharCode_shiftL1,
                                 KeyCode::KeyCode toKeyCode_shiftL2, CharCode::CharCode toCharCode_shiftL2,
                                 KeyCode::KeyCode toKeyCode_shiftR1, CharCode::CharCode toCharCode_shiftR1,
                                 KeyCode::KeyCode toKeyCode_shiftR2, CharCode::CharCode toCharCode_shiftR2);

    void keyToPointingButton(const RemapParams &remapParams, KeyCode::KeyCode fromKeyCode, PointingButton::PointingButton toButton);

    bool keyToConsumer(const RemapParams &remapParams,
                       KeyCode::KeyCode fromKeyCode, unsigned int fromFlags,
                       ConsumerKeyCode::ConsumerKeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE);
    inline bool keyToConsumer(const RemapParams &remapParams,
                              KeyCode::KeyCode fromKeyCode,
                              ConsumerKeyCode::ConsumerKeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE) {
      return keyToConsumer(remapParams, fromKeyCode, 0, toKeyCode, toFlags);
    }

    bool consumerToKey(const RemapConsumerParams &remapParams,
                       ConsumerKeyCode::ConsumerKeyCode fromKeyCode, unsigned int fromFlags,
                       KeyCode::KeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE);
    inline bool consumerToKey(const RemapConsumerParams &remapParams,
                              ConsumerKeyCode::ConsumerKeyCode fromKeyCode,
                              KeyCode::KeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE) {
      return consumerToKey(remapParams, fromKeyCode, 0, toKeyCode, toFlags);
    }

    bool consumerToConsumer(const RemapConsumerParams &remapParams,
                            ConsumerKeyCode::ConsumerKeyCode fromKeyCode, unsigned int fromFlags,
                            ConsumerKeyCode::ConsumerKeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE);
    inline bool consumerToConsumer(const RemapConsumerParams &remapParams,
                                   ConsumerKeyCode::ConsumerKeyCode fromKeyCode,
                                   ConsumerKeyCode::ConsumerKeyCode toKeyCode, unsigned int toFlags = ModifierFlag::NONE) {
      return consumerToConsumer(remapParams, fromKeyCode, 0, toKeyCode, toFlags);
    }

    bool pointingButtonToPointingButton(const RemapPointingParams_relative &remapParams,
                                        PointingButton::PointingButton fromButton, unsigned int fromFlags,
                                        PointingButton::PointingButton toButton);
    inline bool pointingButtonToPointingButton(const RemapPointingParams_relative &remapParams,
                                               PointingButton::PointingButton fromButton,
                                               PointingButton::PointingButton toButton) {
      return pointingButtonToPointingButton(remapParams, fromButton, 0, toButton);
    }

    // ----------------------------------------
    void fireModifiers(KeyboardEventCallback callback, const Params_KeyboardEventCallBack &params);
    void fireKey(KeyboardEventCallback callback, const Params_KeyboardEventCallBack &params);
    void fireConsumer(KeyboardSpecialEventCallback callback, const Params_KeyboardSpecialEventCallback &params);

    // ----------------------------------------
    void jis_toggle_eisuu_kana(const RemapParams &remapParams, KeyCode::KeyCode fromKeyCode);

    // ----------------------------------------
    void pointingRelativeToScroll(const RemapPointingParams_relative &remapParams);
  }

  extern ListFireConsumerKey listFireConsumerKey;

  // ----------------------------------------------------------------------
  namespace FireFunc {
    typedef void (*FireFunc)(const RemapParams &remapParams);
    void firefunc_nop(const RemapParams &remapParams);
    void firefunc_backslash(const RemapParams &remapParams);
    void firefunc_commandO(const RemapParams &remapParams);
    void firefunc_commandSpace(const RemapParams &remapParams);
    void firefunc_enter(const RemapParams &remapParams);
    void firefunc_escape(const RemapParams &remapParams);
    void firefunc_exposeAll(const RemapParams &remapParams);
    void firefunc_return(const RemapParams &remapParams);
    void firefunc_space(const RemapParams &remapParams);
    void firefunc_tab(const RemapParams &remapParams);
    void firefunc_emacsmode_controlK(const RemapParams &remapParams, bool first);
    void firefunc_emacsmode_controlK_2nd(const RemapParams &remapParams);
    void firefunc_french_backslash(const RemapParams &remapParams);
    void firefunc_jis_kana(const RemapParams &remapParams);
    void firefunc_jis_kana_x2(const RemapParams &remapParams);
    void firefunc_jis_eisuu(const RemapParams &remapParams);
    void firefunc_jis_eisuu_x2(const RemapParams &remapParams);
    void firefunc_jis_toggle_eisuu_kana(const RemapParams &remapParams);
  }

  namespace ExtraRepeatFunc {
    void call_firefunc(FireFunc::FireFunc firefunc, KeyboardEventCallback callback, OSObject *target, unsigned int flags, unsigned int keyboardType, AbsoluteTime ts, OSObject *sender, void *refcon);

    void extraRepeatFunc_enter(KeyboardEventCallback callback, OSObject *target, unsigned int flags, unsigned int keyboardType, AbsoluteTime ts, OSObject *sender, void *refcon);
    void extraRepeatFunc_space(KeyboardEventCallback callback, OSObject *target, unsigned int flags, unsigned int keyboardType, AbsoluteTime ts, OSObject *sender, void *refcon);
    void extraRepeatFunc_emacsmode_controlK(KeyboardEventCallback callback, OSObject *target, unsigned int flags, unsigned int keyboardType, AbsoluteTime ts, OSObject *sender, void *refcon);

    void register_keyCombination(KeyCode::KeyCode keyCode1, CharCode::CharCode charCode1, KeyCode::KeyCode keyCode2, CharCode::CharCode charCode2);
    void extraRepeatFunc_keyCombination(KeyboardEventCallback callback, OSObject *target, unsigned int flags, unsigned int keyboardType, AbsoluteTime ts, OSObject *sender, void *refcon);
  }

  // ----------------------------------------
  // for SandS like behavior remappings (remap_space2shift, remap_enter2optionL_commandSpace, ...)
  class KeyOverlaidModifier {
  public:
    void remap(const RemapParams &remapParams, KeyCode::KeyCode fromKeyCode, ModifierFlag::ModifierFlag toFlag, FireFunc::FireFunc firefunc, ExtraRepeatFunc::ExtraRepeatFunc extraRepeatFunc = NULL);

  private:
    bool useAsModifier;
    bool isClick;
    IntervalChecker ic;
  };

  // ----------------------------------------
  // Command_R+Command_L to Escape, ...
  class KeyOverlaidModifierCombination {
  public:
    void remap(const RemapParams &remapParams, ModifierFlag::ModifierFlag fromFlag1, ModifierFlag::ModifierFlag fromFlag2, FireFunc::FireFunc firefunc);

  private:
    bool isModifier1HeldDown;
    bool isCallFireFunc;
    bool isClick;
  };

  // ----------------------------------------
  // A modifier has DoublePressed key action.
  class DoublePressModifier {
  public:
    void remap(const RemapParams &remapParams, KeyCode::KeyCode fromKeyCode, ModifierFlag::ModifierFlag toFlag, FireFunc::FireFunc firefunc);

  private:
    int pressCount;
  };

  // ----------------------------------------
  // Modifier Holding + Key -> Key
  class ModifierHoldingKeyToKey {
  public:
    void remap(const RemapParams &remapParams, ModifierFlag::ModifierFlag fromFlag, KeyCode::KeyCode fromKeyCode, KeyCode::KeyCode toKeyCode);

  private:
    IntervalChecker ic;
    bool doremap;
    bool first;
  };

  // --------------------
  extern ListFireRelativePointer listFireRelativePointer;

  // --------------------
  class FirePointingScroll {
  public:
    void set(short int _deltaAxis1, short int _deltaAxis2, short int _deltaAxis3, IOFixed _fixedDelta1, IOFixed _fixedDelta2, IOFixed _fixedDelta3, SInt32 _pointDelta1, SInt32 _pointDelta2, SInt32 _pointDelta3) {
      enable = true;
      deltaAxis1 = _deltaAxis1;
      deltaAxis2 = _deltaAxis2;
      deltaAxis3 = _deltaAxis3;
      fixedDelta1 = _fixedDelta1;
      fixedDelta2 = _fixedDelta2;
      fixedDelta3 = _fixedDelta3;
      pointDelta1 = _pointDelta1;
      pointDelta2 = _pointDelta2;
      pointDelta3 = _pointDelta3;
    }
    void fire(ScrollWheelEventCallback callback, OSObject *target, IOHIPointing *pointing, AbsoluteTime ts);
    bool isEnable(void) const { return enable; }

  private:
    bool enable;
    short int deltaAxis1;
    short int deltaAxis2;
    short int deltaAxis3;
    IOFixed fixedDelta1;
    IOFixed fixedDelta2;
    IOFixed fixedDelta3;
    SInt32 pointDelta1;
    SInt32 pointDelta2;
    SInt32 pointDelta3;
  };

  extern FirePointingScroll firePointingScroll;

  // ----------------------------------------
  class ButtonRelativeToScroll {
  public:
    void remap(const RemapPointingParams_relative &remapParams, unsigned int button);

  private:
    bool isButtonHeldDown;
  };
}

#endif
