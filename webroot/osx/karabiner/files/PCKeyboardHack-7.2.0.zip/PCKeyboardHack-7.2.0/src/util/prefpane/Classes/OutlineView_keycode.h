// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-
#import <Cocoa/Cocoa.h>
#import "OutlineView.h"

@interface org_pqrs_PCKeyboardHack_OutlineView_keycode : org_pqrs_PCKeyboardHack_OutlineView

- (NSString*) getKeyName:(int)keycode;

@end
