#ifndef CONFIG_HPP
#define CONFIG_HPP

#include "keymap.hpp"

namespace org_pqrs_PCKeyboardHack {
  class Config {
  public:
    int keycode_xfer;
    int keycode_nfer;

    Config(void) {
      keycode_xfer = KeyMapCode::KANA;
      keycode_nfer = KeyMapCode::EISUU;
    }
  };
  extern Config config;

  void sysctl_register(void);
  void sysctl_unregister(void);
}

#endif
