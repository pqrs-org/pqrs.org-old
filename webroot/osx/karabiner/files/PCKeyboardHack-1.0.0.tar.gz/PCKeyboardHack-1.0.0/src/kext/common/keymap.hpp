#ifndef KEYMAP_HPP
#define KEYMAP_HPP

namespace org_pqrs_PCKeyboardHack {
  namespace KeyMapIndex {
    enum KeyMapIndex {
      XFER = 0x008a,
      NFER = 0x008b,
    };
  }
  namespace KeyMapCode {
    enum KeyMapCode {
      KANA = 0x0068,
      EISUU = 0x0066,
    };
  }
}

#endif
