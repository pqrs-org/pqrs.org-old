#!/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin; export PATH

basedir="/Applications/PCKeyboardHack"

argument="$1"
[ -z "$argument" ] && argument=start
case "$argument" in
    start)
        echo "Starting PCKeyboardHack"
        sleep 10 # wait for avoid kext loading collision.
        "$basedir/scripts/load.sh"
        ;;

    quickstart)
        echo "Starting PCKeyboardHack"
        "$basedir/scripts/load.sh"
        ;;

    stop)
        echo "Stopping PCKeyboardHack"
        "$basedir/scripts/unload.sh"
        ;;

    *)
        echo "Usage: $0 {start|stop}"
        ;;
esac

exit 0
