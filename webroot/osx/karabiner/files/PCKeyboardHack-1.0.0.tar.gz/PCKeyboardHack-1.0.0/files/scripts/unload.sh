#!/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin; export PATH

basedir="/Applications/PCKeyboardHack"
kextfile="$basedir/PCKeyboardHack.kext"

"$basedir/scripts/save.sh"
kextunload "$kextfile"

exit 0
