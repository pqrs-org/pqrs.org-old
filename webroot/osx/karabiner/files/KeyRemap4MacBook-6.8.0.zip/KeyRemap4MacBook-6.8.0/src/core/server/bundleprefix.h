/* -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*- */

#define BUNDLEPREFIX(x) org_pqrs_KeyRemap4MacBook_ ## x
