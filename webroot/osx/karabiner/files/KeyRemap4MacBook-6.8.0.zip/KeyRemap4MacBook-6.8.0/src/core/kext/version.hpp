char config_version[] = "6.8.0";
