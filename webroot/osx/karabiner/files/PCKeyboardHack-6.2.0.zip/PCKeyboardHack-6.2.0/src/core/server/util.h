#ifndef UTIL_H
#define UTIL_H

#ifdef __cplusplus
extern "C" {
#endif

void sysctl_reset(void);
void sysctl_load(void);

#ifdef __cplusplus
}
#endif

#endif
