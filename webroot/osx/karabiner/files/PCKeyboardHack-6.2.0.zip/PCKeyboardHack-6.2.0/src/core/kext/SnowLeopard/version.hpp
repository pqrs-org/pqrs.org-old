char config_version[] = "6.2.0-SnowLeopard";
