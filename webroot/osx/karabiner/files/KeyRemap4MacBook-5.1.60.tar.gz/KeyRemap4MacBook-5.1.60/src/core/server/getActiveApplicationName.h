#ifndef GETACTIVEAPPLICATIONNAME_H
#define GETACTIVEAPPLICATIONNAME_H

extern "C" {
  void getActiveApplicationName(char *buffer, size_t len);
}

#endif
