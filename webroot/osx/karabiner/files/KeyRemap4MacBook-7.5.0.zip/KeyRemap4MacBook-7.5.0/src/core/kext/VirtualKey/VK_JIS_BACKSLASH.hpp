#ifndef VIRTUALKEY_VK_JIS_BACKSLASH_HPP
#define VIRTUALKEY_VK_JIS_BACKSLASH_HPP

namespace org_pqrs_KeyRemap4MacBook {
  namespace VirtualKey {
    class VK_JIS_BACKSLASH {
    public:
      static bool handle(const Params_KeyboardEventCallBack& params);
    };
  }
}

#endif
