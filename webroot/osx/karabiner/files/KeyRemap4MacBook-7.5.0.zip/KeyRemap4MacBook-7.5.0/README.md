KeyRemap4MacBook
================

KeyRemap4MacBook is a powerful utility for keyboard customization.

* Change the key. (For example, "Change Right Option to Enter")
* Accelerate speed of the key repeat.
* The revival of a lost NumPad key (Fn+jkluio789…)
* Features for more efficient operations. (Emacs Mode, Vi Mode, Mouse Keys Mode, ...)

System requirements
-------------------
Mac OS X 10.6 or higher.

If you require KeyRemap4MacBook for Mac OS X 10.4.x or 10.5.x, use KeyRemap4MacBook 5.1.0.
