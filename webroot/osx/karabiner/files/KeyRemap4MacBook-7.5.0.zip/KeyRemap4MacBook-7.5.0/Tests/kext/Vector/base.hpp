#ifndef BASE_HPP
#define BASE_HPP

#include <stdio.h>

#endif
