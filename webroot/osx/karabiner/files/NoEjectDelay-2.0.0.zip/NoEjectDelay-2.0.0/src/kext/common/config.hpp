#ifndef CONFIG_HPP
#define CONFIG_HPP

namespace org_pqrs_NoEjectDelay {
  void sysctl_register(void);
  void sysctl_unregister(void);
}

#endif
