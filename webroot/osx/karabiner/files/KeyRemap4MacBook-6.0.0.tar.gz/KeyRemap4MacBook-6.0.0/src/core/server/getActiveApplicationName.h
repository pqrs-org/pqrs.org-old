#ifndef GETACTIVEAPPLICATIONNAME_H
#define GETACTIVEAPPLICATIONNAME_H

#ifdef __cplusplus
extern "C" {
#endif

  void getActiveApplicationName(char *buffer, size_t len);

#ifdef __cplusplus
}
#endif

#endif
