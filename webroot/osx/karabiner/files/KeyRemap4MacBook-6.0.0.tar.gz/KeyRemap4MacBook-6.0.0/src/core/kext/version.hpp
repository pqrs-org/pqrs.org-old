char config_version[] = "6.0.0";
